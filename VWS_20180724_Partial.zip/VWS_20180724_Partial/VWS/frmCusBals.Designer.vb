﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCusBals
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSelCust = New System.Windows.Forms.Button
        Me.txtCustcode = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.btnTrnDetails = New System.Windows.Forms.Button
        Me.btnBalances = New System.Windows.Forms.Button
        Me.btnClose = New System.Windows.Forms.Button
        Me.btnTrnMoreDet = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnSelCust
        '
        Me.btnSelCust.Location = New System.Drawing.Point(251, 61)
        Me.btnSelCust.Name = "btnSelCust"
        Me.btnSelCust.Size = New System.Drawing.Size(45, 27)
        Me.btnSelCust.TabIndex = 13
        Me.btnSelCust.Text = "---"
        Me.btnSelCust.UseVisualStyleBackColor = True
        '
        'txtCustcode
        '
        Me.txtCustcode.Location = New System.Drawing.Point(133, 63)
        Me.txtCustcode.Name = "txtCustcode"
        Me.txtCustcode.Size = New System.Drawing.Size(103, 23)
        Me.txtCustcode.TabIndex = 12
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(56, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 16)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Customer"
        '
        'btnTrnDetails
        '
        Me.btnTrnDetails.Location = New System.Drawing.Point(133, 135)
        Me.btnTrnDetails.Name = "btnTrnDetails"
        Me.btnTrnDetails.Size = New System.Drawing.Size(163, 47)
        Me.btnTrnDetails.TabIndex = 14
        Me.btnTrnDetails.Text = "Transactions"
        Me.btnTrnDetails.UseVisualStyleBackColor = True
        '
        'btnBalances
        '
        Me.btnBalances.Location = New System.Drawing.Point(328, 135)
        Me.btnBalances.Name = "btnBalances"
        Me.btnBalances.Size = New System.Drawing.Size(163, 47)
        Me.btnBalances.TabIndex = 15
        Me.btnBalances.Text = "Customer Balances"
        Me.btnBalances.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(385, 216)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(106, 35)
        Me.btnClose.TabIndex = 16
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnTrnMoreDet
        '
        Me.btnTrnMoreDet.Location = New System.Drawing.Point(133, 204)
        Me.btnTrnMoreDet.Name = "btnTrnMoreDet"
        Me.btnTrnMoreDet.Size = New System.Drawing.Size(163, 47)
        Me.btnTrnMoreDet.TabIndex = 17
        Me.btnTrnMoreDet.Text = "Transaction Details"
        Me.btnTrnMoreDet.UseVisualStyleBackColor = True
        '
        'frmCusBals
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(566, 293)
        Me.Controls.Add(Me.btnTrnMoreDet)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnBalances)
        Me.Controls.Add(Me.btnTrnDetails)
        Me.Controls.Add(Me.btnSelCust)
        Me.Controls.Add(Me.txtCustcode)
        Me.Controls.Add(Me.Label4)
        Me.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmCusBals"
        Me.Text = "Pre-Paid Customer Balances"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSelCust As System.Windows.Forms.Button
    Friend WithEvents txtCustcode As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnTrnDetails As System.Windows.Forms.Button
    Friend WithEvents btnBalances As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnTrnMoreDet As System.Windows.Forms.Button
End Class
