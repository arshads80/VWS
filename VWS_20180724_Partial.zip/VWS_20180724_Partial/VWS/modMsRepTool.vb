﻿Module modMsRepTool

    Dim CellPadding As String

    Private Sub MakeReportDir()

        If Not My.Computer.FileSystem.DirectoryExists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports") Then
            My.Computer.FileSystem.CreateDirectory(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports")
        End If

    End Sub

    Public Function msOpenReport(ByVal RptLook As String, ByVal ComNam As String, ByVal RepTitle As String) As String

        Dim fntType As String
        Dim fntSize As String
        Dim CellBorderColor As String
        Dim CellBorderSize As String
        Dim CellHeadBackColor As String
        Dim CellPadding As String

        If RptLook = "1" Then

            fntType = "Calibri;"
            fntSize = "small;"      ' point 12
            CellBorderColor = "#66FFCC dotted;"      ' light blue dotted
            CellBorderSize = "1px "
            CellHeadBackColor = "#99CCFF;"
            CellPadding = "5"

        ElseIf RptLook = "2" Then

            fntType = "Calibri;"
            fntSize = "small;"      ' point 12
            CellBorderColor = "#99FF66 Solid;"      ' light green
            CellBorderSize = "1px "
            CellHeadBackColor = "#99CCFF;"
            CellPadding = "2"

        ElseIf RptLook = "3" Then       ' 0
            fntType = "Verdana;"
            fntSize = "x-small;"        ' point 10
            CellBorderColor = "#DDFFAA Solid;"      ' very light green
            CellBorderSize = "1px "
            CellHeadBackColor = "#99CCFF;"
            CellPadding = "0"

        ElseIf RptLook = "4" Then       ' 0
            fntType = "Calibri;"
            fntSize = "small;"      ' point 12
            CellBorderColor = "#CCCC00 dotted;"      ' light blue dotted
            CellBorderSize = "1px "        '"thin "               
            CellHeadBackColor = "#CCFF99;"
            CellPadding = "4"

        Else   ' 0
            fntType = "Verdana;"
            fntSize = "x-small;"        ' point 10
            CellBorderColor = "#DDFFAA Solid;"    ' very light green
            CellBorderSize = "0.5px "           ' may not be visible
            CellHeadBackColor = "#99CCFF;"
            CellPadding = "1"
        End If

        Dim sr As String
        sr = "<!DOCTYPE html>"   ' PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
        sr = sr & "<html xmlns='http://www.w3.org/1999/xhtml'>"

        sr = sr & "<head>"
        sr = sr & "<meta http-equiv='Content-Language' content='en-us' />"
        sr = sr & "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"
        sr = sr & "<title>Analyst Systems Report</title>"

        sr = sr & "<style type='text/css'>"

        sr = sr & ".stylenormal {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "}"

        sr = sr & ".styletable {"
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "}"

        sr = sr & ".styleCell {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: " & CellBorderSize & CellBorderColor
        sr = sr & "}"

        sr = sr & ".styleCellRight {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: " & CellBorderSize & CellBorderColor
        sr = sr & "		text-align: right;"
        sr = sr & "}"

        sr = sr & ".styleCellCenter {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: " & CellBorderSize & CellBorderColor
        sr = sr & "		text-align: center;"
        sr = sr & "}"

        sr = sr & ".styleCellhead {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "		background-color: " & CellHeadBackColor
        sr = sr & "}"

        sr = sr & ".styleCellheadCenter {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "		text-align: center;"
        sr = sr & "		background-color: " & CellHeadBackColor
        sr = sr & "}"

        sr = sr & ".styleCellheadRight {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "		text-align: right;"
        sr = sr & "		background-color: " & CellHeadBackColor
        sr = sr & "}"

        sr = sr & ".styletitle {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: medium;"
        sr = sr & "}"

        sr = sr & ".styleCellBarcode {"
        sr = sr & "		font-family: 'SKANDATA C39';"
        sr = sr & "		font-size: x-large;"
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "}"

        sr = sr & ".styleComname {"
        sr = sr & "		text-align: center;"
        sr = sr & "		font-size: large;"
        sr = sr & "		font-family: Calibri;"
        sr = sr & "		color: #000080;"
        sr = sr & "}"
        sr = sr & "</style>"

        sr = sr & "</head>"

        sr = sr & "<body>"

        sr = sr & "<p class='styleComname'><strong>" & ComNam & "</strong></p>"
        'sr = sr & "<p class='styletitle'><em>" & RepTitle & "</em></p>"
        sr = sr & "<p class='styletitle'><strong><i>" & RepTitle & "</i></strong></p>"

        Dim fn As String
        fn = ""

        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "yyMMddHHmmss")
        fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSRep" & subFn & ".html"

        msOpenReport = fn

        Try
            My.Computer.FileSystem.WriteAllText(fn, sr, False)
        Catch ex As Exception
            MsgBox("can not create report file" & vbCrLf & ex.Message, MsgBoxStyle.Critical)
            Exit Function
        End Try

        msOpenReport = fn

    End Function


    Public Function msPrepareTableFromList(ByVal hdgList As List(Of String), Optional ByVal colnums As Integer = 2, Optional ByVal tblWidth As String = "50") As String

        ' 2016-06-24

        Dim hdg As String

        hdg = "<table style='width: " & tblWidth & "%' cellpadding='0' cellspacing='0' class='styletable'>"

        Dim i As Integer
        Dim j As Integer

        Do While i < hdgList.Count
            hdg = hdg & "<tr>"
            For j = 1 To colnums
                If i < hdgList.Count Then
                    hdg = hdg & "<td class='styleCell'>" & hdgList(i).ToString & "</td> "
                    i = i + 1
                Else
                    Exit For
                End If
            Next
            hdg = hdg & "</tr>"
        Loop
        

        hdg = hdg & "</table>"

        hdg = "<p class='stylenormal'>" & hdg & "</p>"

        msPrepareTableFromList = hdg

    End Function

    Public Function msPrepareReportAndSummary(ByRef DSrp As DataSet, ByVal rpF As List(Of String), ByVal rpH As List(Of String), ByVal rpT As List(Of String), ByVal CountCaption As String, ByVal SumCaptions As List(Of String), ByVal SumFields As List(Of String), ByVal ShowSrNo As Boolean, ByVal RepFileName As String) As String

        msPrepareReportAndSummary = "Error 160624"

        Dim cnt As Long
        cnt = 0

        Dim sumAmt(6) As Double
        sumAmt(0) = 0
        sumAmt(1) = 0
        sumAmt(2) = 0
        sumAmt(3) = 0
        sumAmt(4) = 0
        sumAmt(5) = 0

        Dim sumDataType(6) As String
        sumDataType(0) = ""
        sumDataType(1) = ""
        sumDataType(2) = ""
        sumDataType(3) = ""
        sumDataType(4) = ""
        sumDataType(5) = ""

        Dim sumLoop As Integer

        Dim sr As String
        sr = ""

        sr = sr & "<table style='width: 100%' cellspacing='0' cellpadding=" & CellPadding & " class='styletable'>"
        sr = sr & "		<thead><tr>"

        If ShowSrNo Then
            sr = sr & "						<td class='styleCellhead'>Sr#</td>"
        End If

        Dim i As Integer

        Dim sNo As Integer
        sNo = 1

        ' make table header
        For i = 0 To rpF.Count - 1
            If rpF(i) = "" Then Exit For ' should not b possible
            If rpT(i) = "c" Or rpT(i) = "bl" Or rpT(i) = "bc" Or rpT(i) = "d" Or rpT(i) = "dt" Then
                sr = sr & "						<td class='styleCellheadCenter'>"
            ElseIf rpT(i) = "n" Or rpT(i) = "f" Then
                sr = sr & "						<td class='styleCellheadRight'>"
            ElseIf rpT(i) = "h" Then    ' hidden no output for calculation only" Then
                sr = sr & "	"

            Else    ' d-date dt-datetime s-string t-text
                sr = sr & "						<td class='styleCellhead'>"
            End If

            If rpH(i) = "" Then
                rpH(i) = rpF(i)
            End If

            sr = sr & rpH(i) & "</td>"

        Next
        sr = sr & "		</tr></thead>"
        '--------------------------------------------

        ' making details
        Dim r As Integer
        Dim tmp As String
        tmp = ""

        Try

            Dim dr As DataRow
            sr = sr & " <tbody>"
            For r = 0 To DSrp.Tables(0).Rows.Count - 1   ' do while read

                If r Mod 10 = 0 Then
                    If sr.Length > 32000 Then
                        My.Computer.FileSystem.WriteAllText(RepFileName, sr, True)
                        sr = ""
                    End If
                End If

                dr = DSrp.Tables(0).Rows(r)
                sr = sr & " <tr>"
                For i = 0 To rpF.Count - 1
                    If i = 0 And ShowSrNo Then
                        sr = sr & "	<td class='styleCellCenter'>" & Val(r + 1) & "</td>"
                    End If
                    If rpF(i) = "" Then Exit For ' should not b possible

                    If rpT(i) = "bl" Then    ' blank column and rpf keeps size of no of spaces

                    Else
                        tmp = dr.Item(rpF(i)).ToString.Trim
                    End If

                    If rpT(i) = "c" Then
                        sr = sr & "						<td class='styleCellCenter'>"
                        If tmp = "" Then tmp = "&nbsp;"
                        sr = sr & tmp

                    ElseIf rpT(i) = "n" Then
                        sr = sr & "						<td class='styleCellRight'>"
                        sr = sr & tmp

                    ElseIf rpT(i) = "f" Then
                        sr = sr & "						<td class='styleCellRight'>"
                        If IsNumeric(tmp) Then
                            tmp = Format(Val(tmp), "#0.00")
                        End If
                        sr = sr & tmp
                    ElseIf rpT(i) = "h" Then    ' hidden not to be printed
                        sr = sr & "	"
                        tmp = " "
                    ElseIf rpT(i) = "d" Then  ' date
                        sr = sr & "						<td class='styleCellCenter'>"
                        If tmp = "" Then
                            sr = sr & "&nbsp;"
                        Else
                            's = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4)
                            sr = sr & Format(DateSerial(Mid(tmp, 1, 4), Mid(tmp, 6, 2), Mid(tmp, 9, 2)), "Short Date")
                        End If

                    ElseIf rpT(i) = "dt" Then  'date time
                        sr = sr & "						<td class='styleCellCenter'>"
                        If tmp = "" Then
                            sr = sr & "&nbsp;"

                        Else    ' 4 digits year
                            sr = sr & Mid(tmp, 9, 2) & "/" & Mid(tmp, 6, 2) & "/" & Mid(tmp, 1, 4) & " " & Mid(tmp, 12, 5) ' w/o seconds & ":" & Mid(d, 11, 2)

                        End If

                    ElseIf rpT(i) = "bc" Then      'barcode
                        sr = sr & "						<td class='styleCellBarcode'>"
                        If tmp = "" Then tmp = "&nbsp;"
                        sr = sr & tmp

                    ElseIf rpT(i) = "si" Then    ' signature image
                        sr = sr & "						<td class='styleCellCenter'>"
                        sr = sr & "<img border='0' src=" & tmp & ">"

                    ElseIf rpT(i) = "sic" Then    ' signature image custom size
                        'If Len(ArType(i)) = 9 Then
                        '    s = s & "<img border='0' src=" & Trim(dr.Item(ArFields(i)).ToString) & " width='" & Mid(ArType(i), 4, 3) & "' height='" & Mid(ArType(i), 7, 3) & "'></td>"
                        'End If

                    ElseIf rpT(i) = "bl" Then   ' blank
                        sr = sr & "						<td class='styleCellCenter'>"
                        'sr = sr & msStr("&nbsp;", rpF(i), "&nbsp;")   ' field will be numeric size of spaces
                        'sr = sr & msStr(" ", rpF(i), " ")   ' field will be numeric size of spaces
                        sr = sr & "&nbsp;"

                    Else    '  s-string t-text
                        sr = sr & "						<td class='styleCell'>"
                        If tmp = "" Then
                            sr = sr & "&nbsp;"
                        ElseIf IsNumeric(tmp) Then
                            sr = sr & tmp & "&nbsp;"
                        ElseIf IsDate(tmp) Then
                            sr = sr & tmp & "&nbsp;"
                        Else
                            sr = sr & tmp
                        End If
                    End If

                    sr = sr & "</td>"

                    ' check for sum field
                    For sumLoop = 0 To SumFields.Count - 1
                        If sumLoop > 5 Then Exit For
                        If SumFields(sumLoop) <> "" Then
                            If rpF(i) = SumFields(sumLoop) Then
                                sumAmt(sumLoop) = sumAmt(sumLoop) + dr.Item(rpF(i))
                                sumDataType(sumLoop) = rpT(i)
                            End If
                        End If
                    Next

                Next
                sr = sr & " </tr>"
                cnt = cnt + 1

            Next
            sr = sr & " </tbody>"

        Catch ex As Exception

            msPrepareReportAndSummary = "Error: 150424 Reports generation" & vbCrLf & ex.Message
            'MsgBox("Error: 150424 Reports generation" & vbCrLf & ex.Message, MsgBoxStyle.Critical)
            Exit Function
        End Try

        ' table footer

        sr = sr & "</table>"

        sr = sr & "<p>"


        ' summary table-------------------------

        Dim ftpair As New List(Of String)


        If CountCaption <> "" Then
            ftpair.Add(CountCaption)
            ftpair.Add(DSrp.Tables(0).Rows.Count)
            sumLoop = 1
        End If


        For sumLoop = 0 To SumFields.Count - 1

            If sumLoop > 5 Then Exit For
            If SumFields(sumLoop) <> "" Then
                ftpair.Add(SumCaptions(sumLoop))
                ftpair.Add(sumAmt(sumLoop))
            End If
        Next

        sr = sr & msPrepareTableFromList(ftpair)

        ' write footer
        sr = sr & "<p>&nbsp;</p>"

        Try
            My.Computer.FileSystem.WriteAllText(RepFileName, sr, True)
        Catch ex As Exception
            msPrepareReportAndSummary = "Error: 160624 Writing Report File" & vbCrLf & ex.Message
            Exit Function
        End Try

        msPrepareReportAndSummary = ""

    End Function

    Public Function msgetNewParagraph() As String

        msgetNewParagraph = "<p>&nbsp;</p>"

    End Function

    Public Function msCloseReport() As String

        Dim sr As String
        sr = "</body>"
        sr = sr & "</html>"
        msCloseReport = sr

    End Function


End Module
