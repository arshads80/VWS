﻿Public Class frmOtherMasters

    Private FormMode As FormModes

    Dim curRecNo As Integer


    Dim tblName As String
    Dim fldCode As String
    Dim fldName As String

    Dim retKey As String

    Public Function ShowDialog_OtherMasters(ByVal prmtblName As String, ByVal prmfldCode As String, ByVal prmfldName As String) As String

        tblName = prmtblName.ToLower

        fldCode = prmfldCode

        fldName = prmfldName

        If tblName.ToLower = "tblsource" Then
            Text = "Source / Transporter"
            Me.lblCodeCaption.Text = "Source Code"
            Me.lblNameCaption.Text = "Source Name"
        ElseIf tblName.ToLower = "tbllocations" Then
            Text = "Locations / Destinations"
            Me.lblCodeCaption.Text = "Location Code"
            Me.lblNameCaption.Text = "Location Name"
        ElseIf tblName.ToLower = "tblsites" Then
            Text = "Site"
            Me.lblCodeCaption.Text = "Site Code"
            Me.lblNameCaption.Text = "Site Name"
        Else
            ' not possible
        End If


        ShowDialog()

        ShowDialog_OtherMasters = retKey


    End Function



    Private Sub frmOtherMasters_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If arUserAccess(enUAcs.Edit_Other_Masters) = 1 Then
            Me.bnEdit.Visible = True
        Else
            Me.bnEdit.Visible = False
        End If

        If arUserAccess(enUAcs.Delete_Other_Masters) = "1" Then
            Me.bnDeleteItem.Visible = True
        Else
            Me.bnDeleteItem.Visible = False
        End If

        DisableEdits()
        PopulateGrid()



    End Sub

    Private Sub msWriteLM(ByVal LmData As String, Optional ByVal rgbh As String = "0")

        Dim obj As Control
        obj = Me.txtLM

        If TypeOf obj Is TextBox Then
            If CType(obj, TextBox).Multiline Then
                Me.txtLM.Text = LmData & vbCrLf & Me.txtLM.Text
            Else
                Me.txtLM.Text = LmData
            End If

        Else
            Me.txtLM.Text = LmData
        End If

        'msDoEvents()

        Dim pColor As Color
        Select Case rgbh.ToLower
            Case "r"
                pColor = Color.Crimson
            Case "b"    ' blue
                pColor = Color.Blue
            Case "g"
                pColor = Color.Green
            Case "h"  ' highlight
                pColor = Color.DarkBlue
            Case Else
                pColor = Color.Black
        End Select


        txtLM.ForeColor = pColor

        If rgbh = "h" Then
            txtLM.BackColor = Color.Yellow
        Else
            txtLM.BackColor = Color.WhiteSmoke
        End If

    End Sub


    Private Sub DisableEdits()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls    ' Me.pnlMatMaster.Controls
            If TypeOf ctr Is TextBox Then
                CType(ctr, TextBox).ReadOnly = True
                CType(ctr, TextBox).Text = Trim(ctr.Text)
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Enabled = False
            ElseIf TypeOf ctr Is ComboBox Then
                CType(ctr, ComboBox).Enabled = False
            End If
        Next

        ' disable navigation controls

        Me.GroupBoxSearch.Enabled = True
        Me.DataGridView1.Enabled = True
        Me.bnMoveFirstItem.Enabled = True
        Me.txtSearch.ReadOnly = False

        Me.bnMoveFirstItem.Enabled = True
        Me.bnMovePreviousItem.Enabled = True
        Me.bnMoveNextItem.Enabled = True
        Me.bnMoveLastItem.Enabled = True
        Me.bnAddNewItem.Enabled = True
        Me.bnCancel.Enabled = False
        Me.bnDeleteItem.Enabled = True
        Me.bnEdit.Enabled = True
        Me.bnRefresh.Enabled = True
        Me.bnSave.Enabled = False

        FormMode = FormModes.SearchMode


    End Sub

    Private Sub EnableEdits()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls
            If TypeOf ctr Is TextBox Then
                CType(ctr, TextBox).ReadOnly = False
                CType(ctr, TextBox).Text = Trim(ctr.Text)
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Enabled = True
            ElseIf TypeOf ctr Is ComboBox Then
                CType(ctr, ComboBox).Enabled = True
            End If
        Next

        ' disable navigation controls

        Me.GroupBoxSearch.Enabled = False
        Me.DataGridView1.Enabled = False
        Me.bnMoveFirstItem.Enabled = False
        Me.txtSearch.ReadOnly = True

        Me.bnMoveFirstItem.Enabled = False
        Me.bnMovePreviousItem.Enabled = False
        Me.bnMoveNextItem.Enabled = False
        Me.bnMoveLastItem.Enabled = False
        Me.bnAddNewItem.Enabled = False
        Me.bnCancel.Enabled = True
        Me.bnDeleteItem.Enabled = False
        Me.bnEdit.Enabled = False
        Me.bnRefresh.Enabled = False
        Me.bnSave.Enabled = True

        '           Me.txtDisable.ReadOnly = True

    End Sub


    Private Sub ClearForm()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls
            If TypeOf ctr Is TextBox Then
                ctr.Text = ""
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Checked = False
            End If
        Next

        Me.lblCode.Text = ""

    End Sub

    Private Sub PopulateGrid()

        Dim webEr As String
        Dim s As String
        Dim ser As String
        Dim wh As String
        wh = ""

        If Me.txtSearch.Text.Trim <> "" Then
            ser = Me.txtSearch.Text.Trim
            ser = ser.Replace(" ", "% ")
            wh = wh & fldName & " Like '%" & ser & "%' "
            wh = wh & " or " & fldCode & " = '" & ser & "' "

        End If

        webEr = ""

        s = "Select top 100 * from " & tblName & " where " & fldCode & " > '0' "

        If wh <> "" Then
            s = s & " and (" & wh & ")"
            s = s & " order by " & fldName
        Else
            s = s & " order by LastUpdateAt DESC"
        End If

        Dim ds As New DataSet
        Dim a As String
        a = mslCons.WebAuthCode
        Try

            ds = msWebGetDS(s, a)

            If a = mslCons.WebAuthCode Or IsNumeric(a) Then
                Dim f As Font
                f = New Font("Verdana", 8, FontStyle.Regular, GraphicsUnit.Point)

                DataGridView1.Font = f

                DataGridView1.DataSource = ds
                DataGridView1.DataMember = ds.Tables(0).TableName

                'If pOpenfTime Then
                '    Dim i As Integer
                '    For i = 0 To DataGridView1.Columns.Count - 1
                '        DataGridView1.Columns(i).Visible = False
                '    Next
                '    DataGridView1.Columns("ProdID").Visible = True
                '    DataGridView1.Columns("ProdCode").Visible = True
                '    DataGridView1.Columns("ProductName").Visible = True
                '    pOpenfTime = False
                'End If

                DataGridView1.AutoResizeColumns()

                Me.bnCountItem.Text = "of " & DataGridView1.RowCount


            Else

                MsgBox("error 150206 " & a, MsgBoxStyle.Critical)

            End If

        Catch ex As Exception
            MsgBox("Error: 150409 " & "Populate Grid " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Function FormNotValid() As Boolean

        FormNotValid = True

        If Me.txtName.Text = "" Then
            msWriteLM("Enter Name!", "r")
            Me.txtName.Focus()
            Exit Function
        End If

        FormNotValid = False

    End Function

    Private Sub txtSearch_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown

        If e.KeyCode = Keys.Down Then
            Me.DataGridView1.Focus()
        End If

    End Sub


    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        PopulateGrid()

    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSearch.TextChanged

        If Me.txtSearch.Text = "" Or Me.txtSearch.Text.Length > 2 Then
            PopulateGrid()
        End If

    End Sub


    Private Sub PopulateForm()

        If Me.DataGridView1.RowCount <= 0 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim enm As String

        enm = DataGridView1.CurrentRow.Cells(fldCode).Value

        Dim s As String
        s = "Select * from " & tblName & " where " & fldCode & " = '" & enm & "'"

        Dim ds As DataSet

        Try

            ds = msWebGetDsFt(s)

            If ds.Tables.Count < 1 Then Exit Sub
            If ds.Tables(0).Rows.Count < 1 Then Exit Sub


            Dim dr As DataRow
            dr = ds.Tables(0).Rows(0)

            Me.txtName.Text = dr(fldName)
            Me.lblCode.Text = dr(fldCode)

            Me.bnPositionItem.Text = DataGridView1.CurrentRow.Index + 1


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)

        End Try

    End Sub

    Private Sub DataGridView1_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEnter

        If DataGridView1.RowCount < 1 Then Exit Sub

        If DataGridView1.CurrentRow Is Nothing Then Exit Sub
        '  If popProcess Then Exit Sub

        PopulateForm()

    End Sub


    Private Sub bnAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnAddNewItem.Click

        FormMode = FormModes.AddMode
        EnableEdits()
        ClearForm()
        'Me.txtDisable.Text = 0
        Me.txtName.Focus()

    End Sub

    Private Sub bnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnEdit.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        FormMode = FormModes.EditMode
        EnableEdits()

        Me.txtName.Focus()

    End Sub

    Private Sub bnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnCancel.Click

        DisableEdits()
        PopulateForm()

    End Sub


    Private Sub bnDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnDeleteItem.Click

        If FormMode = FormModes.NormalMode Or FormMode = FormModes.SearchMode Then
            ' ok
        Else
            Exit Sub
        End If

        If Me.DataGridView1.RowCount < 1 Then Exit Sub

        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        If Me.DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("Select a record to edit ....", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim envnum As String
        envnum = DataGridView1.CurrentRow.Cells(fldCode).Value

        If MsgBox("Are you sure you want to delete selected record from the database" & vbCrLf & "Code: " & envnum, MsgBoxStyle.DefaultButton2 + MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim ds As DataSet
        Dim ww As String
        Try
            ww = mslCons.WebAuthCode
            ds = msWebGetDS("Select top 1 TicketNo from tblWeighing where " & fldCode & " = '" & envnum & "'", ww)
            If ds.Tables(0).Rows.Count > 0 Then
                MsgBox("There are transactions for this " & fldName & vbCrLf & "Record can not be deleted", MsgBoxStyle.Exclamation)
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox("Error 150404 : " & ex.Message & vbCrLf & "Record can not be deleted", MsgBoxStyle.Critical)
            Exit Sub
        End Try

        Dim s As String
        s = "Delete from " & tblName & " where " & fldCode & " = '" & envnum & "'"

        Dim a As String
        Dim w As String
        w = mslCons.WebAuthCode

        a = msWebProcessCommand(s, w)

        If IsNumeric(a) Then

            'MsgBox(a & " records deleted", MsgBoxStyle.Exclamation)
            msWriteLM(a & " record/s deleted", "r")
            PopulateGrid()

        Else
            MsgBox("Error " & vbCrLf & a, MsgBoxStyle.Critical)

        End If


    End Sub


    Private Sub bnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnSave.Click

        If FormNotValid() Then Exit Sub


        '''''''  using update statment
        Dim ArF As New List(Of String)
        Dim ArV As New List(Of String)
        Dim ArT As New List(Of String)

        ' following is required for multiple table updates or update in loop
        ArF.Clear()
        ArV.Clear()
        ArT.Clear()
        '==================================


        If FormMode = FormModes.AddMode Then
            ArF.Add(fldCode)
            If Me.lblCode.Text = "" Then
                Me.lblCode.Text = getNewFldCode(Me.txtName.Text)
            End If
            ArV.Add(Me.lblCode.Text.ToUpper)
            ArT.Add("s")  ' or S

        End If

        '=============================


        ArF.Add("LastUpdateAt")
        ArV.Add("server time")             ' Format(Date.Now, "yyyy-MM-dd HH:mm"))
        ArT.Add("st")    ' st server time


        ArF.Add(fldName)
        ArV.Add(txtName.Text.ToUpper)
        ArT.Add("s")

        ArF.Add("SyncFlag")
        If FormMode = FormModes.EditMode Then
            ArV.Add("2")
        Else
            ArV.Add("1")        ' addmode  1    record synced = 0 
        End If
        ArT.Add("n")


        Dim ww As String
        ww = mslCons.WebAuthcode

        '=============================

        Dim a As String

        Try
            Me.bnSave.Enabled = False
            'a = msrv.getlictoolcode(arF.ToArray, arV.ToArray, arT.ToArray, arH.ToArray, Me.txtEmail.Text)
            If FormMode = FormModes.EditMode Then
                Dim wcls As String

                wcls = fldCode & " = '" & Me.DataGridView1.CurrentRow.Cells(fldCode).Value & "'"

                a = msWebUpdateArrayListInDB(tblName, ArF.ToArray, ArV.ToArray, ArT.ToArray, wcls, ww)
                If IsNumeric(a) Then
                    MsgBox(a & " Record/s updated", MsgBoxStyle.Information)
                End If

            Else
                a = msWebInsertRecIntoDb(tblName, ArF.ToArray, ArV.ToArray, ArT.ToArray, ww)
            End If

            If a <> "1" Then
                MsgBox("Error 508112 unable to save record" & vbCrLf & a, MsgBoxStyle.Critical)
                Me.bnSave.Enabled = True
                Exit Sub
            End If

            If FormMode = FormModes.AddMode Then

                Me.txtSearch.Text = ""

            End If

            'ClearForm()

            PopulateGrid()

            If FormMode = FormModes.EditMode Then
                If curRecNo < DataGridView1.RowCount Then
                    'DataGridView1.Rows(curRecNo).Selected = True
                    DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
                End If
            End If

            DisableEdits()

        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical)
            Exit Sub

        End Try


    End Sub

    Private Function getNewFldCode(ByVal mname As String) As String

        getNewFldCode = ""

        Dim fldnum As String

        If tblName.ToLower = "tblsource" Then
            fldnum = "Sounum"
        ElseIf tblName.ToLower = "tbllocations" Then
            fldnum = "Locnum"
        ElseIf tblName.ToLower = "tblsites" Then
            fldnum = "Sitenum"
        Else
            ' not possible
            fldnum = ""
        End If


        Dim fc As String    ' first char
        Dim s As String
        fc = UCase(Mid(mname, 1, 1))

        If fc < "A" Or fc > "Z" Then
            fc = "#"
        End If

        Dim l As Long
        Dim sStr As String
        sStr = "select Alpha, " & fldnum & " from tblNextCode where Alpha = '" & fc & "'"

        Dim ds As DataSet

        Dim ww As String

        Try

            ww = mslCons.WebAuthcode
            ds = msWebGetDS(sStr, ww)

            Dim dr As DataRow

            dr = ds.Tables(0).Rows(0)

            '------------
            If dr IsNot Nothing Then
                l = CLng(dr(fldnum))
                l = l + 1
                If fc = "#" Then
                    If l < 10000 Then
                        s = msStr(CStr(l), 4)
                    Else
                        s = l
                    End If
                Else
                    If l < 1000 Then
                        s = fc & msStr(CStr(l), 3)
                    Else
                        s = fc & l
                    End If
                End If

                s = mslv.WeighingSiteCode & s

                ww = mslCons.WebAuthcode

                sStr = "Update tblnextcode set " & fldnum & " = " & l & " where Alpha = '" & fc & "'"

                Dim a As String
                a = msWebProcessCommand(sStr, ww)

                If IsNumeric(a) Then
                    If Val(a) > 0 Then
                        getNewFldCode = s
                    Else
                        MsgBox("Can not update next code", MsgBoxStyle.Critical, "Update Error")
                    End If

                End If

            End If
            ';--------------

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try


    End Function


    Private Sub bnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnClose.Click

        Me.Close()

    End Sub

    Private Sub bnMoveNextItem_Click(sender As Object, e As EventArgs) Handles bnMoveNextItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        If curRecNo < DataGridView1.RowCount - 1 Then
            curRecNo = curRecNo + 1
            DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
        End If

    End Sub


    Private Sub bnMoveLastItem_Click(sender As Object, e As EventArgs) Handles bnMoveLastItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub

        curRecNo = DataGridView1.RowCount - 1
        DataGridView1.CurrentCell = DataGridView1(0, curRecNo)

    End Sub

    Private Sub bnMovePreviousItem_Click(sender As Object, e As EventArgs) Handles bnMovePreviousItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        If curRecNo > 0 Then
            curRecNo = curRecNo - 1
            DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
        End If


    End Sub

    Private Sub bnMoveFirstItem_Click(sender As Object, e As EventArgs) Handles bnMoveFirstItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        curRecNo = 0
        DataGridView1.CurrentCell = DataGridView1(0, curRecNo)

    End Sub

End Class