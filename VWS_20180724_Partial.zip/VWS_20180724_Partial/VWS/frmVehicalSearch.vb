﻿Public Class frmVehicalSearch


    Dim selectedcode As String
    Dim vhCode As String


    Public Function ShowDialog_VehicleSearch(ByVal prmVehCode As String, ByVal ShowSelect As Boolean, ByVal Showfile As Boolean) As String

        'msrv.Url = mslv.webServiceURL

        selectedcode = prmVehCode
        vhCode = ""

        Me.btnSelect.Visible = ShowSelect

        If arUserAccess(enUAcs.Open_Vehicle_file) = "1" Then
            Me.btnFile.Visible = Showfile
        Else
            Me.btnFile.Visible = False
        End If

        ShowDialog()

        ShowDialog_VehicleSearch = vhCode

    End Function


    Private Sub btnClose_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

    Private Sub frmSelVehical_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        populateGrid()

        If selectedcode <> "" Then

            ' select item in db grid 
            Dim a As Integer
            a = msFindGridRowByValue(DataGridView1, "VehCode", selectedcode)

            If a > 0 Then
                DataGridView1.CurrentCell = DataGridView1.Item(1, a)
            End If

        End If

        Me.txtSearch.Focus()

    End Sub

    Private Sub PopulateGrid()

        Dim webEr As String
        Dim s As String
        Dim ser As String
        Dim wh As String
        wh = ""

        If Me.txtSearch.Text.Trim <> "" Then
            ser = Me.txtSearch.Text.Trim
            ser = ser.Replace(" ", " %")
            wh = wh & "VehName Like '%" & ser & "%'"
            wh = wh & " or VehCode Like '" & ser & "%'"
        End If

        webEr = ""

        s = "Select top 100 VehCode, VehName, VehTareWt, VehWtRemark, VehID "
        s = s & " from tblVehicles "
        s = s & " where VehID > 0 "

        If wh <> "" Then
            s = s & " and (" & wh & ")"
            s = s & " order by VehName"
        ElseIf selectedcode <> "" Then
            wh = "VehCode >= '" & selectedcode & "'"
            s = s & " and (" & wh & ")"
            s = s & " order by VehCode "
        Else
            s = s & " order by LastUpdateAt DESC"    ' PartyID DESC"
        End If

        Dim ds As New DataSet
        Dim a As String
        a = mslCons.WebAuthCode
        Try

            ds = msWebGetDS(s, a)

            If a = mslCons.WebAuthCode Or IsNumeric(a) Then

                DataGridView1.DataSource = ds
                DataGridView1.DataMember = ds.Tables(0).TableName

                DataGridView1.AutoResizeColumns()

            Else

                MsgBox("error 150206 " & a, MsgBoxStyle.Critical)

            End If

        Catch ex As Exception

            MsgBox("Error: 150117 " & "Populate Grid " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub txtSearch_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles txtSearch.KeyDown

        If e.KeyCode = Keys.Down Then
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearch.TextChanged

        ' If Me.txtSearch.Text = "" Or Me.txtSearch.Text.Length > 2 Then    '  (Me.txtSearch.Text.Length > 3 And Me.txtSearch.Text.Length Mod 2 = 0) Then
        PopulateGrid()
        'End If

    End Sub

    Private Sub btnRef_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRef.Click

        Me.txtSearch.Text = ""
        PopulateGrid()

    End Sub

    Private Sub btnSelect_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSelect.Click

        If Me.DataGridView1.RowCount <= 0 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim enm As String
        enm = DataGridView1.CurrentRow.Cells("VehCode").Value

        If enm = "" Then Exit Sub

        vhcode = enm

        Me.Close()

    End Sub


    Private Sub btnFile_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnFile.Click

        Dim skey As String
        skey = ""

        'If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow IsNot Nothing Then

            skey = DataGridView1.CurrentRow.Cells("VehCode").Value

        End If

        Dim FRMPT As New frmVehicles

        skey = FRMPT.ShowDialog_Vehicles(skey)
        Me.txtSearch.Text = skey

        msDoEvents()

        PopulateGrid()

    End Sub

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        PopulateGrid()

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellContentDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentDoubleClick

        btnSelect.PerformClick()


    End Sub

    Private Sub DataGridView1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DataGridView1.KeyDown

        If e.KeyCode = Keys.Enter Then
            btnSelect.PerformClick()

        End If

    End Sub

End Class