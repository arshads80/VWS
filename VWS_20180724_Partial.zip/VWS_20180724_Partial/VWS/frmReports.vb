Imports System.Resources
Imports System.Runtime.InteropServices


Public Class frmReports
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbPrint As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbClose As System.Windows.Forms.ToolStripButton
    Friend WithEvents tscbOpenWith As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents MSWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MSExcelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents tsbFind As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbSendReport As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReports))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.tsbPrint = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbFind = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.tscbOpenWith = New System.Windows.Forms.ToolStripDropDownButton()
        Me.MSWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSExcelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbSendReport = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbClose = New System.Windows.Forms.ToolStripButton()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.MediumTurquoise
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(48, 48)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbPrint, Me.ToolStripSeparator1, Me.tsbFind, Me.ToolStripSeparator3, Me.tscbOpenWith, Me.ToolStripSeparator2, Me.tsbSendReport, Me.ToolStripSeparator4, Me.tsbClose})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1180, 70)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "Reporting Toolbar"
        '
        'tsbPrint
        '
        Me.tsbPrint.Image = CType(resources.GetObject("tsbPrint.Image"), System.Drawing.Image)
        Me.tsbPrint.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPrint.Name = "tsbPrint"
        Me.tsbPrint.Size = New System.Drawing.Size(52, 67)
        Me.tsbPrint.Text = "Print"
        Me.tsbPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 70)
        '
        'tsbFind
        '
        Me.tsbFind.Image = CType(resources.GetObject("tsbFind.Image"), System.Drawing.Image)
        Me.tsbFind.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbFind.Name = "tsbFind"
        Me.tsbFind.Size = New System.Drawing.Size(52, 67)
        Me.tsbFind.Text = "Find"
        Me.tsbFind.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 70)
        '
        'tscbOpenWith
        '
        Me.tscbOpenWith.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MSWordToolStripMenuItem, Me.MSExcelToolStripMenuItem})
        Me.tscbOpenWith.Image = CType(resources.GetObject("tscbOpenWith.Image"), System.Drawing.Image)
        Me.tscbOpenWith.Name = "tscbOpenWith"
        Me.tscbOpenWith.Size = New System.Drawing.Size(77, 67)
        Me.tscbOpenWith.Text = "Open With"
        Me.tscbOpenWith.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'MSWordToolStripMenuItem
        '
        Me.MSWordToolStripMenuItem.BackColor = System.Drawing.Color.MediumTurquoise
        Me.MSWordToolStripMenuItem.Image = CType(resources.GetObject("MSWordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MSWordToolStripMenuItem.Name = "MSWordToolStripMenuItem"
        Me.MSWordToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.MSWordToolStripMenuItem.Text = "MS Word"
        '
        'MSExcelToolStripMenuItem
        '
        Me.MSExcelToolStripMenuItem.BackColor = System.Drawing.Color.MediumTurquoise
        Me.MSExcelToolStripMenuItem.Image = CType(resources.GetObject("MSExcelToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MSExcelToolStripMenuItem.Name = "MSExcelToolStripMenuItem"
        Me.MSExcelToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.MSExcelToolStripMenuItem.Text = "MS Excel"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 70)
        '
        'tsbSendReport
        '
        Me.tsbSendReport.Image = CType(resources.GetObject("tsbSendReport.Image"), System.Drawing.Image)
        Me.tsbSendReport.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSendReport.Name = "tsbSendReport"
        Me.tsbSendReport.Size = New System.Drawing.Size(52, 67)
        Me.tsbSendReport.Text = "Email"
        Me.tsbSendReport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsbSendReport.Visible = False
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 70)
        '
        'tsbClose
        '
        Me.tsbClose.Image = CType(resources.GetObject("tsbClose.Image"), System.Drawing.Image)
        Me.tsbClose.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbClose.Name = "tsbClose"
        Me.tsbClose.Size = New System.Drawing.Size(52, 67)
        Me.tsbClose.Text = "Exit"
        Me.tsbClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 70)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(1180, 437)
        Me.WebBrowser1.TabIndex = 1
        '
        'frmReports
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1180, 507)
        Me.ControlBox = False
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmReports"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Vehicle Weighing System Report"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Dim RFileName As String
    Dim ReportSubject As String

    Public Overloads Sub ShowDialog(ByVal repFileName As String, Optional ByVal prmReportSubject As String = "Report - Mailing Simplified")

        RFileName = repFileName
        ReportSubject = prmReportSubject
        Me.Text = ReportSubject
        ShowDialog()

    End Sub

    Public Overloads Sub Show(ByVal repFileName As String, Optional ByVal prmReportSubject As String = "Report - Mailing Simplified")

        Me.StartPosition = FormStartPosition.CenterScreen
        RFileName = repFileName
        ReportSubject = prmReportSubject
        Me.Text = ReportSubject
        Show()

    End Sub


    Private Sub tsbPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbPrint.Click

        Me.WebBrowser1.Focus()

        System.Windows.Forms.SendKeys.SendWait("^a")

        'SendKeys("^a", True)
        Application.DoEvents()
        SendKeys.SendWait("^p")
        Application.DoEvents()


    End Sub

    Private Sub MSWordToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSWordToolStripMenuItem.Click

        Dim ptW(30) As String
        Dim ptE(30) As String

        ptE(0) = "C:\Program Files\Microsoft Office\OFFICE12\EXCEL.EXE"
        ptE(1) = "C:\Program Files\Microsoft Office\OFFICE11\EXCEL.EXE"
        ptE(2) = "C:\Program Files\Microsoft Office\OFFICE10\EXCEL.EXE"
        ptE(3) = "C:\Program Files (x86)\Microsoft Office\OFFICE12\EXCEL.EXE"
        ptE(4) = "C:\Program Files (x86)\Microsoft Office\OFFICE11\EXCEL.EXE"
        ptE(5) = "C:\Program Files (x86)\Microsoft Office\OFFICE10\EXCEL.EXE"
        ptE(6) = "C:\Program Files\Microsoft Office\OFFICE14\EXCEL.EXE"
        ptE(7) = "C:\Program Files (x86)\Microsoft Office\OFFICE14\EXCEL.EXE"

        ptE(8) = "D:\Program Files\Microsoft Office\OFFICE12\EXCEL.EXE"
        ptE(9) = "D:\Program Files\Microsoft Office\OFFICE11\EXCEL.EXE"
        ptE(10) = "D:\Program Files\Microsoft Office\OFFICE10\EXCEL.EXE"
        ptE(11) = "D:\Program Files (x86)\Microsoft Office\OFFICE12\EXCEL.EXE"
        ptE(12) = "D:\Program Files (x86)\Microsoft Office\OFFICE11\EXCEL.EXE"
        ptE(13) = "D:\Program Files (x86)\Microsoft Office\OFFICE10\EXCEL.EXE"
        ptE(14) = "D:\Program Files\Microsoft Office\OFFICE14\EXCEL.EXE"
        ptE(15) = "D:\Program Files (x86)\Microsoft Office\OFFICE14\EXCEL.EXE"

        ptE(16) = "E:\Program Files\Microsoft Office\OFFICE12\EXCEL.EXE"
        ptE(17) = "E:\Program Files\Microsoft Office\OFFICE11\EXCEL.EXE"
        ptE(18) = "E:\Program Files\Microsoft Office\OFFICE10\EXCEL.EXE"
        ptE(19) = "E:\Program Files (x86)\Microsoft Office\OFFICE12\EXCEL.EXE"
        ptE(20) = "E:\Program Files (x86)\Microsoft Office\OFFICE11\EXCEL.EXE"
        ptE(21) = "E:\Program Files (x86)\Microsoft Office\OFFICE10\EXCEL.EXE"
        ptE(22) = "E:\Program Files\Microsoft Office\OFFICE14\EXCEL.EXE"
        ptE(23) = "E:\Program Files (x86)\Microsoft Office\OFFICE14\EXCEL.EXE"


        ptW(0) = "C:\Program Files\Microsoft Office\OFFICE12\WINWORD.EXE"
        ptW(1) = "C:\Program Files\Microsoft Office\OFFICE11\WINWORD.EXE"
        ptW(2) = "C:\Program Files\Microsoft Office\OFFICE10\WINWORD.EXE"
        ptW(3) = "C:\Program Files (x86)\Microsoft Office\OFFICE12\WINWORD.EXE"
        ptW(4) = "C:\Program Files (x86)\Microsoft Office\OFFICE11\WINWORD.EXE"
        ptW(5) = "C:\Program Files (x86)\Microsoft Office\OFFICE10\WINWORD.EXE"
        ptW(6) = "C:\Program Files\Microsoft Office\OFFICE14\WINWORD.EXE"
        ptW(7) = "C:\Program Files (x86)\Microsoft Office\OFFICE14\WINWORD.EXE"

        ptW(8) = "D:\Program Files\Microsoft Office\OFFICE12\WINWORD.EXE"
        ptW(9) = "D:\Program Files\Microsoft Office\OFFICE11\WINWORD.EXE"
        ptW(10) = "D:\Program Files\Microsoft Office\OFFICE10\WINWORD.EXE"
        ptW(11) = "D:\Program Files (x86)\Microsoft Office\OFFICE12\WINWORD.EXE"
        ptW(12) = "D:\Program Files (x86)\Microsoft Office\OFFICE11\WINWORD.EXE"
        ptW(13) = "D:\Program Files (x86)\Microsoft Office\OFFICE10\WINWORD.EXE"
        ptW(14) = "D:\Program Files\Microsoft Office\OFFICE14\WINWORD.EXE"
        ptW(15) = "D:\Program Files (x86)\Microsoft Office\OFFICE14\WINWORD.EXE"

        ptW(16) = "E:\Program Files\Microsoft Office\OFFICE12\WINWORD.EXE"
        ptW(17) = "E:\Program Files\Microsoft Office\OFFICE11\WINWORD.EXE"
        ptW(18) = "E:\Program Files\Microsoft Office\OFFICE10\WINWORD.EXE"
        ptW(19) = "E:\Program Files (x86)\Microsoft Office\OFFICE12\WINWORD.EXE"
        ptW(20) = "E:\Program Files (x86)\Microsoft Office\OFFICE11\WINWORD.EXE"
        ptW(21) = "E:\Program Files (x86)\Microsoft Office\OFFICE10\WINWORD.EXE"
        ptW(22) = "E:\Program Files\Microsoft Office\OFFICE14\WINWORD.EXE"
        ptW(23) = "E:\Program Files (x86)\Microsoft Office\OFFICE14\WINWORD.EXE"

        ' check path
        'Try
        '    If Dir(Sysvars.WordPath) = "" Then
        '        Dim ik As Integer
        '        For ik = 0 To 23
        '            If Dir(ptW(ik)) <> "" Then
        '                Sysvars.WordPath = ptW(ik)
        '                SaveSetting("CallSpy", "Settings", "WordPath", Sysvars.WordPath)
        '                Exit For
        '            End If
        '        Next
        '    End If
        'Catch ex As Exception

        'End Try

        Dim f As String
        Dim f2 As String

        f = ""
        Dim fs As New frmStatus
        fs.Show("Opening Microsoft Word, Please wait ...")
        Try

            f = Replace(RFileName, ".html", "")
            f = f & ".doc"

            f2 = Dir(f)
            If f2 <> "" Then
                Kill(f)

            End If

            f = Replace(RFileName, ".html", "")
            f = f & ".doc"

            FileCopy(RFileName, f)

            ' to check here
            '    Shell(Sysvars.WordPath & " " & Chr(34) & f & Chr(34))      ' "c:\MyReport.doc")
            Process.Start(f)

        Catch ex As Exception
            MsgBox("Err: 2002" & vbCrLf & ex.Message, MsgBoxStyle.Critical)   ' Emoticons.ErrorIcon)

        End Try

        Dim i As Int32
        For i = 1 To 100000
            System.Windows.Forms.Application.DoEvents()
        Next
        fs.Close()

    End Sub

    Private Sub tsbClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbClose.Click

        Try
            My.Computer.FileSystem.DeleteFile(RFileName)

        Catch ex As Exception

        End Try
        
        Me.Close()

    End Sub

    Private Sub frmReports_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        'Try
        '    My.Computer.FileSystem.DeleteFile(RFileName)
        'Catch ex As Exception

        'End Try


    End Sub

    Private Sub frmReports_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.WebBrowser1.Navigate(RFileName)

    End Sub

    Private Sub MSExcelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSExcelToolStripMenuItem.Click


        Dim f As String
        f = ""

        Dim f2 As String

        Dim fs As New frmStatus
        fs.Show("Opening Microsoft Excel, Please wait ...")

        Try


            f = Replace(RFileName, ".html", "")
            f = f & ".xls"

            f2 = Dir(f)
            If f2 <> "" Then
                Kill(f)

            End If

            f = Replace(RFileName, ".html", "")
            f = f & ".xls"


            FileCopy(RFileName, f)   ' "c:\MyReport.xls")

            ' to check here
            'Shell(Sysvars.ExcelPath & " " & Chr(34) & f & Chr(34))  ' "c:\MyReport.xls")
            Process.Start(f)

        Catch ex As Exception
            MsgBox("Err: 2001" & ex.Message, MsgBoxStyle.Critical)  ' Emoticons.ErrorIcon)

        End Try

        Dim i As Int32
        For i = 1 To 100000
            System.Windows.Forms.Application.DoEvents()
        Next
        fs.Close()


    End Sub


    

    
    Private Sub tsbFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbFind.Click
        Me.WebBrowser1.Focus()

        System.Windows.Forms.SendKeys.SendWait("^f")

        'SendKeys("^a", True)
        Application.DoEvents()


    End Sub

    Private Sub tsbSendReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbSendReport.Click

        ' Dim frmEm As New frmEmailReport
        'frmEm.ShowDialog(RFileName, ReportSubject)

    End Sub

End Class
