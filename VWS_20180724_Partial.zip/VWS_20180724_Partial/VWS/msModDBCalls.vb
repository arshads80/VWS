﻿Imports System.Net.Mail
Imports System.Data
Imports System.Data.OleDb

Module msModdbCalls

    Structure usrdef

        Dim usrid As String
        Dim usrpw As String
        Dim usremail As String

        Dim comname As String
        Dim conname As String
        Dim telno As String
        Dim mobno As String
        Dim custemail As String
        Dim custBank As String

        Dim olddongcode As String
        Dim newdongcode As String

        Dim oldlics As Integer
        Dim newlics As Integer


    End Structure

    Public donginfo As usrdef

    Public Const webAuthCode As String = "1234"

    Public Function msLetFly(ByVal prmPostTo As String, ByVal prmsub As String, ByVal prmbdy As String, ByVal prmPostCc1 As String, ByVal prmPostCc2 As String) As String

        ' returns 0 on success

        'If msIsInternetOk("www.google.ae") Then
        '    ' ok
        'Else
        '    If msIsInternetOk("www.google.com") Then

        '    Else
        '        msRadiate = 1    ' can not reach intenet
        '        Exit Function
        '    End If

        'End If

        Dim m As MailMessage = New MailMessage
        With m

            .From = New MailAddress("Analyst International<info@wpsuae.com>")
            .ReplyTo = New MailAddress("info@wpsuae.com")
            .To.Add(New MailAddress(prmPostTo))
            If prmPostCc1 <> "" Then
                .CC.Add(New MailAddress(prmPostCc1))
            End If
            If prmPostCc2 <> "" Then
                .CC.Add(New MailAddress(prmPostCc2))
            End If
            .Bcc.Add(New MailAddress("info@wpsuae.com"))

            .Body = prmbdy

            .IsBodyHtml = True
            .Subject = prmsub
            .Priority = MailPriority.Normal          'Note you could add a lot more Options and also could add them to the Sub.
        End With

        Dim smtp As New System.Net.Mail.SmtpClient

        smtp.Credentials = New System.Net.NetworkCredential(Convert.ToString("info@aijunction.com"), "quicknotes26")

        'smtp.Credentials = New System.Net.NetworkCredential(Convert.ToString("info@wpsuae.com"), "hamraz122")

        'smtp.Host = "sendmail.brinkster.com"
        'smtp.Host = "mail.aijunction.com"
        'smtp.Host = "aijunction.com"
        'smtp.Host = "wpsuae.com"

        smtp.Host = "localhost"
        smtp.Port = 25

        'smtp.EnableSsl = True

        Try
            smtp.Send(m)

            msLetFly = "0"

            'Response.Redirect("http://www.wpsuae.com/confirmation.aspx")

        Catch ex As Exception
            msLetFly = ex.ToString

        End Try

    End Function

#Region "oledb"

    Public Enum ConnectType

        Access2003 = 1
        Access2007 = 2
        Excel2003 = 3
        Excel2007 = 4
        odbc = 5
        Sqlcleint = 6
        SqlOledb = 7
        Access = 8
        FromRegFile = 9

    End Enum

    Public Function msgetConnectionStringValue(ByVal ConType As ConnectType, ByVal prmdbPath As String, ByVal prmUpw As String, ByVal prmUid As String, ByVal prmCatalogOrSheetName As String, Optional ByVal prmServerName As String = "") As String

        Dim tmp As String

        If ConType = ConnectType.Access2003 Then  ' access 2003
            msgetConnectionStringValue = "Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password=" & prmUpw & ";Data Source=" & prmdbPath
        ElseIf ConType = ConnectType.Access2007 Then   ' contype = 3 or 0   access 2007
            msgetConnectionStringValue = "Provider=Microsoft.ACE.OLEDB.12.0;Jet OLEDB:Database Password=" & prmUpw & ";Data Source=" & prmdbPath
        ElseIf ConType = ConnectType.Excel2003 Then
            msgetConnectionStringValue = "" ' to set later when reuired
        ElseIf ConType = ConnectType.Excel2007 Then
            msgetConnectionStringValue = "" ' to set later when reuired
        ElseIf ConType = ConnectType.Sqlcleint Then
            If prmUpw = "" Then
                ' sql client connection windows authentication
                msgetConnectionStringValue = "Data Source=" & prmdbPath & ";Initial Catalog=" & prmCatalogOrSheetName & ";Integrated Security=True;"   'User Id=" & dbUserID & ";Password=" & dbPw & ";"
            Else
                ' sql client connection sql user authentication
                'msgetConnectionStringValue = "Data Source=" & prmdbPath & ";Initial Catalog=dbMCB_NPP;Persist Security Info=True;User Id=" & prmUid & ";Password=" & prmUpw & ";"
                msgetConnectionStringValue = "Data Source=" & prmdbPath & ";Initial Catalog=" & prmCatalogOrSheetName & ";Persist Security Info=True;User Id=" & prmUid & ";Password=" & prmUpw & ";"
            End If
            '=========END sqlclient connection from a file
        ElseIf ConType = ConnectType.SqlOledb Then
            If prmUpw = "" Then
                msgetConnectionStringValue = "Provider=SQLOLEDB;Data Source=" & prmServerName & ";Initial Catalog=" & prmCatalogOrSheetName & ";Integrated Security=SSPI;"
            Else
                msgetConnectionStringValue = "Provider=SQLOLEDB;Data Source=" & prmServerName & ";Initial Catalog=" & prmCatalogOrSheetName & ";User ID=" & prmUid & ";Password=" & prmUpw & ";"
            End If
        ElseIf ConType = ConnectType.FromRegFile Then
            tmp = msReadRegXML("DBConStr", "")
            If tmp = "" Then
                tmp = "Provider=SQLOLEDB;Data Source=MSPC2013\SQLEXPRESS;Initial Catalog=dbMICRJobSheets;Integrated Security=SSPI;"
                msWriteRegXML("DBConStr", tmp)
            End If
            msgetConnectionStringValue = tmp
        Else
            msgetConnectionStringValue = "Provider=Microsoft.ACE.OLEDB.12.0;Jet OLEDB:Database Password=" & prmUpw & ";Data Source=" & prmdbPath
        End If

    End Function

    Public Function msOpenDbConnection(ByRef dbCn As OleDbConnection, Optional ByRef prmErr As String = "") As Boolean

        ' for oledb

        'If mslv.SqlConStr = "" Then
        'msSetConnectionStringValue()
        'End If

        Dim SqlConStr As String
        ' run local
        'SqlConStr = msgetConnectionStringValue(ConnectType.SqlOledb, "", "besta_x3#", "functionadmin", "wpsuae_dbfunction", "wpsuae.com")

        ' run on server
        'SqlConStr = msgetConnectionStringValue(ConnectType.SqlOledb, "", "besta_x3#", "functionadmin", "wpsuae_dbfunction", "(local)")
        'SqlConStr = msgetConnectionStringValue(ConnectType.Access2007, "dbMICRjobs.accdb", "", "", "", "")
        SqlConStr = msgetConnectionStringValue(ConnectType.FromRegFile, "", "", "", "")

        '  MsgBox(SqlConStr)
        SqlConStr = mslv.OleconStr

        Try
            dbCn = New OleDbConnection
            dbCn.ConnectionString = SqlConStr
            dbCn.Open()
            msOpenDbConnection = True

        Catch e As Exception

            prmErr = e.Message

            msOpenDbConnection = False

            If InStr("Err: 2010 " & e.Message, "Not a valid password") > 0 Then
                'End
                Exit Try
            End If

            MsgBox(e.Message, MsgBoxStyle.Critical)
            End

            'Dim frmG As New frmStatus               ' ms0813
            'frmG.Show("Err: 2000 " & "Database Connection Error")

            msOpenDbConnection = False

            'Dim i As Long
            'For i = 0 To 50000
            '    msDoEvents()
            'Next
            'frmG.Close()

            'If MsgBox("Data base connection Error" & vbCrLf & e.Message, MsgBoxStyle.Critical + MsgBoxStyle.AbortRetryIgnore, "ERROR") = MsgBoxResult.Abort Then
            '    'End
            'End If

        End Try

    End Function

    Public Function msWebGetDS(ByVal prmStrSql As String, ByRef prmWeber As String) As DataSet

        Dim prmds As New DataSet

        msWebGetDS = prmds

        If prmWeber <> webAuthCode Then   ' web service authorization

            prmWeber = "Invalid"
            Exit Function
        End If

        prmWeber = ""

        Dim dbCn As New OleDbConnection

        If Not msOpenDbConnection(dbCn, prmWeber) Then

            Exit Function
        End If

        prmWeber = ""

        Dim apt As OleDbDataAdapter

        Try
            apt = New OleDbDataAdapter(prmStrSql, dbCn)

            apt.FillSchema(prmds, SchemaType.Source, "tblA")

            apt.Fill(prmds, "tblA")

            prmWeber = prmds.Tables(0).Rows.Count

            msWebGetDS = prmds

        Catch ex As Exception

            prmWeber = "Error: ws150116: " & ex.Message

        End Try

        dbCn.Close()


    End Function

    Public Function msFillDS(ByVal prmStrSql As String, ByRef prmDS As DataSet) As String

        msFillDS = ""

        Dim dbCn As New OleDbConnection

        If Not msOpenDbConnection(dbCn) Then
            msFillDS = "DB error"
            Exit Function
        End If


        Dim apt As OleDbDataAdapter

        Try
            apt = New OleDbDataAdapter(prmStrSql, dbCn)

            apt.FillSchema(prmDS, SchemaType.Source, "tblA")

            apt.Fill(prmDS, "tblA")

            msFillDS = prmDS.Tables.Count

            '  MsgBox(prmDS.Tables(0).Rows.Count)

        Catch ex As Exception

            msFillDS = "Error: ws150116: " & ex.Message

        End Try

        dbCn.Close()


    End Function

    Public Function msWebProcessCommand(ByVal prmStr As String, ByRef prmWeber As String) As String


        msWebProcessCommand = ""

        If prmWeber <> webAuthCode Then   ' web service authorization
            prmWeber = "Invalid"
            Exit Function
        End If

        prmWeber = ""

        Dim dbCn20150206 As New OleDbConnection

        If Not msOpenDbConnection(dbCn20150206, prmWeber) Then
            Exit Function
        End If


        Try


            Dim cmSQL As OleDbCommand
            Dim a As Integer

            cmSQL = New OleDbCommand(prmStr, dbCn20150206)
            a = cmSQL.ExecuteNonQuery()

            msWebProcessCommand = a

            ' Close and Clean up objects

            cmSQL.Dispose()
            'dbCn1109221311.Close()


        Catch ex As OleDbException
            'msMessagebox("Err: 110922309 " & ex.Message, Emoticons.ErrorIcon, "Database Error", , , )
            'MsgBox(e.Message, MsgBoxStyle.Critical, "Database error")

            prmWeber = ex.Message

        Catch ex As Exception
            'msMessagebox("Err: 1109221310 " & ex.Message, Emoticons.ErrorIcon, "Error")
            'MsgBox(e.Message, MsgBoxStyle.Critical, "Error")

            prmWeber = ex.Message

        End Try

        dbCn20150206.Close()


    End Function


    Public Function msGetFieldValue(ByVal prmStrSql As String, Optional ByVal PrmDbCn110407 As OleDbConnection = Nothing, Optional ByVal FieldName As String = "", Optional ByRef prmRetErr As String = "") As String

        Dim mustclosedbcon As Boolean
        mustclosedbcon = False

        msGetFieldValue = ""
        If PrmDbCn110407 Is Nothing Then
            If Not msOpenDbConnection(PrmDbCn110407) Then Exit Function
            mustclosedbcon = True
        End If

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader

        Try

            cm = New OleDbCommand(prmStrSql, PrmDbCn110407)
            dr = cm.ExecuteReader()
            If dr.Read Then

                If FieldName = "" Then
                    msGetFieldValue = dr.Item(0).ToString()
                Else
                    msGetFieldValue = dr.Item(FieldName).ToString()
                End If

            End If
            dr.Close()

        Catch ex As Exception
            'MessageBox.Show("Err: 110407 " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            prmRetErr = ex.Message

        End Try

        If mustclosedbcon Then
            PrmDbCn110407.Close()
        End If

    End Function

    Public Function msUpdateFlagInDb(ByVal prmtbl As String, ByVal prmFld As String, ByVal prmVal As String, ByVal prmWhere As String, Optional ByVal prmDbCn As OleDbConnection = Nothing) As String

        ' 2013-06-09
        ' updates one field in db table numeric or string enclosed by single qoute
        'prmval must be numeric or should be enclosed with 'single qoute if string

        Dim mustClosedbcon As Boolean
        mustClosedbcon = False

        msUpdateFlagInDb = "DB Error"

        If prmFld = "" Or prmtbl = "" Then
            msUpdateFlagInDb = "incorrect parameters"
            Exit Function
        End If

        Dim s As String

        s = "Update " & prmtbl & " Set "
        s = s & " [" & prmFld & "] = "
        s = s & " " & prmVal


        If prmWhere <> "" Then
            s = s & " where " & prmWhere
        End If

        If prmDbCn Is Nothing Then
            If Not msOpenDbConnection(prmDbCn) Then
                msUpdateFlagInDb = "Database connection Error"
                Exit Function
            End If
            mustClosedbcon = True
        End If

        Dim n As Integer
        Dim cm As OleDbCommand
        Try
            cm = New OleDbCommand(s, prmDbCn)
            n = cm.ExecuteNonQuery
            msUpdateFlagInDb = n

        Catch ex As Exception
            msUpdateFlagInDb = ex.Message

        End Try

        If mustClosedbcon Then
            prmDbCn.Close()
        End If


    End Function


    Public Function msUpdate3FieldsInDb(ByVal prmtbl As String, ByVal prmFld1 As String, ByVal prmVal1 As String, ByVal prmFld2 As String, ByVal prmVal2 As String, ByVal prmFld3 As String, ByVal prmVal3 As String, ByVal prmWhere As String, Optional ByVal prmDbCn As OleDbConnection = Nothing) As String

        ' 2013-06-09
        ' updates one field in db table numeric or string enclosed by single qoute
        'prmval must be numeric or should be enclosed with 'single qoute if string

        Dim mustClosedbcon As Boolean
        mustClosedbcon = False

        msUpdate3FieldsInDb = "DB Error"

        If prmFld1 = "" Or prmtbl = "" Then
            msUpdate3FieldsInDb = "incorrect parameters"
            Exit Function
        End If

        Dim s As String

        s = "Update " & prmtbl & " Set "
        s = s & " [" & prmFld1 & "] = "
        s = s & " " & prmVal1
        If prmFld2 >= "A" Then
            s = s & ", [" & prmFld2 & "] = "
            s = s & " " & prmVal2
        End If
        If prmFld3 >= "A" Then
            s = s & ", [" & prmFld3 & "] = "
            s = s & " " & prmVal3
        End If

        If prmWhere <> "" Then
            s = s & " where " & prmWhere
        End If

        If prmDbCn Is Nothing Then
            If Not msOpenDbConnection(prmDbCn) Then
                msUpdate3FieldsInDb = "Database connection Error"
                Exit Function
            End If
            mustClosedbcon = True
        End If


        Dim n As Integer
        Dim cm As OleDbCommand
        Try
            cm = New OleDbCommand(s, prmDbCn)
            n = cm.ExecuteNonQuery
            msUpdate3FieldsInDb = n

        Catch ex As Exception
            msUpdate3FieldsInDb = "Error 130609 " & ex.Message

        End Try

        If mustClosedbcon Then
            prmDbCn.Close()
        End If


    End Function


    Public Function msInsert3FieldsInDb(ByVal prmtbl As String, ByVal prmFld1 As String, ByVal prmVal1 As String, ByVal prmFld2 As String, ByVal prmVal2 As String, ByVal prmFld3 As String, ByVal prmVal3 As String, Optional ByVal prmDbCn As OleDbConnection = Nothing) As String

        ' 2013-11-06
        ' insert upto 3 fields in db table numeric or string enclosed by single qoute
        'prmval must be numeric or should be enclosed with 'single qoute if string

        Dim mustClosedbcon As Boolean
        mustClosedbcon = False

        msInsert3FieldsInDb = "DB Error"

        If prmFld1 = "" Or prmtbl = "" Then
            msInsert3FieldsInDb = "incorrect parameters"
            Exit Function
        End If

        Dim s As String

        s = "Insert Into " & prmtbl & "("
        s = s & " [" & prmFld1 & "] "
        If prmFld2 >= "A" Then
            s = s & ", [" & prmFld2 & "] "
        End If
        If prmFld3 >= "A" Then
            s = s & ", [" & prmFld3 & "] "
        End If
        s = s & " ) Values ( "
        s = s & prmVal1
        If prmFld2 >= "A" Then
            s = s & ", " & prmVal2 & " "
        End If
        If prmFld3 >= "A" Then
            s = s & ", " & prmVal3 & " "
        End If

        s = s & ")"

        If prmDbCn Is Nothing Then
            If Not msOpenDbConnection(prmDbCn) Then
                msInsert3FieldsInDb = "Database connection Error"
                Exit Function
            End If
            mustClosedbcon = True
        End If


        Dim n As Integer
        Dim cm As OleDbCommand
        Try
            cm = New OleDbCommand(s, prmDbCn)
            n = cm.ExecuteNonQuery
            msInsert3FieldsInDb = n

        Catch ex As Exception
            msInsert3FieldsInDb = "Error 131106 " & ex.Message

        End Try

        If mustClosedbcon Then
            prmDbCn.Close()
        End If


    End Function

    Public Function msInsertArrayListInDB(ByVal prmTableName As String, ByVal prmFields As List(Of String), ByVal prmValues As List(Of String), ByVal prmTypes As List(Of String), Optional ByVal prmDbCng211130 As OleDbConnection = Nothing) As String

        ' 2013-05-25

        ' Preparation to call this function

        'Dim ArF As New List(Of String)
        'Dim ArV As New List(Of String)
        'Dim ArT As New List(Of String)
        'ArF.Add("")
        'ArV.Add(a)   
        'ArT.Add("s")
        '--------------------------------------------

        Dim mustClosedbcon As Boolean
        mustClosedbcon = False

        msInsertArrayListInDB = "DB Error"

        If prmFields.Count <> prmValues.Count Then
            msInsertArrayListInDB = "Fields and Values count not matching"
            Exit Function
        End If

        Dim s As String
        Dim I As Integer

        s = "Insert Into " & prmTableName & " ( "

        For I = 0 To prmFields.Count - 1
            If prmFields(i) <> "" Then
                If I <> 0 Then
                    s = s & ", "
                End If
                s = s & "[" & prmFields(i) & "]"
            End If
        Next

        s = s & " ) Values ( "

        For I = 0 To prmFields.Count - 1
            If prmFields(i) <> "" Then
                If I <> 0 Then
                    s = s & ", "
                End If

                If prmTypes(I).ToLower = "n" Then
                    If IsNumeric(prmValues(I)) Then
                        s = s & prmValues(I)
                    Else
                        s = s & "0"
                    End If

                ElseIf prmTypes(I).ToLower = "sd" Then         ' server date
                    s = s & " '" & Format(Date.Today, "yyyy-MM-dd") & "' "
                ElseIf prmTypes(I).ToLower = "st" Then         ' server time
                    s = s & " '" & Format(Date.Now, "yyyy-MM-dd HH:mm:ss") & "' "
                Else
                    prmValues(i) = Replace(prmValues(i), "'", "`")
                    prmValues(i) = Replace(prmValues(i), """", " ")
                    s = s & "'" & prmValues(i) & "'"
                End If

            End If
        Next
        s = s & " ) "



        '        MsgBox(s)


        If prmDbCng211130 Is Nothing Then
            If Not msOpenDbConnection(prmDbCng211130) Then
                msInsertArrayListInDB = "Database connection Error"
                Exit Function
            End If
            mustClosedbcon = True
        End If

        Dim cm As OleDbCommand
        Try
            cm = New OleDbCommand(s, prmDbCng211130)
            I = cm.ExecuteNonQuery
            msInsertArrayListInDB = I
        Catch ex As Exception
            msInsertArrayListInDB = ex.Message
            My.Computer.Clipboard.SetText(s)

        End Try

        If mustClosedbcon Then
            prmDbCng211130.Close()
        End If

    End Function

    Public Function msUpdateArrayListInDB(ByVal prmTableName As String, ByVal prmFields As List(Of String), ByVal prmValues As List(Of String), ByVal prmTypes As List(Of String), ByVal prmWhereExp As String, Optional ByVal prmDbCng211132 As OleDbConnection = Nothing) As String

        ' 2013-05-25

        ' Preparation to call this function

        'Dim ArF As New List(Of String)
        'Dim ArV As New List(Of String)
        'Dim ArT As New List(Of String)

        'ArF.Add("")
        'ArV.Add(a)
        'ArT.Add("N")  ' or S

        '--------------------------------------------

        Dim mustClosedbcon As Boolean
        mustClosedbcon = False

        msUpdateArrayListInDB = "DB Error"

        If prmFields.Count <> prmValues.Count Then
            msUpdateArrayListInDB = "Fields and Values count not matching"
            Exit Function
        End If

        If prmFields.Count <> prmTypes.Count Then
            msUpdateArrayListInDB = "Fields and Types count not matching"
            Exit Function
        End If

        Dim s As String
        Dim i As Integer

        s = "Update " & prmTableName & " Set "
        For i = 0 To prmFields.Count - 1
            If i <> 0 Then
                s = s & ","
            End If
            If prmFields(i) <> "" Then
                s = s & " [" & prmFields(i) & "] = "
            End If
            If prmTypes(i).ToLower = "n" Then
                If IsNumeric(prmValues(i)) Then
                    s = s & " " & prmValues(i)
                Else
                    s = s & " 0"
                End If

            ElseIf prmTypes(i).ToLower = "sd" Then         ' server date
                s = s & " '" & Format(Date.Today, "yyyy-MM-dd") & "' "
            ElseIf prmTypes(i).ToLower = "st" Then         ' server time
                s = s & " '" & Format(Date.Now, "yyyy-MM-dd HH:mm:ss") & "' "
            Else
                prmValues(i) = Replace(prmValues(i), "'", "`")
                prmValues(i) = Replace(prmValues(i), """", " ")
                s = s & " '" & prmValues(i) & "'"
            End If

        Next

        If prmWhereExp <> "" Then
            s = s & " where " & prmWhereExp
        End If

        If prmDbCng211132 Is Nothing Then
            If Not msOpenDbConnection(prmDbCng211132) Then
                msUpdateArrayListInDB = "Database connection Error"
                Exit Function
            End If
            mustClosedbcon = True
        End If


        Dim n As Integer
        Dim cm As OleDbCommand
        Try
            cm = New OleDbCommand(s, prmDbCng211132)
            n = cm.ExecuteNonQuery
            msUpdateArrayListInDB = n

        Catch ex As Exception
            msUpdateArrayListInDB = ex.Message

        End Try

        If mustClosedbcon Then
            prmDbCng211132.Close()
        End If



    End Function


#End Region

#Region "General"

    Private Function getencarray2014() As String()

        Dim ar(1024) As String


        ar(1) = "AC"
        ar(2) = "47"
        ar(3) = "V4"
        ar(4) = "WG"
        ar(5) = "7N"
        ar(6) = "KJ"
        ar(7) = "3D"
        ar(8) = "FJ"
        ar(9) = "ZM"
        ar(10) = "TE"
        ar(11) = "BN"
        ar(12) = "7G"
        ar(13) = "ER"
        ar(14) = "K8"
        ar(15) = "RN"
        ar(16) = "4B"
        ar(17) = "Z6"
        ar(18) = "9B"
        ar(19) = "LU"
        ar(20) = "PB"
        ar(21) = "66"
        ar(22) = "5F"
        ar(23) = "2D"
        ar(24) = "HG"
        ar(25) = "WX"
        ar(26) = "MF"
        ar(27) = "4T"
        ar(28) = "LE"
        ar(29) = "RK"
        ar(30) = "GZ"
        ar(31) = "3N"
        ar(32) = "YP"
        ar(33) = "D8"
        ar(34) = "H6"
        ar(35) = "VP"
        ar(36) = "5L"
        ar(37) = "24"
        ar(38) = "7D"
        ar(39) = "ZX"
        ar(40) = "K5"
        ar(41) = "N2"
        ar(42) = "LT"
        ar(43) = "WZ"
        ar(44) = "ZG"
        ar(45) = "EB"
        ar(46) = "VD"
        ar(47) = "TN"
        ar(48) = "Y4"
        ar(49) = "Y2"
        ar(50) = "H5"
        ar(51) = "74"
        ar(52) = "4Y"
        ar(53) = "UP"
        ar(54) = "EK"
        ar(55) = "6B"
        ar(56) = "WV"
        ar(57) = "68"
        ar(58) = "CY"
        ar(59) = "UY"
        ar(60) = "M2"
        ar(61) = "FN"
        ar(62) = "HZ"
        ar(63) = "3Z"
        ar(64) = "HH"
        ar(65) = "5N"
        ar(66) = "K2"
        ar(67) = "LG"
        ar(68) = "VB"
        ar(69) = "6Y"
        ar(70) = "UE"
        ar(71) = "JJ"
        ar(72) = "WK"
        ar(73) = "WC"
        ar(74) = "LK"
        ar(75) = "7L"
        ar(76) = "UM"
        ar(77) = "NN"
        ar(78) = "X5"
        ar(79) = "LA"
        ar(80) = "6A"
        ar(81) = "SP"
        ar(82) = "QN"
        ar(83) = "KV"
        ar(84) = "MN"
        ar(85) = "Z2"
        ar(86) = "WR"
        ar(87) = "DJ"
        ar(88) = "F7"
        ar(89) = "52"
        ar(90) = "FZ"
        ar(91) = "CM"
        ar(92) = "DT"
        ar(93) = "XK"
        ar(94) = "BP"
        ar(95) = "CH"
        ar(96) = "G3"
        ar(97) = "EX"
        ar(98) = "W7"
        ar(99) = "WJ"
        ar(100) = "88"
        ar(101) = "XB"
        ar(102) = "9W"
        ar(103) = "GA"
        ar(104) = "A2"
        ar(105) = "V9"
        ar(106) = "JN"
        ar(107) = "JC"
        ar(108) = "JR"
        ar(109) = "5G"
        ar(110) = "25"
        ar(111) = "X4"
        ar(112) = "48"
        ar(113) = "ZU"
        ar(114) = "R5"
        ar(115) = "8E"
        ar(116) = "Z8"
        ar(117) = "AF"
        ar(118) = "2J"
        ar(119) = "B5"
        ar(120) = "BC"
        ar(121) = "6Z"
        ar(122) = "JG"
        ar(123) = "CF"
        ar(124) = "34"
        ar(125) = "QQ"
        ar(126) = "P5"
        ar(127) = "A8"
        ar(128) = "JK"
        ar(129) = "X8"
        ar(130) = "AT"
        ar(131) = "SU"
        ar(132) = "TK"
        ar(133) = "N9"
        ar(134) = "WY"
        ar(135) = "WU"
        ar(136) = "7T"
        ar(137) = "S2"
        ar(138) = "XZ"
        ar(139) = "KF"
        ar(140) = "XR"
        ar(141) = "R8"
        ar(142) = "TM"
        ar(143) = "HE"
        ar(144) = "EE"
        ar(145) = "2U"
        ar(146) = "LN"
        ar(147) = "RY"
        ar(148) = "NL"
        ar(149) = "6C"
        ar(150) = "5E"
        ar(151) = "XM"
        ar(152) = "XG"
        ar(153) = "DE"
        ar(154) = "A9"
        ar(155) = "LR"
        ar(156) = "WD"
        ar(157) = "RG"
        ar(158) = "RD"
        ar(159) = "NW"
        ar(160) = "VH"
        ar(161) = "JF"
        ar(162) = "C3"
        ar(163) = "93"
        ar(164) = "LF"
        ar(165) = "CK"
        ar(166) = "28"
        ar(167) = "VL"
        ar(168) = "9A"
        ar(169) = "Y8"
        ar(170) = "XA"
        ar(171) = "D2"
        ar(172) = "9Z"
        ar(173) = "NY"
        ar(174) = "7J"
        ar(175) = "RA"
        ar(176) = "HT"
        ar(177) = "U7"
        ar(178) = "AQ"
        ar(179) = "ZJ"
        ar(180) = "N7"
        ar(181) = "TW"
        ar(182) = "XC"
        ar(183) = "VA"
        ar(184) = "KD"
        ar(185) = "6U"
        ar(186) = "XS"
        ar(187) = "2V"
        ar(188) = "L7"
        ar(189) = "FL"
        ar(190) = "YZ"
        ar(191) = "6N"
        ar(192) = "FV"
        ar(193) = "L3"
        ar(194) = "84"
        ar(195) = "YR"
        ar(196) = "GW"
        ar(197) = "QZ"
        ar(198) = "SH"
        ar(199) = "2F"
        ar(200) = "LS"
        ar(201) = "CC"
        ar(202) = "U3"
        ar(203) = "FP"
        ar(204) = "AP"
        ar(205) = "QV"
        ar(206) = "85"
        ar(207) = "P2"
        ar(208) = "6S"
        ar(209) = "86"
        ar(210) = "4U"
        ar(211) = "7H"
        ar(212) = "DS"
        ar(213) = "WP"
        ar(214) = "L5"
        ar(215) = "7P"
        ar(216) = "BL"
        ar(217) = "YK"
        ar(218) = "TX"
        ar(219) = "NH"
        ar(220) = "82"
        ar(221) = "FW"
        ar(222) = "LB"
        ar(223) = "PN"
        ar(224) = "Q5"
        ar(225) = "7V"
        ar(226) = "HR"
        ar(227) = "58"
        ar(228) = "W3"
        ar(229) = "3V"
        ar(230) = "QK"
        ar(231) = "SW"
        ar(232) = "3E"
        ar(233) = "DH"
        ar(234) = "P6"
        ar(235) = "5A"
        ar(236) = "F5"
        ar(237) = "83"
        ar(238) = "3C"
        ar(239) = "4X"
        ar(240) = "SM"
        ar(241) = "B2"
        ar(242) = "AW"
        ar(243) = "SV"
        ar(244) = "P4"
        ar(245) = "CN"
        ar(246) = "J4"
        ar(247) = "9S"
        ar(248) = "DU"
        ar(249) = "K9"
        ar(250) = "FT"
        ar(251) = "EY"
        ar(252) = "X3"
        ar(253) = "XX"
        ar(254) = "R9"
        ar(255) = "U5"
        ar(256) = "TH"
        ar(257) = "3G"
        ar(258) = "FK"
        ar(259) = "F4"
        ar(260) = "M5"
        ar(261) = "NC"
        ar(262) = "GM"
        ar(263) = "5C"
        ar(264) = "MT"
        ar(265) = "FF"
        ar(266) = "YY"
        ar(267) = "SX"
        ar(268) = "RV"
        ar(269) = "8F"
        ar(270) = "6K"
        ar(271) = "YN"
        ar(272) = "KL"
        ar(273) = "HD"
        ar(274) = "TR"
        ar(275) = "H8"
        ar(276) = "T4"
        ar(277) = "3S"
        ar(278) = "2A"
        ar(279) = "8R"
        ar(280) = "YU"
        ar(281) = "9V"
        ar(282) = "KR"
        ar(283) = "CJ"
        ar(284) = "57"
        ar(285) = "3Q"
        ar(286) = "3W"
        ar(287) = "2C"
        ar(288) = "C6"
        ar(289) = "38"
        ar(290) = "8H"
        ar(291) = "9M"
        ar(292) = "7C"
        ar(293) = "V5"
        ar(294) = "UG"
        ar(295) = "BK"
        ar(296) = "K3"
        ar(297) = "79"
        ar(298) = "SZ"
        ar(299) = "HV"
        ar(300) = "MC"
        ar(301) = "B9"
        ar(302) = "SK"
        ar(303) = "TL"
        ar(304) = "7Q"
        ar(305) = "M4"
        ar(306) = "7A"
        ar(307) = "KU"
        ar(308) = "7B"
        ar(309) = "9H"
        ar(310) = "J2"
        ar(311) = "4A"
        ar(312) = "EU"
        ar(313) = "6E"
        ar(314) = "A6"
        ar(315) = "EP"
        ar(316) = "T7"
        ar(317) = "QD"
        ar(318) = "CB"
        ar(319) = "PJ"
        ar(320) = "75"
        ar(321) = "KW"
        ar(322) = "EA"
        ar(323) = "VV"
        ar(324) = "35"
        ar(325) = "YM"
        ar(326) = "AN"
        ar(327) = "TG"
        ar(328) = "NP"
        ar(329) = "Z3"
        ar(330) = "5U"
        ar(331) = "8L"
        ar(332) = "MK"
        ar(333) = "YQ"
        ar(334) = "2S"
        ar(335) = "4H"
        ar(336) = "NQ"
        ar(337) = "FB"
        ar(338) = "YS"
        ar(339) = "BY"
        ar(340) = "3Y"
        ar(341) = "8V"
        ar(342) = "QL"
        ar(343) = "AH"
        ar(344) = "H2"
        ar(345) = "TU"
        ar(346) = "M7"
        ar(347) = "W4"
        ar(348) = "UT"
        ar(349) = "BT"
        ar(350) = "G4"
        ar(351) = "DD"
        ar(352) = "WF"
        ar(353) = "TT"
        ar(354) = "ND"
        ar(355) = "3T"
        ar(356) = "6F"
        ar(357) = "GF"
        ar(358) = "XT"
        ar(359) = "JA"
        ar(360) = "L9"
        ar(361) = "2H"
        ar(362) = "5P"
        ar(363) = "89"
        ar(364) = "GS"
        ar(365) = "Q4"
        ar(366) = "KT"
        ar(367) = "PU"
        ar(368) = "RQ"
        ar(369) = "LL"
        ar(370) = "B6"
        ar(371) = "UQ"
        ar(372) = "YB"
        ar(373) = "RT"
        ar(374) = "QM"
        ar(375) = "RM"
        ar(376) = "9G"
        ar(377) = "4S"
        ar(378) = "6J"
        ar(379) = "G9"
        ar(380) = "6X"
        ar(381) = "G7"
        ar(382) = "L6"
        ar(383) = "YD"
        ar(384) = "6Q"
        ar(385) = "CA"
        ar(386) = "4R"
        ar(387) = "W2"
        ar(388) = "YV"
        ar(389) = "E9"
        ar(390) = "9T"
        ar(391) = "6H"
        ar(392) = "UH"
        ar(393) = "L8"
        ar(394) = "Q6"
        ar(395) = "CQ"
        ar(396) = "GQ"
        ar(397) = "QE"
        ar(398) = "U8"
        ar(399) = "NE"
        ar(400) = "J5"
        ar(401) = "36"
        ar(402) = "YF"
        ar(403) = "S7"
        ar(404) = "NK"
        ar(405) = "SF"
        ar(406) = "YW"
        ar(407) = "DG"
        ar(408) = "RZ"
        ar(409) = "U6"
        ar(410) = "EM"
        ar(411) = "GJ"
        ar(412) = "2L"
        ar(413) = "PZ"
        ar(414) = "KP"
        ar(415) = "5D"
        ar(416) = "KX"
        ar(417) = "PP"
        ar(418) = "HF"
        ar(419) = "Y6"
        ar(420) = "SJ"
        ar(421) = "YH"
        ar(422) = "Q8"
        ar(423) = "96"
        ar(424) = "FQ"
        ar(425) = "MV"
        ar(426) = "WQ"
        ar(427) = "A5"
        ar(428) = "S4"
        ar(429) = "AE"
        ar(430) = "8S"
        ar(431) = "BF"
        ar(432) = "9F"
        ar(433) = "SD"
        ar(434) = "LP"
        ar(435) = "TP"
        ar(436) = "Y5"
        ar(437) = "D6"
        ar(438) = "TB"
        ar(439) = "3P"
        ar(440) = "VU"
        ar(441) = "7X"
        ar(442) = "GC"
        ar(443) = "72"
        ar(444) = "FG"
        ar(445) = "2T"
        ar(446) = "TJ"
        ar(447) = "H9"
        ar(448) = "ZV"
        ar(449) = "XJ"
        ar(450) = "Y7"
        ar(451) = "53"
        ar(452) = "KB"
        ar(453) = "ED"
        ar(454) = "FA"
        ar(455) = "YT"
        ar(456) = "N8"
        ar(457) = "6V"
        ar(458) = "QY"
        ar(459) = "RE"
        ar(460) = "JD"
        ar(461) = "MB"
        ar(462) = "PR"
        ar(463) = "3K"
        ar(464) = "TY"
        ar(465) = "XD"
        ar(466) = "ME"
        ar(467) = "UW"
        ar(468) = "AJ"
        ar(469) = "FU"
        ar(470) = "9U"
        ar(471) = "SB"
        ar(472) = "SN"
        ar(473) = "VW"
        ar(474) = "MJ"
        ar(475) = "3R"
        ar(476) = "37"
        ar(477) = "QR"
        ar(478) = "Q3"
        ar(479) = "NF"
        ar(480) = "5H"
        ar(481) = "HY"
        ar(482) = "59"
        ar(483) = "92"
        ar(484) = "7S"
        ar(485) = "YJ"
        ar(486) = "ET"
        ar(487) = "BA"
        ar(488) = "WH"
        ar(489) = "MM"
        ar(490) = "VY"
        ar(491) = "8Y"
        ar(492) = "8U"
        ar(493) = "WE"
        ar(494) = "44"
        ar(495) = "LC"
        ar(496) = "UD"
        ar(497) = "QX"
        ar(498) = "ZP"
        ar(499) = "N6"
        ar(500) = "ZY"
        ar(501) = "E8"
        ar(502) = "CD"
        ar(503) = "RW"
        ar(504) = "4K"
        ar(505) = "YA"
        ar(506) = "Z4"
        ar(507) = "ZF"
        ar(508) = "JY"
        ar(509) = "S5"
        ar(510) = "J9"
        ar(511) = "GD"
        ar(512) = "2X"
        ar(513) = "LZ"
        ar(514) = "EC"
        ar(515) = "C9"
        ar(516) = "R7"
        ar(517) = "C2"
        ar(518) = "8D"
        ar(519) = "XY"
        ar(520) = "4Z"
        ar(521) = "TA"
        ar(522) = "BV"
        ar(523) = "8Q"
        ar(524) = "55"
        ar(525) = "JW"
        ar(526) = "U4"
        ar(527) = "C8"
        ar(528) = "CR"
        ar(529) = "BX"
        ar(530) = "KM"
        ar(531) = "77"
        ar(532) = "Q9"
        ar(533) = "KK"
        ar(534) = "SE"
        ar(535) = "8G"
        ar(536) = "DV"
        ar(537) = "WB"
        ar(538) = "AD"
        ar(539) = "DW"
        ar(540) = "CP"
        ar(541) = "KZ"
        ar(542) = "A7"
        ar(543) = "DA"
        ar(544) = "H7"
        ar(545) = "BR"
        ar(546) = "BQ"
        ar(547) = "P3"
        ar(548) = "ZK"
        ar(549) = "C7"
        ar(550) = "5B"
        ar(551) = "NJ"
        ar(552) = "5Q"
        ar(553) = "UC"
        ar(554) = "JM"
        ar(555) = "5R"
        ar(556) = "GE"
        ar(557) = "4L"
        ar(558) = "7Y"
        ar(559) = "G5"
        ar(560) = "98"
        ar(561) = "23"
        ar(562) = "PA"
        ar(563) = "T2"
        ar(564) = "5X"
        ar(565) = "AA"
        ar(566) = "NS"
        ar(567) = "Y9"
        ar(568) = "RS"
        ar(569) = "EJ"
        ar(570) = "U2"
        ar(571) = "YL"
        ar(572) = "DY"
        ar(573) = "F9"
        ar(574) = "CL"
        ar(575) = "B4"
        ar(576) = "RF"
        ar(577) = "PD"
        ar(578) = "4J"
        ar(579) = "GP"
        ar(580) = "RX"
        ar(581) = "LD"
        ar(582) = "NT"
        ar(583) = "K6"
        ar(584) = "N4"
        ar(585) = "6M"
        ar(586) = "5M"
        ar(587) = "22"
        ar(588) = "PT"
        ar(589) = "3X"
        ar(590) = "3A"
        ar(591) = "4Q"
        ar(592) = "YC"
        ar(593) = "ZH"
        ar(594) = "AY"
        ar(595) = "JH"
        ar(596) = "BD"
        ar(597) = "D9"
        ar(598) = "2R"
        ar(599) = "QP"
        ar(600) = "D7"
        ar(601) = "AV"
        ar(602) = "PG"
        ar(603) = "QS"
        ar(604) = "4W"
        ar(605) = "XQ"
        ar(606) = "WL"
        ar(607) = "67"
        ar(608) = "DX"
        ar(609) = "GX"
        ar(610) = "64"
        ar(611) = "UJ"
        ar(612) = "87"
        ar(613) = "TS"
        ar(614) = "KN"
        ar(615) = "5T"
        ar(616) = "8K"
        ar(617) = "M3"
        ar(618) = "BG"
        ar(619) = "3L"
        ar(620) = "LM"
        ar(621) = "UF"
        ar(622) = "C4"
        ar(623) = "RH"
        ar(624) = "4E"
        ar(625) = "UX"
        ar(626) = "PW"
        ar(627) = "G6"
        ar(628) = "JS"
        ar(629) = "2G"
        ar(630) = "7E"
        ar(631) = "MH"
        ar(632) = "2Z"
        ar(633) = "2M"
        ar(634) = "DN"
        ar(635) = "99"
        ar(636) = "6D"
        ar(637) = "X9"
        ar(638) = "GY"
        ar(639) = "FY"
        ar(640) = "AL"
        ar(641) = "SY"
        ar(642) = "ZS"
        ar(643) = "6G"
        ar(644) = "DC"
        ar(645) = "PS"
        ar(646) = "JX"
        ar(647) = "E6"
        ar(648) = "E7"
        ar(649) = "W6"
        ar(650) = "UR"
        ar(651) = "DL"
        ar(652) = "WA"
        ar(653) = "P8"
        ar(654) = "LJ"
        ar(655) = "CV"
        ar(656) = "Z5"
        ar(657) = "9C"
        ar(658) = "AB"
        ar(659) = "EH"
        ar(660) = "LX"
        ar(661) = "B3"
        ar(662) = "LQ"
        ar(663) = "GU"
        ar(664) = "GL"
        ar(665) = "GV"
        ar(666) = "XF"
        ar(667) = "Q2"
        ar(668) = "3F"
        ar(669) = "HN"
        ar(670) = "LW"
        ar(671) = "AR"
        ar(672) = "NR"
        ar(673) = "SQ"
        ar(674) = "6P"
        ar(675) = "AU"
        ar(676) = "V2"
        ar(677) = "P9"
        ar(678) = "32"
        ar(679) = "GR"
        ar(680) = "D4"
        ar(681) = "ZR"
        ar(682) = "NZ"
        ar(683) = "PK"
        ar(684) = "CS"
        ar(685) = "J6"
        ar(686) = "E2"
        ar(687) = "DP"
        ar(688) = "B7"
        ar(689) = "NX"
        ar(690) = "6T"
        ar(691) = "3J"
        ar(692) = "PX"
        ar(693) = "YX"
        ar(694) = "27"
        ar(695) = "JL"
        ar(696) = "ZQ"
        ar(697) = "4D"
        ar(698) = "BS"
        ar(699) = "HW"
        ar(700) = "U9"
        ar(701) = "54"
        ar(702) = "ES"
        ar(703) = "HS"
        ar(704) = "TD"
        ar(705) = "49"
        ar(706) = "VS"
        ar(707) = "RJ"
        ar(708) = "4G"
        ar(709) = "2Y"
        ar(710) = "J7"
        ar(711) = "FX"
        ar(712) = "F6"
        ar(713) = "MW"
        ar(714) = "EZ"
        ar(715) = "KY"
        ar(716) = "FS"
        ar(717) = "ZE"
        ar(718) = "2Q"
        ar(719) = "PL"
        ar(720) = "N5"
        ar(721) = "94"
        ar(722) = "G8"
        ar(723) = "BM"
        ar(724) = "WT"
        ar(725) = "QA"
        ar(726) = "WW"
        ar(727) = "DK"
        ar(728) = "DM"
        ar(729) = "BH"
        ar(730) = "9J"
        ar(731) = "63"
        ar(732) = "5Z"
        ar(733) = "RL"
        ar(734) = "V8"
        ar(735) = "UK"
        ar(736) = "73"
        ar(737) = "F3"
        ar(738) = "8P"
        ar(739) = "A4"
        ar(740) = "5J"
        ar(741) = "8Z"
        ar(742) = "7K"
        ar(743) = "8A"
        ar(744) = "MA"
        ar(745) = "8M"
        ar(746) = "UN"
        ar(747) = "GK"
        ar(748) = "V7"
        ar(749) = "Q7"
        ar(750) = "J3"
        ar(751) = "R2"
        ar(752) = "6R"
        ar(753) = "HL"
        ar(754) = "69"
        ar(755) = "R4"
        ar(756) = "78"
        ar(757) = "H3"
        ar(758) = "ZZ"
        ar(759) = "K4"
        ar(760) = "5Y"
        ar(761) = "8W"
        ar(762) = "BZ"
        ar(763) = "L2"
        ar(764) = "VX"
        ar(765) = "JE"
        ar(766) = "D5"
        ar(767) = "SS"
        ar(768) = "M8"
        ar(769) = "ZW"
        ar(770) = "7W"
        ar(771) = "2E"
        ar(772) = "9N"
        ar(773) = "NV"
        ar(774) = "KQ"
        ar(775) = "4V"
        ar(776) = "FH"
        ar(777) = "5W"
        ar(778) = "PM"
        ar(779) = "WS"
        ar(780) = "SC"
        ar(781) = "ZA"
        ar(782) = "XP"
        ar(783) = "XE"
        ar(784) = "RB"
        ar(785) = "MG"
        ar(786) = "6L"
        ar(787) = "3U"
        ar(788) = "W5"
        ar(789) = "KS"
        ar(790) = "M9"
        ar(791) = "3M"
        ar(792) = "39"
        ar(793) = "GH"
        ar(794) = "T8"
        ar(795) = "KH"
        ar(796) = "FE"
        ar(797) = "DB"
        ar(798) = "BB"
        ar(799) = "H4"
        ar(800) = "SA"
        ar(801) = "8N"
        ar(802) = "HK"
        ar(803) = "BW"
        ar(804) = "VF"
        ar(805) = "C5"
        ar(806) = "RU"
        ar(807) = "JV"
        ar(808) = "JZ"
        ar(809) = "M6"
        ar(810) = "2P"
        ar(811) = "VR"
        ar(812) = "WN"
        ar(813) = "45"
        ar(814) = "TF"
        ar(815) = "UZ"
        ar(816) = "5S"
        ar(817) = "W8"
        ar(818) = "MX"
        ar(819) = "S8"
        ar(820) = "PC"
        ar(821) = "YG"
        ar(822) = "8B"
        ar(823) = "T5"
        ar(824) = "B8"
        ar(825) = "Z9"
        ar(826) = "DQ"
        ar(827) = "PH"
        ar(828) = "R6"
        ar(829) = "EF"
        ar(830) = "3B"
        ar(831) = "UL"
        ar(832) = "NG"
        ar(833) = "ZL"
        ar(834) = "56"
        ar(835) = "QT"
        ar(836) = "D3"
        ar(837) = "P7"
        ar(838) = "QU"
        ar(839) = "FM"
        ar(840) = "E4"
        ar(841) = "K7"
        ar(842) = "AM"
        ar(843) = "MS"
        ar(844) = "2N"
        ar(845) = "N3"
        ar(846) = "FD"
        ar(847) = "9X"
        ar(848) = "EQ"
        ar(849) = "E3"
        ar(850) = "8C"
        ar(851) = "ZT"
        ar(852) = "PQ"
        ar(853) = "97"
        ar(854) = "76"
        ar(855) = "NU"
        ar(856) = "43"
        ar(857) = "MD"
        ar(858) = "SG"
        ar(859) = "EL"
        ar(860) = "HQ"
        ar(861) = "DZ"
        ar(862) = "E5"
        ar(863) = "JP"
        ar(864) = "VC"
        ar(865) = "XU"
        ar(866) = "US"
        ar(867) = "KA"
        ar(868) = "6W"
        ar(869) = "VT"
        ar(870) = "TC"
        ar(871) = "EW"
        ar(872) = "4N"
        ar(873) = "9K"
        ar(874) = "2K"
        ar(875) = "GN"
        ar(876) = "RC"
        ar(877) = "VG"
        ar(878) = "BU"
        ar(879) = "4F"
        ar(880) = "DR"
        ar(881) = "QB"
        ar(882) = "HJ"
        ar(883) = "7M"
        ar(884) = "9D"
        ar(885) = "9E"
        ar(886) = "HM"
        ar(887) = "QH"
        ar(888) = "F2"
        ar(889) = "CU"
        ar(890) = "MU"
        ar(891) = "QG"
        ar(892) = "EN"
        ar(893) = "CW"
        ar(894) = "JQ"
        ar(895) = "46"
        ar(896) = "GB"
        ar(897) = "QC"
        ar(898) = "V6"
        ar(899) = "9R"
        ar(900) = "T6"
        ar(901) = "9Q"
        ar(902) = "KG"
        ar(903) = "LY"
        ar(904) = "8X"
        ar(905) = "HP"
        ar(906) = "R3"
        ar(907) = "XW"
        ar(908) = "JB"
        ar(909) = "QJ"
        ar(910) = "X2"
        ar(911) = "UA"
        ar(912) = "62"
        ar(913) = "MR"
        ar(914) = "JU"
        ar(915) = "4P"
        ar(916) = "S3"
        ar(917) = "DF"
        ar(918) = "JT"
        ar(919) = "42"
        ar(920) = "AK"
        ar(921) = "Z7"
        ar(922) = "TV"
        ar(923) = "2B"
        ar(924) = "S6"
        ar(925) = "KE"
        ar(926) = "XV"
        ar(927) = "ZD"
        ar(928) = "TZ"
        ar(929) = "NA"
        ar(930) = "ZB"
        ar(931) = "L4"
        ar(932) = "5V"
        ar(933) = "5K"
        ar(934) = "UV"
        ar(935) = "ZC"
        ar(936) = "LV"
        ar(937) = "VZ"
        ar(938) = "8T"
        ar(939) = "XL"
        ar(940) = "S9"
        ar(941) = "PF"
        ar(942) = "ST"
        ar(943) = "XN"
        ar(944) = "CT"
        ar(945) = "UB"
        ar(946) = "CX"
        ar(947) = "VE"
        ar(948) = "29"
        ar(949) = "X6"
        ar(950) = "HC"
        ar(951) = "ZN"
        ar(952) = "VM"
        ar(953) = "VJ"
        ar(954) = "GG"
        ar(955) = "MP"
        ar(956) = "QF"
        ar(957) = "4C"
        ar(958) = "MY"
        ar(959) = "ML"
        ar(960) = "AZ"
        ar(961) = "MZ"
        ar(962) = "QW"
        ar(963) = "WM"
        ar(964) = "HU"
        ar(965) = "7Z"
        ar(966) = "RP"
        ar(967) = "YE"
        ar(968) = "CG"
        ar(969) = "G2"
        ar(970) = "PV"
        ar(971) = "T9"
        ar(972) = "7R"
        ar(973) = "F8"
        ar(974) = "7F"
        ar(975) = "UU"
        ar(976) = "TQ"
        ar(977) = "7U"
        ar(978) = "RR"
        ar(979) = "PE"
        ar(980) = "NM"
        ar(981) = "NB"
        ar(982) = "SL"
        ar(983) = "FC"
        ar(984) = "AX"
        ar(985) = "EG"
        ar(986) = "CZ"
        ar(987) = "VK"
        ar(988) = "W9"
        ar(989) = "VN"
        ar(990) = "9P"
        ar(991) = "V3"
        ar(992) = "95"
        ar(993) = "AG"
        ar(994) = "MQ"
        ar(995) = "KC"
        ar(996) = "BE"
        ar(997) = "4M"
        ar(998) = "CE"
        ar(999) = "26"
        ar(1000) = "VQ"
        ar(1001) = "GT"
        ar(1002) = "J8"
        ar(1003) = "HB"
        ar(1004) = "3H"
        ar(1005) = "Y3"
        ar(1006) = "BJ"
        ar(1007) = "HX"
        ar(1008) = "T3"
        ar(1009) = "AS"
        ar(1010) = "EV"
        ar(1011) = "FR"
        ar(1012) = "9Y"
        ar(1013) = "PY"
        ar(1014) = "A3"
        ar(1015) = "33"
        ar(1016) = "X7"
        ar(1017) = "LH"
        ar(1018) = "SR"
        ar(1019) = "HA"
        ar(1020) = "XH"
        ar(1021) = "65"
        ar(1022) = "2W"
        ar(1023) = "8J"
        ar(1024) = "9L"

        getencarray2014 = ar

    End Function

    Public Function msEncryptTool2014(ByVal prmdataToEncrypt As String, ByVal prmEncCode As String) As String

        ' this tool generate 90 random encrypted values 
        ' code will change as per enccode
        ' 0, 1, i, and o is not returned
        ' only caps alpha and numbers are returned
        ' enccode must be 5 to digits
        ' data to encrypt must be more than 5 digits
        ' 2014-10-20

        msEncryptTool2014 = ""

        Dim retVal As String
        retVal = ""

        If prmdataToEncrypt.Length < 5 Or prmEncCode.Length < 5 Then

            Exit Function

        End If

        Dim ar(1024) As String

        ar = getencarray2014()

        prmEncCode = Mid(prmEncCode & "shgft", 1, 10)

        If prmdataToEncrypt.Length < 10 Then
            prmdataToEncrypt = Mid(prmdataToEncrypt & "       ", 1, 10)
        End If

        Dim forcs As Long
        forcs = 0

        Dim rnval As String
        Randomize()

        rnval = Int(Rnd() * 90) + 10
        'rnval = 99    'to remove

        forcs = rnval

        Dim mult As Integer
        mult = 1

        Dim rcoal(10) As Integer
        Dim i As Integer

        For i = 1 To 10
            rcoal(i) = Asc(Mid(prmEncCode, i, 1)) + rnval * mult + 19   '    Mid(rnval, i Mod 2 + 1, 1)
            mult = mult + 1
            If mult > 5 Then mult = 1
            forcs = forcs + rcoal(i)
        Next

        i = 1

        Dim j As Integer
        Dim n As Integer

        retVal = ar(rnval)


        For j = 1 To prmdataToEncrypt.Length

            n = Asc(Mid(prmdataToEncrypt, j, 1)) + rcoal(i)
            i = i + 1
            If i > 10 Then i = 1
            forcs = forcs + n

            retVal = retVal & ar(n)

        Next

        retVal = ar(forcs Mod 678 + 13) & retVal

        msEncryptTool2014 = retVal

    End Function

#End Region


#Region "RerurnReports"


    Public Function msReturnCrossTabSummary(ByVal sSqlHead As String, ByVal sSqlDetails As String, ByVal MatchField As String, ByVal LeftTitle As String, ByVal LeftTitleField As String, ByVal SumField As String, Optional ByVal SumDataType As String = "N", Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal RepFileName As String = "", Optional ByVal ComNam As String = "", Optional ByVal colCode As String = "#0000FF", Optional ByVal OpenAsModal As Boolean = True, Optional ByVal MDI_Parent_Form As Form = Nothing) As Object

        ' 2010-08-27 

        ' sql rules
        ' ssqlhead should be sorted by matchfield (only one field neded)
        ' ssqldetails should be sorted by leftsidefield, matchfield (3 fields need including sumfield )
        'If sSqlHead and sqldetail should have same where cluase

        msReturnCrossTabSummary = ""

        Dim dbCnCT As New OleDbConnection
        If Not msOpenDbConnection(dbCnCT) Then GoTo gout

        Dim s As String

        s = ""

        ' -----------------------------------------
        s = s & "<html>"

        s = s & "<head>"
        s = s & "<meta http-equiv='Content-Language' content='en-us'>"
        s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>SS Report</title>"
        s = s & "<STYLE>"
        s = s & "BR.page { page-break-after: always }"
        s = s & "</STYLE>"
        s = s & "</head>"

        s = s & "<body style='font-family: Verdana; font-size: 10px'>"

        'My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

        s = s & "<p><i><b><font face='Tahoma' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
        s = s & "<p><font color='#800000' size='2'><b>" & RepHead & "</b></font></p>"

        'My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header
        's = ""

        Dim i As Integer

        Dim heads(100) As String
        Dim ColTotal(100) As Double
        Dim TotHeads As Integer

        Dim cmHead As OleDbCommand
        Dim drHead As OleDbDataReader

        Try

            i = 0
            cmHead = New OleDbCommand(sSqlHead, dbCnCT)
            drHead = cmHead.ExecuteReader
            Do While drHead.Read
                heads(i) = drHead.Item(MatchField).ToString
                i = i + 1
            Loop
            drHead.Close()
            cmHead.Dispose()
            TotHeads = i

        Catch ex As Exception
            msReturnCrossTabSummary = "Error : 3219" & ex.Message
            Exit Function
        End Try


        'My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

        s = s & "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'>"

        s = s & "<thead><tr bgcolor='#99FFCC'>"
        s = s & "<td><b><font size='2'>" & LeftTitle & "</font></b></td>"

        For i = 0 To 99
            If heads(i) = "" Then Exit For
            s = s & "<td><b><font size='2'>" & heads(i) & "</font></b></td>"
        Next

        s = s & "<td><b>Totals</b></td>"
        s = s & "</tr>"
        'My.Computer.FileSystem.WriteAllText(fn, s, True)
        's = ""

        Dim SideHead As String
        Dim OldSideHead As String
        Dim colHead As String

        OldSideHead = ""
        i = 0
        Dim c As Integer

        Dim cmDet As OleDbCommand
        Dim drDet As OleDbDataReader

        Dim RowTotal As Double
        Dim FullTotal As Double

        Try
            cmDet = New OleDbCommand(sSqlDetails, dbCnCT)
            drDet = cmDet.ExecuteReader
            's = 0
            RowTotal = 0

            Do While drDet.Read
                SideHead = drDet.Item(LeftTitleField).ToString
                ' s = ""
                ' close and got next row 
                If SideHead <> OldSideHead Then
                    ' if not firt row
                    If OldSideHead <> "" Then
                        Do While i < TotHeads
                            's = s & "<td>&nbsp;0</td>"
                            s = s & "<td align='right'><font size='2'>0</font></td>"
                            i = i + 1
                        Loop
                        If SumDataType = "F" Then
                            s = s & "<td align='right'><font size='2'>" & Format(RowTotal, "N") & "</font></td>"
                        Else
                            s = s & "<td align='right'><font size='2'>" & RowTotal & "</font></td>"
                        End If

                        s = s & "</tr>"
                    End If

                    OldSideHead = SideHead
                    s = s & "<tr>"
                    If IsDate(SideHead) Then
                        s = s & "<td>" & Format(CDate(SideHead), "Short Date") & "</td>"  ' hear option should be there to convert msdate to normal date if side head is date
                    Else
                        s = s & "<td><font size='2'>" & SideHead & "</font></td>"
                    End If
                    i = 0
                    RowTotal = 0
                End If

                colHead = drDet.Item(MatchField).ToString
                For c = i To TotHeads
                    If heads(c) = "" Then Exit For
                    If heads(c) = colHead Then
                        s = s & "<td "
                        s = s & " align='right' "
                        If SumDataType = "F" Then
                            s = s & " ><font size='2'>" & Format(drDet.Item(SumField), "N") & "</font></td>"

                        Else ' N
                            s = s & " ><font size='2'>" & drDet.Item(SumField) & "</font></td>"

                        End If

                        ColTotal(c) = ColTotal(c) + drDet.Item(SumField)
                        RowTotal = RowTotal + drDet.Item(SumField)
                        FullTotal = FullTotal + drDet.Item(SumField)
                        i = i + 1
                        Exit For
                    Else
                        's = s & "<td>&nbsp;0</td>"
                        s = s & "<td align='right'><font size='2'>0</font></td>"
                        i = i + 1
                    End If


                Next
                ' My.Computer.FileSystem.WriteAllText(fn, s, True)
                's = ""

            Loop

        Catch ex As Exception

            msReturnCrossTabSummary = "Error : 160816 " & ex.Message


        End Try

        ' close if in complete row

        ' if not first row
        If OldSideHead <> "" Then
            ' add row total
            Do While i < TotHeads
                s = s & "<td align='right'><font size='2'>0</font></td>"
                i = i + 1
            Loop
            If SumDataType = "F" Then
                s = s & "<td align='right'><font size='2'>" & Format(RowTotal, "N") & "</font></td>"
            Else
                s = s & "<td align='right'><font size='2'>" & RowTotal & "</font></td>"
            End If

            s = s & "</tr>"
        End If

        s = s & "<tr  bgcolor='#99FFCC'>"
        s = s & "<td><b>Totals</b></td>"
        's = s & "<td><b>المجموعة</b></td>"
        For i = 0 To 99
            If heads(i) = "" Then Exit For
            If SumDataType = "F" Then
                s = s & "<td align='right'><b><font size='2'>" & Format(ColTotal(i), "N") & "<font size='2'></b></td>"
            Else
                s = s & "<td align='right'><b><font size='2'>" & ColTotal(i) & "<font size='2'></b></td>"
            End If

        Next
        If SumDataType = "F" Then
            s = s & "<td align='right'><b><font size='2'>" & Format(FullTotal, "N") & "<font size='2'></b></td>"
        Else
            s = s & "<td align='right'><b><font size='2'>" & FullTotal & "<font size='2'></b></td>"
        End If

        s = s & "</tr>"

        s = s & "</thead></table>"
        '  My.Computer.FileSystem.WriteAllText(fn, s, True)

        ' s = ""

        'frmS.Close()


        s = s & "</body>"

        s = s & "</html>"

        msReturnCrossTabSummary = s

        'My.Computer.FileSystem.WriteAllText(fn, s, True)

        'Dim frmRep As New frmReports
        'frmRep.ShowDialog(fn)


gout:

    End Function

    Public Function msReturnCrossTabSummary2016(ByVal sSqlHead As String, ByVal sSqlDetails As String, ByVal MatchField As String, ByVal LeftTitle As String, ByVal LeftTitleField As String, ByVal SumField As String, Optional ByVal SumDataType As String = "N", Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal RepFileName As String = "", Optional ByVal Cellprintwidth As String = "", Optional ByVal TitlePrintWidth As String = "") As Object

        ' 2010-08-27 
        ' 2016 09 04   modified at Almousa crusher 

        ' sql rules
        ' ssqlhead should be sorted by matchfield (only one field neded)
        ' ssqldetails should be sorted by leftsidefield, matchfield (3 fields need including sumfield )
        'If sSqlHead and sqldetail should have same where cluase

        msReturnCrossTabSummary2016 = ""

        Dim dbCnCT As New OleDbConnection
        If Not msOpenDbConnection(dbCnCT) Then GoTo gout

        Dim frmS As New frmStatus
        frmS.Show("Generating Report, Please wait ...")

        Dim fntname As String
        fntname = "Tahoma"
        Dim fntSize As String
        fntSize = "1"



        '---------------------------------
        'MakeReportDir()
        'Dim subFn As String
        'subFn = Format(Now(), "mmss")
        'Dim fn As String
        ''fn = "c:\Report.html"
        'fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
        '-----------------------------------

        Dim s As String

        ' -----------------------------------------
        s = "<html>"

        s = s & "<head>"
        s = s & "<meta http-equiv='Content-Language' content='en-us'>"
        s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>SS Report</title>"
        s = s & "<STYLE>"
        s = s & "BR.page { page-break-after: always }"
        s = s & "</STYLE>"
        s = s & "</head>"

        s = s & "<body style='font-family: " & fntname & "; font-size: 10px'>"

        ' My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

        s = s & "<p><i>   <font face='" & fntname & "' size='2' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
        s = s & "<p><font color='#800000' size='1'>   " & RepHead & " </font></p>"

        'My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header
        's = ""

        Dim i As Integer

        Dim heads(100) As String
        Dim ColTotal(100) As Double
        Dim TotHeads As Integer

        Dim cmHead As OleDbCommand
        Dim drHead As OleDbDataReader

        Try

            i = 0
            cmHead = New OleDbCommand(sSqlHead, dbCnCT)
            drHead = cmHead.ExecuteReader
            Do While drHead.Read
                heads(i) = drHead.Item(MatchField).ToString.Trim
                i = i + 1
            Loop
            drHead.Close()
            cmHead.Dispose()
            TotHeads = i

        Catch ex As Exception
            MessageBox.Show("Error : 3219" & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Function

        End Try

        'My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

        s = s & "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'><font face='" & fntname & "' size=" & fntSize & ">"

        s = s & "<thead><tr bgcolor='#99FFCC'>"
        If TitlePrintWidth = "" Then
            s = s & "<td><font face='" & fntname & "' size=" & fntSize & ">" & LeftTitle & " </font></td>"
        Else
            s = s & "<td style='width:" & TitlePrintWidth & "px'><font face='" & fntname & "' size=" & fntSize & ">" & LeftTitle & " </font></td>"
        End If


        For i = 0 To 99
            If heads(i) = "" Then Exit For
            If Cellprintwidth = "" Then
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & heads(i) & " </font></td>"
            Else
                s = s & "<td style='width:" & Cellprintwidth & "px' align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & heads(i) & "</font></td>"
            End If

        Next

        s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">Total Tons</font></td>"
        s = s & "</tr>"
        
        Dim SideHead As String
        Dim OldSideHead As String
        Dim colHead As String

        OldSideHead = ""
        i = 0
        Dim c As Integer

        Dim cmDet As OleDbCommand
        Dim drDet As OleDbDataReader

        Dim RowTotal As Double
        Dim FullTotal As Double

        Try
            cmDet = New OleDbCommand(sSqlDetails, dbCnCT)
            drDet = cmDet.ExecuteReader
            '   s = 0
            RowTotal = 0

            Do While drDet.Read
                SideHead = drDet.Item(LeftTitleField).ToString.Trim

                ' close and got next row 
                If SideHead <> OldSideHead Then
                    ' if not firt row
                    If OldSideHead <> "" Then
                        Do While i < TotHeads
                            's = s & "<td>&nbsp;0</td>"
                            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">0</font></td>"
                            i = i + 1
                        Loop
                        If SumDataType = "F" Then
                            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & Format(RowTotal, "N") & "</font></td>"
                        Else
                            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & RowTotal & "</font></td>"
                        End If

                        s = s & "</tr>"
                    End If

                    OldSideHead = SideHead
                    s = s & "<tr>"
                    If IsDate(SideHead) Then
                        s = s & "<td><font face='" & fntname & "' size=" & fntSize & ">" & Format(CDate(SideHead), "Short Date") & "</font></td>"  ' hear option should be there to convert msdate to normal date if side head is date
                    Else
                        If TitlePrintWidth = "" Then
                            s = s & "<td><font face='" & fntname & "' size=" & fntSize & ">" & SideHead & "</font></td>"
                        Else
                            s = s & "<td style='width:" & TitlePrintWidth & "px'><font face='" & fntname & "' size=" & fntSize & ">" & SideHead & "</font></td>"
                        End If

                    End If
                    i = 0
                    RowTotal = 0

                End If

                colHead = drDet.Item(MatchField).ToString.Trim
                For c = i To TotHeads
                    If heads(c) = "" Then Exit For
                    If heads(c) = colHead Then
                        s = s & "<td "
                        s = s & " align='Center' "
                        If SumDataType = "F" Then
                            s = s & " ><font face='" & fntname & "' size=" & fntSize & ">" & Format(drDet.Item(SumField), "N") & "</font></td>"

                        Else ' N
                            s = s & " ><font face='" & fntname & "' size=" & fntSize & ">" & drDet.Item(SumField) & "</font></td>"

                        End If

                        ColTotal(c) = ColTotal(c) + drDet.Item(SumField)
                        RowTotal = RowTotal + drDet.Item(SumField)
                        FullTotal = FullTotal + drDet.Item(SumField)
                        i = i + 1
                        Exit For
                    Else
                        's = s & "<td>&nbsp;0</font></td>"
                        s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">0</font></td>"
                        i = i + 1
                    End If


                Next
                '     My.Computer.FileSystem.WriteAllText(fn, s, True)
                '    s = ""

            Loop

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

        ' close if in complete row

        ' if not first row
        If OldSideHead <> "" Then
            ' add row total
            Do While i < TotHeads
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">0</font></td>"
                i = i + 1
            Loop
            If SumDataType = "F" Then
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & Format(RowTotal, "N") & "</font></td>"
            Else
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & RowTotal & "</font></td>"
            End If

            s = s & "</tr>"
        End If

        s = s & "<tr  bgcolor='#99FFCC'>"
        s = s & "<td><font face='" & fntname & "' size=" & fntSize & "><b>Total Tons</b></font></td>"

        For i = 0 To 99
            If heads(i) = "" Then Exit For
            If SumDataType = "F" Then
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & "><b>" & Format(ColTotal(i), "N") & "</b></font></td>"
            Else
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & "><b>" & ColTotal(i) & "</b></font></td>"
            End If

        Next
        If SumDataType = "F" Then
            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & "><b>" & Format(FullTotal, "N") & "</b></font></td>"
        Else
            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & "><b>" & FullTotal & "</b></font></td>"
        End If

        s = s & "</tr>"

        s = s & "</thead></font></table>"
        'My.Computer.FileSystem.WriteAllText(fn, s, True)

        's = ""

        frmS.Close()


        s = s & "</body>"

        s = s & "</html>"

        msReturnCrossTabSummary2016 = s

        'My.Computer.FileSystem.WriteAllText(fn, s, True)

        'Dim frmRep As New frmReports
        'frmRep.ShowDialog(fn)

gout:

    End Function


    Public Sub msPrepareCrossTabSummary2016(ByVal sSqlHead As String, ByVal sSqlDetails As String, ByVal MatchField As String, ByVal LeftTitle As String, ByVal LeftTitleField As String, ByVal SumField As String, Optional ByVal SumDataType As String = "N", Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal Cellprintwidth As String = "", Optional ByVal TitlePrintWidth As String = "")

        ' 2010-08-27 
        ' 2016 09 04   modified at Almousa crusher 

        ' sql rules
        ' ssqlhead should be sorted by matchfield (only one field neded)
        ' ssqldetails should be sorted by leftsidefield, matchfield (3 fields need including sumfield )
        'If sSqlHead and sqldetail should have same where cluase

        Dim dbCnCT As New OleDbConnection
        If Not msOpenDbConnection(dbCnCT) Then GoTo gout

        Dim frmS As New frmStatus
        frmS.Show("Generating Report, Please wait ...")

        Dim fntname As String
        fntname = "Tahoma"
        Dim fntSize As String
        fntSize = "1"



        '---------------------------------
        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "mmss")
        Dim fn As String
        'fn = "c:\Report.html"
        fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
        '-----------------------------------

        Dim s As String

        ' -----------------------------------------
        s = "<html>"

        s = s & "<head>"
        s = s & "<meta http-equiv='Content-Language' content='en-us'>"
        s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>SS Report</title>"
        s = s & "<STYLE>"
        s = s & "BR.page { page-break-after: always }"
        s = s & "</STYLE>"
        s = s & "</head>"

        s = s & "<body style='font-family: Verdana; font-size: 10px'>"

        My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

        s = "<p><i>   <font face='Tahoma' size='2' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
        s = s & "<p><font color='#800000' size='1'>   " & RepHead & " </font></p>"

        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header
        s = ""

        Dim i As Integer

        Dim heads(100) As String
        Dim ColTotal(100) As Double
        Dim TotHeads As Integer

        Dim cmHead As OleDbCommand
        Dim drHead As OleDbDataReader

        Try

            i = 0
            cmHead = New OleDbCommand(sSqlHead, dbCnCT)
            drHead = cmHead.ExecuteReader
            Do While drHead.Read
                heads(i) = drHead.Item(MatchField).ToString.Trim
                i = i + 1
            Loop
            drHead.Close()
            cmHead.Dispose()
            TotHeads = i

        Catch ex As Exception
            MessageBox.Show("Error : 3219" & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub

        End Try

        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

        s = "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'><font face='" & fntname & "' size=" & fntSize & ">"


        s = s & "<thead><tr bgcolor='#99FFCC'>"
        If TitlePrintWidth = "" Then
            s = s & "<td><font face='" & fntname & "' size=" & fntSize & ">" & LeftTitle & " </font></td>"
        Else
            s = s & "<td style='width:" & TitlePrintWidth & "px'><font face='" & fntname & "' size=" & fntSize & ">" & LeftTitle & " </font></td>"
        End If


        For i = 0 To 99
            If heads(i) = "" Then Exit For
            If Cellprintwidth = "" Then
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & heads(i) & " </font></td>"
            Else
                's = s & "<td style='width:" & Cellprintwidth & "px' align='Center'><b><font size='2'>" & heads(i) & "</font></b></font></td>"
                s = s & "<td style='width:" & Cellprintwidth & "px' align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & heads(i) & "</font></td>"
            End If

        Next

        s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">Total Tons</font></td>"
        s = s & "</tr>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)
        s = ""

        Dim SideHead As String
        Dim OldSideHead As String
        Dim colHead As String

        OldSideHead = ""
        i = 0
        Dim c As Integer

        Dim cmDet As OleDbCommand
        Dim drDet As OleDbDataReader

        Dim RowTotal As Double
        Dim FullTotal As Double

        Try
            cmDet = New OleDbCommand(sSqlDetails, dbCnCT)
            drDet = cmDet.ExecuteReader
            s = 0
            RowTotal = 0

            Do While drDet.Read
                SideHead = drDet.Item(LeftTitleField).ToString.Trim
                s = ""
                ' close and got next row 
                If SideHead <> OldSideHead Then
                    ' if not firt row
                    If OldSideHead <> "" Then
                        Do While i < TotHeads
                            's = s & "<td>&nbsp;0</td>"
                            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">0</font></td>"
                            i = i + 1
                        Loop
                        If SumDataType = "F" Then
                            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & Format(RowTotal, "N") & "</font></td>"
                        Else
                            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & RowTotal & "</font></td>"
                        End If

                        s = s & "</tr>"
                    End If

                    OldSideHead = SideHead
                    s = s & "<tr>"
                    If IsDate(SideHead) Then
                        s = s & "<td><font face='" & fntname & "' size=" & fntSize & ">" & Format(CDate(SideHead), "Short Date") & "</font></td>"  ' hear option should be there to convert msdate to normal date if side head is date
                    Else
                        If TitlePrintWidth = "" Then
                            s = s & "<td><font face='" & fntname & "' size=" & fntSize & ">" & SideHead & "</font></td>"
                        Else
                            s = s & "<td style='width:" & TitlePrintWidth & "px'><font face='" & fntname & "' size=" & fntSize & ">" & SideHead & "</font></td>"
                        End If

                    End If
                    i = 0
                    RowTotal = 0

                End If

                colHead = drDet.Item(MatchField).ToString.Trim
                For c = i To TotHeads
                    If heads(c) = "" Then Exit For
                    If heads(c) = colHead Then
                        s = s & "<td "
                        s = s & " align='Center' "
                        If SumDataType = "F" Then
                            s = s & " ><font face='" & fntname & "' size=" & fntSize & ">" & Format(drDet.Item(SumField), "N") & "</font></td>"

                        Else ' N
                            s = s & " ><font face='" & fntname & "' size=" & fntSize & ">" & drDet.Item(SumField) & "</font></td>"

                        End If

                        ColTotal(c) = ColTotal(c) + drDet.Item(SumField)
                        RowTotal = RowTotal + drDet.Item(SumField)
                        FullTotal = FullTotal + drDet.Item(SumField)
                        i = i + 1
                        Exit For
                    Else
                        's = s & "<td>&nbsp;0</font></td>"
                        s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">0</font></td>"
                        i = i + 1
                    End If


                Next
                My.Computer.FileSystem.WriteAllText(fn, s, True)
                s = ""

            Loop

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

        ' close if in complete row

        ' if not first row
        If OldSideHead <> "" Then
            ' add row total
            Do While i < TotHeads
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">0</font></td>"
                i = i + 1
            Loop
            If SumDataType = "F" Then
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & Format(RowTotal, "N") & "</font></td>"
            Else
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & ">" & RowTotal & "</font></td>"
            End If

            s = s & "</tr>"
        End If

        s = s & "<tr  bgcolor='#99FFCC'>"
        s = s & "<td><font face='" & fntname & "' size=" & fntSize & "><b>Total Tons</b></font></td>"

        For i = 0 To 99
            If heads(i) = "" Then Exit For
            If SumDataType = "F" Then
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & "><b>" & Format(ColTotal(i), "N") & "</b></font></td>"
            Else
                s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & "><b>" & ColTotal(i) & "</b></font></td>"
            End If

        Next
        If SumDataType = "F" Then
            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & "><b>" & Format(FullTotal, "N") & "</b></font></td>"
        Else
            s = s & "<td align='Center'><font face='" & fntname & "' size=" & fntSize & "><b>" & FullTotal & "</b></font></td>"
        End If

        s = s & "</tr>"

        s = s & "</thead></font></table>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)

        s = ""

        frmS.Close()


        s = s & "</body>"

        s = s & "</html>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)

        Dim frmRep As New frmReports
        frmRep.ShowDialog(fn)


gout:

    End Sub

    


#End Region

#Region "Old db routines"

    Public Sub msFillGroupCombo(ByVal prmStrSql As String, ByVal LB As ComboBox, Optional ByVal ListMaxCount As Integer = 0, Optional ByVal prmdbCn211119 As OleDbConnection = Nothing, Optional ByVal noID As Boolean = False, Optional ByVal SelectedID As String = "")

        Dim mustClosedbcon As Boolean
        mustClosedbcon = False

        Dim lstItem As New msListItem

        LB.Items.Clear()

        If prmdbCn211119 Is Nothing Then
            If Not msOpenDbConnection(prmdbCn211119) Then Exit Sub
            mustClosedbcon = True
        End If

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
        Dim x As Integer
        Dim cnt As Integer

        Try

            cm = New OleDbCommand(prmStrSql, prmdbCn211119)
            dr = cm.ExecuteReader

            Do While dr.Read

                If noID Then
                    x = LB.Items.Add(dr.Item(0).ToString)

                Else
                    lstItem = New msListItem(dr.Item(1).ToString, dr.Item(0).ToString)
                    x = LB.Items.Add(lstItem)
                    If SelectedID <> "" Then
                        If dr.Item(0).ToString = SelectedID Then
                            LB.SelectedIndex = x
                        End If
                    End If
                End If

                cnt = cnt + 1
                If ListMaxCount > 0 Then
                    If cnt >= ListMaxCount Then Exit Do
                End If

            Loop

            dr.Close()
            cm.Dispose()

        Catch ex As Exception
            MsgBox("Err: 211119 " & vbCrLf & ex.Message, MsgBoxStyle.Critical)

        End Try

        If mustClosedbcon Then
            prmdbCn211119.Close()
        End If

gout:

    End Sub

#End Region

End Module
