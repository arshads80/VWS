﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmVehicles
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmVehicles))
        Me.txtLM = New System.Windows.Forms.Label()
        Me.GroupBoxSearch = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtVehCode = New System.Windows.Forms.TextBox()
        Me.txtVehName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtOwner = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtDriver = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtDriverMob = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtTareWt = New System.Windows.Forms.TextBox()
        Me.btnW1 = New System.Windows.Forms.Button()
        Me.btnW2 = New System.Windows.Forms.Button()
        Me.btnManualTare = New System.Windows.Forms.Button()
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.bnAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.bnCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.bnDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.bnPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnEdit = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnRefresh = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnSave = New System.Windows.Forms.ToolStripButton()
        Me.bnCancel = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnClose = New System.Windows.Forms.ToolStripButton()
        Me.lbldispError = New System.Windows.Forms.ToolStripLabel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.txtMTare = New System.Windows.Forms.TextBox()
        Me.tmrGetWT = New System.Windows.Forms.Timer(Me.components)
        Me.pnlInvisible = New System.Windows.Forms.Panel()
        Me.GroupBoxSearch.SuspendLayout()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlInvisible.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtLM
        '
        Me.txtLM.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLM.Location = New System.Drawing.Point(611, 10)
        Me.txtLM.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtLM.Name = "txtLM"
        Me.txtLM.Size = New System.Drawing.Size(336, 44)
        Me.txtLM.TabIndex = 34
        Me.txtLM.Text = "Vehicles"
        Me.txtLM.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBoxSearch
        '
        Me.GroupBoxSearch.Controls.Add(Me.btnSearch)
        Me.GroupBoxSearch.Controls.Add(Me.txtSearch)
        Me.GroupBoxSearch.Location = New System.Drawing.Point(15, 10)
        Me.GroupBoxSearch.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBoxSearch.Name = "GroupBoxSearch"
        Me.GroupBoxSearch.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBoxSearch.Size = New System.Drawing.Size(561, 68)
        Me.GroupBoxSearch.TabIndex = 33
        Me.GroupBoxSearch.TabStop = False
        Me.GroupBoxSearch.Text = "Search Code / Name / Driver / Mobile / Owner"
        '
        'btnSearch
        '
        Me.btnSearch.Image = CType(resources.GetObject("btnSearch.Image"), System.Drawing.Image)
        Me.btnSearch.Location = New System.Drawing.Point(495, 27)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(37, 30)
        Me.btnSearch.TabIndex = 2
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSearch.Location = New System.Drawing.Point(31, 28)
        Me.txtSearch.Margin = New System.Windows.Forms.Padding(4)
        Me.txtSearch.MaxLength = 20
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(455, 22)
        Me.txtSearch.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(43, 108)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 14)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Vehicle Code"
        '
        'txtVehCode
        '
        Me.txtVehCode.Location = New System.Drawing.Point(171, 105)
        Me.txtVehCode.MaxLength = 20
        Me.txtVehCode.Name = "txtVehCode"
        Me.txtVehCode.ReadOnly = True
        Me.txtVehCode.Size = New System.Drawing.Size(209, 22)
        Me.txtVehCode.TabIndex = 36
        '
        'txtVehName
        '
        Me.txtVehName.Location = New System.Drawing.Point(255, 148)
        Me.txtVehName.MaxLength = 35
        Me.txtVehName.Name = "txtVehName"
        Me.txtVehName.ReadOnly = True
        Me.txtVehName.Size = New System.Drawing.Size(437, 22)
        Me.txtVehName.TabIndex = 38
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(43, 151)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 14)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Transporter / Vehicle"
        '
        'txtOwner
        '
        Me.txtOwner.Location = New System.Drawing.Point(171, 189)
        Me.txtOwner.MaxLength = 50
        Me.txtOwner.Name = "txtOwner"
        Me.txtOwner.ReadOnly = True
        Me.txtOwner.Size = New System.Drawing.Size(521, 22)
        Me.txtOwner.TabIndex = 40
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(43, 192)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 14)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "Owner"
        '
        'txtDriver
        '
        Me.txtDriver.Location = New System.Drawing.Point(234, 25)
        Me.txtDriver.MaxLength = 35
        Me.txtDriver.Name = "txtDriver"
        Me.txtDriver.ReadOnly = True
        Me.txtDriver.Size = New System.Drawing.Size(437, 22)
        Me.txtDriver.TabIndex = 42
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(22, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 14)
        Me.Label4.TabIndex = 41
        Me.Label4.Text = "Driver"
        '
        'txtDriverMob
        '
        Me.txtDriverMob.Location = New System.Drawing.Point(234, 66)
        Me.txtDriverMob.MaxLength = 20
        Me.txtDriverMob.Name = "txtDriverMob"
        Me.txtDriverMob.ReadOnly = True
        Me.txtDriverMob.Size = New System.Drawing.Size(246, 22)
        Me.txtDriverMob.TabIndex = 44
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(22, 69)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(88, 14)
        Me.Label5.TabIndex = 43
        Me.Label5.Text = "Driver Mobile"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(43, 243)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(119, 14)
        Me.Label6.TabIndex = 45
        Me.Label6.Text = "Tare Weight (Kgs)"
        '
        'txtTareWt
        '
        Me.txtTareWt.Location = New System.Drawing.Point(255, 240)
        Me.txtTareWt.MaxLength = 35
        Me.txtTareWt.Name = "txtTareWt"
        Me.txtTareWt.ReadOnly = True
        Me.txtTareWt.Size = New System.Drawing.Size(136, 22)
        Me.txtTareWt.TabIndex = 46
        Me.txtTareWt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnW1
        '
        Me.btnW1.Location = New System.Drawing.Point(531, 239)
        Me.btnW1.Name = "btnW1"
        Me.btnW1.Size = New System.Drawing.Size(118, 63)
        Me.btnW1.TabIndex = 47
        Me.btnW1.TabStop = False
        Me.btnW1.Text = "Weight 1"
        Me.btnW1.UseVisualStyleBackColor = True
        '
        'btnW2
        '
        Me.btnW2.Location = New System.Drawing.Point(669, 240)
        Me.btnW2.Name = "btnW2"
        Me.btnW2.Size = New System.Drawing.Size(118, 63)
        Me.btnW2.TabIndex = 48
        Me.btnW2.TabStop = False
        Me.btnW2.Text = "Weight 2"
        Me.btnW2.UseVisualStyleBackColor = True
        Me.btnW2.Visible = False
        '
        'btnManualTare
        '
        Me.btnManualTare.Location = New System.Drawing.Point(806, 239)
        Me.btnManualTare.Name = "btnManualTare"
        Me.btnManualTare.Size = New System.Drawing.Size(118, 63)
        Me.btnManualTare.TabIndex = 49
        Me.btnManualTare.TabStop = False
        Me.btnManualTare.Text = "Manual Tare"
        Me.btnManualTare.UseVisualStyleBackColor = True
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.bnAddNewItem
        Me.BindingNavigator1.CountItem = Me.bnCountItem
        Me.BindingNavigator1.DeleteItem = Me.bnDeleteItem
        Me.BindingNavigator1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.bnMoveFirstItem, Me.bnMovePreviousItem, Me.BindingNavigatorSeparator, Me.bnPositionItem, Me.bnCountItem, Me.BindingNavigatorSeparator1, Me.bnMoveNextItem, Me.bnMoveLastItem, Me.BindingNavigatorSeparator2, Me.bnAddNewItem, Me.bnEdit, Me.bnDeleteItem, Me.ToolStripSeparator1, Me.bnRefresh, Me.ToolStripSeparator2, Me.bnSave, Me.bnCancel, Me.ToolStripSeparator3, Me.bnClose, Me.lbldispError})
        Me.BindingNavigator1.Location = New System.Drawing.Point(0, 330)
        Me.BindingNavigator1.MoveFirstItem = Me.bnMoveFirstItem
        Me.BindingNavigator1.MoveLastItem = Me.bnMoveLastItem
        Me.BindingNavigator1.MoveNextItem = Me.bnMoveNextItem
        Me.BindingNavigator1.MovePreviousItem = Me.bnMovePreviousItem
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.bnPositionItem
        Me.BindingNavigator1.Size = New System.Drawing.Size(960, 38)
        Me.BindingNavigator1.TabIndex = 51
        Me.BindingNavigator1.Text = "BindingNavigator1"
        '
        'bnAddNewItem
        '
        Me.bnAddNewItem.Image = CType(resources.GetObject("bnAddNewItem.Image"), System.Drawing.Image)
        Me.bnAddNewItem.Name = "bnAddNewItem"
        Me.bnAddNewItem.RightToLeftAutoMirrorImage = True
        Me.bnAddNewItem.Size = New System.Drawing.Size(35, 35)
        Me.bnAddNewItem.Text = "New"
        Me.bnAddNewItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'bnCountItem
        '
        Me.bnCountItem.Name = "bnCountItem"
        Me.bnCountItem.Size = New System.Drawing.Size(35, 35)
        Me.bnCountItem.Text = "of {0}"
        Me.bnCountItem.ToolTipText = "Total number of items"
        '
        'bnDeleteItem
        '
        Me.bnDeleteItem.Image = CType(resources.GetObject("bnDeleteItem.Image"), System.Drawing.Image)
        Me.bnDeleteItem.Name = "bnDeleteItem"
        Me.bnDeleteItem.RightToLeftAutoMirrorImage = True
        Me.bnDeleteItem.Size = New System.Drawing.Size(44, 35)
        Me.bnDeleteItem.Text = "Delete"
        Me.bnDeleteItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnDeleteItem.Visible = False
        '
        'bnMoveFirstItem
        '
        Me.bnMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveFirstItem.Image = CType(resources.GetObject("bnMoveFirstItem.Image"), System.Drawing.Image)
        Me.bnMoveFirstItem.Name = "bnMoveFirstItem"
        Me.bnMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveFirstItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveFirstItem.Text = "Move first"
        '
        'bnMovePreviousItem
        '
        Me.bnMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMovePreviousItem.Image = CType(resources.GetObject("bnMovePreviousItem.Image"), System.Drawing.Image)
        Me.bnMovePreviousItem.Name = "bnMovePreviousItem"
        Me.bnMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.bnMovePreviousItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 38)
        '
        'bnPositionItem
        '
        Me.bnPositionItem.AccessibleName = "Position"
        Me.bnPositionItem.Name = "bnPositionItem"
        Me.bnPositionItem.Size = New System.Drawing.Size(36, 38)
        Me.bnPositionItem.Text = "0"
        Me.bnPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'bnMoveNextItem
        '
        Me.bnMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveNextItem.Image = CType(resources.GetObject("bnMoveNextItem.Image"), System.Drawing.Image)
        Me.bnMoveNextItem.Name = "bnMoveNextItem"
        Me.bnMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveNextItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveNextItem.Text = "Move next"
        '
        'bnMoveLastItem
        '
        Me.bnMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveLastItem.Image = CType(resources.GetObject("bnMoveLastItem.Image"), System.Drawing.Image)
        Me.bnMoveLastItem.Name = "bnMoveLastItem"
        Me.bnMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveLastItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'bnEdit
        '
        Me.bnEdit.Image = CType(resources.GetObject("bnEdit.Image"), System.Drawing.Image)
        Me.bnEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnEdit.Name = "bnEdit"
        Me.bnEdit.Size = New System.Drawing.Size(31, 35)
        Me.bnEdit.Text = "Edit"
        Me.bnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'bnRefresh
        '
        Me.bnRefresh.Image = CType(resources.GetObject("bnRefresh.Image"), System.Drawing.Image)
        Me.bnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnRefresh.Name = "bnRefresh"
        Me.bnRefresh.Size = New System.Drawing.Size(50, 35)
        Me.bnRefresh.Text = "Refresh"
        Me.bnRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'bnSave
        '
        Me.bnSave.Image = CType(resources.GetObject("bnSave.Image"), System.Drawing.Image)
        Me.bnSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnSave.Name = "bnSave"
        Me.bnSave.Size = New System.Drawing.Size(35, 35)
        Me.bnSave.Text = "Save"
        Me.bnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnSave.ToolTipText = "Save"
        '
        'bnCancel
        '
        Me.bnCancel.Image = CType(resources.GetObject("bnCancel.Image"), System.Drawing.Image)
        Me.bnCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnCancel.Name = "bnCancel"
        Me.bnCancel.Size = New System.Drawing.Size(47, 35)
        Me.bnCancel.Text = "Cancel"
        Me.bnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnCancel.ToolTipText = "Cancel"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 38)
        '
        'bnClose
        '
        Me.bnClose.Image = CType(resources.GetObject("bnClose.Image"), System.Drawing.Image)
        Me.bnClose.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnClose.Name = "bnClose"
        Me.bnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.bnClose.Size = New System.Drawing.Size(40, 35)
        Me.bnClose.Text = "Close"
        Me.bnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnClose.ToolTipText = "Close"
        '
        'lbldispError
        '
        Me.lbldispError.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldispError.ForeColor = System.Drawing.Color.Red
        Me.lbldispError.Name = "lbldispError"
        Me.lbldispError.Size = New System.Drawing.Size(0, 35)
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridView1.Location = New System.Drawing.Point(0, 368)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 26
        Me.DataGridView1.Size = New System.Drawing.Size(960, 218)
        Me.DataGridView1.TabIndex = 50
        '
        'txtMTare
        '
        Me.txtMTare.Enabled = False
        Me.txtMTare.Location = New System.Drawing.Point(416, 239)
        Me.txtMTare.Name = "txtMTare"
        Me.txtMTare.ReadOnly = True
        Me.txtMTare.Size = New System.Drawing.Size(85, 22)
        Me.txtMTare.TabIndex = 52
        Me.txtMTare.TabStop = False
        '
        'tmrGetWT
        '
        Me.tmrGetWT.Enabled = True
        Me.tmrGetWT.Interval = 400
        '
        'pnlInvisible
        '
        Me.pnlInvisible.Controls.Add(Me.Label4)
        Me.pnlInvisible.Controls.Add(Me.txtDriver)
        Me.pnlInvisible.Controls.Add(Me.Label5)
        Me.pnlInvisible.Controls.Add(Me.txtDriverMob)
        Me.pnlInvisible.Location = New System.Drawing.Point(726, 93)
        Me.pnlInvisible.Name = "pnlInvisible"
        Me.pnlInvisible.Size = New System.Drawing.Size(222, 113)
        Me.pnlInvisible.TabIndex = 53
        Me.pnlInvisible.Visible = False
        '
        'frmVehicles
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(960, 586)
        Me.Controls.Add(Me.pnlInvisible)
        Me.Controls.Add(Me.txtMTare)
        Me.Controls.Add(Me.BindingNavigator1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnManualTare)
        Me.Controls.Add(Me.btnW2)
        Me.Controls.Add(Me.btnW1)
        Me.Controls.Add(Me.txtTareWt)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtOwner)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtVehName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtVehCode)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtLM)
        Me.Controls.Add(Me.GroupBoxSearch)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "frmVehicles"
        Me.Text = "Vehicles"
        Me.GroupBoxSearch.ResumeLayout(False)
        Me.GroupBoxSearch.PerformLayout()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlInvisible.ResumeLayout(False)
        Me.pnlInvisible.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtLM As System.Windows.Forms.Label
    Friend WithEvents GroupBoxSearch As System.Windows.Forms.GroupBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtVehCode As System.Windows.Forms.TextBox
    Friend WithEvents txtVehName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtOwner As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtDriver As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtDriverMob As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtTareWt As System.Windows.Forms.TextBox
    Friend WithEvents btnW1 As System.Windows.Forms.Button
    Friend WithEvents btnW2 As System.Windows.Forms.Button
    Friend WithEvents btnManualTare As System.Windows.Forms.Button
    Friend WithEvents BindingNavigator1 As System.Windows.Forms.BindingNavigator
    Friend WithEvents bnAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents bnDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnEdit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnRefresh As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnCancel As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnClose As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbldispError As System.Windows.Forms.ToolStripLabel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents txtMTare As System.Windows.Forms.TextBox
    Friend WithEvents tmrGetWT As System.Windows.Forms.Timer
    Friend WithEvents pnlInvisible As System.Windows.Forms.Panel
End Class
