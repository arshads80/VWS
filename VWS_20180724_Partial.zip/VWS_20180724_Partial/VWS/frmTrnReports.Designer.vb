﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTrnReports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.rbRepCustMat = New System.Windows.Forms.RadioButton()
        Me.rbRepCustTick = New System.Windows.Forms.RadioButton()
        Me.rbRep1stTicket = New System.Windows.Forms.RadioButton()
        Me.rbRepMatTick = New System.Windows.Forms.RadioButton()
        Me.rbRepAllTickets = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkNetWeightTons = New System.Windows.Forms.CheckBox()
        Me.chkLastUpdate = New System.Windows.Forms.CheckBox()
        Me.chkNetWeight = New System.Windows.Forms.CheckBox()
        Me.chkPrepaidFlag = New System.Windows.Forms.CheckBox()
        Me.chkUserCancelled = New System.Windows.Forms.CheckBox()
        Me.chkFWdt = New System.Windows.Forms.CheckBox()
        Me.chkSyncFlag = New System.Windows.Forms.CheckBox()
        Me.chkUserID = New System.Windows.Forms.CheckBox()
        Me.chkUserModified = New System.Windows.Forms.CheckBox()
        Me.chkFirstTickNo = New System.Windows.Forms.CheckBox()
        Me.chkVehCode = New System.Windows.Forms.CheckBox()
        Me.chkDlvOrder = New System.Windows.Forms.CheckBox()
        Me.chkRemark = New System.Windows.Forms.CheckBox()
        Me.chkWtRemark = New System.Windows.Forms.CheckBox()
        Me.chkFWdate = New System.Windows.Forms.CheckBox()
        Me.chkCancelRemark = New System.Windows.Forms.CheckBox()
        Me.chkModifyRemark = New System.Windows.Forms.CheckBox()
        Me.chkSWdt = New System.Windows.Forms.CheckBox()
        Me.chkSWdate = New System.Windows.Forms.CheckBox()
        Me.chkSecondWt = New System.Windows.Forms.CheckBox()
        Me.chkFirstWt = New System.Windows.Forms.CheckBox()
        Me.chkWtType = New System.Windows.Forms.CheckBox()
        Me.chkInOut = New System.Windows.Forms.CheckBox()
        Me.chkSite = New System.Windows.Forms.CheckBox()
        Me.chkSiteCode = New System.Windows.Forms.CheckBox()
        Me.chkLocation = New System.Windows.Forms.CheckBox()
        Me.chkLocCode = New System.Windows.Forms.CheckBox()
        Me.chkSource = New System.Windows.Forms.CheckBox()
        Me.chkSoucode = New System.Windows.Forms.CheckBox()
        Me.chkPriceGroup = New System.Windows.Forms.CheckBox()
        Me.chkMaterial = New System.Windows.Forms.CheckBox()
        Me.chkMatCode = New System.Windows.Forms.CheckBox()
        Me.chkCustName = New System.Windows.Forms.CheckBox()
        Me.chkCustcode = New System.Windows.Forms.CheckBox()
        Me.chkDriverMob = New System.Windows.Forms.CheckBox()
        Me.chkDriver = New System.Windows.Forms.CheckBox()
        Me.chkVehical = New System.Windows.Forms.CheckBox()
        Me.chkTicket = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtpTo = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpFrm = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rbObMatTick = New System.Windows.Forms.RadioButton()
        Me.rbObCustTick = New System.Windows.Forms.RadioButton()
        Me.rbObEntry = New System.Windows.Forms.RadioButton()
        Me.rbOb2ndDT = New System.Windows.Forms.RadioButton()
        Me.rbObTicket = New System.Windows.Forms.RadioButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnDeliveryReport = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbRptLook = New System.Windows.Forms.ComboBox()
        Me.txtCustcode = New System.Windows.Forms.TextBox()
        Me.btnSelCust = New System.Windows.Forms.Button()
        Me.btnMat = New System.Windows.Forms.Button()
        Me.txtMatCode = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSelsou = New System.Windows.Forms.Button()
        Me.txtSoucode = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnSelLoc = New System.Windows.Forms.Button()
        Me.txtLocCode = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnSelSite = New System.Windows.Forms.Button()
        Me.txtSiteCode = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmbCustType = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnSelVeh = New System.Windows.Forms.Button()
        Me.txtVehcode = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnCustMatCrReport = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtCustcodeTo = New System.Windows.Forms.TextBox()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rbRepCustMat)
        Me.GroupBox4.Controls.Add(Me.rbRepCustTick)
        Me.GroupBox4.Controls.Add(Me.rbRep1stTicket)
        Me.GroupBox4.Controls.Add(Me.rbRepMatTick)
        Me.GroupBox4.Controls.Add(Me.rbRepAllTickets)
        Me.GroupBox4.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox4.Location = New System.Drawing.Point(24, 24)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox4.Size = New System.Drawing.Size(225, 180)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Report"
        '
        'rbRepCustMat
        '
        Me.rbRepCustMat.AutoSize = True
        Me.rbRepCustMat.Location = New System.Drawing.Point(18, 141)
        Me.rbRepCustMat.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbRepCustMat.Name = "rbRepCustMat"
        Me.rbRepCustMat.Size = New System.Drawing.Size(182, 18)
        Me.rbRepCustMat.TabIndex = 4
        Me.rbRepCustMat.Text = "Customer / Material wise"
        Me.rbRepCustMat.UseVisualStyleBackColor = True
        Me.rbRepCustMat.Visible = False
        '
        'rbRepCustTick
        '
        Me.rbRepCustTick.AutoSize = True
        Me.rbRepCustTick.Location = New System.Drawing.Point(18, 85)
        Me.rbRepCustTick.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbRepCustTick.Name = "rbRepCustTick"
        Me.rbRepCustTick.Size = New System.Drawing.Size(119, 18)
        Me.rbRepCustTick.TabIndex = 2
        Me.rbRepCustTick.Text = "Customer wise"
        Me.rbRepCustTick.UseVisualStyleBackColor = True
        '
        'rbRep1stTicket
        '
        Me.rbRep1stTicket.AutoSize = True
        Me.rbRep1stTicket.Checked = True
        Me.rbRep1stTicket.Location = New System.Drawing.Point(18, 56)
        Me.rbRep1stTicket.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbRep1stTicket.Name = "rbRep1stTicket"
        Me.rbRep1stTicket.Size = New System.Drawing.Size(155, 18)
        Me.rbRep1stTicket.TabIndex = 1
        Me.rbRep1stTicket.TabStop = True
        Me.rbRep1stTicket.Text = "Tickets 1st Weighing"
        Me.rbRep1stTicket.UseVisualStyleBackColor = True
        '
        'rbRepMatTick
        '
        Me.rbRepMatTick.AutoSize = True
        Me.rbRepMatTick.Location = New System.Drawing.Point(18, 114)
        Me.rbRepMatTick.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbRepMatTick.Name = "rbRepMatTick"
        Me.rbRepMatTick.Size = New System.Drawing.Size(108, 18)
        Me.rbRepMatTick.TabIndex = 3
        Me.rbRepMatTick.Text = "Material wise"
        Me.rbRepMatTick.UseVisualStyleBackColor = True
        '
        'rbRepAllTickets
        '
        Me.rbRepAllTickets.AutoSize = True
        Me.rbRepAllTickets.Location = New System.Drawing.Point(18, 30)
        Me.rbRepAllTickets.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbRepAllTickets.Name = "rbRepAllTickets"
        Me.rbRepAllTickets.Size = New System.Drawing.Size(86, 18)
        Me.rbRepAllTickets.TabIndex = 0
        Me.rbRepAllTickets.Text = "All Tickets"
        Me.rbRepAllTickets.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkNetWeightTons)
        Me.GroupBox2.Controls.Add(Me.chkLastUpdate)
        Me.GroupBox2.Controls.Add(Me.chkNetWeight)
        Me.GroupBox2.Controls.Add(Me.chkPrepaidFlag)
        Me.GroupBox2.Controls.Add(Me.chkUserCancelled)
        Me.GroupBox2.Controls.Add(Me.chkFWdt)
        Me.GroupBox2.Controls.Add(Me.chkSyncFlag)
        Me.GroupBox2.Controls.Add(Me.chkUserID)
        Me.GroupBox2.Controls.Add(Me.chkUserModified)
        Me.GroupBox2.Controls.Add(Me.chkFirstTickNo)
        Me.GroupBox2.Controls.Add(Me.chkVehCode)
        Me.GroupBox2.Controls.Add(Me.chkDlvOrder)
        Me.GroupBox2.Controls.Add(Me.chkRemark)
        Me.GroupBox2.Controls.Add(Me.chkWtRemark)
        Me.GroupBox2.Controls.Add(Me.chkFWdate)
        Me.GroupBox2.Controls.Add(Me.chkCancelRemark)
        Me.GroupBox2.Controls.Add(Me.chkModifyRemark)
        Me.GroupBox2.Controls.Add(Me.chkSWdt)
        Me.GroupBox2.Controls.Add(Me.chkSWdate)
        Me.GroupBox2.Controls.Add(Me.chkSecondWt)
        Me.GroupBox2.Controls.Add(Me.chkFirstWt)
        Me.GroupBox2.Controls.Add(Me.chkWtType)
        Me.GroupBox2.Controls.Add(Me.chkInOut)
        Me.GroupBox2.Controls.Add(Me.chkSite)
        Me.GroupBox2.Controls.Add(Me.chkSiteCode)
        Me.GroupBox2.Controls.Add(Me.chkLocation)
        Me.GroupBox2.Controls.Add(Me.chkLocCode)
        Me.GroupBox2.Controls.Add(Me.chkSource)
        Me.GroupBox2.Controls.Add(Me.chkSoucode)
        Me.GroupBox2.Controls.Add(Me.chkPriceGroup)
        Me.GroupBox2.Controls.Add(Me.chkMaterial)
        Me.GroupBox2.Controls.Add(Me.chkMatCode)
        Me.GroupBox2.Controls.Add(Me.chkCustName)
        Me.GroupBox2.Controls.Add(Me.chkCustcode)
        Me.GroupBox2.Controls.Add(Me.chkDriverMob)
        Me.GroupBox2.Controls.Add(Me.chkDriver)
        Me.GroupBox2.Controls.Add(Me.chkVehical)
        Me.GroupBox2.Controls.Add(Me.chkTicket)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 318)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(790, 284)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Print Options"
        '
        'chkNetWeightTons
        '
        Me.chkNetWeightTons.AutoSize = True
        Me.chkNetWeightTons.Location = New System.Drawing.Point(299, 240)
        Me.chkNetWeightTons.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkNetWeightTons.Name = "chkNetWeightTons"
        Me.chkNetWeightTons.Size = New System.Drawing.Size(131, 18)
        Me.chkNetWeightTons.TabIndex = 37
        Me.chkNetWeightTons.Text = "Net Weight Tons"
        Me.chkNetWeightTons.UseVisualStyleBackColor = True
        '
        'chkLastUpdate
        '
        Me.chkLastUpdate.AutoSize = True
        Me.chkLastUpdate.Location = New System.Drawing.Point(450, 240)
        Me.chkLastUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkLastUpdate.Name = "chkLastUpdate"
        Me.chkLastUpdate.Size = New System.Drawing.Size(123, 18)
        Me.chkLastUpdate.TabIndex = 36
        Me.chkLastUpdate.Text = "Last Update DT"
        Me.chkLastUpdate.UseVisualStyleBackColor = True
        '
        'chkNetWeight
        '
        Me.chkNetWeight.AutoSize = True
        Me.chkNetWeight.Location = New System.Drawing.Point(299, 210)
        Me.chkNetWeight.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkNetWeight.Name = "chkNetWeight"
        Me.chkNetWeight.Size = New System.Drawing.Size(97, 18)
        Me.chkNetWeight.TabIndex = 35
        Me.chkNetWeight.Text = "Net Weight"
        Me.chkNetWeight.UseVisualStyleBackColor = True
        Me.chkNetWeight.Visible = False
        '
        'chkPrepaidFlag
        '
        Me.chkPrepaidFlag.AutoSize = True
        Me.chkPrepaidFlag.Location = New System.Drawing.Point(162, 60)
        Me.chkPrepaidFlag.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkPrepaidFlag.Name = "chkPrepaidFlag"
        Me.chkPrepaidFlag.Size = New System.Drawing.Size(104, 18)
        Me.chkPrepaidFlag.TabIndex = 34
        Me.chkPrepaidFlag.Text = "Prepaid Flag"
        Me.chkPrepaidFlag.UseVisualStyleBackColor = True
        '
        'chkUserCancelled
        '
        Me.chkUserCancelled.AutoSize = True
        Me.chkUserCancelled.Location = New System.Drawing.Point(623, 120)
        Me.chkUserCancelled.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkUserCancelled.Name = "chkUserCancelled"
        Me.chkUserCancelled.Size = New System.Drawing.Size(120, 18)
        Me.chkUserCancelled.TabIndex = 31
        Me.chkUserCancelled.Text = "User Cancelled"
        Me.chkUserCancelled.UseVisualStyleBackColor = True
        '
        'chkFWdt
        '
        Me.chkFWdt.AutoSize = True
        Me.chkFWdt.Location = New System.Drawing.Point(449, 60)
        Me.chkFWdt.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkFWdt.Name = "chkFWdt"
        Me.chkFWdt.Size = New System.Drawing.Size(107, 18)
        Me.chkFWdt.TabIndex = 22
        Me.chkFWdt.Text = "FW Datetime"
        Me.chkFWdt.UseVisualStyleBackColor = True
        '
        'chkSyncFlag
        '
        Me.chkSyncFlag.AutoSize = True
        Me.chkSyncFlag.Location = New System.Drawing.Point(623, 180)
        Me.chkSyncFlag.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSyncFlag.Name = "chkSyncFlag"
        Me.chkSyncFlag.Size = New System.Drawing.Size(85, 18)
        Me.chkSyncFlag.TabIndex = 33
        Me.chkSyncFlag.Text = "Sync Flag"
        Me.chkSyncFlag.UseVisualStyleBackColor = True
        '
        'chkUserID
        '
        Me.chkUserID.AutoSize = True
        Me.chkUserID.Location = New System.Drawing.Point(623, 30)
        Me.chkUserID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkUserID.Name = "chkUserID"
        Me.chkUserID.Size = New System.Drawing.Size(73, 18)
        Me.chkUserID.TabIndex = 28
        Me.chkUserID.Text = "User ID"
        Me.chkUserID.UseVisualStyleBackColor = True
        '
        'chkUserModified
        '
        Me.chkUserModified.AutoSize = True
        Me.chkUserModified.Location = New System.Drawing.Point(623, 60)
        Me.chkUserModified.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkUserModified.Name = "chkUserModified"
        Me.chkUserModified.Size = New System.Drawing.Size(111, 18)
        Me.chkUserModified.TabIndex = 29
        Me.chkUserModified.Text = "User Modified"
        Me.chkUserModified.UseVisualStyleBackColor = True
        '
        'chkFirstTickNo
        '
        Me.chkFirstTickNo.AutoSize = True
        Me.chkFirstTickNo.Checked = True
        Me.chkFirstTickNo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFirstTickNo.Location = New System.Drawing.Point(15, 60)
        Me.chkFirstTickNo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkFirstTickNo.Name = "chkFirstTickNo"
        Me.chkFirstTickNo.Size = New System.Drawing.Size(106, 18)
        Me.chkFirstTickNo.TabIndex = 1
        Me.chkFirstTickNo.Text = "FirstTicketNo"
        Me.chkFirstTickNo.UseVisualStyleBackColor = True
        '
        'chkVehCode
        '
        Me.chkVehCode.AutoSize = True
        Me.chkVehCode.Checked = True
        Me.chkVehCode.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkVehCode.Location = New System.Drawing.Point(15, 90)
        Me.chkVehCode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkVehCode.Name = "chkVehCode"
        Me.chkVehCode.Size = New System.Drawing.Size(107, 18)
        Me.chkVehCode.TabIndex = 2
        Me.chkVehCode.Text = "Vehicle Code"
        Me.chkVehCode.UseVisualStyleBackColor = True
        '
        'chkDlvOrder
        '
        Me.chkDlvOrder.AutoSize = True
        Me.chkDlvOrder.Location = New System.Drawing.Point(450, 180)
        Me.chkDlvOrder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDlvOrder.Name = "chkDlvOrder"
        Me.chkDlvOrder.Size = New System.Drawing.Size(116, 18)
        Me.chkDlvOrder.TabIndex = 26
        Me.chkDlvOrder.Text = "Delivery Order"
        Me.chkDlvOrder.UseVisualStyleBackColor = True
        '
        'chkRemark
        '
        Me.chkRemark.AutoSize = True
        Me.chkRemark.Location = New System.Drawing.Point(450, 210)
        Me.chkRemark.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkRemark.Name = "chkRemark"
        Me.chkRemark.Size = New System.Drawing.Size(73, 18)
        Me.chkRemark.TabIndex = 27
        Me.chkRemark.Text = "Remark"
        Me.chkRemark.UseVisualStyleBackColor = True
        '
        'chkWtRemark
        '
        Me.chkWtRemark.AutoSize = True
        Me.chkWtRemark.Location = New System.Drawing.Point(450, 150)
        Me.chkWtRemark.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkWtRemark.Name = "chkWtRemark"
        Me.chkWtRemark.Size = New System.Drawing.Size(95, 18)
        Me.chkWtRemark.TabIndex = 25
        Me.chkWtRemark.Text = "Wt Remark"
        Me.chkWtRemark.UseVisualStyleBackColor = True
        '
        'chkFWdate
        '
        Me.chkFWdate.AutoSize = True
        Me.chkFWdate.Location = New System.Drawing.Point(449, 30)
        Me.chkFWdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkFWdate.Name = "chkFWdate"
        Me.chkFWdate.Size = New System.Drawing.Size(80, 18)
        Me.chkFWdate.TabIndex = 21
        Me.chkFWdate.Text = "FW Date"
        Me.chkFWdate.UseVisualStyleBackColor = True
        '
        'chkCancelRemark
        '
        Me.chkCancelRemark.AutoSize = True
        Me.chkCancelRemark.Location = New System.Drawing.Point(623, 150)
        Me.chkCancelRemark.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkCancelRemark.Name = "chkCancelRemark"
        Me.chkCancelRemark.Size = New System.Drawing.Size(119, 18)
        Me.chkCancelRemark.TabIndex = 32
        Me.chkCancelRemark.Text = "Cancel Remark"
        Me.chkCancelRemark.UseVisualStyleBackColor = True
        '
        'chkModifyRemark
        '
        Me.chkModifyRemark.AutoSize = True
        Me.chkModifyRemark.Location = New System.Drawing.Point(623, 90)
        Me.chkModifyRemark.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkModifyRemark.Name = "chkModifyRemark"
        Me.chkModifyRemark.Size = New System.Drawing.Size(117, 18)
        Me.chkModifyRemark.TabIndex = 30
        Me.chkModifyRemark.Text = "Modify Remark"
        Me.chkModifyRemark.UseVisualStyleBackColor = True
        '
        'chkSWdt
        '
        Me.chkSWdt.AutoSize = True
        Me.chkSWdt.Checked = True
        Me.chkSWdt.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSWdt.Location = New System.Drawing.Point(450, 120)
        Me.chkSWdt.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSWdt.Name = "chkSWdt"
        Me.chkSWdt.Size = New System.Drawing.Size(108, 18)
        Me.chkSWdt.TabIndex = 24
        Me.chkSWdt.Text = "SW Datetime"
        Me.chkSWdt.UseVisualStyleBackColor = True
        '
        'chkSWdate
        '
        Me.chkSWdate.AutoSize = True
        Me.chkSWdate.Checked = True
        Me.chkSWdate.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSWdate.Location = New System.Drawing.Point(450, 90)
        Me.chkSWdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSWdate.Name = "chkSWdate"
        Me.chkSWdate.Size = New System.Drawing.Size(81, 18)
        Me.chkSWdate.TabIndex = 23
        Me.chkSWdate.Text = "SW Date"
        Me.chkSWdate.UseVisualStyleBackColor = True
        '
        'chkSecondWt
        '
        Me.chkSecondWt.AutoSize = True
        Me.chkSecondWt.Location = New System.Drawing.Point(299, 180)
        Me.chkSecondWt.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSecondWt.Name = "chkSecondWt"
        Me.chkSecondWt.Size = New System.Drawing.Size(121, 18)
        Me.chkSecondWt.TabIndex = 20
        Me.chkSecondWt.Text = "Second Weight"
        Me.chkSecondWt.UseVisualStyleBackColor = True
        '
        'chkFirstWt
        '
        Me.chkFirstWt.AutoSize = True
        Me.chkFirstWt.Checked = True
        Me.chkFirstWt.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFirstWt.Location = New System.Drawing.Point(299, 150)
        Me.chkFirstWt.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkFirstWt.Name = "chkFirstWt"
        Me.chkFirstWt.Size = New System.Drawing.Size(102, 18)
        Me.chkFirstWt.TabIndex = 19
        Me.chkFirstWt.Text = "First Weight"
        Me.chkFirstWt.UseVisualStyleBackColor = True
        '
        'chkWtType
        '
        Me.chkWtType.AutoSize = True
        Me.chkWtType.Location = New System.Drawing.Point(299, 120)
        Me.chkWtType.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkWtType.Name = "chkWtType"
        Me.chkWtType.Size = New System.Drawing.Size(100, 18)
        Me.chkWtType.TabIndex = 18
        Me.chkWtType.Text = "Weigh Type"
        Me.chkWtType.UseVisualStyleBackColor = True
        '
        'chkInOut
        '
        Me.chkInOut.AutoSize = True
        Me.chkInOut.Location = New System.Drawing.Point(300, 90)
        Me.chkInOut.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkInOut.Name = "chkInOut"
        Me.chkInOut.Size = New System.Drawing.Size(75, 18)
        Me.chkInOut.TabIndex = 17
        Me.chkInOut.Text = "In / Out"
        Me.chkInOut.UseVisualStyleBackColor = True
        '
        'chkSite
        '
        Me.chkSite.AutoSize = True
        Me.chkSite.Location = New System.Drawing.Point(300, 60)
        Me.chkSite.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSite.Name = "chkSite"
        Me.chkSite.Size = New System.Drawing.Size(50, 18)
        Me.chkSite.TabIndex = 16
        Me.chkSite.Text = "Site"
        Me.chkSite.UseVisualStyleBackColor = True
        '
        'chkSiteCode
        '
        Me.chkSiteCode.AutoSize = True
        Me.chkSiteCode.Location = New System.Drawing.Point(300, 30)
        Me.chkSiteCode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSiteCode.Name = "chkSiteCode"
        Me.chkSiteCode.Size = New System.Drawing.Size(87, 18)
        Me.chkSiteCode.TabIndex = 15
        Me.chkSiteCode.Text = "Site Code"
        Me.chkSiteCode.UseVisualStyleBackColor = True
        '
        'chkLocation
        '
        Me.chkLocation.AutoSize = True
        Me.chkLocation.Checked = True
        Me.chkLocation.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLocation.Location = New System.Drawing.Point(162, 240)
        Me.chkLocation.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkLocation.Name = "chkLocation"
        Me.chkLocation.Size = New System.Drawing.Size(79, 18)
        Me.chkLocation.TabIndex = 14
        Me.chkLocation.Text = "Location"
        Me.chkLocation.UseVisualStyleBackColor = True
        '
        'chkLocCode
        '
        Me.chkLocCode.AutoSize = True
        Me.chkLocCode.Location = New System.Drawing.Point(162, 210)
        Me.chkLocCode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkLocCode.Name = "chkLocCode"
        Me.chkLocCode.Size = New System.Drawing.Size(81, 18)
        Me.chkLocCode.TabIndex = 13
        Me.chkLocCode.Text = "Loc code"
        Me.chkLocCode.UseVisualStyleBackColor = True
        '
        'chkSource
        '
        Me.chkSource.AutoSize = True
        Me.chkSource.Location = New System.Drawing.Point(162, 180)
        Me.chkSource.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSource.Name = "chkSource"
        Me.chkSource.Size = New System.Drawing.Size(69, 18)
        Me.chkSource.TabIndex = 12
        Me.chkSource.Text = "Source"
        Me.chkSource.UseVisualStyleBackColor = True
        '
        'chkSoucode
        '
        Me.chkSoucode.AutoSize = True
        Me.chkSoucode.Location = New System.Drawing.Point(162, 150)
        Me.chkSoucode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSoucode.Name = "chkSoucode"
        Me.chkSoucode.Size = New System.Drawing.Size(87, 18)
        Me.chkSoucode.TabIndex = 11
        Me.chkSoucode.Text = "Sou Code"
        Me.chkSoucode.UseVisualStyleBackColor = True
        '
        'chkPriceGroup
        '
        Me.chkPriceGroup.AutoSize = True
        Me.chkPriceGroup.Checked = True
        Me.chkPriceGroup.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPriceGroup.Location = New System.Drawing.Point(162, 30)
        Me.chkPriceGroup.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkPriceGroup.Name = "chkPriceGroup"
        Me.chkPriceGroup.Size = New System.Drawing.Size(98, 18)
        Me.chkPriceGroup.TabIndex = 10
        Me.chkPriceGroup.Text = "Price Group"
        Me.chkPriceGroup.UseVisualStyleBackColor = True
        '
        'chkMaterial
        '
        Me.chkMaterial.AutoSize = True
        Me.chkMaterial.Location = New System.Drawing.Point(162, 120)
        Me.chkMaterial.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkMaterial.Name = "chkMaterial"
        Me.chkMaterial.Size = New System.Drawing.Size(76, 18)
        Me.chkMaterial.TabIndex = 9
        Me.chkMaterial.Text = "Material"
        Me.chkMaterial.UseVisualStyleBackColor = True
        '
        'chkMatCode
        '
        Me.chkMatCode.AutoSize = True
        Me.chkMatCode.Location = New System.Drawing.Point(162, 90)
        Me.chkMatCode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkMatCode.Name = "chkMatCode"
        Me.chkMatCode.Size = New System.Drawing.Size(83, 18)
        Me.chkMatCode.TabIndex = 8
        Me.chkMatCode.Text = "Mat code"
        Me.chkMatCode.UseVisualStyleBackColor = True
        '
        'chkCustName
        '
        Me.chkCustName.AutoSize = True
        Me.chkCustName.Location = New System.Drawing.Point(15, 240)
        Me.chkCustName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkCustName.Name = "chkCustName"
        Me.chkCustName.Size = New System.Drawing.Size(87, 18)
        Me.chkCustName.TabIndex = 7
        Me.chkCustName.Text = "Customer"
        Me.chkCustName.UseVisualStyleBackColor = True
        '
        'chkCustcode
        '
        Me.chkCustcode.AutoSize = True
        Me.chkCustcode.Checked = True
        Me.chkCustcode.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCustcode.Location = New System.Drawing.Point(15, 210)
        Me.chkCustcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkCustcode.Name = "chkCustcode"
        Me.chkCustcode.Size = New System.Drawing.Size(92, 18)
        Me.chkCustcode.TabIndex = 6
        Me.chkCustcode.Text = "Cust Code"
        Me.chkCustcode.UseVisualStyleBackColor = True
        '
        'chkDriverMob
        '
        Me.chkDriverMob.AutoSize = True
        Me.chkDriverMob.Location = New System.Drawing.Point(15, 180)
        Me.chkDriverMob.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDriverMob.Name = "chkDriverMob"
        Me.chkDriverMob.Size = New System.Drawing.Size(107, 18)
        Me.chkDriverMob.TabIndex = 5
        Me.chkDriverMob.Text = "Driver Mobile"
        Me.chkDriverMob.UseVisualStyleBackColor = True
        '
        'chkDriver
        '
        Me.chkDriver.AutoSize = True
        Me.chkDriver.Location = New System.Drawing.Point(15, 150)
        Me.chkDriver.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDriver.Name = "chkDriver"
        Me.chkDriver.Size = New System.Drawing.Size(63, 18)
        Me.chkDriver.TabIndex = 4
        Me.chkDriver.Text = "Driver"
        Me.chkDriver.UseVisualStyleBackColor = True
        '
        'chkVehical
        '
        Me.chkVehical.AutoSize = True
        Me.chkVehical.Checked = True
        Me.chkVehical.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkVehical.Location = New System.Drawing.Point(15, 120)
        Me.chkVehical.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkVehical.Name = "chkVehical"
        Me.chkVehical.Size = New System.Drawing.Size(100, 18)
        Me.chkVehical.TabIndex = 3
        Me.chkVehical.Text = "Transporter"
        Me.chkVehical.UseVisualStyleBackColor = True
        '
        'chkTicket
        '
        Me.chkTicket.AutoSize = True
        Me.chkTicket.Location = New System.Drawing.Point(15, 30)
        Me.chkTicket.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkTicket.Name = "chkTicket"
        Me.chkTicket.Size = New System.Drawing.Size(83, 18)
        Me.chkTicket.TabIndex = 0
        Me.chkTicket.Text = "Ticket No"
        Me.chkTicket.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpTo)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.dtpFrm)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(273, 24)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(273, 114)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dates"
        '
        'dtpTo
        '
        Me.dtpTo.CustomFormat = "dd/MM/yyyy HH:mm"
        Me.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTo.Location = New System.Drawing.Point(67, 71)
        Me.dtpTo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dtpTo.Name = "dtpTo"
        Me.dtpTo.Size = New System.Drawing.Size(190, 22)
        Me.dtpTo.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(22, 14)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "To"
        '
        'dtpFrm
        '
        Me.dtpFrm.CustomFormat = "dd/MM/yyyy HH:mm"
        Me.dtpFrm.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFrm.Location = New System.Drawing.Point(67, 32)
        Me.dtpFrm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dtpFrm.Name = "dtpFrm"
        Me.dtpFrm.Size = New System.Drawing.Size(190, 22)
        Me.dtpFrm.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 14)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "From"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbObMatTick)
        Me.GroupBox3.Controls.Add(Me.rbObCustTick)
        Me.GroupBox3.Controls.Add(Me.rbObEntry)
        Me.GroupBox3.Controls.Add(Me.rbOb2ndDT)
        Me.GroupBox3.Controls.Add(Me.rbObTicket)
        Me.GroupBox3.ForeColor = System.Drawing.Color.Indigo
        Me.GroupBox3.Location = New System.Drawing.Point(827, 300)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox3.Size = New System.Drawing.Size(273, 188)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Order by"
        '
        'rbObMatTick
        '
        Me.rbObMatTick.AutoSize = True
        Me.rbObMatTick.Location = New System.Drawing.Point(17, 129)
        Me.rbObMatTick.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbObMatTick.Name = "rbObMatTick"
        Me.rbObMatTick.Size = New System.Drawing.Size(138, 18)
        Me.rbObMatTick.TabIndex = 4
        Me.rbObMatTick.TabStop = True
        Me.rbObMatTick.Text = "Material / Ticket #"
        Me.rbObMatTick.UseVisualStyleBackColor = True
        '
        'rbObCustTick
        '
        Me.rbObCustTick.AutoSize = True
        Me.rbObCustTick.Location = New System.Drawing.Point(17, 103)
        Me.rbObCustTick.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbObCustTick.Name = "rbObCustTick"
        Me.rbObCustTick.Size = New System.Drawing.Size(149, 18)
        Me.rbObCustTick.TabIndex = 3
        Me.rbObCustTick.TabStop = True
        Me.rbObCustTick.Text = "Customer / Ticket #"
        Me.rbObCustTick.UseVisualStyleBackColor = True
        '
        'rbObEntry
        '
        Me.rbObEntry.AutoSize = True
        Me.rbObEntry.Location = New System.Drawing.Point(17, 77)
        Me.rbObEntry.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbObEntry.Name = "rbObEntry"
        Me.rbObEntry.Size = New System.Drawing.Size(119, 18)
        Me.rbObEntry.TabIndex = 2
        Me.rbObEntry.TabStop = True
        Me.rbObEntry.Text = "Entry Datetime"
        Me.rbObEntry.UseVisualStyleBackColor = True
        '
        'rbOb2ndDT
        '
        Me.rbOb2ndDT.AutoSize = True
        Me.rbOb2ndDT.Location = New System.Drawing.Point(17, 51)
        Me.rbOb2ndDT.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbOb2ndDT.Name = "rbOb2ndDT"
        Me.rbOb2ndDT.Size = New System.Drawing.Size(132, 18)
        Me.rbOb2ndDT.TabIndex = 1
        Me.rbOb2ndDT.TabStop = True
        Me.rbOb2ndDT.Text = "2nd Wt Datetime"
        Me.rbOb2ndDT.UseVisualStyleBackColor = True
        '
        'rbObTicket
        '
        Me.rbObTicket.AutoSize = True
        Me.rbObTicket.Checked = True
        Me.rbObTicket.Location = New System.Drawing.Point(17, 25)
        Me.rbObTicket.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbObTicket.Name = "rbObTicket"
        Me.rbObTicket.Size = New System.Drawing.Size(75, 18)
        Me.rbObTicket.TabIndex = 0
        Me.rbObTicket.TabStop = True
        Me.rbObTicket.Text = "Ticket #"
        Me.rbObTicket.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1028, 561)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(72, 33)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnDeliveryReport
        '
        Me.btnDeliveryReport.Location = New System.Drawing.Point(827, 496)
        Me.btnDeliveryReport.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnDeliveryReport.Name = "btnDeliveryReport"
        Me.btnDeliveryReport.Size = New System.Drawing.Size(185, 45)
        Me.btnDeliveryReport.TabIndex = 4
        Me.btnDeliveryReport.Text = "Generate Report"
        Me.btnDeliveryReport.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(842, 180)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 14)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Report Style"
        '
        'cmbRptLook
        '
        Me.cmbRptLook.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRptLook.FormattingEnabled = True
        Me.cmbRptLook.Location = New System.Drawing.Point(950, 177)
        Me.cmbRptLook.Name = "cmbRptLook"
        Me.cmbRptLook.Size = New System.Drawing.Size(68, 22)
        Me.cmbRptLook.TabIndex = 7
        '
        'txtCustcode
        '
        Me.txtCustcode.Location = New System.Drawing.Point(86, 28)
        Me.txtCustcode.Name = "txtCustcode"
        Me.txtCustcode.Size = New System.Drawing.Size(103, 22)
        Me.txtCustcode.TabIndex = 9
        '
        'btnSelCust
        '
        Me.btnSelCust.Location = New System.Drawing.Point(144, 84)
        Me.btnSelCust.Name = "btnSelCust"
        Me.btnSelCust.Size = New System.Drawing.Size(45, 27)
        Me.btnSelCust.TabIndex = 10
        Me.btnSelCust.Text = "---"
        Me.btnSelCust.UseVisualStyleBackColor = True
        '
        'btnMat
        '
        Me.btnMat.Location = New System.Drawing.Point(761, 169)
        Me.btnMat.Name = "btnMat"
        Me.btnMat.Size = New System.Drawing.Size(45, 27)
        Me.btnMat.TabIndex = 13
        Me.btnMat.Text = "---"
        Me.btnMat.UseVisualStyleBackColor = True
        '
        'txtMatCode
        '
        Me.txtMatCode.Location = New System.Drawing.Point(652, 174)
        Me.txtMatCode.Name = "txtMatCode"
        Me.txtMatCode.Size = New System.Drawing.Size(103, 22)
        Me.txtMatCode.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(575, 177)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 14)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Material"
        '
        'btnSelsou
        '
        Me.btnSelsou.Location = New System.Drawing.Point(761, 222)
        Me.btnSelsou.Name = "btnSelsou"
        Me.btnSelsou.Size = New System.Drawing.Size(45, 27)
        Me.btnSelsou.TabIndex = 16
        Me.btnSelsou.Text = "---"
        Me.btnSelsou.UseVisualStyleBackColor = True
        '
        'txtSoucode
        '
        Me.txtSoucode.Location = New System.Drawing.Point(652, 227)
        Me.txtSoucode.Name = "txtSoucode"
        Me.txtSoucode.Size = New System.Drawing.Size(103, 22)
        Me.txtSoucode.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(575, 210)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(137, 14)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Source / Transporter"
        '
        'btnSelLoc
        '
        Me.btnSelLoc.Location = New System.Drawing.Point(1010, 51)
        Me.btnSelLoc.Name = "btnSelLoc"
        Me.btnSelLoc.Size = New System.Drawing.Size(45, 27)
        Me.btnSelLoc.TabIndex = 19
        Me.btnSelLoc.Text = "---"
        Me.btnSelLoc.UseVisualStyleBackColor = True
        '
        'txtLocCode
        '
        Me.txtLocCode.Location = New System.Drawing.Point(901, 56)
        Me.txtLocCode.Name = "txtLocCode"
        Me.txtLocCode.Size = New System.Drawing.Size(103, 22)
        Me.txtLocCode.TabIndex = 18
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(824, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(145, 14)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Location / Destination"
        '
        'btnSelSite
        '
        Me.btnSelSite.Location = New System.Drawing.Point(1009, 92)
        Me.btnSelSite.Name = "btnSelSite"
        Me.btnSelSite.Size = New System.Drawing.Size(45, 27)
        Me.btnSelSite.TabIndex = 22
        Me.btnSelSite.Text = "---"
        Me.btnSelSite.UseVisualStyleBackColor = True
        '
        'txtSiteCode
        '
        Me.txtSiteCode.Location = New System.Drawing.Point(900, 97)
        Me.txtSiteCode.Name = "txtSiteCode"
        Me.txtSiteCode.Size = New System.Drawing.Size(103, 22)
        Me.txtSiteCode.TabIndex = 21
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(823, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 14)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Site"
        '
        'cmbCustType
        '
        Me.cmbCustType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCustType.FormattingEnabled = True
        Me.cmbCustType.Location = New System.Drawing.Point(351, 145)
        Me.cmbCustType.Name = "cmbCustType"
        Me.cmbCustType.Size = New System.Drawing.Size(195, 22)
        Me.cmbCustType.TabIndex = 40
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(274, 149)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(70, 14)
        Me.Label18.TabIndex = 39
        Me.Label18.Text = "Cust Type"
        '
        'btnSelVeh
        '
        Me.btnSelVeh.Location = New System.Drawing.Point(1010, 136)
        Me.btnSelVeh.Name = "btnSelVeh"
        Me.btnSelVeh.Size = New System.Drawing.Size(45, 27)
        Me.btnSelVeh.TabIndex = 43
        Me.btnSelVeh.Text = "---"
        Me.btnSelVeh.UseVisualStyleBackColor = True
        '
        'txtVehcode
        '
        Me.txtVehcode.Location = New System.Drawing.Point(901, 141)
        Me.txtVehcode.Name = "txtVehcode"
        Me.txtVehcode.Size = New System.Drawing.Size(103, 22)
        Me.txtVehcode.TabIndex = 42
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(824, 144)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(51, 14)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "Vehicle"
        '
        'btnCustMatCrReport
        '
        Me.btnCustMatCrReport.Location = New System.Drawing.Point(827, 555)
        Me.btnCustMatCrReport.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCustMatCrReport.Name = "btnCustMatCrReport"
        Me.btnCustMatCrReport.Size = New System.Drawing.Size(185, 45)
        Me.btnCustMatCrReport.TabIndex = 44
        Me.btnCustMatCrReport.Text = "Cust / Mat Report"
        Me.btnCustMatCrReport.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtCustcodeTo)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.txtCustcode)
        Me.GroupBox5.Controls.Add(Me.btnSelCust)
        Me.GroupBox5.Location = New System.Drawing.Point(574, 24)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(200, 131)
        Me.GroupBox5.TabIndex = 46
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Customer"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(22, 14)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "To"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(20, 31)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(38, 14)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "From"
        '
        'txtCustcodeTo
        '
        Me.txtCustcodeTo.Location = New System.Drawing.Point(86, 56)
        Me.txtCustcodeTo.Name = "txtCustcodeTo"
        Me.txtCustcodeTo.Size = New System.Drawing.Size(103, 22)
        Me.txtCustcodeTo.TabIndex = 13
        '
        'frmTrnReports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1249, 592)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.btnCustMatCrReport)
        Me.Controls.Add(Me.btnSelVeh)
        Me.Controls.Add(Me.txtVehcode)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cmbCustType)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.btnSelSite)
        Me.Controls.Add(Me.txtSiteCode)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnSelLoc)
        Me.Controls.Add(Me.txtLocCode)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnSelsou)
        Me.Controls.Add(Me.txtSoucode)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnMat)
        Me.Controls.Add(Me.txtMatCode)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cmbRptLook)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnDeliveryReport)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox4)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "frmTrnReports"
        Me.Text = "Transaction Reports"
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents rbRepCustTick As System.Windows.Forms.RadioButton
    Friend WithEvents rbRep1stTicket As System.Windows.Forms.RadioButton
    Friend WithEvents rbRepMatTick As System.Windows.Forms.RadioButton
    Friend WithEvents rbRepAllTickets As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents chkFWdt As System.Windows.Forms.CheckBox
    Friend WithEvents chkSyncFlag As System.Windows.Forms.CheckBox
    Friend WithEvents chkUserID As System.Windows.Forms.CheckBox
    Friend WithEvents chkUserModified As System.Windows.Forms.CheckBox
    Friend WithEvents chkFirstTickNo As System.Windows.Forms.CheckBox
    Friend WithEvents chkVehCode As System.Windows.Forms.CheckBox
    Friend WithEvents chkDlvOrder As System.Windows.Forms.CheckBox
    Friend WithEvents chkRemark As System.Windows.Forms.CheckBox
    Friend WithEvents chkWtRemark As System.Windows.Forms.CheckBox
    Friend WithEvents chkFWdate As System.Windows.Forms.CheckBox
    Friend WithEvents chkCancelRemark As System.Windows.Forms.CheckBox
    Friend WithEvents chkModifyRemark As System.Windows.Forms.CheckBox
    Friend WithEvents chkSWdt As System.Windows.Forms.CheckBox
    Friend WithEvents chkSWdate As System.Windows.Forms.CheckBox
    Friend WithEvents chkSecondWt As System.Windows.Forms.CheckBox
    Friend WithEvents chkFirstWt As System.Windows.Forms.CheckBox
    Friend WithEvents chkWtType As System.Windows.Forms.CheckBox
    Friend WithEvents chkInOut As System.Windows.Forms.CheckBox
    Friend WithEvents chkSite As System.Windows.Forms.CheckBox
    Friend WithEvents chkSiteCode As System.Windows.Forms.CheckBox
    Friend WithEvents chkLocation As System.Windows.Forms.CheckBox
    Friend WithEvents chkLocCode As System.Windows.Forms.CheckBox
    Friend WithEvents chkSource As System.Windows.Forms.CheckBox
    Friend WithEvents chkSoucode As System.Windows.Forms.CheckBox
    Friend WithEvents chkPriceGroup As System.Windows.Forms.CheckBox
    Friend WithEvents chkMaterial As System.Windows.Forms.CheckBox
    Friend WithEvents chkMatCode As System.Windows.Forms.CheckBox
    Friend WithEvents chkCustName As System.Windows.Forms.CheckBox
    Friend WithEvents chkCustcode As System.Windows.Forms.CheckBox
    Friend WithEvents chkDriverMob As System.Windows.Forms.CheckBox
    Friend WithEvents chkDriver As System.Windows.Forms.CheckBox
    Friend WithEvents chkVehical As System.Windows.Forms.CheckBox
    Friend WithEvents chkTicket As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtpFrm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbObMatTick As System.Windows.Forms.RadioButton
    Friend WithEvents rbObCustTick As System.Windows.Forms.RadioButton
    Friend WithEvents rbObEntry As System.Windows.Forms.RadioButton
    Friend WithEvents rbOb2ndDT As System.Windows.Forms.RadioButton
    Friend WithEvents rbObTicket As System.Windows.Forms.RadioButton
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnDeliveryReport As System.Windows.Forms.Button
    Friend WithEvents chkUserCancelled As System.Windows.Forms.CheckBox
    Friend WithEvents chkPrepaidFlag As System.Windows.Forms.CheckBox
    Friend WithEvents chkNetWeight As System.Windows.Forms.CheckBox
    Friend WithEvents chkLastUpdate As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbRptLook As System.Windows.Forms.ComboBox
    Friend WithEvents txtCustcode As System.Windows.Forms.TextBox
    Friend WithEvents btnSelCust As System.Windows.Forms.Button
    Friend WithEvents btnMat As System.Windows.Forms.Button
    Friend WithEvents txtMatCode As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnSelsou As System.Windows.Forms.Button
    Friend WithEvents txtSoucode As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnSelLoc As System.Windows.Forms.Button
    Friend WithEvents txtLocCode As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnSelSite As System.Windows.Forms.Button
    Friend WithEvents txtSiteCode As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmbCustType As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents rbRepCustMat As System.Windows.Forms.RadioButton
    Friend WithEvents btnSelVeh As System.Windows.Forms.Button
    Friend WithEvents txtVehcode As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnCustMatCrReport As System.Windows.Forms.Button
    Friend WithEvents chkNetWeightTons As CheckBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents txtCustcodeTo As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label10 As Label
End Class
