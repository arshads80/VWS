﻿Public Class frmUserAccess


    Dim Accesscode As String

    Private chk(100) As System.Windows.Forms.CheckBox
    'Private chkList As List(Of CheckBox)


    Public Function showDialog_frmUserAccess(ByVal uid As String, ByVal prmAccessCode As String) As String

        Me.txtUserID.Text = uid

        Accesscode = prmAccessCode

        ' Dim tp As Integer
        'tp = 50

        'Dim lt As Integer
        'lt = 50

        For i As Integer = 1 To enUAcs.AccessTotal - 1

            chk(i) = New System.Windows.Forms.CheckBox
            '   tp = tp + 30
            'chk(i).Top = tp   ' 50 + i * 30
            'chk(i).Left = lt
            chk(i).Width = 300
            chk(i).Name = "chk" & i
            chk(i).Tag = i
            chk(i).Text = [Enum].GetName(GetType(enUAcs), i)
            If chk(i).Text = "" Then
                Me.chk(i).Visible = False
            End If
            Me.FlowLayoutPanel1.Controls.Add(chk(i))

            'If i = 10 Or i = 20 Then
            '    tp = 50
            '    lt = lt + 300
            'End If

            If Accesscode.Length >= i Then

                If Mid(Accesscode, i, 1) = "1" Then
                    chk(i).Checked = True
                Else
                    chk(i).Checked = False
                End If

            Else
                Accesscode = Accesscode & "0"
            End If

            '       chkList.Add(chk(i))

            AddHandler chk(i).CheckedChanged, AddressOf ChkCheckedChanged


        Next i

        ShowDialog()

        showDialog_frmUserAccess = Accesscode

    End Function




    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Accesscode = ""
        Me.Close()

    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Accesscode = ""
        For i = 1 To enUAcs.AccessTotal - 1
            If chk(i).Checked Then
                Accesscode = Accesscode & "1"
            Else
                Accesscode = Accesscode & "0"
            End If
        Next

        Me.Close()

    End Sub

    Private Sub ChkCheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged

        '        MsgBox(DirectCast(sender, CheckBox).Name)
        Dim ci As String
        ci = DirectCast(sender, CheckBox).Tag

        Dim v As Integer

        Dim b(100) As Integer


        If IsNumeric(ci) Then

            If DirectCast(sender, CheckBox).Checked Then
                v = 1
            Else
                v = 0
            End If

            Dim i As Integer
            For i = 1 To enUAcs.AccessTotal - 1
                b(i) = Mid(Accesscode, i, 1)
            Next

            b(ci) = v

            'Accesscode = Accesscode.Remove(ci, 1).Insert(ci - 1, v)

            Accesscode = ""
            For i = 1 To enUAcs.AccessTotal - 1
                Accesscode = Accesscode & b(i)
            Next

        End If


    End Sub

    Private Sub frmUserAccess_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnSelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelAll.Click

        Dim c As CheckBox
        For Each c In FlowLayoutPanel1.Controls
            c.Checked = True
        Next


    End Sub

End Class