﻿Imports System.Math
Imports System.Data
Imports System.Data.OleDb

Public Class frmEditTicket

    Dim tikno As Long

    Dim droldrec As DataRow

    Dim isfirstTick As Boolean

    Public Sub ShowDialog_EditTicket(ByVal prmTickno As Long, ByVal prmisFirstTick As Boolean)

        tikno = prmTickno
        isfirstTick = prmisFirstTick

        ShowDialog()

    End Sub

    Private Sub frmEditTicket_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim s As String
        s = "Select RemDescription from tblRemarks order by RemDescription"

        msFillGroupCombo(s, Me.cmbRemark, 0, , True)

        Me.cmbRemark.Items.Insert(0, " ")

        Me.cmbRemark.SelectedIndex = 0

        getTickInfo()

    End Sub

    Private Sub getTickInfo()

        Dim dt As String

        Dim s As String
        If isfirstTick Then
            s = "Select * from tblWeighing where FirstTicketNo = " & tikno
            s = s & " and weightype = 1 and canflag = 0"

            dt = Format(DateAdd(DateInterval.Month, -1, Date.Today), "yyyy-MM-dd")
            s = s & " and FWDatetime >= '" & dt & "'"

        Else
            s = "Select * from tblWeighing where TicketNo = " & tikno
            s = s & " and weightype <> 1 and canflag = 0"

            dt = Format(DateAdd(DateInterval.Month, -1, Date.Today), "yyyy-MM-dd")
            s = s & " and SWDatetime >= '" & dt & "'"
        End If
        
        'Select * from tblweighing where FirstTicketNo = " & Val(txtTickNo.Text.Trim) & " and WeighType = 1 and CanFlag = 0


        Dim ds As New DataSet

        Dim w As String
        w = msFillDS(s, ds)

        If Not IsNumeric(w) Then
            MsgBox("Error 160912 " & w)
            Me.Close()
            Exit Sub
        End If

        If ds.Tables(0).Rows.Count <= 0 Then
            MsgBox("Record not found", MsgBoxStyle.Exclamation)
            Me.Close()
            Exit Sub
        End If

        Dim dr As DataRow
        dr = ds.Tables(0).Rows(0)
        droldrec = ds.Tables(0).Rows(0)

        txtFwt.Text = dr("FWeight")
        txtSwt.Text = dr("SWeight")
        txtNwt.Text = dr("NWeight")

        Me.txtTicketNo.Text = dr("TicketNo")

        Me.txtVehCode.Text = dr("VehCode")
        lblVehical.Text = dr("VehName")
        txtDriver.Text = dr("DriverName")
        txtMobile.Text = dr("DriverMob")

        If dr("InOut") = "I" Then
            rbIn.Checked = True
        Else
            rbOut.Checked = True
        End If

        txtCustcode.Text = dr("Custcode")
        lblCustName.Text = dr("CustName")
        lblCustType.Text = dr("CustType")

        txtMatCode.Text = dr("Matcode")
        lblMatName.Text = dr("MatName")

        txtSouCode.Text = dr("SouCode")
        lblSouName.Text = dr("SouName")

        txtLocCode.Text = dr("Loccode")
        lblLocName.Text = dr("LocName")

        txtSiteCode.Text = dr("SiteCode")
        lblSiteName.Text = dr("SiteName")

        txtDlvOrder.Text = dr("DeliveryOrder")
        txtRemark.Text = dr("Remarks")

        Sysvars.WtType = dr("WeighType")

        GetCustDetails()


    End Sub

    Private Sub btnSelVeh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelVeh.Click

        Dim vc As String

        Dim frmv As New frmVehicalSearch
        vc = frmv.ShowDialog_VehicleSearch("", True, True)
        If vc <> "" Then

            Me.txtVehCode.Text = vc

            ' If Sysvars.WtType = 1 Then
            'If FirstWeighDone() Then
            '    MsgBox("1st weight already taken for this v ehicle, Pls check" & vbCrLf & "can not continue", MsgBoxStyle.Exclamation)
            '    Me.txtVehCode.Text = ""
            '    Exit Sub
            'End If
            'End If

            getVehDetails(vc)
            'getLastVehEntry(vc)
            If Me.txtDriver.Text = "" Then
                Me.txtDriver.Focus()
            Else
                btnSelCust.Focus()
            End If
        End If

    End Sub

    Private Sub getVehDetails(ByVal vcd As String)

        Dim s As String
        s = "Select top 1 * from tblVehicles where VehCode = '" & vcd & "'"

        Dim ds As DataSet
        Dim w As String
        w = mslCons.WebAuthcode
        ds = msWebGetDS(s, w)

        If ds.Tables.Count < 1 Then
            ' not found take entry from vehicle table
            MsgBox("Error 160607203 " & w, MsgBoxStyle.Critical)
            Exit Sub
        End If

        If ds.Tables(0).Rows.Count < 1 Then
            ' not found take entry from vehicle table
            msWriteLM("Vehicle record not found")
            Exit Sub
        End If

        Try
            Me.lblVehical.Text = ds.Tables(0).Rows(0)("VehName").ToString
            If Sysvars.WtType <> 1 Then         ' first weight
                Me.txtFwt.Text = ds.Tables(0).Rows(0)("VehTareWt").ToString
                Me.lblManualTare.Text = ds.Tables(0).Rows(0)("VehWtRemark").ToString
            End If

        Catch ex As Exception
            msWriteLM("Error 160603 " & ex.Message, "r")
            MsgBox("Error 160603 " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub


    Private Sub msWriteLM(ByVal LmData As String, Optional ByVal rgbh As String = "0")

        Dim obj As Control
        obj = Me.txtLM

        If TypeOf obj Is TextBox Then
            If CType(obj, TextBox).Multiline Then
                Me.txtLM.Text = LmData & vbCrLf & Me.txtLM.Text
            Else
                Me.txtLM.Text = LmData
            End If

        Else
            Me.txtLM.Text = LmData
        End If

        'msDoEvents()

        Dim pColor As Color
        Select Case rgbh.ToLower
            Case "r"
                pColor = Color.Crimson
            Case "1"
                pColor = Color.Crimson
            Case "g"
                pColor = Color.Green
            Case "2"
                pColor = Color.Green
            Case "b"    ' blue
                pColor = Color.Blue
            Case "3"   ' blue
                pColor = Color.Blue
            Case "h"      ' highlight
                pColor = Color.DarkBlue
            Case "4"     ' highlight
                pColor = Color.DarkBlue
            Case Else
                pColor = Color.Black
        End Select


        txtLM.ForeColor = pColor

        If rgbh = "h" Or rgbh = "4" Then
            txtLM.BackColor = Color.Yellow
        Else
            txtLM.BackColor = Color.WhiteSmoke
        End If

    End Sub


    Private Sub btnSelCust_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelCust.Click

        Dim frmc As New frmPartySearch

        Dim cs As String

        If arUserAccess(enUAcs.Open_Customer_file) = 1 Then
            cs = frmc.ShowDialog_PartySearch("", Me.txtVehCode.Text, True, True)
        Else
            cs = frmc.ShowDialog_PartySearch("", Me.txtVehCode.Text, True, False)
        End If

        If cs <> "" Then
            Me.txtCustcode.Text = cs
            GetCustDetails()
            ' btnSelMat.Focus()
        End If


    End Sub

    Private Sub GetCustDetails()

        If Me.txtCustcode.Text = "" Then Exit Sub

        Dim s As String
        s = "Select top 1 * from tblCustomers where CustCode = '" & Me.txtCustcode.Text & "' and CustDisable = 0 "

        Dim ds As DataSet
        ds = msWebGetDsFt(s)

        If ds.Tables.Count < 1 Then
            ' not found take entry from vehicle table
            Exit Sub
        End If

        If ds.Tables(0).Rows.Count < 1 Then
            ' not found take entry from vehicle table
            msWriteLM("Customer record not found", "r")
            Exit Sub
        End If

        Try
            Me.lblCustName.Text = ds.Tables(0).Rows(0)("CustName").ToString
            Me.lblCustGroup.Text = ds.Tables(0).Rows(0)("PriceGroup").ToString
            Me.lblPrePaidCust.Text = ds.Tables(0).Rows(0)("PrepaidCust").ToString
            Me.lblCustType.Text = ds.Tables(0).Rows(0)("CustType").ToString

        Catch ex As Exception
            msWriteLM("Error 160604 " & ex.Message, "r")
            MsgBox("Error 160604 " & ex.Message, MsgBoxStyle.Critical)
        End Try

        If lblPrePaidCust.Text = "Y" Then
            getCustBalance()
        Else
            Me.lblBalance.Text = 0
        End If

    End Sub

    Private Sub getCustBalance()

        If Me.txtCustcode.Text = "" Then Exit Sub

        Dim s As String
        s = "select Custcode, Sum(AmtIn) as totAmtIn, Sum(AmtOut) as TotamtOut, (Sum(AmtIn) - Sum(AmtOut)) CustBalance "
        s = s & " from tblCustPayments where Custcode = '" & Me.txtCustcode.Text & "' group by Custcode"

        Dim ds As DataSet
        ds = msWebGetDsFt(s)

        If ds.Tables.Count < 1 Then
            ' not found take entry from vehicle table
            Exit Sub
        End If

        If ds.Tables(0).Rows.Count < 1 Then
            ' not found take entry from vehicle table
            msWriteLM("Customer record not found while checking balance", "r")
            Exit Sub
        End If

        Try
            Me.lblBalance.Text = ds.Tables(0).Rows(0)("CustBalance").ToString

            'Me.lblCustGroup.Text = ds.Tables(0).Rows(0)("PriceGroup").ToString
            'Me.lblPrePaidCust.Text = ds.Tables(0).Rows(0)("PrepaidCust").ToString

        Catch ex As Exception
            msWriteLM("Error 16060417 " & ex.Message, "r")
            MsgBox("Error 16060417 " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub


    Private Sub btnSelMat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelMat.Click

        If Me.txtCustcode.Text = "" Then
            MsgBox("Please select customer", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim frmc As New frmMaterialSearch

        Dim mcs As String

        If arUserAccess(enUAcs.Open_Material_file) = 1 Then
            mcs = frmc.ShowDialog_MatSearch("", txtCustcode.Text, True, True)
        Else
            mcs = frmc.ShowDialog_MatSearch("", txtCustcode.Text, True, False)
        End If

        If mcs <> "" Then
            Me.txtMatCode.Text = mcs
            GetMatDetails()
            btnSelSource.Focus()
        End If

    End Sub

    Private Sub GetMatDetails()

        If Me.txtMatCode.Text = "" Then Exit Sub

        Dim s As String
        s = "Select top 1 * from tblMaterials where MatCode = '" & Me.txtMatCode.Text & "'"   '  and matDisable = 0 "

        Dim ds As DataSet
        ds = msWebGetDsFt(s)

        If ds.Tables.Count < 1 Then
            ' not found take entry from vehicle table
            Exit Sub
        End If

        If ds.Tables(0).Rows.Count < 1 Then
            ' not found take entry from vehicle table
            msWriteLM("Customer record not found", "r")
            Exit Sub
        End If

        Try
            Me.lblMatName.Text = ds.Tables(0).Rows(0)("MatName").ToString

            Me.lblRate.Text = ds.Tables(0).Rows(0)("Price" & Me.lblCustGroup.Text).ToString

            calCost()

        Catch ex As Exception

            msWriteLM("Error 160604 " & ex.Message, "r")
            MsgBox("Error 160604 " & ex.Message, MsgBoxStyle.Critical)

        End Try

    End Sub


    Private Sub calCost()


        If Not IsNumeric(lblRate.Text) Then
            lblRate.Text = 0
        End If

        If IsNumeric(Me.txtNwt.Text) Then
            Me.lblAmount.Text = Format(Round((Val(Me.lblRate.Text) * Val(Me.txtNwt.Text) / 1000), 2), "0.00")
        End If


    End Sub

    Private Sub btnSelSource_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelSource.Click

        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        If arUserAccess(enUAcs.Open_Other_Masters) = 1 Then
            cs = frmc.ShowDialog_OtherMasterSearch("tblSource", "Soucode", "SouName", "", Me.txtCustcode.Text, True, True)
        Else
            cs = frmc.ShowDialog_OtherMasterSearch("tblSource", "Soucode", "SouName", "", Me.txtCustcode.Text, True, False)
        End If

        If cs <> "" Then
            Me.txtSouCode.Text = cs
            GetOtherDetails("tblSource")
            btnSelLoc.Focus()
        End If

    End Sub

    Private Sub GetOtherDetails(ByVal prmtblName As String)

        Dim tblname As String
        tblname = prmtblName.ToLower

        Dim fldcode As String
        Dim fldname As String

        Dim txtCode As String

        If tblname.ToLower = "tblsource" Then
            fldcode = "soucode"
            txtCode = Me.txtSouCode.Text
            fldname = "SouName"
        ElseIf tblname.ToLower = "tbllocations" Then
            fldcode = "LocCode"
            txtCode = txtLocCode.Text
            fldname = "LocName"
        ElseIf tblname.ToLower = "tblsites" Then
            fldcode = "SiteCode"
            txtCode = txtSiteCode.Text
            fldname = "SiteName"
        Else
            ' not possible
            fldcode = ""
            fldname = ""
            txtCode = ""
        End If

        Dim s As String

        s = "Select top 1 * from " & tblname & " where " & fldcode & " = '" & txtCode & "'"

        Dim ds As DataSet
        Dim w As String
        w = mslCons.WebAuthcode
        ds = msWebGetDS(s, w)

        If Not (IsNumeric(w) Or w = mslCons.WebAuthcode) Then
            MsgBox("error 160609 " & w, MsgBoxStyle.Critical)
            Exit Sub
        End If

        If ds.Tables.Count < 1 Then
            Exit Sub
        End If

        If ds.Tables(0).Rows.Count < 1 Then
            ' not found take entry from vehicle table
            msWriteLM("W160609: record not found", "r")
            Exit Sub
        End If

        Try

            If tblname.ToLower = "tblsource" Then
                Me.lblSouName.Text = ds.Tables(0).Rows(0)(fldname).ToString
            ElseIf tblname.ToLower = "tbllocations" Then
                Me.lblLocName.Text = ds.Tables(0).Rows(0)(fldname).ToString
            ElseIf tblname.ToLower = "tblsites" Then
                Me.lblSiteName.Text = ds.Tables(0).Rows(0)(fldname).ToString
            Else
                ' not possible

            End If

        Catch ex As Exception

            msWriteLM("Error 160604 " & ex.Message, "r")
            MsgBox("Error 160604 " & ex.Message, MsgBoxStyle.Critical)

        End Try


    End Sub

    Private Sub btnSelLoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelLoc.Click

        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        If arUserAccess(enUAcs.Open_Customer_file) = 1 Then
            cs = frmc.ShowDialog_OtherMasterSearch("tblLocations", "Loccode", "LocName", "", Me.txtCustcode.Text, True, True)
        Else
            cs = frmc.ShowDialog_OtherMasterSearch("tblLocations", "Loccode", "LocName", "", Me.txtCustcode.Text, True, False)
        End If

        If cs <> "" Then
            Me.txtLocCode.Text = cs
            GetOtherDetails("tblLocations")
            btnSelSite.Focus()
        End If


    End Sub

    Private Sub btnSelSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelSite.Click

        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        If arUserAccess(enUAcs.Open_Customer_file) = 1 Then
            cs = frmc.ShowDialog_OtherMasterSearch("tblSites", "Sitecode", "SiteName", "", Me.txtCustcode.Text, True, True)
        Else
            cs = frmc.ShowDialog_OtherMasterSearch("tblSites", "Sitecode", "SiteName", "", Me.txtCustcode.Text, True, False)
        End If

        If cs <> "" Then
            Me.txtSiteCode.Text = cs
            GetOtherDetails("tblSites")
            txtDlvOrder.Focus()
        End If

    End Sub


    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Close()

    End Sub


    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        If FormNotValid() Then Exit Sub

        If Me.cmbRemark.Text.Trim = "" Then
            MsgBox("Please select Remark")
            Exit Sub
        End If

        pnlWeighentry.Enabled = False

        btnSave.Enabled = False
        System.Windows.Forms.Application.DoEvents()

        Dim b As Boolean

        b = SavetoPrime()


        btnSave.Enabled = True

        ' not required as it slows down the speed
        'LoadLastTicket()

        'pnlWeighSelect.Enabled = True

        btnWB1.BackColor = Color.LightCyan


        If b Then
            MsgBox("Record updated", MsgBoxStyle.Exclamation)
            Close()
        End If

    End Sub

    Private Function FormNotValid() As Boolean

        FormNotValid = False

        If Trim(Me.txtVehCode.Text) = "" Then
            MsgBox("Vehicle not selected !!", MsgBoxStyle.Exclamation)
            FormNotValid = True
            Me.btnSelVeh.Focus()
            Exit Function
        End If

        If Trim(Me.txtCustcode.Text) = "" Then
            MsgBox("Customer not selected !!", MsgBoxStyle.Exclamation)
            FormNotValid = True
            Me.btnSelCust.Focus()
            Exit Function
        End If

        If Trim(Me.txtMatCode.Text) = "" Then
            MsgBox("Material not selected !!", MsgBoxStyle.Exclamation)
            FormNotValid = True
            Me.btnSelMat.Focus()
            Exit Function
        End If

        'If Not SelW Then
        '    If MsgBox("You have not taken Weight From the Weigh Bridge" & vbCrLf & "Are you sure tare weight is correct? ", MsgBoxStyle.Question + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
        '        FormNotValid = True
        '        Exit Function
        '    End If

        'End If

        'Dim invalidWt As Boolean
        ''Dim wtwt As Double

        'If UCase(Sysvars.WUnit) = "TN" Then
        '    If Sysvars.WtType = 1 Then      ' 1st weighing
        '        If Val(Me.txtNwt.Text) < 0.1 Or Val(Me.txtFwt.Text) < 0.1 Then
        '            invalidWt = True

        '        End If
        '    Else
        '        If Val(Me.txtNwt.Text) < 0.1 Or Val(Me.txtFwt.Text) < 0.1 Or Val(Me.txtSwt.Text) < 0.1 Then
        '            invalidWt = True

        '        End If
        '    End If
        'Else
        '    If Sysvars.WtType = 1 Then
        '        If Val(Me.txtNwt.Text) < 100 Or Val(Me.txtFwt.Text) < 100 Then
        '            invalidWt = True

        '        End If
        '    Else
        '        If Val(Me.txtNwt.Text) < 100 Or Val(Me.txtFwt.Text) < 100 Or Val(Me.txtSwt.Text) < 100 Then
        '            invalidWt = True

        '        End If
        '    End If
        'End If

        'If invalidWt Then
        '    If MsgBox("Invalid Weight !!!" & vbCrLf & "Please check" & vbCrLf & "Do you want to continue?", MsgBoxStyle.Question + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
        '        FormNotValid = True
        '        Exit Function
        '    End If

        'End If

        If Trim(Me.txtSouCode.Text) = "" Then
            Me.txtSouCode.Text = "001"    ' to check here by ms
            Me.lblSouName.Text = ""
        End If

        If Trim(Me.txtLocCode.Text) = "" Then
            Me.txtLocCode.Text = "001"    ' to check here by ms
            Me.lblLocName.Text = ""
        End If

        If Not IsNumeric(Me.lblRate.Text) Then
            Me.lblRate.Text = 0
            Me.lblAmount.Text = 0

        End If



        Me.lblAmount.Text = Val(Me.lblRate.Text) * Val(Me.txtNwt.Text) / 1000


    End Function

    Private Function SaveOldRecord() As String


        SaveOldRecord = ""

        Dim dsmod As New DataSet
        Dim dAdap As OleDbDataAdapter

        Dim dbcn As New OleDbConnection
        If Not msOpenDbConnection(dbcn) Then
            Exit Function
        End If

        Dim s As String
        s = "Select * from tblWeighingModified where WgID < 1"

        dAdap = New OleDbDataAdapter(s, dbcn)

        Try
            dAdap.Fill(dsmod, "tblA")
        Catch ex As Exception
            SaveOldRecord = "Error 160913 " & ex.Message
        End Try

        ' MsgBox(dsmod.Tables(0).Rows.Count)

        Dim dr As DataRow
        Try
            ' no need as this saved in original table 
            'droldrec("UserModified") = User.ID
            'droldrec("ModifyRemark") = Me.cmbRemark.Text

            dr = dsmod.Tables(0).NewRow

            dr.ItemArray = droldrec.ItemArray

            dsmod.Tables(0).Rows.Add(dr)
        Catch ex As Exception
            SaveOldRecord = "Error 16091319 " & ex.Message
            Exit Function
        End Try



        ' update checnges
        Dim commandbuilder As New OleDbCommandBuilder(dAdap)

        Try
            commandbuilder.GetUpdateCommand()
            dAdap.Update(dsmod, "tblA")

        Catch ex As Exception
            'MessageBox.Show(ex.Message)
            SaveOldRecord = "Error 1609138 " & ex.Message
            Exit Function
        End Try

        Try
            dsmod.AcceptChanges()
        Catch ex As Exception
            SaveOldRecord = "Error 160913195 " & ex.Message
            Exit Function
        End Try

        SaveOldRecord = ""

    End Function

    Private Function SavetoPrime() As Boolean

        SavetoPrime = False

        ' Dim tickno As Long

        'If Sysvars.WtType = 1 Then          ' 1st weighing

        '    tick1stNo = GetNext1stTick()
        '    tickno = getNextnegTick()


        'Else        ' 2nd and new weighing

        '    tickno = GetNextTickNo()
        '    If tickno <= LastTickNo Then
        '        msWait(5)
        '        tickno = GetNextTickNo()
        '    End If

        'End If

        '   tickno = 3

        Dim sm As String
        sm = SaveOldRecord()
        If sm = "" Then

        Else
            MsgBox("Error saving old values : " & sm, MsgBoxStyle.Critical)
            Exit Function
        End If


        Dim tm As String
        tm = msNow()

        Dim arf As New List(Of String)
        Dim arv As New List(Of String)
        Dim art As New List(Of String)

        arf.Clear()
        arv.Clear()
        art.Clear()

        'arf.Add("EntryDateTime")
        'arv.Add(tm)
        'art.Add("s")

        'arf.Add("TicketNo")
        'arv.Add(tickno)
        'art.Add("n")

        'If Sysvars.WtType = 1 Then      ' 1st weight
        '    arf.Add("FirstTicketNo")
        '    arv.Add(tick1stNo)
        '    art.Add("n")
        'End If

        arf.Add("VehCode")
        arv.Add(Me.txtVehCode.Text)
        art.Add("s")

        arf.Add("VehName")
        arv.Add(Me.lblVehical.Text)
        art.Add("s")

        arf.Add("DriverName")
        arv.Add(Me.txtDriver.Text)
        art.Add("s")

        arf.Add("DriverMob")
        arv.Add(Me.txtMobile.Text)
        art.Add("s")

        arf.Add("CustCode")
        arv.Add(Me.txtCustcode.Text)
        art.Add("s")

        arf.Add("CustName")
        arv.Add(Me.lblCustName.Text)
        art.Add("s")

        arf.Add("CustType")
        arv.Add(Me.lblCustType.Text)
        art.Add("n")

        arf.Add("PriceGroup")
        arv.Add(Me.lblCustGroup.Text)
        art.Add("s")

        arf.Add("PrepaidCust")
        arv.Add(lblPrePaidCust.Text)
        art.Add("s")

        arf.Add("MatCode")
        arv.Add(txtMatCode.Text)
        art.Add("s")

        arf.Add("MatName")
        arv.Add(lblMatName.Text)
        art.Add("s")

        arf.Add("SouCode")
        arv.Add(txtSouCode.Text)
        art.Add("s")

        arf.Add("SouName")
        arv.Add(Me.lblSouName.Text)
        art.Add("s")

        arf.Add("LocCode")
        arv.Add(Me.txtLocCode.Text)
        art.Add("s")

        arf.Add("LocName")
        arv.Add(Me.lblLocName.Text)
        art.Add("s")

        arf.Add("SiteCode")
        arv.Add(Me.txtSiteCode.Text)
        art.Add("s")

        arf.Add("SiteName")
        arv.Add(Me.lblSiteName.Text)
        art.Add("s")

        arf.Add("InOut")
        If Me.rbIn.Checked Then
            arv.Add("I")
        Else
            arv.Add("O")
        End If
        art.Add("s")

        'arf.Add("WeighType")
        'arv.Add(Sysvars.WtType)
        'art.Add("n")

        'arf.Add("FWeight")
        'arv.Add(Me.txtFwt.Text)
        'art.Add("n")

        'arf.Add("SWeight")
        'arv.Add(Me.txtSwt.Text)
        'art.Add("n")

        'arf.Add("NWeight")
        'arv.Add(Me.txtNwt.Text)
        'art.Add("n")

        arf.Add("VehWtRemark")
        arv.Add(Me.lblManualTare.Text)
        art.Add("s")


        'If Sysvars.WtType = 1 Then      ' 1st weight
        '    arf.Add("FWDateTime")
        '    arv.Add(tm)
        '    art.Add("s")

        'Else

        '    arf.Add("SWDateTime")
        '    arv.Add(tm)
        '    art.Add("s")

        'End If

        arf.Add("CostPerTon")
        arv.Add(Me.lblRate.Text)
        art.Add("n")

        arf.Add("Amount")
        arv.Add(Me.lblAmount.Text)
        art.Add("n")

        arf.Add("Commission")
        arv.Add(0)
        art.Add("n")

        arf.Add("DeliveryOrder")
        arv.Add(Me.txtDlvOrder.Text)
        art.Add("s")

        arf.Add("Remarks")
        arv.Add(Me.txtRemark.Text)
        art.Add("s")

        arf.Add("LastUpdateAt")
        arv.Add(msNow())
        art.Add("s")

        'arf.Add("UserID")
        'arv.Add(User.ID)
        'art.Add("s")

        arf.Add("UserModified")
        arv.Add(User.ID)
        art.Add("s")

        arf.Add("UserCancelled")
        arv.Add(" ")
        art.Add("s")

        arf.Add("CanFlag")
        arv.Add(0)
        art.Add("s")

        arf.Add("SyncFlag")
        arv.Add(2)
        art.Add("n")

        arf.Add("ModifyRemark")
        arv.Add(cmbRemark.Text)
        art.Add("s")

        Dim a As String
        Dim w As String
        w = mslCons.WebAuthcode

        If isfirstTick Then
            a = msWebUpdateArrayListInDB("tblWeighing", arf.ToArray, arv.ToArray, art.ToArray, "FirstTicketNo = " & tikno & "  and weightype = 1 and Canflag = 0", w)
        Else
            a = msWebUpdateArrayListInDB("tblWeighing", arf.ToArray, arv.ToArray, art.ToArray, "TicketNo = " & tikno & " and weightype <> 1 and Canflag = 0", w)
        End If


        If a = "1" Then

            ' record updated
            'LastEntrytime = tm
            'LastTickNo = tickno
            'Me.lblTickNo.Text = LastTickNo

            ' cancel any repord in prepaid

            If Sysvars.WtType <> 1 Then
                w = mslCons.WebAuthcode
                a = ""
                a = msWebUpdate3FieldsInDb("tblCustPayments", "Canflag", 1, "Syncflag", 2, "", "", "TicketNo = " & tikno, w)
            End If

            If Me.lblPrePaidCust.Text = "Y" Then
                If Sysvars.WtType <> 1 Then
                    UpdatePrepaidBalance()
                End If
            End If

            SavetoPrime = True

        Else

            If a.ToLower.Contains("violation of primary key") Then

                MsgBox("Error : 160913 duplicate ticket no. Please retry", MsgBoxStyle.Exclamation)

                pnlWeighentry.Enabled = True

            Else
                MsgBox("Error 060606: " & a, MsgBoxStyle.Critical)

            End If

        End If

    End Function

    Private Sub UpdatePrepaidBalance()

        Dim arf As New List(Of String)
        Dim arv As New List(Of String)
        Dim art As New List(Of String)

        arf.Clear()
        arv.Clear()
        art.Clear()

        arf.Add("EntryDateTime")
        arv.Add(msNow())
        art.Add("s")

        arf.Add("TicketNo")
        arv.Add(tikno)
        art.Add("n")

        arf.Add("CustCode")
        arv.Add(Me.txtCustcode.Text)
        art.Add("s")

        arf.Add("AmtIN")
        arv.Add(0)
        art.Add("n")

        arf.Add("AmtOut")
        arv.Add(Me.lblAmount.Text)
        art.Add("s")

        arf.Add("SyncFlag")
        arv.Add(1)
        art.Add("n")

        Dim a As String
        Dim w As String
        w = mslCons.WebAuthcode

        a = msWebInsertRecIntoDb("tblCustPayments", arf.ToArray, arv.ToArray, art.ToArray, w)
        If a = "1" Then
            ' record updated
        Else
            MsgBox("Error 06060614 : " & a & vbCrLf & "Error updating prepaid balance", MsgBoxStyle.Critical)

        End If

    End Sub

End Class