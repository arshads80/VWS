﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDelTick
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbRemark = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.btnDel = New System.Windows.Forms.Button
        Me.lblTickInfo = New System.Windows.Forms.Label
        Me.btnCheck = New System.Windows.Forms.Button
        Me.txtTickNo = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'cmbRemark
        '
        Me.cmbRemark.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRemark.FormattingEnabled = True
        Me.cmbRemark.Location = New System.Drawing.Point(166, 252)
        Me.cmbRemark.Name = "cmbRemark"
        Me.cmbRemark.Size = New System.Drawing.Size(282, 24)
        Me.cmbRemark.TabIndex = 15
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(37, 255)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(123, 16)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Reason to Cancel"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(331, 305)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(99, 36)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnDel
        '
        Me.btnDel.Location = New System.Drawing.Point(144, 305)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(99, 36)
        Me.btnDel.TabIndex = 12
        Me.btnDel.Text = "Delete"
        Me.btnDel.UseVisualStyleBackColor = True
        '
        'lblTickInfo
        '
        Me.lblTickInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTickInfo.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTickInfo.Location = New System.Drawing.Point(40, 69)
        Me.lblTickInfo.Name = "lblTickInfo"
        Me.lblTickInfo.Size = New System.Drawing.Size(408, 166)
        Me.lblTickInfo.TabIndex = 11
        Me.lblTickInfo.Text = "   "
        Me.lblTickInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnCheck
        '
        Me.btnCheck.Location = New System.Drawing.Point(292, 24)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(38, 23)
        Me.btnCheck.TabIndex = 10
        Me.btnCheck.Text = "---"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'txtTickNo
        '
        Me.txtTickNo.Location = New System.Drawing.Point(143, 24)
        Me.txtTickNo.Name = "txtTickNo"
        Me.txtTickNo.Size = New System.Drawing.Size(143, 23)
        Me.txtTickNo.TabIndex = 9
        Me.txtTickNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 16)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Ticket No."
        '
        'frmDelTick
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(502, 369)
        Me.Controls.Add(Me.cmbRemark)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnDel)
        Me.Controls.Add(Me.lblTickInfo)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.txtTickNo)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmDelTick"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Delete Ticket"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbRemark As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents btnDel As System.Windows.Forms.Button
    Friend WithEvents lblTickInfo As System.Windows.Forms.Label
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents txtTickNo As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
