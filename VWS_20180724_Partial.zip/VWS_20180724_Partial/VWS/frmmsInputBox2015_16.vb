﻿Public Class frmmsInputBox2015_16

    Dim retVal As String

    Public Function ShowDialog_InputBox(Optional ByVal InputCaption As String = "Input", Optional ByVal StartStr As String = "", Optional ByVal RetLen As Integer = 30) As String

        Me.lblInput.Text = InputCaption
        Me.txtInput.Text = StartStr

        If RetLen > 0 Then
            Me.txtInput.MaxLength = RetLen
        End If

        ShowDialog()

        ShowDialog_InputBox = retVal

    End Function


    Private Sub btnOk_Click_1(sender As Object, e As EventArgs) Handles btnOk.Click

        retVal = Me.txtInput.Text
        Me.Close()

    End Sub

    Private Sub btnCancel_Click_1(sender As Object, e As EventArgs) Handles btnCancel.Click

        retVal = mslCons.Cancel
        Me.Close()

    End Sub

End Class