﻿Imports System.Collections.Generic

Public Class frmSummaryReport

    Private Sub btnCustMatReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCustMatReport.Click

        Dim wh As String

        Dim ft1 As String
        Dim ft2 As String

        Dim hdg As String

        ft1 = Format(Me.dtpFrm.Value, "yyyy-MM-dd")
        ft2 = Format(Me.dtpTo.Value, "yyyy-MM-dd9")    '    & "99"

        wh = "SWDateTime >= '" & ft1 & "' and SWDateTime <= '" & ft2 & "'"

        hdg = "From: " & Format(Me.dtpFrm.Value, "dd/MMM/yyyy") & "  To: " & Format(Me.dtpTo.Value, "dd/MMM/yyyy")

        Dim sh As String

        sh = "Select MatName from tblweighing where canflag = 0 and weighType <> 1 "

        sh = sh & "and ( " & wh & " ) group by MatName order by MatName"


        Dim sd As String

        sd = "Select CustName, MatName, sum(NWeight) as Nwt from tblweighing where canflag = 0 and weighType <> 1 "

        sd = sd & "and ( " & wh & " ) group by CustName, MatName order by CustName, MatName"

        '---------------------------------
        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "mmss")
        Dim fn As String
        'fn = "c:\Report.html"
        fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
        '-----------------------------------

        Dim retHtm As String

        '   retHtm = msReturnCrossTabSummary(sh, sd, "MatName", "Customer", "CustName", "Nwt", "N", "Customer / Material Report", hdg)
        retHtm = msReturnCrossTabSummary2016(sh, sd, "MatName", "Customer", "CustName", "Nwt", "N", "Customer / Material Summary", hdg, "", "", 90, 225)


        If retHtm.StartsWith("<html>") Then
            My.Computer.FileSystem.WriteAllText(fn, retHtm, False)

            Dim frmRep As New frmReports
            frmRep.ShowDialog(fn)

        Else

            MsgBox(retHtm, MsgBoxStyle.Critical)
        End If


    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

    Private Sub btnMatsummary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMatsummary.Click

        Dim wh As String

        Dim ft1 As String
        Dim ft2 As String

        'Dim hdg As String

        ft1 = Format(Me.dtpFrm.Value, "yyyy-MM-dd")
        ft2 = Format(Me.dtpTo.Value, "yyyy-MM-dd9")    '    & "99"

        wh = "SWDateTime >= '" & ft1 & "' and SWDateTime <= '" & ft2 & "'"

        ' hdg = "From: " & Me.dtpFrm.Value & "  To: " & Me.dtpTo.Value


        Dim arf As New List(Of String)
        Dim arh As New List(Of String)
        Dim art As New List(Of String)

        arf.Add("MatName")
        arh.Add("Material")
        art.Add("s")

        arf.Add("Nwt")
        arh.Add("Total Weight")
        art.Add("n")

        Dim hdgList As New List(Of String)
        hdgList.Add("Date From")
        hdgList.Add(Format(Me.dtpFrm.Value, "yyyy-MM-dd"))

        hdgList.Add("To")
        hdgList.Add(Format(Me.dtpTo.Value, "yyyy-MM-dd"))


        Dim hdg As String
        hdg = msPrepareHeader(hdgList)

        Dim sc As New List(Of String)
        Dim sf As New List(Of String)

        sc.Add("Total Weight")
        sf.Add("Nwt")

        Dim s As String
        s = "Select  MatName, sum(NWeight) as Nwt from tblweighing where canflag = 0 and weighType <> 1 "
        s = s & "and ( " & wh & " ) group by MatName order by MatName"

        Dim fm As New frmStatus
        fm.Show("Preparing report, Please wait ...")

        Dim dsr As New DataSet
        Dim w As String
        w = msFillDS(s, dsr)

        'If w <> "" Then
        '    fm.Close()
        '    MsgBox("Error : " & w, MsgBoxStyle.Critical)
        '    Exit Sub
        'End If

        If dsr.Tables.Count < 1 Then
            fm.Close()
            MsgBox("Error retrieving data", MsgBoxStyle.Critical)
            Exit Sub
        End If

        Dim fn As String
        fn = ""

        fn = msReturnBasicReport(dsr, arf, arh, art, "Material Summary", hdg, "", "Total Records", sc, sf, True, " ", 1, True)


        Dim frmRep As New frmReports

        'frmRep.MdiParent = mdiMS
        'frmRep.Show(fn)
        fm.Close()

        If My.Computer.FileSystem.FileExists(fn) Then

            frmRep.ShowDialog(fn, "Reports - Simplified Cheque")
        Else
            MsgBox("Error " & fn, MsgBoxStyle.Critical)
        End If




    End Sub


    Private Sub btnCustInside_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCustInside.Click



        Dim hdg As String

        hdg = ""

        Dim sh As String

        sh = "Select MatName from tblweighing where canflag = 0 and weighType = 1 "

        sh = sh & " group by MatName order by MatName"


        Dim sd As String

        sd = "Select CustName, MatName, Count(CustName) as VhCount from tblweighing where canflag = 0 and weighType = 1 "

        sd = sd & " group by CustName, MatName order by CustName, MatName"

        '---------------------------------
        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "mmss")
        Dim fn As String
        'fn = "c:\Report.html"
        fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
        '-----------------------------------

        Dim retHtm As String

        retHtm = msReturnCrossTabSummary(sh, sd, "MatName", "Customer", "CustName", "VhCount", "N", "Customer`s Vehicles Inside", hdg)

        If retHtm.StartsWith("<html>") Then
            My.Computer.FileSystem.WriteAllText(fn, retHtm, False)

            Dim frmRep As New frmReports
            frmRep.ShowDialog(fn)

        Else

            MsgBox(retHtm, MsgBoxStyle.Critical)
        End If

    End Sub

End Class