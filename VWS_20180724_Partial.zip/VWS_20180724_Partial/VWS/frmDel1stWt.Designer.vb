﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDel1stWt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtTickNo = New System.Windows.Forms.TextBox
        Me.btnCheck = New System.Windows.Forms.Button
        Me.lblTickInfo = New System.Windows.Forms.Label
        Me.btnDel = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.cmbRemark = New System.Windows.Forms.ComboBox
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(39, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(199, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Ticket No.  (1st Ticket Only)"
        '
        'txtTickNo
        '
        Me.txtTickNo.Location = New System.Drawing.Point(244, 43)
        Me.txtTickNo.Name = "txtTickNo"
        Me.txtTickNo.Size = New System.Drawing.Size(143, 23)
        Me.txtTickNo.TabIndex = 1
        Me.txtTickNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnCheck
        '
        Me.btnCheck.Location = New System.Drawing.Point(393, 43)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(38, 23)
        Me.btnCheck.TabIndex = 2
        Me.btnCheck.Text = "---"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'lblTickInfo
        '
        Me.lblTickInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTickInfo.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTickInfo.Location = New System.Drawing.Point(42, 88)
        Me.lblTickInfo.Name = "lblTickInfo"
        Me.lblTickInfo.Size = New System.Drawing.Size(408, 166)
        Me.lblTickInfo.TabIndex = 3
        Me.lblTickInfo.Text = "   "
        Me.lblTickInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnDel
        '
        Me.btnDel.Location = New System.Drawing.Point(145, 337)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(99, 36)
        Me.btnDel.TabIndex = 4
        Me.btnDel.Text = "Delete"
        Me.btnDel.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(332, 337)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(99, 36)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(39, 274)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Remark"
        '
        'cmbRemark
        '
        Me.cmbRemark.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRemark.FormattingEnabled = True
        Me.cmbRemark.Location = New System.Drawing.Point(145, 271)
        Me.cmbRemark.Name = "cmbRemark"
        Me.cmbRemark.Size = New System.Drawing.Size(286, 24)
        Me.cmbRemark.TabIndex = 7
        '
        'frmDel1stWt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(502, 397)
        Me.Controls.Add(Me.cmbRemark)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnDel)
        Me.Controls.Add(Me.lblTickInfo)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.txtTickNo)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmDel1stWt"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Delete First Weight"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtTickNo As System.Windows.Forms.TextBox
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents lblTickInfo As System.Windows.Forms.Label
    Friend WithEvents btnDel As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbRemark As System.Windows.Forms.ComboBox
End Class
