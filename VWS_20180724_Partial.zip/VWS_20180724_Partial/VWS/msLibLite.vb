﻿Imports System.Management

Module msLibLite

    Public Structure mslCons
        Dim ms As String

        Const sVers = "1.0.0"
        Const RelMonth = "June 2016"

        Const Cancel As String = "~`uu~^#~"
        Const mmToTwips As Single = 56.667
        Const inchToMm As Single = 25.4
        Const ListFldSeparator As String = " | "   ' list field separator
        Const StrDelimiter As String = "~^`~"    ' string Delimiter
        Const RegFldEquator As String = "=:="   ' Registry field equator 

        Const WebAuthcode As String = "1234"

    End Structure

    Public Enum FormModes
        NormalMode = 0
        EditMode = 1
        AddMode = 2
        SearchMode = 3
    End Enum

    Public Structure msl

        'Dim ExcelPath As String   should not be required any more
        'Dim WordPath As String

        Dim ProjName As String
        Dim ProjVersion As String

        Dim OleconStr As String

        Dim OleconStrA As String
        Dim OleconStrB As String
        Dim OleconStrC As String
        Dim OleconStrD As String

        Dim CurPath As String
        Dim CompanyName As String

        Dim isDongOk As String
        Dim ProductCode As String

        Dim ReportsPath As String

        Dim WeighingSiteCode As String
        Dim WeighingPCcode As String

        Dim SiteSelection As String

        Dim inputValue As String

    End Structure

    Public mslv As msl

    Structure sv

        Dim CompanyName As String

        ' manage sw version - to stop use of old versions
        Dim VerShouldBe As String
        Dim VersionMessage As String
        Dim VersionStop As String

        Dim WeighOpen As Boolean
        Dim WeighA As String
        Dim WeighB As String
        Dim WUnit As String

        Dim isPortAOpen As Boolean
        Dim isPortBOpen As Boolean

        Dim UseWA As String

        Dim WComA As String
        Dim WBaudRateA As String
        Dim WParityA As String
        Dim WDataBitsA As String
        Dim WStopBitsA As String

        Dim IndMaxLenA As String
        Dim IndWtStartsAtA As String
        Dim IndWtLenA As String
        Dim IndUnitStartsAtA As String
        Dim IndUnitLenA As String
        Dim IndStatusStartsAtA As String
        Dim IndStatusLenA As String

        Dim StCharA As String

        Dim WComB As String
        Dim WBaudRateB As String
        Dim WParityB As String
        Dim WDataBitsB As String
        Dim WStopBitsB As String
        Dim UseWB As String

        Dim IndMaxLenB As String
        Dim IndStatusLenB As String
        Dim IndStatusStartsAtB As String
        Dim IndUnitLenB As String
        Dim IndUnitStartsAtB As String
        Dim IndWtLenB As String
        Dim IndWtStartsAtB As String
        Dim StcharB As String

        Dim WtType As Integer
        Dim DefaultInOut As String

        Dim FTicketFormat As String
        Dim STicketFormat As String
        Dim NTicketFormat As String


    End Structure

    Public Sysvars As sv

    Public Enum enUAcs

        Change_Password = 1
        User_Adminstration = 2
        Assign_Access_rights = 3
        Delete_User = 4

        Open_Material_file = 10
        Edit_Material = 11
        Delete_Material = 12
        ' Disable_Material = 13

        Open_Customer_file = 20
        Edit_Customer = 21
        Delete_Customer = 22
        'Disable_Customer = 23

        Add_Cust_Credit = 30
        Modify_cust_Credit = 31
        Delete_cust_Credit = 32

        Open_Vehicle_file = 40
        Edit_Vehicle = 41
        Delete_Vehicle = 42
        'Disable_Vehicle = 43
        Manual_Tare_entry = 44

        Open_Other_Masters = 50
        Edit_Other_Masters = 51
        Delete_Other_Masters = 52

        Weighing = 60

        Reports = 70
        Weighment_Report = 71

        Reprint_Ticket = 80

        Edit_1st_ticket = 81
        Delete_1st_Ticket = 82
        Edit_Ticket = 83
        Delete_Ticket = 84

        System_Settings = 90

        AccessTotal = 100            ' AccessTotal counter - must be 1 plus max enum  

        'ManualWeightEntry = 26
        'Global_Settings = 27

    End Enum

    Structure usr

        Dim ID As String
        Dim Name As String
        Dim Access As String

    End Structure

    Public User As usr

    Public arUserAccess(100) As String

    Public TestMode As Boolean     '  True     ' must be false 


    Public Sub Init_mslvs()

        mslv.CurPath = My.Computer.FileSystem.CurrentDirectory

        ' i think this is better
        mslv.CurPath = System.Windows.Forms.Application.StartupPath
        mslv.ProjName = "Vehicle Weighing System"
        mslv.CompanyName = "Stevin Rock LLC"

        ' mslv.ExportFolder = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Adsaa_Export"

        Dim sa As String
        Dim i As Integer
        Dim sb As String
        sb = ""

        Try
            sa = msGetHDDMacID()
            For i = 1 To Len(sa)
                If IsNumeric(Mid(sa, i, 1)) Then
                    sb = sb & Mid(sa, i, 1)
                Else
                    sb = sb & Asc(Mid(sa, i, 1))
                End If
            Next

            sa = msStr(sb, 7)
        Catch ex As Exception
            sa = ""
        End Try

        'If Len(sa) > 6 Then
        '    sa = Mid(sa, 3, 5)
        'Else
        '    Dim getInfo As System.IO.DriveInfo()
        '    getInfo = System.IO.DriveInfo.GetDrives
        '    sa = msGetHDserial(getInfo(0).Name)
        '    If Len(sa) > 6 Then
        '        sa = Mid(sa, 3, 5)
        '    Else
        '        sa = "0"
        '    End If
        'End If

        mslv.ProductCode = sa

        mslv.ProjVersion = Application.ProductVersion

    End Sub

    Public Function msGetAllMacIDs() As ArrayList

        Dim hdCollection As New ArrayList()

        Dim searcher As New ManagementObjectSearcher

        Dim wmi_HD As New ManagementObject
        Dim hdSerial As String
        hdSerial = ""

        Try

            searcher = New ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia")

            ' searcher = New ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive WHERE InterfaceType='USB'")

            ' searcher = New ManagementObjectSearcher("SELECT * FROM Win32_PointingDevice")

            For Each wmi_HD In searcher.Get()

                '// get the hard drive from collection
                '	// using index

                Try

                    'MsgBox(wmi_HD("Name").ToString)

                    hdSerial = wmi_HD("SerialNumber").ToString

                    'MsgBox(wmi_HD("Model").ToString)
                    'MsgBox(wmi_HD("Size").ToString)

                    'MsgBox(wmi_HD("Manufacturer").ToString)
                    'MsgBox(wmi_HD("Status").ToString)

                    hdCollection.Add(Trim(hdSerial))
                    MsgBox(hdSerial)
                    Console.WriteLine(Trim(hdSerial))

                Catch ex As Exception
                    MsgBox(ex.Message)
                    ' Exit For
                End Try

            Next


        Catch ex As Exception

        End Try


        msGetAllMacIDs = hdCollection
        

    End Function

    Public Function msGetHDDMacID() As String

        msGetHDDMacID = ""

        Dim hdCollection As New ArrayList()

        Dim searcher As New ManagementObjectSearcher


        '     searcher = New ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive")


        'foreach(ManagementObject wmi_HD in searcher.Get())
        '{
        '	HardDrive hd = new HardDrive();
        '	hd.Model	= wmi_HD["Model"].ToString();
        '	hd.Type		= wmi_HD["InterfaceType"].ToString();

        '	hdCollection.Add(hd);
        '}

        searcher = New ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia")

        'int i = 0;

        Dim wmi_HD As New ManagementObject
        Dim hdSerial As String
        hdSerial = ""
        For Each wmi_HD In searcher.Get()

            '// get the hard drive from collection
            '	// using index

            Try
                hdSerial = wmi_HD("SerialNumber").ToString
                Exit For
            Catch ex As Exception
                Exit For
            End Try

        Next

        msGetHDDMacID = Trim(hdSerial)

    End Function


    Public Function msNow() As String

        '2016-03-14 simplified cheque

        msNow = Format(Date.Now, "yyyy-MM-dd HH:mm:ss")

    End Function

    Public Function msRandomNo(ByVal nFrm As Integer, ByVal nTo As Integer) As Integer

        Dim n As Integer

        Randomize()

        n = Int(Rnd() * (nTo + 1 - nFrm))

        msRandomNo = n + nFrm


    End Function

    Public Function msStr(ByVal sNum As String, ByVal lLen As Integer, Optional ByVal PadChar As String = "0") As String

        'msStr = Right("000000000000000000000000000000" & sNum, lLen)
        'msStr = Microsoft.VisualBasic.Right(StrDup(lLen, PadChar) & sNum, lLen)

        Dim s As String
        s = StrDup(lLen, PadChar) & sNum
        Dim sret As String
        sret = s.Substring(s.Length - lLen)
        msStr = sret

    End Function

    Public Sub msWait(ByVal CentiSecs As Long)

        ' 2009-05-13
        Dim t1 As Long
        Dim t2 As Long
        t1 = Date.Now.Ticks / 1000000
        t2 = t1 + CentiSecs

        Do While t2 > t1
            t1 = Date.Now.Ticks / 1000000
            msDoEvents()
        Loop

    End Sub

   

    Public Function msPopulateAutoCompleteListDS(ByVal SQLStr As String, Optional ByVal list_count As Integer = 0, Optional ByVal FieldsToAdd As Integer = 1) As AutoCompleteStringCollection

        ' 2013-05-15
        ' 2015-02-06   using dataset return method to make compatible with webservice

        Dim alist As New AutoCompleteStringCollection
        msPopulateAutoCompleteListDS = alist

        Dim ds As New DataSet
        Dim dr As DataRow

        Dim i As Integer
        i = 0
        Dim a As String
        a = mslCons.WebAuthcode
        Try
            ds = msWebGetDS(SQLStr, a)
            If IsNumeric(a) Then
                For Each dr In ds.Tables(0).Rows

                    alist.Add(dr(0))
                    If FieldsToAdd > 1 Then
                        alist.Add(dr(1))
                        'txtBox.AutoCompleteCustomSource.Add(dr.Item(1).ToString)
                    End If
                    If FieldsToAdd > 2 Then
                        alist.Add(dr(2))
                    End If
                    If FieldsToAdd > 3 Then
                        alist.Add(dr(3))
                    End If
                    If FieldsToAdd > 4 Then
                        alist.Add(dr(5))
                    End If
                    i = i + 1
                    If list_count = 0 Then
                        msDoEvents()
                    Else
                        If i > list_count Then
                            Exit For
                        End If
                    End If

                Next

                msPopulateAutoCompleteListDS = alist


            Else
                MsgBox("error 150206 " & "Populate auto complete" & a)
            End If

        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical)

        End Try

    End Function

    Public Sub msDoEvents()

        System.Windows.Forms.Application.DoEvents()

    End Sub

    Public Sub msWriteActivity(ByVal prmActivity As String, ByVal prmActivityDesc As String)

        Dim arf As New List(Of String)
        Dim arv As New List(Of String)
        Dim art As New List(Of String)

        arf.Add("ActivityTime")
        arv.Add(msNow)
        art.Add("st")

        arf.Add("UserID")
        arv.Add(User.ID)
        art.Add("s")

        arf.Add("Activity")
        arv.Add(prmActivity)
        art.Add("s")

        arf.Add("ActDetail")
        arv.Add(prmActivityDesc)
        art.Add("s")

        Dim w As String
        w = mslCons.WebAuthcode

        Dim a As String
        Try
            a = msWebInsertRecIntoDb("tblActivities", art.ToArray, arv.ToArray, art.ToArray, w)
        Catch ex As Exception

        End Try

    End Sub

    Public Function msWebGetDsFt(ByVal prmSql As String) As DataSet

        ' 2016-05-17
        ' msWebGetDS fast track

        Dim w As String
        w = mslCons.WebAuthcode

        Dim ds As New DataSet
        ds = msWebGetDS(prmSql, w)

        If IsNumeric(w) Or w = mslCons.WebAuthcode Then
            ' ok
        Else
            MsgBox("Error 16060720 : " & w & vbCrLf & prmSql, MsgBoxStyle.Critical)
        End If

        msWebGetDsFt = ds

    End Function

#Region "List & Grid"

    Public Function msFindGridRowByValue(ByRef prmGrid As DataGridView, ByVal prmHeaderName As String, ByVal prmValue As String) As Integer

        ' return row number numeric 

        msFindGridRowByValue = 0

        Dim i As Integer
        For i = 0 To prmGrid.RowCount - 1

            If prmGrid.Rows(i).Cells(prmHeaderName).Value = prmValue Then
                msFindGridRowByValue = i
                Exit For
            End If

        Next

    End Function

#End Region

#Region "msRead Write XML settings"


    Public Function msReadRegXML(ByVal RegName As String, Optional ByVal RegDefValue As String = "", Optional ByVal RegLevel As String = "", Optional ByVal RegDesc As String = "", Optional ByVal RegFile As String = "msRegSet.rs.xml") As String

        ' 2016-05-15

        Dim dsxml As New DataSet
        Dim dtbl As New DataTable
        Dim dr As DataRow
        msReadRegXML = RegDefValue

        If My.Computer.FileSystem.FileExists(mslv.CurPath & "\" & RegFile) Then
            ' ok check
        Else
            ' create xml file
            dtbl.TableName = "msRegSetting"
            dtbl.Columns.Add("KeyName")
            dtbl.Columns.Add("KeyValue")
            dtbl.Columns.Add("KeyDesc")
            dtbl.Columns.Add("KeyLevel")

            dr = dtbl.Rows.Add

            dr("KeyName") = RegName
            dr("KeyValue") = RegDefValue
            dr("KeyDesc") = RegDesc
            If RegLevel = "" Then
                dr("KeyLevel") = "001"
            Else
                dr("KeyLevel") = RegLevel
            End If


            dsxml.Tables.Add(dtbl)

            dsxml.WriteXml(mslv.CurPath & "\" & RegFile)

        End If

        Dim readD As String
        readD = RegDefValue

        Dim i As Integer

        Dim recfound As Boolean
        recfound = False

        ' read xml file
        Try
            dsxml = New DataSet()

            dsxml.ReadXml(mslv.CurPath & "\" & RegFile)

            'dsxml.Tables(0).DefaultView.RowFilter = "KeyName = '" & RegName & "'"

            If dsxml.Tables(0).Rows.Count > 0 Then

                For i = 0 To dsxml.Tables(0).Rows.Count - 1
                    dr = dsxml.Tables(0).Rows(i)
                    If dr("KeyName") = RegName Then
                        readD = dsxml.Tables(0).Rows(i).Item("KeyValue").ToString
                        recfound = True
                        Exit For
                    End If
                Next

            End If

            If Not recfound Then

                ' add new row 
                dr = dsxml.Tables(0).Rows.Add
                dr.Item("KeyName") = RegName
                dr.Item("KeyValue") = RegDefValue
                dr("KeyDesc") = RegDesc
                If RegLevel = "" Then
                    dr("KeyLevel") = "001"
                Else
                    dr("KeyLevel") = RegLevel
                End If
                dsxml.WriteXml(mslv.CurPath & "\" & RegFile)

            End If

        Catch ex As Exception

            MsgBox(ex.ToString)
            Exit Function
        End Try

        msReadRegXML = readD

    End Function

    Public Sub msWriteRegXML(ByVal RegName As String, ByVal RegValue As String, Optional ByVal RegLevel As String = "", Optional ByVal RegDesc As String = "", Optional ByVal RegFile As String = "msRegSet.rs.xml")

        ' 2016-05-15

        Dim dsxml As New DataSet
        Dim dtbl As New DataTable
        Dim dr As DataRow

        If My.Computer.FileSystem.FileExists(mslv.CurPath & "\" & RegFile) Then
            ' ok check

        Else
            ' create xml file
            dtbl.TableName = "msRegSetting"
            dtbl.Columns.Add("KeyName")
            dtbl.Columns.Add("KeyValue")
            dtbl.Columns.Add("KeyDesc")
            dtbl.Columns.Add("KeyLevel")

            dr = dtbl.Rows.Add

            dr("KeyName") = RegName
            dr("KeyValue") = RegValue
            dr("KeyDesc") = RegDesc
            If RegLevel = "" Then
                dr("KeyLevel") = "001"
            Else
                dr("KeyLevel") = RegLevel
            End If


            dsxml.Tables.Add(dtbl)

            dsxml.WriteXml(mslv.CurPath & "\" & RegFile)

        End If

        Dim recfound As Boolean
        recfound = False

        ' open xml file
        Try
            dsxml = New DataSet()

            dsxml.ReadXml(mslv.CurPath & "\" & RegFile)

            'dsxml.Tables(0).DefaultView.RowFilter = "KeyName = '" & RegName & "'"

            If dsxml.Tables(0).Rows.Count > 0 Then
                For i = 0 To dsxml.Tables(0).Rows.Count - 1
                    dr = dsxml.Tables(0).Rows(i)
                    If dr("KeyName") = RegName Then
                        dr = dsxml.Tables(0).Rows(i)
                        dr.Item("KeyValue") = RegValue
                        If RegDesc <> "" Then
                            dr("KeyDesc") = RegDesc
                        End If

                        If RegLevel <> "" Then
                            dr("KeyLevel") = RegLevel
                        End If
                        recfound = True
                        Exit For
                    End If
                Next

                If Not recfound Then
                    ' add new row 
                    dr = dsxml.Tables(0).Rows.Add
                    dr.Item("KeyName") = RegName
                    dr.Item("KeyValue") = RegValue
                    dr("KeyDesc") = RegDesc
                    If RegLevel = "" Then
                        dr("KeyLevel") = "001"
                    Else
                        dr("KeyLevel") = RegLevel
                    End If

                End If
                
            End If

            dsxml.WriteXml(mslv.CurPath & "\" & RegFile)

        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try

    End Sub

#End Region

#Region "Global Settings from database using dataset"


    Private FieldName(2, 1000) As String

    Public Sub msAddSysValue(ByVal sysName As String, ByVal sysVal As String)

        'msMessagebox(sysName & vbCrLf & sysVal)

        Dim i As Integer
        For i = 0 To 999
            If FieldName(0, i) = "" Then
                FieldName(0, i) = sysName
                FieldName(1, i) = sysVal
                Exit For
            End If
        Next

    End Sub

    Public Sub msSetSysValue(ByVal sysName As String, ByVal sysVal As String)

        Dim i As Integer
        For i = 0 To 999
            If FieldName(0, i) = "" Then
                'msMessagebox("Sys vars column: " & sysName & " notfound", Emoticons.ErrorIcon, "Warning")
                FieldName(0, i) = sysName
                FieldName(1, i) = sysVal
                Exit For
            ElseIf FieldName(0, i) = sysName Then
                FieldName(1, i) = sysVal
                Exit For
            End If
        Next
        ' 2012-10-01
        msWriteSetTable(sysName, sysVal)

    End Sub

    Public Function msGetSysValue(ByVal prmsysName As String, Optional ByVal prmDefaultValue As String = "") As String

        Dim i As Integer

        msGetSysValue = prmDefaultValue

        For i = 0 To 999
            If FieldName(0, i) = prmsysName Then
                msGetSysValue = FieldName(1, i)
                Exit Function

            End If
        Next

        If i >= 999 Then ' sysname not exist in database

            Dim w As String
            w = mslCons.WebAuthcode

            Dim s As String
            s = msWebInsert3FieldsInDb("tblSettings", "KeyName", "'" & prmsysName & "'", "KeyValue", "'" & prmDefaultValue & "'", "", "", w)

            If Not IsNumeric(s) Then
                'msMessagebox(s, Emoticons.ErrorIcon)
                MessageBox.Show("Error: 160516 " & vbCrLf & s, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        End If

    End Function

    Public Sub msClearSysArray()

        Dim I As Int16
        Dim j As Int16
        For I = 0 To 1
            For j = 0 To 999
                FieldName(I, j) = ""
            Next
        Next
    End Sub

    Public Function msReadSetTable() As Boolean

        msReadSetTable = False
        msClearSysArray()

        Dim sStr As String
        sStr = "Select * from tblSettings order by KeyName"

        Dim dsSet As New DataSet
        Dim w As String
        w = mslCons.WebAuthcode

        Try

            dsSet = msWebGetDS(sStr, w)
            If dsSet.Tables.Count <= 0 Then Exit Function

            If dsSet.Tables(0).Rows.Count <= 0 Then Exit Function

            Dim i As Integer

            Dim dr As DataRow

            For i = 0 To dsSet.Tables(0).Rows.Count - 1
                dr = dsSet.Tables(0).Rows(i)
                msAddSysValue(dr.Item("KeyName").ToString, dr.Item("KeyValue").ToString)

            Next

            ' free memory 
            dsSet.Clear()
            dsSet = Nothing

            msReadSetTable = True

        Catch ex As Exception

            ' no need to display
            'msMessagebox(ex.ToString, Emoticons.ErrorIcon2, "Error")

        End Try

    End Function

    Public Sub msWriteSetTable(ByVal prmKeyName As String, ByVal prmkeyValue As String)

        Dim sStr As String
        sStr = "Update tblSettings set KeyValue = '" & prmkeyValue & "' where KeyName = '" & prmKeyName & "'"

        Dim w As String
        w = mslCons.WebAuthcode

        Dim a As String

        Try

            a = msWebProcessCommand(sStr, w)

        Catch ex As Exception
            'MsgBox(ex.ToString, MsgBoxStyle.Critical)

        End Try

    End Sub


#End Region


#Region "Reports 2015"

    Public Sub MakeReportDir()

        If Not My.Computer.FileSystem.DirectoryExists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports") Then
            My.Computer.FileSystem.CreateDirectory(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports")
        End If

    End Sub

    Public Function msPrepareHeader(ByVal hdgPair As List(Of String)) As String

        ' 2015-05-20

        Dim hdg As String

        hdg = "<table style='width: 50%' cellpadding='0' cellspacing='0' class='styletable'>"

        Dim i As Integer

        For i = 0 To hdgPair.Count - 1 Step 2
            hdg = hdg & "<tr>"
            hdg = hdg & "<td class='styleCell'>" & hdgPair(i).ToString & "</td> "
            If i < hdgPair.Count Then
                hdg = hdg & "<td class='styleCellCenter'>" & hdgPair(i + 1).ToString & "</td> "
            End If
            hdg = hdg & "</tr>"
        Next

        hdg = hdg & "</table>"

        msPrepareHeader = hdg

    End Function

    Private Function msOpenHTMLreport(ByVal RptLook As String) As String

        Dim fntType As String
        Dim fntSize As String
        Dim CellBorderColor As String
        Dim CellBorderSize As String
        Dim CellHeadBackColor As String
        Dim CellPadding As String

        If RptLook = "1" Then

            fntType = "Calibri;"
            fntSize = "small;"      ' point 12
            CellBorderColor = "#66FFCC dotted;"      ' light blue dotted
            CellBorderSize = "1px "
            CellHeadBackColor = "#99CCFF;"
            CellPadding = "5"

        ElseIf RptLook = "2" Then

            fntType = "Calibri;"
            fntSize = "small;"      ' point 12
            CellBorderColor = "#99FF66 Solid;"      ' light green
            CellBorderSize = "1px "
            CellHeadBackColor = "#99CCFF;"
            CellPadding = "2"

        ElseIf RptLook = "3" Then       ' 0
            fntType = "Verdana;"
            fntSize = "x-small;"        ' point 10
            CellBorderColor = "#DDFFAA Solid;"      ' very light green
            CellBorderSize = "1px "
            CellHeadBackColor = "#99CCFF;"
            CellPadding = "0"

        ElseIf RptLook = "4" Then       ' 0
            fntType = "Calibri;"
            fntSize = "small;"      ' point 12
            CellBorderColor = "#CCCC00 dotted;"      ' light blue dotted
            CellBorderSize = "1px "        '"thin "               
            CellHeadBackColor = "#CCFF99;"
            CellPadding = "4"

        Else   ' 0
            fntType = "Verdana;"
            fntSize = "x-small;"        ' point 10
            CellBorderColor = "#DDFFAA Solid;"    ' very light green
            CellBorderSize = "0.5px "           ' may not be visible
            CellHeadBackColor = "#99CCFF;"
            CellPadding = "1"
        End If



        Dim sr As String
        sr = "<!DOCTYPE html>"   ' PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
        sr = sr & "<html xmlns='http://www.w3.org/1999/xhtml'>"

        sr = sr & "<head>"
        sr = sr & "<meta http-equiv='Content-Language' content='en-us' />"
        sr = sr & "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"
        sr = sr & "<title>Analyst Systems Report</title>"

        sr = sr & "<style type='text/css'>"

        sr = sr & ".stylenormal {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "}"

        sr = sr & ".styletable {"
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "}"

        sr = sr & ".styleCell {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: " & CellBorderSize & CellBorderColor
        sr = sr & "}"

        sr = sr & ".styleCellRight {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: " & CellBorderSize & CellBorderColor
        sr = sr & "		text-align: right;"
        sr = sr & "}"

        sr = sr & ".styleCellCenter {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: " & CellBorderSize & CellBorderColor
        sr = sr & "		text-align: center;"
        sr = sr & "}"

        sr = sr & ".styleCellhead {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "		background-color: " & CellHeadBackColor
        sr = sr & "}"

        sr = sr & ".styleCellheadCenter {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "		text-align: center;"
        sr = sr & "		background-color: " & CellHeadBackColor
        sr = sr & "}"

        sr = sr & ".styleCellheadRight {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: " & fntSize
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "		text-align: right;"
        sr = sr & "		background-color: " & CellHeadBackColor
        sr = sr & "}"

        sr = sr & ".styletitle {"
        sr = sr & "		font-family: " & fntType
        sr = sr & "		font-size: medium;"
        sr = sr & "}"

        sr = sr & ".styleCellBarcode {"
        sr = sr & "		font-family: 'SKANDATA C39';"
        sr = sr & "		font-size: x-large;"
        sr = sr & "		border: 0px " & CellBorderColor
        sr = sr & "}"

        sr = sr & ".styleComname {"
        sr = sr & "		text-align: center;"
        sr = sr & "		font-size: large;"
        sr = sr & "		font-family: Calibri;"
        sr = sr & "		color: #000080;"
        sr = sr & "}"
        sr = sr & "</style>"

        sr = sr & "</head>"

        sr = sr & "<body>"

        msOpenHTMLreport = sr

    End Function

    Public Function msReturnBasicReport(ByRef DSrp As DataSet, ByVal rpF As List(Of String), ByVal rpH As List(Of String), ByVal rpT As List(Of String), ByVal RepTitle As String, ByVal RepHead As String, ByVal RepFoot As String, ByVal CountCaption As String, ByVal SumCaptions As List(Of String), ByVal SumFields As List(Of String), Optional ByVal ShowSrNo As Boolean = True, Optional ByVal ComNam As String = "", Optional ByVal RptLook As String = "0", Optional ByVal bRetFile As Boolean = False, Optional ByVal OpenHTM As Boolean = True, Optional ByVal CloseHTM As Boolean = True) As String

        msReturnBasicReport = ""

        Dim fn As String
        fn = ""

        If bRetFile Then
            MakeReportDir()
            Dim subFn As String
            subFn = Format(Now(), "yyMMddHHmmss")
            fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSRep" & subFn & ".html"

            msReturnBasicReport = fn

            Try
                My.Computer.FileSystem.WriteAllText(fn, "", False)
            Catch ex As Exception
                MsgBox("can not create report file" & vbCrLf & ex.Message, MsgBoxStyle.Critical)
                Exit Function
            End Try

        End If

        Dim CellPadding As String

        If RptLook = "1" Then
            CellPadding = "5"
        ElseIf RptLook = "2" Then
            CellPadding = "2"
        ElseIf RptLook = "3" Then       ' 0
            CellPadding = "0"
        ElseIf RptLook = "4" Then       ' 0
            CellPadding = "4"
        Else   ' 0
            CellPadding = "1"
        End If


        '---------------------------------

        Dim cnt As Long
        cnt = 0

        Dim sumAmt(6) As Double
        sumAmt(0) = 0
        sumAmt(1) = 0
        sumAmt(2) = 0
        sumAmt(3) = 0
        sumAmt(4) = 0
        sumAmt(5) = 0

        Dim sumDataType(6) As String
        sumDataType(0) = ""
        sumDataType(1) = ""
        sumDataType(2) = ""
        sumDataType(3) = ""
        sumDataType(4) = ""
        sumDataType(5) = ""

        Dim sumLoop As Integer

        Dim sr As String
        sr = ""

        If OpenHTM Then
            sr = msOpenHTMLreport(RptLook)
        End If

        sr = sr & "<p class='styleComname'><strong>" & ComNam & "</strong></p>"
        'sr = sr & "<p class='styletitle'><em>" & RepTitle & "</em></p>"
        sr = sr & "<p class='styletitle'><strong><i>" & RepTitle & "</i></strong></p>"

        sr = sr & "<p class='stylenormal'>" & RepHead & "</p>"

        sr = sr & "<table style='width: 100%' cellspacing='0' cellpadding=" & CellPadding & " class='styletable'>"
        sr = sr & "		<thead><tr>"    ' table header 

        If ShowSrNo Then
            sr = sr & "						<td class='styleCellhead'>Sr#</td>"
        End If

        Dim i As Integer

        Dim sNo As Integer
        sNo = 1



        ' make table header
        For i = 0 To rpF.Count - 1
            If rpF(i) = "" Then Exit For ' should not b possible
            If rpT(i) = "c" Or rpT(i) = "bl" Or rpT(i) = "bc" Then
                sr = sr & "						<td class='styleCellheadCenter'>"
            ElseIf rpT(i) = "n" Or rpT(i) = "f" Then
                sr = sr & "						<td class='styleCellheadRight'>"
            ElseIf rpT(i) = "h" Then    ' hidden no output for calculation only" Then
                sr = sr & "	"
            Else    ' d-date dt-datetime s-string t-text
                sr = sr & "						<td class='styleCellhead'>"
            End If

            If rpH(i) = "" Then
                rpH(i) = rpF(i)
            End If

            sr = sr & rpH(i) & "</td>"

        Next
        sr = sr & "		</tr></thead>"
        '--------------------------------------------
        ' making details
        Dim r As Integer
        Dim tmp As String
        tmp = ""

        Try

            Dim dr As DataRow
            sr = sr & " <tbody>"
            For r = 0 To DSrp.Tables(0).Rows.Count - 1   ' do while read
                If bRetFile Then
                    If r Mod 10 = 0 Then
                        If sr.Length > 32000 Then
                            My.Computer.FileSystem.WriteAllText(fn, sr, True)
                            sr = ""
                        End If
                    End If
                End If

                dr = DSrp.Tables(0).Rows(r)
                sr = sr & " <tr>"
                For i = 0 To rpF.Count - 1
                    If i = 0 And ShowSrNo Then
                        sr = sr & "	<td class='styleCellCenter'>" & Val(r + 1) & "</td>"
                    End If
                    If rpF(i) = "" Then Exit For ' should not b possible

                    If rpT(i) = "bl" Then    ' blank column and rpf keeps size of no of spaces

                    Else
                        tmp = dr.Item(rpF(i)).ToString.Trim
                    End If

                    If rpT(i) = "c" Then
                        sr = sr & "						<td class='styleCellCenter'>"
                        If tmp = "" Then tmp = "&nbsp;"
                        sr = sr & tmp

                    ElseIf rpT(i) = "n" Then
                        sr = sr & "						<td class='styleCellRight'>"
                        sr = sr & tmp

                    ElseIf rpT(i) = "f" Then
                        sr = sr & "						<td class='styleCellRight'>"
                        If IsNumeric(tmp) Then
                            tmp = Format(Val(tmp), "#0.00")
                        End If
                        sr = sr & tmp
                    ElseIf rpT(i) = "h" Then    ' hidden not to be printed
                        sr = sr & "	"
                        tmp = " "
                    ElseIf rpT(i) = "d" Then  ' date
                        sr = sr & "						<td class='styleCell'>"
                        If tmp = "" Then
                            sr = sr & "&nbsp;"
                        Else
                            's = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4)
                            sr = sr & Format(DateSerial(Mid(tmp, 1, 4), Mid(tmp, 6, 2), Mid(tmp, 9, 2)), "Short Date")
                        End If

                    ElseIf rpT(i) = "dt" Then  'date time
                        sr = sr & "						<td class='styleCell'>"
                        If tmp = "" Then
                            sr = sr & "&nbsp;"

                        Else    ' 4 digits year
                            sr = sr & Mid(tmp, 9, 2) & "/" & Mid(tmp, 6, 2) & "/" & Mid(tmp, 1, 4) & " " & Mid(tmp, 12, 5) ' w/o seconds & ":" & Mid(d, 11, 2)

                        End If

                    ElseIf rpT(i) = "bc" Then      'barcode
                        sr = sr & "						<td class='styleCellBarcode'>"
                        If tmp = "" Then tmp = "&nbsp;"
                        sr = sr & tmp

                    ElseIf rpT(i) = "si" Then    ' signature image
                        sr = sr & "						<td class='styleCellCenter'>"
                        sr = sr & "<img border='0' src=" & tmp & ">"

                    ElseIf rpT(i) = "sic" Then    ' signature image custom size
                        'If Len(ArType(i)) = 9 Then
                        '    s = s & "<img border='0' src=" & Trim(dr.Item(ArFields(i)).ToString) & " width='" & Mid(ArType(i), 4, 3) & "' height='" & Mid(ArType(i), 7, 3) & "'></td>"
                        'End If

                    ElseIf rpT(i) = "bl" Then   ' blank
                        sr = sr & "						<td class='styleCellCenter'>"
                        'sr = sr & msStr("&nbsp;", rpF(i), "&nbsp;")   ' field will be numeric size of spaces
                        'sr = sr & msStr(" ", rpF(i), " ")   ' field will be numeric size of spaces
                        sr = sr & "&nbsp;"

                    Else    '  s-string t-text
                        sr = sr & "						<td class='styleCell'>"
                        If tmp = "" Then
                            sr = sr & "&nbsp;"
                        ElseIf IsNumeric(tmp) Then
                            sr = sr & tmp & "&nbsp;"
                        ElseIf IsDate(tmp) Then
                            sr = sr & tmp & "&nbsp;"
                        Else
                            sr = sr & tmp
                        End If
                    End If

                    sr = sr & "</td>"

                    ' check for sum field
                    For sumLoop = 0 To SumFields.Count - 1
                        If sumLoop > 5 Then Exit For
                        If SumFields(sumLoop) <> "" Then
                            If rpF(i) = SumFields(sumLoop) Then
                                sumAmt(sumLoop) = sumAmt(sumLoop) + dr.Item(rpF(i))
                                sumDataType(sumLoop) = rpT(i)
                            End If
                        End If
                    Next

                Next
                sr = sr & " </tr>"
                cnt = cnt + 1
                If bRetFile Then
                    If sr.Length > 30000 Then
                        My.Computer.FileSystem.WriteAllText(fn, sr, True)
                        sr = ""
                    End If
                End If
            Next
            sr = sr & " </tbody>"

        Catch ex As Exception

            msReturnBasicReport = "Error: 150424 Reports generation" & vbCrLf & ex.Message
            'MsgBox("Error: 150424 Reports generation" & vbCrLf & ex.Message, MsgBoxStyle.Critical)
            Exit Function
        End Try

        ' table footer

        sr = sr & "</table>"

        sr = sr & "<p>"

        ' summary table-------------------------

        Dim ftpair As New List(Of String)


        If CountCaption <> "" Then
            ftpair.Add(CountCaption)
            ftpair.Add(DSrp.Tables(0).Rows.Count)
            sumLoop = 1
        End If


        For sumLoop = 0 To SumFields.Count - 1

            If sumLoop > 5 Then Exit For
            If SumFields(sumLoop) <> "" Then
                ftpair.Add(SumCaptions(sumLoop))
                ftpair.Add(sumAmt(sumLoop))
            End If
        Next

        sr = sr & msPrepareHeader(ftpair)

        ' write footer
        If RepFoot <> "" Then
            sr = sr & "<p class='stylenormal'>" & RepFoot & "</p>"
        End If

        sr = sr & "<p>&nbsp;</p>"

        If CloseHTM Then
            sr = sr & mscloseHTML()
        End If

        If bRetFile Then
            My.Computer.FileSystem.WriteAllText(fn, sr, True)
            msReturnBasicReport = fn      ' returning file name only for bigger report
        Else
            msReturnBasicReport = sr
        End If

    End Function

    Private Function mscloseHTML() As String

        Dim sr As String
        sr = "</body>"
        sr = sr & "</html>"
        mscloseHTML = sr

    End Function



#End Region


End Module
