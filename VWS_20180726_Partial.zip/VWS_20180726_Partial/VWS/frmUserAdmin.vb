﻿Public Class frmUserAdmin

    Private Sub frmUseAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        PopulateGridFromDS()

        If arUserAccess(enUAcs.Assign_Access_rights) = 0 Then
            Me.btnAccessRights.Visible = False
        End If

        If arUserAccess(enUAcs.Delete_User) = 0 Then
            Me.btnDelete.Visible = False
        End If

        
    End Sub

    Private Sub PopulateGridFromDS()

        Dim ser As String
        ser = Me.txtSearch.Text.Trim

        Dim wh As String
        wh = ""

        If ser <> "" Then
            wh = " Where UserName like '" & ser & "%'"
            wh = wh & " or UserID like '" & ser & "%'"
            wh = wh & " or mobileno like '" & ser & "%'"
        End If

        Dim s As String
        s = "Select UserName, UserID, mobileno, UserDisabled, Email, UID "
        s = s & ",UserPW, UserAccess, LastUpdateAt"
        s = s & " from tblUsers "
        s = s & wh
        s = s & " order by UserName"

        Dim w As String
        w = mslCons.WebAuthcode

        Dim ds As DataSet

        Try

            ds = msWebGetDS(s, w)

            If w = mslCons.WebAuthcode Or IsNumeric(w) Then
                Dim f As Font
                f = New Font("Verdana", 8, FontStyle.Regular, GraphicsUnit.Point)

                DataGridView1.Font = f

                DataGridView1.DataSource = ds
                DataGridView1.DataMember = ds.Tables(0).TableName

                DataGridView1.AutoResizeColumns()
                Me.DataGridView1.Columns("UserPW").Visible = False
                Me.DataGridView1.Columns("UserAccess").Visible = False

                'Me.lblTotRec.Text = DataGridView1.RowCount

            Else

                MsgBox("error 150206 " & w, MsgBoxStyle.Critical)

            End If

        Catch ex As Exception
            MsgBox("Error: 160319 " & "Populate Grid " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        Me.Close()

    End Sub

    Private Sub btnNewUser_Click(sender As Object, e As EventArgs) Handles btnNewUser.Click

        Dim ftc As New frmUserCreate
        ftc.ShowDialog()

        PopulateGridFromDS()

    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged

        If txtSearch.Text = "" Or txtSearch.Text.Trim.Length > 3 Then
            PopulateGridFromDS()
        End If

    End Sub

  
    Private Sub btnAccessRights_Click(sender As Object, e As EventArgs) Handles btnAccessRights.Click

        If Me.DataGridView1.Rows.Count < 1 Then Exit Sub

        'If Me.DataGridView1.SelectedRows.Count <> 1 Then
        'MsgBox("Please select a record to modify", MsgBoxStyle.Exclamation)
        'Exit Sub
        'End If

        Dim newAcs As String
        Dim frmua As New frmUserAccess
        newAcs = frmua.showDialog_frmUserAccess(Me.DataGridView1.CurrentRow.Cells("UserID").Value, Me.DataGridView1.CurrentRow.Cells("UserAccess").Value)
        ' MsgBox(newAcs)

        If newAcs <> "" And newAcs.Length > 1 Then

            Dim w As String
            w = mslCons.WebAuthcode
            Dim a As String
            a = msWebUpdate3FieldsInDb("tblUsers", "UserAccess", "'" & newAcs & "'", "LastUpdateAt", "'" & msNow() & "'", "", "", "UserID = '" & DataGridView1.CurrentRow.Cells("UserID").Value & "'", w)
            If IsNumeric(a) Then
                MsgBox(a & " records updated", MsgBoxStyle.Information)
            End If
            PopulateGridFromDS()
        End If

    End Sub

    Private Sub btnResetPW_Click(sender As Object, e As EventArgs) Handles btnResetPW.Click

        If Me.DataGridView1.Rows.Count < 1 Then Exit Sub

        If Me.DataGridView1.SelectedRows.Count <> 1 Then
            MsgBox("Please select a record to modify", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If MsgBox("Are you sure you want to reset password of User ID: " & DataGridView1.CurrentRow.Cells("UserID").Value, MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim tmp As String
        Randomize(Date.Now.Second)
        tmp = Chr(msRandomNo(65, 90)) & msStr(msRandomNo(1, 9999), 4)

        Dim ArF As New List(Of String)
        Dim ArV As New List(Of String)
        Dim ArT As New List(Of String)

        ' following is required for multiple table updates or update in loop
        ArF.Clear()
        ArV.Clear()
        ArT.Clear()
        '==================================


        ArF.Add("UserPW")
        ArV.Add(Me.DataGridView1.CurrentRow.Cells("UserID").Value.ToString.ToLower)  '  tmp.ToLower)
        ArT.Add("s")  ' or S


        ArF.Add("LastUpdateAt")
        ArV.Add(msNow)
        ArT.Add("s")  ' or S

        Dim w As String
        Dim a As String
        w = mslCons.WebAuthcode

        a = ""
        a = msWebUpdateArrayListInDB("tblUsers", ArF.ToArray, ArV.ToArray, ArT.ToArray, "UserID = '" & DataGridView1.CurrentRow.Cells("UserID").Value & "'", w)

        If a = "1" Then
            'Dim sms As String
            'sms = "MailingSimplified Password reset." & vbCrLf & vbCrLf & "User id : " & DataGridView1.CurrentRow.Cells("UserID").Value & vbCrLf & "password : " & tmp
            'sms = sms & vbCrLf & vbCrLf & "You can change pw after login"
            'Send_XML_SMS(Sysvars.ModemComPort, DataGridView1.CurrentRow.Cells("MobileNo").Value, sms)
            'WriteMailActivity("User", "PW Reset", DataGridView1.CurrentRow.Cells("UserID").Value, "pc code: " & mslv.ProductCode, True)
            MsgBox("Password reset ....", MsgBoxStyle.Exclamation)
        Else
            MsgBox("Error 160411: " & a, MsgBoxStyle.Critical)
        End If

    End Sub

    Private Sub btnModify_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModify.Click

        If Me.DataGridView1.Rows.Count < 1 Then Exit Sub

        If Me.DataGridView1.SelectedRows.Count <> 1 Then
            MsgBox("Please select a record to modify", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim s As String
        s = "Select * from tblUsers where UserID = '" & Me.DataGridView1.CurrentRow.Cells("UserID").Value & "'"
        Dim ds As DataSet
        ds = msWebGetDsFt(s)

        If ds.Tables.Count <= 0 Then Exit Sub
        If ds.Tables(0).Rows.Count <= 0 Then Exit Sub

        Dim ftc As New frmUserCreate
        ftc.ShowDialog_modifyUser(ds)

        PopulateGridFromDS()

    End Sub

    Private Sub btnDisable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisable.Click

        If Me.DataGridView1.Rows.Count < 1 Then Exit Sub

        If Me.DataGridView1.SelectedRows.Count <> 1 Then
            MsgBox("Please select a record to modify", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If MsgBox("Are you sure you want to disable / enable User ID: " & DataGridView1.CurrentRow.Cells("UserID").Value, MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim enval As String
        enval = DataGridView1.CurrentRow.Cells("UserDisabled").Value

        If enval = "Y" Then
            enval = "N"
        Else
            enval = "Y"
        End If

        Dim a As String
        a = msUpdate3FieldsInDb("tblUsers", "UserDisabled", "'" & enval & "'", "LastUpdateAt", "'" & msNow() & "'", "", "", "UserID = '" & DataGridView1.CurrentRow.Cells("UserID").Value & "'")

        If a = "1" Then
            MsgBox("Record Updated", MsgBoxStyle.Exclamation)
        Else
            MsgBox("Error 1600517 " & a, MsgBoxStyle.Critical)
        End If

        PopulateGridFromDS()

    End Sub


    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click

        If Me.DataGridView1.Rows.Count < 1 Then Exit Sub

        If Me.DataGridView1.SelectedRows.Count <> 1 Then
            MsgBox("Please select a record to delete", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If MsgBox("Are you sure you want to delete User ID: " & DataGridView1.CurrentRow.Cells("UserID").Value, MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim s As String
        s = "Delete from tblUsers where UserID = '" & DataGridView1.CurrentRow.Cells("UserID").Value & "'"

        Dim w As String
        w = mslCons.WebAuthcode

        Dim a As String
        a = msWebProcessCommand(s, w)

        If a = "1" Then

            MsgBox("Record deleted", MsgBoxStyle.Exclamation)
        Else
            MsgBox("Error 160618 " & a, MsgBoxStyle.Critical)

        End If

        PopulateGridFromDS()


    End Sub


End Class