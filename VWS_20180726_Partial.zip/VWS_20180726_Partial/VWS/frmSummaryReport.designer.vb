﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSummaryReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.dtpTo = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.dtpFrm = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnCustMatReport = New System.Windows.Forms.Button
        Me.btnMatsummary = New System.Windows.Forms.Button
        Me.btnClose = New System.Windows.Forms.Button
        Me.btnCustInside = New System.Windows.Forms.Button
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.dtpTo)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.dtpFrm)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Location = New System.Drawing.Point(35, 32)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(235, 137)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Date Selection"
        '
        'dtpTo
        '
        Me.dtpTo.CustomFormat = "dd/MM/yyyy"
        Me.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTo.Location = New System.Drawing.Point(64, 76)
        Me.dtpTo.Name = "dtpTo"
        Me.dtpTo.Size = New System.Drawing.Size(143, 23)
        Me.dtpTo.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "To"
        '
        'dtpFrm
        '
        Me.dtpFrm.CustomFormat = "dd/MM/yyyy"
        Me.dtpFrm.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFrm.Location = New System.Drawing.Point(64, 37)
        Me.dtpFrm.Name = "dtpFrm"
        Me.dtpFrm.Size = New System.Drawing.Size(143, 23)
        Me.dtpFrm.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "From"
        '
        'btnCustMatReport
        '
        Me.btnCustMatReport.Location = New System.Drawing.Point(54, 189)
        Me.btnCustMatReport.Name = "btnCustMatReport"
        Me.btnCustMatReport.Size = New System.Drawing.Size(216, 38)
        Me.btnCustMatReport.TabIndex = 4
        Me.btnCustMatReport.Text = "Customer / Material"
        Me.btnCustMatReport.UseVisualStyleBackColor = True
        '
        'btnMatsummary
        '
        Me.btnMatsummary.Location = New System.Drawing.Point(54, 253)
        Me.btnMatsummary.Name = "btnMatsummary"
        Me.btnMatsummary.Size = New System.Drawing.Size(216, 38)
        Me.btnMatsummary.TabIndex = 5
        Me.btnMatsummary.Text = "Material Summary"
        Me.btnMatsummary.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(424, 253)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(86, 38)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnCustInside
        '
        Me.btnCustInside.Location = New System.Drawing.Point(294, 189)
        Me.btnCustInside.Name = "btnCustInside"
        Me.btnCustInside.Size = New System.Drawing.Size(216, 38)
        Me.btnCustInside.TabIndex = 7
        Me.btnCustInside.Text = "Customer`s Truck Inside"
        Me.btnCustInside.UseVisualStyleBackColor = True
        '
        'frmSummaryReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(539, 332)
        Me.Controls.Add(Me.btnCustInside)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnMatsummary)
        Me.Controls.Add(Me.btnCustMatReport)
        Me.Controls.Add(Me.GroupBox3)
        Me.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmSummaryReport"
        Me.Text = "Summary Report"
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtpFrm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCustMatReport As System.Windows.Forms.Button
    Friend WithEvents btnMatsummary As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnCustInside As System.Windows.Forms.Button
End Class
