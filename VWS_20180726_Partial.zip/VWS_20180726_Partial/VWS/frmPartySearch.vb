﻿Public Class frmPartySearch


    'Dim msrv As New com.aijunction.Service1

    Dim cscode As String

    Dim vhCode As String

    Dim selectedcode As String

    Public Function ShowDialog_PartySearch(ByVal prmPartyCode As String, ByVal prmvhCode As String, ByVal ShowSelect As Boolean, ByVal Showfile As Boolean) As String

        'msrv.Url = mslv.webServiceURL

        selectedcode = prmPartyCode
        cscode = ""

        vhCode = prmvhCode

        Me.btnSelect.Visible = ShowSelect

        If arUserAccess(enUAcs.Open_Customer_file) = "1" Then
            Me.btnFile.Visible = Showfile
        Else
            Me.btnFile.Visible = False
        End If

        ShowDialog()

        ShowDialog_PartySearch = cscode

    End Function


    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

    Private Sub frmPartySearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        populateGrid()

        If selectedcode <> "" Then

            ' select item in db grid 
            Dim a As Integer
            a = msFindGridRowByValue(DataGridView1, "CustCode", selectedcode)

            If a > 0 Then
                DataGridView1.CurrentCell = DataGridView1.Item(1, a)
            End If

        End If

        Me.txtSearch.Focus()

    End Sub

    

    Private Sub PopulateGrid()

        Dim webEr As String
       

        Dim s As String

        If Me.txtSearch.Text.Trim = "" And vhCode <> "" Then

            s = getSqlFromTransactions()

        Else
            s = getSqlFromMaster()

        End If


        webEr = ""

        Dim ds As New DataSet
        Dim a As String
        a = mslCons.WebAuthcode
        Try

            ds = msWebGetDS(s, a)

            If a = mslCons.WebAuthcode Or IsNumeric(a) Then
                'Dim f As Font
                'f = New Font("Verdana", 8, FontStyle.Regular, GraphicsUnit.Point)

                'DataGridView1.Font = f

                DataGridView1.DataSource = ds
                DataGridView1.DataMember = ds.Tables(0).TableName

                DataGridView1.AutoResizeColumns()

                ' Me.bnCountItem.Text = "of " & DataGridView1.RowCount

            Else

                MsgBox("error 150206 " & a, MsgBoxStyle.Critical)

            End If


        Catch ex As Exception
            MsgBox("Error: 150117 " & "Populate Grid " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub txtSearch_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles txtSearch.KeyDown

        If e.KeyCode = Keys.Down Then
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearch.TextChanged

        'If Me.txtSearch.Text = "" Or txtSearch.Text.Length > 2 Then    '  (Me.txtSearch.Text.Length > 3 And Me.txtSearch.Text.Length Mod 2 = 0) Then
        PopulateGrid()
        'End If

    End Sub

    Private Sub DataGridView1_CellContentDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentDoubleClick

        'If e.KeyCode = Keys.Enter Then
        btnSelect.PerformClick()

        'End If

    End Sub

    Private Sub DataGridView1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DataGridView1.KeyDown
        If e.KeyCode = Keys.Enter Then
            btnSelect.PerformClick()

        End If

    End Sub


    Private Sub btnRef_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRef.Click

        Me.txtSearch.Text = ""
        PopulateGrid()

    End Sub

    Private Sub btnSelect_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSelect.Click

        If Me.DataGridView1.RowCount <= 0 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim enm As String
        enm = ""
        If DataGridView1.SelectedRows.Count() <= 1 Then
            enm = DataGridView1.CurrentRow.Cells("CustCode").Value
        Else
            For Each selecteditem As DataGridViewRow In DataGridView1.SelectedRows
                enm = selecteditem.Cells("CustCode").Value + "_" + enm
            Next
        End If


        If enm = "" Then Exit Sub

        cscode = enm

        Me.Close()

    End Sub


    Private Sub btnFile_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnFile.Click

        Dim skey As String
        skey = ""

        'If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow IsNot Nothing Then

            skey = DataGridView1.CurrentRow.Cells("PartyName").Value

        End If


        Dim FRMPT As New frmParties

        skey = FRMPT.ShowDialog_Parties(skey)
        Me.txtSearch.Text = skey

        msDoEvents()

        PopulateGrid()

    End Sub

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        PopulateGrid()

    End Sub

    Private Function getSqlFromMaster() As String

        Dim s As String
        Dim ser As String
        Dim wh As String
        wh = ""

        If Me.txtSearch.Text.Trim <> "" Then
            ser = Me.txtSearch.Text.Trim
            ser = ser.Replace(" ", " %")
            wh = wh & "CustName Like '" & ser & "%'"
            wh = wh & " or CustCode Like '" & ser & "%'"

        End If

        s = "Select top 100 CustCode , CustName , PriceGroup , PrepaidCust "
        s = s & " from tblCustomers "
        s = s & " where CustDisable = 0 "          '  CustID > 0 "

        If wh <> "" Then
            s = s & " and (" & wh & ")"
            s = s & " order by CustName"
        ElseIf selectedcode <> "" Then
            wh = "CustCode >= '" & selectedcode & "'"
            s = s & " and (" & wh & ")"
            s = s & " order by CustCode "
        Else
            s = s & " order by LastUpdateAt DESC"    ' PartyID DESC"
        End If

        getSqlFromMaster = s

    End Function

    Private Function getSqlFromTransactions() As String

        Dim s As String

        s = "Select top 100 CustCode , CustName , PriceGroup , PrepaidCust "
        s = s & " from tblWeighing "
        s = s & " where Vehcode = '" & vhCode & "' order by WgID desc"

        Dim s1 As String
        s1 = "Select CustCode , CustName , PriceGroup , PrepaidCust, count(custCode) as ccnt from ( " & s & " ) as tblB "
        s1 = s1 & "Group by CustCode , CustName , PriceGroup , PrepaidCust"

        s = "Select top 5 * from ( " & s1 & " ) as tblA order by ccnt Desc"

        getSqlFromTransactions = s


    End Function


End Class