﻿
Public Class frmMaterialSearch

    Dim mtcode As String

    Dim csCode As String

    Dim selectedcode As String

    Public Function ShowDialog_MatSearch(ByVal prmMatCode As String, ByVal prmcsCode As String, ByVal ShowSelect As Boolean, ByVal Showfile As Boolean) As String

        'msrv.Url = mslv.webServiceURL

        selectedcode = prmMatCode
        mtcode = ""

        csCode = prmcsCode

        Me.btnSelect.Visible = ShowSelect

        If arUserAccess(enUAcs.Open_Material_file) = "1" Then
            Me.btnFile.Visible = Showfile
        Else
            Me.btnFile.Visible = False
        End If

        ShowDialog()

        ShowDialog_MatSearch = csCode

    End Function


    Private Sub btnClose_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

    Private Sub frmMaterialSearch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        populateGrid()

        If selectedcode <> "" Then

            ' select item in db grid 
            Dim a As Integer
            a = msFindGridRowByValue(DataGridView1, "MatCode", selectedcode)

            If a > 0 Then
                DataGridView1.CurrentCell = DataGridView1.Item(1, a)
            End If

        End If

        Me.txtSearch.Focus()

    End Sub


    Private Sub PopulateGrid()

        Dim webEr As String


        Dim s As String

        If Me.txtSearch.Text.Trim = "" And csCode <> "" Then

            s = getSqlFromTransactions()

        Else
            s = getSqlFromMaster()

        End If


        webEr = ""

        Dim ds As New DataSet
        Dim a As String
        a = mslCons.WebAuthcode
        Try

            ds = msWebGetDS(s, a)

            If a = mslCons.WebAuthcode Or IsNumeric(a) Then
                'Dim f As Font
                'f = New Font("Verdana", 8, FontStyle.Regular, GraphicsUnit.Point)

                'DataGridView1.Font = f

                DataGridView1.DataSource = ds
                DataGridView1.DataMember = ds.Tables(0).TableName

                DataGridView1.AutoResizeColumns()

                ' Me.bnCountItem.Text = "of " & DataGridView1.RowCount

            Else

                MsgBox("error 150206 " & a, MsgBoxStyle.Critical)

            End If


        Catch ex As Exception
            MsgBox("Error: 150117 " & "Populate Grid " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub


    Private Sub txtSearch_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles txtSearch.KeyDown

        If e.KeyCode = Keys.Down Then
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearch.TextChanged

        'If Me.txtSearch.Text = "" Or txtSearch.Text.Length > 2 Then    '  (Me.txtSearch.Text.Length > 3 And Me.txtSearch.Text.Length Mod 2 = 0) Then
        PopulateGrid()
        'End If

    End Sub

    Private Sub DataGridView1_CellContentDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentDoubleClick

        btnSelect.PerformClick()

    End Sub

    Private Sub DataGridView1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DataGridView1.KeyDown
        If e.KeyCode = Keys.Enter Then
            btnSelect.PerformClick()

        End If

    End Sub


    Private Sub btnRef_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRef.Click

        Me.txtSearch.Text = ""
        PopulateGrid()

    End Sub

    Private Sub btnSelect_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSelect.Click

        If Me.DataGridView1.RowCount <= 0 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim enm As String
        enm = DataGridView1.CurrentRow.Cells("MatCode").Value

        If enm = "" Then Exit Sub

        cscode = enm

        Me.Close()

    End Sub


    Private Sub btnFile_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnFile.Click

        Dim skey As String
        skey = ""

        'If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow IsNot Nothing Then

            skey = DataGridView1.CurrentRow.Cells("MatName").Value

        End If


        Dim FRMPT As New frmMaterials

        skey = FRMPT.ShowDialog()
        Me.txtSearch.Text = skey

        msDoEvents()

        PopulateGrid()

    End Sub

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        PopulateGrid()

    End Sub

    Private Function getSqlFromMaster() As String

        Dim s As String
        Dim ser As String
        Dim wh As String
        wh = ""

        If Me.txtSearch.Text.Trim <> "" Then
            ser = Me.txtSearch.Text.Trim
            ser = ser.Replace(" ", " %")
            wh = wh & "MatName Like '" & ser & "%'"
            wh = wh & " or MatCode Like '" & ser & "%'"

        End If

        s = "Select top 100 MatCode , MatName , PriceA , PriceB , PriceC , PriceD , PriceE "
        s = s & " from tblMaterials "
        s = s & " where MatDisable = 0 "            '  CustID > 0 "

        If wh <> "" Then
            s = s & " and (" & wh & ")"
            s = s & " order by MatName"
        ElseIf selectedcode <> "" Then
            wh = "MatCode >= '" & selectedcode & "'"
            s = s & " and (" & wh & ")"
            s = s & " order by MatCode "
        Else
            s = s & " order by LastUpdateAt DESC"    ' PartyID DESC"
        End If

        getSqlFromMaster = s


    End Function

    Private Function getSqlFromTransactions() As String

        Dim s As String

        s = "Select top 100 MatCode , MatName "
        s = s & " from tblWeighing "
        s = s & " where custcode = '" & csCode & "' order by WgID desc"

        Dim s1 As String
        s1 = "Select MatCode , MatName , count(matCode) as ccnt from ( " & s & " ) as tblB "
        s1 = s1 & "Group by MatCode , MatName"

        s = "Select top 5 * from ( " & s1 & " ) as tblA order by ccnt Desc"

        getSqlFromTransactions = s


    End Function


    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class