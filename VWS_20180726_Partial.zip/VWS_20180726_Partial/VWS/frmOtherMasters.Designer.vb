﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOtherMasters
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOtherMasters))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.bnRefresh = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnEdit = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnSave = New System.Windows.Forms.ToolStripButton()
        Me.bnCancel = New System.Windows.Forms.ToolStripButton()
        Me.lblCodeCaption = New System.Windows.Forms.Label()
        Me.lbldispError = New System.Windows.Forms.ToolStripLabel()
        Me.bnClose = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.bnAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.bnCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.bnDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.bnPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblNameCaption = New System.Windows.Forms.Label()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.txtLM = New System.Windows.Forms.Label()
        Me.GroupBoxSearch = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        Me.GroupBoxSearch.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridView1.Location = New System.Drawing.Point(0, 246)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 26
        Me.DataGridView1.Size = New System.Drawing.Size(635, 200)
        Me.DataGridView1.TabIndex = 7
        '
        'bnRefresh
        '
        Me.bnRefresh.Image = CType(resources.GetObject("bnRefresh.Image"), System.Drawing.Image)
        Me.bnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnRefresh.Name = "bnRefresh"
        Me.bnRefresh.Size = New System.Drawing.Size(50, 35)
        Me.bnRefresh.Text = "Refresh"
        Me.bnRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'bnEdit
        '
        Me.bnEdit.Image = CType(resources.GetObject("bnEdit.Image"), System.Drawing.Image)
        Me.bnEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnEdit.Name = "bnEdit"
        Me.bnEdit.Size = New System.Drawing.Size(31, 35)
        Me.bnEdit.Text = "Edit"
        Me.bnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'bnSave
        '
        Me.bnSave.Image = CType(resources.GetObject("bnSave.Image"), System.Drawing.Image)
        Me.bnSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnSave.Name = "bnSave"
        Me.bnSave.Size = New System.Drawing.Size(35, 35)
        Me.bnSave.Text = "Save"
        Me.bnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnSave.ToolTipText = "Save"
        '
        'bnCancel
        '
        Me.bnCancel.Image = CType(resources.GetObject("bnCancel.Image"), System.Drawing.Image)
        Me.bnCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnCancel.Name = "bnCancel"
        Me.bnCancel.Size = New System.Drawing.Size(47, 35)
        Me.bnCancel.Text = "Cancel"
        Me.bnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnCancel.ToolTipText = "Cancel"
        '
        'lblCodeCaption
        '
        Me.lblCodeCaption.AutoSize = True
        Me.lblCodeCaption.Location = New System.Drawing.Point(24, 100)
        Me.lblCodeCaption.Name = "lblCodeCaption"
        Me.lblCodeCaption.Size = New System.Drawing.Size(40, 14)
        Me.lblCodeCaption.TabIndex = 2
        Me.lblCodeCaption.Text = "Code"
        '
        'lbldispError
        '
        Me.lbldispError.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldispError.ForeColor = System.Drawing.Color.Red
        Me.lbldispError.Name = "lbldispError"
        Me.lbldispError.Size = New System.Drawing.Size(0, 35)
        '
        'bnClose
        '
        Me.bnClose.Image = CType(resources.GetObject("bnClose.Image"), System.Drawing.Image)
        Me.bnClose.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnClose.Name = "bnClose"
        Me.bnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.bnClose.Size = New System.Drawing.Size(40, 35)
        Me.bnClose.Text = "Close"
        Me.bnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnClose.ToolTipText = "Close"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 38)
        '
        'bnMoveLastItem
        '
        Me.bnMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveLastItem.Image = CType(resources.GetObject("bnMoveLastItem.Image"), System.Drawing.Image)
        Me.bnMoveLastItem.Name = "bnMoveLastItem"
        Me.bnMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveLastItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveLastItem.Text = "Move last"
        '
        'bnMoveNextItem
        '
        Me.bnMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveNextItem.Image = CType(resources.GetObject("bnMoveNextItem.Image"), System.Drawing.Image)
        Me.bnMoveNextItem.Name = "bnMoveNextItem"
        Me.bnMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveNextItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.bnAddNewItem
        Me.BindingNavigator1.CountItem = Me.bnCountItem
        Me.BindingNavigator1.DeleteItem = Me.bnDeleteItem
        Me.BindingNavigator1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.bnMoveFirstItem, Me.bnMovePreviousItem, Me.BindingNavigatorSeparator, Me.bnPositionItem, Me.bnCountItem, Me.BindingNavigatorSeparator1, Me.bnMoveNextItem, Me.bnMoveLastItem, Me.BindingNavigatorSeparator2, Me.bnAddNewItem, Me.bnEdit, Me.bnDeleteItem, Me.ToolStripSeparator1, Me.bnRefresh, Me.ToolStripSeparator2, Me.bnSave, Me.bnCancel, Me.ToolStripSeparator3, Me.bnClose, Me.lbldispError})
        Me.BindingNavigator1.Location = New System.Drawing.Point(0, 208)
        Me.BindingNavigator1.MoveFirstItem = Me.bnMoveFirstItem
        Me.BindingNavigator1.MoveLastItem = Me.bnMoveLastItem
        Me.BindingNavigator1.MoveNextItem = Me.bnMoveNextItem
        Me.BindingNavigator1.MovePreviousItem = Me.bnMovePreviousItem
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.bnPositionItem
        Me.BindingNavigator1.Size = New System.Drawing.Size(635, 38)
        Me.BindingNavigator1.TabIndex = 6
        Me.BindingNavigator1.Text = "BindingNavigator1"
        '
        'bnAddNewItem
        '
        Me.bnAddNewItem.Image = CType(resources.GetObject("bnAddNewItem.Image"), System.Drawing.Image)
        Me.bnAddNewItem.Name = "bnAddNewItem"
        Me.bnAddNewItem.RightToLeftAutoMirrorImage = True
        Me.bnAddNewItem.Size = New System.Drawing.Size(35, 35)
        Me.bnAddNewItem.Text = "New"
        Me.bnAddNewItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'bnCountItem
        '
        Me.bnCountItem.Name = "bnCountItem"
        Me.bnCountItem.Size = New System.Drawing.Size(35, 35)
        Me.bnCountItem.Text = "of {0}"
        Me.bnCountItem.ToolTipText = "Total number of items"
        '
        'bnDeleteItem
        '
        Me.bnDeleteItem.Image = CType(resources.GetObject("bnDeleteItem.Image"), System.Drawing.Image)
        Me.bnDeleteItem.Name = "bnDeleteItem"
        Me.bnDeleteItem.RightToLeftAutoMirrorImage = True
        Me.bnDeleteItem.Size = New System.Drawing.Size(44, 35)
        Me.bnDeleteItem.Text = "Delete"
        Me.bnDeleteItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnDeleteItem.Visible = False
        '
        'bnMoveFirstItem
        '
        Me.bnMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveFirstItem.Image = CType(resources.GetObject("bnMoveFirstItem.Image"), System.Drawing.Image)
        Me.bnMoveFirstItem.Name = "bnMoveFirstItem"
        Me.bnMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveFirstItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveFirstItem.Text = "Move first"
        '
        'bnMovePreviousItem
        '
        Me.bnMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMovePreviousItem.Image = CType(resources.GetObject("bnMovePreviousItem.Image"), System.Drawing.Image)
        Me.bnMovePreviousItem.Name = "bnMovePreviousItem"
        Me.bnMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.bnMovePreviousItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 38)
        '
        'bnPositionItem
        '
        Me.bnPositionItem.AccessibleName = "Position"
        Me.bnPositionItem.Name = "bnPositionItem"
        Me.bnPositionItem.Size = New System.Drawing.Size(36, 38)
        Me.bnPositionItem.Text = "0"
        Me.bnPositionItem.ToolTipText = "Current position"
        '
        'txtName
        '
        Me.txtName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtName.Location = New System.Drawing.Point(148, 139)
        Me.txtName.MaxLength = 40
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(464, 22)
        Me.txtName.TabIndex = 5
        '
        'lblNameCaption
        '
        Me.lblNameCaption.AutoSize = True
        Me.lblNameCaption.Location = New System.Drawing.Point(24, 142)
        Me.lblNameCaption.Name = "lblNameCaption"
        Me.lblNameCaption.Size = New System.Drawing.Size(43, 14)
        Me.lblNameCaption.TabIndex = 4
        Me.lblNameCaption.Text = "Name"
        '
        'lblCode
        '
        Me.lblCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCode.Location = New System.Drawing.Point(148, 95)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(120, 28)
        Me.lblCode.TabIndex = 3
        Me.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtLM
        '
        Me.txtLM.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLM.Location = New System.Drawing.Point(389, 19)
        Me.txtLM.Name = "txtLM"
        Me.txtLM.Size = New System.Drawing.Size(234, 39)
        Me.txtLM.TabIndex = 1
        Me.txtLM.Text = "  "
        Me.txtLM.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBoxSearch
        '
        Me.GroupBoxSearch.Controls.Add(Me.btnSearch)
        Me.GroupBoxSearch.Controls.Add(Me.txtSearch)
        Me.GroupBoxSearch.Location = New System.Drawing.Point(27, 19)
        Me.GroupBoxSearch.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBoxSearch.Name = "GroupBoxSearch"
        Me.GroupBoxSearch.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBoxSearch.Size = New System.Drawing.Size(357, 57)
        Me.GroupBoxSearch.TabIndex = 0
        Me.GroupBoxSearch.TabStop = False
        Me.GroupBoxSearch.Text = "Search"
        '
        'btnSearch
        '
        Me.btnSearch.Image = CType(resources.GetObject("btnSearch.Image"), System.Drawing.Image)
        Me.btnSearch.Location = New System.Drawing.Point(315, 22)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(24, 25)
        Me.btnSearch.TabIndex = 1
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSearch.Location = New System.Drawing.Point(19, 22)
        Me.txtSearch.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSearch.MaxLength = 20
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(291, 22)
        Me.txtSearch.TabIndex = 0
        '
        'frmOtherMasters
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(635, 446)
        Me.Controls.Add(Me.GroupBoxSearch)
        Me.Controls.Add(Me.lblCodeCaption)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblNameCaption)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.txtLM)
        Me.Controls.Add(Me.BindingNavigator1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "frmOtherMasters"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmOtherMasters"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        Me.GroupBoxSearch.ResumeLayout(False)
        Me.GroupBoxSearch.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents bnRefresh As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnEdit As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnCancel As System.Windows.Forms.ToolStripButton
    Friend WithEvents lblCodeCaption As System.Windows.Forms.Label
    Friend WithEvents lbldispError As System.Windows.Forms.ToolStripLabel
    Friend WithEvents bnClose As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigator1 As System.Windows.Forms.BindingNavigator
    Friend WithEvents bnAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents bnDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblNameCaption As System.Windows.Forms.Label
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents txtLM As System.Windows.Forms.Label
    Friend WithEvents GroupBoxSearch As System.Windows.Forms.GroupBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
End Class
