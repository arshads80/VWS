﻿Public Class frmAddCustCredit

    Private FormMode As FormModes

    'Dim msrv As New com.aijunction.Service1

    Dim curRecNo As Integer

    Dim ww As String

    Public Sub ShowDialog_AddCustCredit(ByVal ccCode As String)

        Me.lblCustcode.Text = ccCode

        ShowDialog()
        
    End Sub

   
    Private Sub frmAddCustCredit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If arUserAccess(enUAcs.Modify_cust_Credit) = "1" Then
            Me.bnEdit.Visible = True
        Else
            Me.bnEdit.Visible = False
        End If

        If arUserAccess(enUAcs.Delete_cust_Credit) = "1" Then
            Me.bnDeleteItem.Visible = True
        Else
            Me.bnDeleteItem.Visible = False
        End If

        '  msrv.Url = mslv.webServiceURL

        
        DisableEdits()
        Populategrid()

    End Sub

    Private Sub msWriteLM(ByVal LmData As String, Optional ByVal rgbh As String = "0")

        Dim obj As Control
        obj = Me.txtLM

        If TypeOf obj Is TextBox Then
            If CType(obj, TextBox).Multiline Then
                Me.txtLM.Text = LmData & vbCrLf & Me.txtLM.Text
            Else
                Me.txtLM.Text = LmData
            End If

        Else
            Me.txtLM.Text = LmData
        End If

        'msDoEvents()

        Dim pColor As Color
        Select Case rgbh.ToLower
            Case "r"
                pColor = Color.Crimson
            Case "b"    ' blue
                pColor = Color.Blue
            Case "g"
                pColor = Color.Green
            Case "h"  ' highlight
                pColor = Color.DarkBlue
            Case Else
                pColor = Color.Black
        End Select


        txtLM.ForeColor = pColor

        If rgbh = "h" Then
            txtLM.BackColor = Color.Yellow
        Else
            txtLM.BackColor = Color.WhiteSmoke
        End If

    End Sub


    Private Sub DisableEdits()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls    ' Me.pnlMatMaster.Controls
            If TypeOf ctr Is TextBox Then
                CType(ctr, TextBox).ReadOnly = True
                CType(ctr, TextBox).Text = Trim(ctr.Text)
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Enabled = False
            ElseIf TypeOf ctr Is ComboBox Then
                CType(ctr, ComboBox).Enabled = False
            End If
        Next

        ' disable navigation controls

        '  Me.GroupBoxSearch.Enabled = True
        Me.DataGridView1.Enabled = True
        Me.bnMoveFirstItem.Enabled = True
        ' Me.txtSearch.ReadOnly = False

        Me.bnMoveFirstItem.Enabled = True
        Me.bnMovePreviousItem.Enabled = True
        Me.bnMoveNextItem.Enabled = True
        Me.bnMoveLastItem.Enabled = True
        Me.bnAddNewItem.Enabled = True
        Me.bnCancel.Enabled = False
        Me.bnDeleteItem.Enabled = True
        Me.bnEdit.Enabled = True
        Me.bnRefresh.Enabled = True
        Me.bnSave.Enabled = False

        FormMode = FormModes.SearchMode


    End Sub

    Private Sub EnableEdits()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls
            If TypeOf ctr Is TextBox Then
                CType(ctr, TextBox).ReadOnly = False
                CType(ctr, TextBox).Text = Trim(ctr.Text)
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Enabled = True
            ElseIf TypeOf ctr Is ComboBox Then
                CType(ctr, ComboBox).Enabled = True
            End If
        Next

        ' disable navigation controls

        'Me.GroupBoxSearch.Enabled = False
        Me.DataGridView1.Enabled = False
        Me.bnMoveFirstItem.Enabled = False
        'Me.txtSearch.ReadOnly = True

        Me.bnMoveFirstItem.Enabled = False
        Me.bnMovePreviousItem.Enabled = False
        Me.bnMoveNextItem.Enabled = False
        Me.bnMoveLastItem.Enabled = False
        Me.bnAddNewItem.Enabled = False
        Me.bnCancel.Enabled = True
        Me.bnDeleteItem.Enabled = False
        Me.bnEdit.Enabled = False
        Me.bnRefresh.Enabled = False
        Me.bnSave.Enabled = True

        

    End Sub


    Private Sub ClearForm()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls
            If TypeOf ctr Is TextBox Then
                ctr.Text = ""
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Checked = False
            End If

        Next

        Me.txtAmount.Text = 0
        
    End Sub

    Private Sub PopulateGrid()

        Dim webEr As String
        Dim s As String
        '  Dim ser As String
        Dim wh As String
        wh = ""

        'If Me.txtSearch.Text.Trim <> "" Then
        '    ser = Me.txtSearch.Text.Trim
        '    ser = ser.Replace(" ", " %")
        '    wh = wh & "CustName Like '" & ser & "%'"
        '    wh = wh & " or CustCode = '" & ser & "'"
        '    wh = wh & " or Mobile Like '" & ser & "%'"
        'End If

        wh = "CustCode = '" & Me.lblCustcode.Text & "'"


        webEr = ""

        s = "Select CustCode, EntryDatetime, AmtIN, AmtOut, TicketNo, CustPayID "
        s = s & " from tblCustPayments "
        s = s & " where CustPayID > 0 and CanFlag = 0  "

        If wh <> "" Then
            s = s & " and (" & wh & ")"
        
        End If
        s = s & " order by CustPayID DESC"


        Dim ds As New DataSet
        Dim a As String
        a = mslCons.WebAuthCode
        Try

            ds = msWebGetDS(s, a)

            If a = mslCons.WebAuthCode Or IsNumeric(a) Then
                Dim f As Font
                f = New Font("Verdana", 8, FontStyle.Regular, GraphicsUnit.Point)

                DataGridView1.Font = f

                DataGridView1.DataSource = ds
                DataGridView1.DataMember = ds.Tables(0).TableName

                DataGridView1.AutoResizeColumns()

                Me.bnCountItem.Text = "of " & DataGridView1.RowCount

            Else

                MsgBox("error 150206 " & a, MsgBoxStyle.Critical)

            End If


        Catch ex As Exception
            MsgBox("Error: 150117 " & "Populate Grid " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Function FormNotValid() As Boolean

        FormNotValid = True

        If Not IsNumeric(Me.txtAmount.Text) Then
            Me.lbldispError.Text = "Invalid Amount"
            Me.txtAmount.Focus()
            Exit Function
        End If

        If Val(Me.txtAmount.Text) = 0 Then
            Me.lbldispError.Text = "Invalid Amount"
            Me.txtAmount.Focus()
            Exit Function
        End If

        FormNotValid = False

    End Function

    'Private Sub txtSearch_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown

    '    If e.KeyCode = Keys.Down Then
    '        Me.DataGridView1.Focus()
    '    End If

    'End Sub


    'Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

    '    PopulateGrid()

    'End Sub


    Private Sub PopulateForm()

        If Me.DataGridView1.RowCount <= 0 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim enm As String
        '  enm = DataGridView1.CurrentRow.Cells("CustPayID").Value

        '  If Me.txtCustCode.Text = enm Then Exit Sub ' same record no need to update

        enm = DataGridView1.CurrentRow.Cells("CustPayID").Value

        If Not IsNumeric(enm) Then Exit Sub

        Dim s As String
        s = "Select * from tblCustPayments where CustPayID = " & Val(enm) & " and CanFlag = 0 "

        Dim ds As DataSet
        Dim a As String
        a = mslCons.WebAuthCode

        Try
            ds = msWebGetDS(s, a)


            If a = mslCons.WebAuthCode Or IsNumeric(a) Then
                'ok
            Else
                Exit Try
            End If

            Dim dr As DataRow
            dr = ds.Tables(0).Rows(0)

            Me.txtAmount.Text = dr("AmtIN").ToString

            Me.bnPositionItem.Text = DataGridView1.CurrentRow.Index + 1

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)

        End Try

    End Sub


    Private Sub DataGridView1_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEnter

        PopulateForm()

    End Sub


    Private Sub bnAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnAddNewItem.Click

        FormMode = FormModes.AddMode
        EnableEdits()
        ClearForm()
        Me.txtAmount.Focus()

    End Sub

    Private Sub bnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnEdit.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        If DataGridView1.CurrentRow.Cells("AmtIn").Value = 0 Then
            MsgBox("Amount Out can not be edited", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        FormMode = FormModes.EditMode
        EnableEdits()

        Me.txtAmount.Focus()

    End Sub

    Private Sub bnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnCancel.Click

        DisableEdits()
        PopulateForm()

    End Sub


    Private Sub bnDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnDeleteItem.Click

        If FormMode = FormModes.NormalMode Or FormMode = FormModes.SearchMode Then
            ' ok
        Else
            Exit Sub
        End If

        If Me.DataGridView1.RowCount < 1 Then Exit Sub

        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        If Me.DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("Select a record to edit ....", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim envnum As String
        envnum = DataGridView1.CurrentRow.Cells("CustPayID").Value

        If DataGridView1.CurrentRow.Cells("AmtIn").Value = 0 Then
            MsgBox("Amount Out can not be deleted", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If MsgBox("Are you sure you want to delete selected record from the database" & vbCrLf & "CustCode: " & envnum, MsgBoxStyle.DefaultButton2 + MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim s As String
        s = "Delete from tblCustPayments where CustPayID = " & envnum

        Dim a As String
        Dim w As String
        w = mslCons.WebAuthCode

        a = msWebProcessCommand(s, w)

        If IsNumeric(a) Then

            ' MsgBox(a & " records deleted", MsgBoxStyle.Exclamation)
            msWriteLM(a & " record/s deleted", "r")


            PopulateGrid()
        Else
            MsgBox("Error " & vbCrLf & a, MsgBoxStyle.Critical)

        End If


    End Sub


    Private Sub bnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnSave.Click

        If FormNotValid() Then Exit Sub

        '''''''  using update statment
        Dim ArF As New List(Of String)
        Dim ArV As New List(Of String)
        Dim ArT As New List(Of String)

        ' following is required for multiple table updates or update in loop
        ArF.Clear()
        ArV.Clear()
        ArT.Clear()
        '==================================

        If FormMode = FormModes.AddMode Then

            ArF.Add("EntryDateTime")
            ArV.Add("server date")
            ArT.Add("St")    '	"N") 

        End If

        ArF.Add("CustCode")
        ArV.Add(Me.lblCustcode.Text)
        ArT.Add("s")  ' or S

        ArF.Add("AmtIn")
        ArV.Add(Me.txtAmount.Text)
        ArT.Add("n")  ' or S

        ArF.Add("AmtOut")
        ArV.Add("0")
        ArT.Add("n")  ' or S

        ArF.Add("TicketNo")
        ArV.Add("0")
        ArT.Add("n")  ' or S

        If FormMode = FormModes.EditMode Then
            ArF.Add("SyncFlag")
            ArV.Add("2")
            ArT.Add("n")
        End If

        Dim a As String

        Try
            Me.bnSave.Enabled = False
            'a = msrv.getlictoolcode(arF.ToArray, arV.ToArray, arT.ToArray, arH.ToArray, Me.txtEmail.Text)
            If FormMode = FormModes.EditMode Then
                Dim wcls As String


                wcls = "CustPayID = " & Me.DataGridView1.CurrentRow.Cells("CustPayID").Value

                a = msWebUpdateArrayListInDB("tblCustPayments", ArF.ToArray, ArV.ToArray, ArT.ToArray, wcls, mslCons.WebAuthcode)
                If IsNumeric(a) Then
                    MsgBox(a & " Record/s updated", MsgBoxStyle.Information)
                End If

            Else
                a = msWebInsertRecIntoDb("tblCustPayments", ArF.ToArray, ArV.ToArray, ArT.ToArray, mslCons.WebAuthcode)

            End If

            If a <> "1" Then
                MsgBox("unable to save" & vbCrLf & a, MsgBoxStyle.Critical)
                Me.bnSave.Enabled = True
                Exit Sub
            End If

            If FormMode = FormModes.AddMode Then

                '  Me.txtSearch.Text = ""

            End If

            'ClearForm()

            PopulateGrid()

            If FormMode = FormModes.EditMode Then

                If curRecNo < DataGridView1.RowCount Then
                    'DataGridView1.Rows(curRecNo).Selected = True
                    DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
                End If

            End If

            DisableEdits()


        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical)

            Exit Sub

        End Try


    End Sub


    Private Sub bnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnClose.Click

        Me.Close()

    End Sub


    Private Sub bnReports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnReports.Click

        Dim arf As New List(Of String)
        Dim arh As New List(Of String)
        Dim art As New List(Of String)

        arf.Add("EntryDatetime")
        arh.Add("EntryDatetime")
        art.Add("dt")

        arf.Add("AmtIN")
        arh.Add("AmtIN")
        art.Add("f")

        arf.Add("AmtOut")
        arh.Add("AmtOut")
        art.Add("f")

        arf.Add("AmtBal")
        arh.Add("AmtBal")
        art.Add("f")

        arf.Add("TicketNo")
        arh.Add("TicketNo")
        art.Add("s")

        Dim hdgList As New List(Of String)
        
        hdgList.Add("Cust Code")
        hdgList.Add(Me.lblCustcode.Text)

        Dim s As String
        Dim w As String
        w = mslCons.WebAuthcode

        s = msWebGetFieldValue("Select CustName from tblCustomers where CustCode = '" & Me.lblCustcode.Text & "'", "CustName", w)

        hdgList.Add("Name")
        hdgList.Add(s)


        Dim hdg As String
        hdg = msPrepareHeader(hdgList)

        Dim sc As New List(Of String)
        Dim sf As New List(Of String)
        sc.Add("Total AmtIN")
        sf.Add("AmtIN")

        sc.Add("Total AmtOut")
        sf.Add("AmtOut")

        sc.Add("Balance")
        sf.Add("AmtBal")

        s = "select *, (amtIN - AmtOut) as AmtBal from tblCustPayments where CustCode = '" & Me.lblCustcode.Text & "' and CanFlag = 0 order by EntryDatetime"

        Dim fm As New frmStatus
        fm.Show("Preparing report, Please wait ...")

        Dim dsr As DataSet
        dsr = msWebGetDS(s, w)

        If dsr.Tables.Count < 1 Then
            fm.Close()
            MsgBox("Error retrieving data", MsgBoxStyle.Critical)
            Exit Sub
        End If

        Dim fn As String
        fn = ""

        fn = msReturnBasicReport(dsr, arf, arh, art, "Customer Credit Details", hdg, "", "Total Transactions", sc, sf, False, "", 1, True)

        Dim frmRep As New frmReports

        'frmRep.MdiParent = mdiMS
        'frmRep.ShowDialog(fn, "Reports - Vehical Weighing System")

        fm.Close()

        If My.Computer.FileSystem.FileExists(fn) Then

            frmRep.ShowDialog(fn, "Reports - Vehical Weighing System")
            Try
                My.Computer.FileSystem.DeleteFile(fn)
            Catch ex As Exception

            End Try
        Else
            MsgBox("Error " & fn, MsgBoxStyle.Critical)
        End If


    End Sub


End Class