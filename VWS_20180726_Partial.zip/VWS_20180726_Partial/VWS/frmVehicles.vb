﻿Public Class frmVehicles

    Private FormMode As FormModes

    Dim keyToRet As String
    'Dim msrv As New com.aijunction.Service1

    Dim curRecNo As Integer

    Dim ww As String


    Public Function ShowDialog_Vehicles(Optional ByVal prmSelectKey As String = "") As String

        'msrv.Url = serviceUrl

        keyToRet = prmSelectKey
        ShowDialog()
        ShowDialog_Vehicles = keyToRet

    End Function

    Private Sub frmVehicles_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If arUserAccess(enUAcs.Edit_Vehicle) = "1" Then
            Me.bnEdit.Visible = True
        Else
            Me.bnEdit.Visible = False
        End If

        If arUserAccess(enUAcs.Delete_Vehicle) = "1" Then
            Me.bnDeleteItem.Visible = True
        Else
            Me.bnDeleteItem.Visible = False
        End If

        If arUserAccess(enUAcs.Manual_Tare_entry) = "1" Then
            Me.btnManualTare.Visible = True
        Else
            Me.btnManualTare.Visible = False
        End If

        '  msrv.Url = mslv.webServiceURL


        Dim alist As New AutoCompleteStringCollection
        Dim sSql As String
        sSql = "Select top 3000 VehCode from tblVehicles order by LastUpdateAt DESC "
        alist = msPopulateAutoCompleteListDS(sSql, 3000, 1)
        txtVehCode.AutoCompleteCustomSource = alist

        DisableEdits()
        Populategrid()

        If keyToRet <> "" Then
            If Me.DataGridView1.RowCount >= 999 Then
                Me.txtSearch.Text = Mid(keyToRet, 1, 2)   '  keyToRet.Substring(1, 2)
            ElseIf DataGridView1.RowCount > 99 Then
                Me.txtSearch.Text = Mid(keyToRet, 1, 1)    '  keyToRet.Substring(0, 1)
            End If
        End If


        If Sysvars.UseWA = "1" Then

            Me.btnW1.Visible = True

        Else
            Me.btnW1.Visible = False

        End If

    
        
    End Sub

    Private Sub msWriteLM(ByVal LmData As String, Optional ByVal rgbh As String = "0")

        Dim obj As Control
        obj = Me.txtLM

        If TypeOf obj Is TextBox Then
            If CType(obj, TextBox).Multiline Then
                Me.txtLM.Text = LmData & vbCrLf & Me.txtLM.Text
            Else
                Me.txtLM.Text = LmData
            End If

        Else
            Me.txtLM.Text = LmData
        End If

        'msDoEvents()

        Dim pColor As Color
        Select Case rgbh.ToLower
            Case "r"
                pColor = Color.Crimson
            Case "b"    ' blue
                pColor = Color.Blue
            Case "g"
                pColor = Color.Green
            Case "h"  ' highlight
                pColor = Color.DarkBlue
            Case Else
                pColor = Color.Black
        End Select


        txtLM.ForeColor = pColor

        If rgbh = "h" Then
            txtLM.BackColor = Color.Yellow
        Else
            txtLM.BackColor = Color.WhiteSmoke
        End If

    End Sub

    Private Sub DisableEdits()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls    ' Me.pnlMatMaster.Controls
            If TypeOf ctr Is TextBox Then
                CType(ctr, TextBox).ReadOnly = True
                CType(ctr, TextBox).Text = Trim(ctr.Text)
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Enabled = False
            ElseIf TypeOf ctr Is ComboBox Then
                CType(ctr, ComboBox).Enabled = False
            End If
        Next

        ' disable navigation controls

        Me.GroupBoxSearch.Enabled = True
        Me.DataGridView1.Enabled = True
        Me.bnMoveFirstItem.Enabled = True
        Me.txtSearch.ReadOnly = False

        Me.bnMoveFirstItem.Enabled = True
        Me.bnMovePreviousItem.Enabled = True
        Me.bnMoveNextItem.Enabled = True
        Me.bnMoveLastItem.Enabled = True
        Me.bnAddNewItem.Enabled = True
        Me.bnCancel.Enabled = False
        Me.bnDeleteItem.Enabled = True
        Me.bnEdit.Enabled = True
        Me.bnRefresh.Enabled = True
        Me.bnSave.Enabled = False

        Me.btnManualTare.Enabled = False
        Me.btnW1.Enabled = False
        Me.btnW2.Enabled = False
        Me.txtTareWt.ReadOnly = True

        FormMode = FormModes.SearchMode


    End Sub

    Private Sub EnableEdits()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls
            If TypeOf ctr Is TextBox Then
                CType(ctr, TextBox).ReadOnly = False
                CType(ctr, TextBox).Text = Trim(ctr.Text)
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Enabled = True
            ElseIf TypeOf ctr Is ComboBox Then
                CType(ctr, ComboBox).Enabled = True
            End If
        Next

        ' disable navigation controls

        Me.GroupBoxSearch.Enabled = False
        Me.DataGridView1.Enabled = False
        Me.bnMoveFirstItem.Enabled = False
        Me.txtSearch.ReadOnly = True

        Me.bnMoveFirstItem.Enabled = False
        Me.bnMovePreviousItem.Enabled = False
        Me.bnMoveNextItem.Enabled = False
        Me.bnMoveLastItem.Enabled = False
        Me.bnAddNewItem.Enabled = False
        Me.bnCancel.Enabled = True
        Me.bnDeleteItem.Enabled = False
        Me.bnEdit.Enabled = False
        Me.bnRefresh.Enabled = False
        Me.bnSave.Enabled = True

        Me.btnManualTare.Enabled = True
        Me.btnW1.Enabled = True
        Me.btnW2.Enabled = True
        Me.txtTareWt.ReadOnly = True


    End Sub


    Private Sub ClearForm()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls
            If TypeOf ctr Is TextBox Then
                ctr.Text = ""
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Checked = False
            End If

        Next

        Me.txtTareWt.Text = 0
        
    End Sub

    Private Sub PopulateGrid()

        Dim webEr As String
        Dim s As String
        Dim ser As String
        Dim wh As String
        wh = ""

        If Me.txtSearch.Text.Trim <> "" Then
            ser = Me.txtSearch.Text.Trim
            ser = ser.Replace(" ", " %")
            wh = wh & "VehCode Like '" & ser & "%'"
            wh = wh & " or VehName Like '" & ser & "%'"
            wh = wh & " or VehOwner Like '" & ser & "%'"
            wh = wh & " or DriverName Like '" & ser & "%'"
            wh = wh & " or DriverMob Like '" & ser & "%'"
        End If

        webEr = ""

        s = "Select top 100 VehCode, VehName, DriverName, DriverMob, VehOwner, VehID "
        s = s & " from tblVehicles "
        s = s & " where VehID > 0 "

        If wh <> "" Then
            s = s & " and (" & wh & ")"
            s = s & " order by VehCode "
        Else
            s = s & " order by LastUpdateAt DESC "    ' CustID DESC"
        End If

        Dim ds As New DataSet
        Dim a As String
        a = mslCons.WebAuthcode

        Try

            ds = msWebGetDS(s, a)

            If a = mslCons.WebAuthCode Or IsNumeric(a) Then
                Dim f As Font
                f = New Font("Verdana", 8, FontStyle.Regular, GraphicsUnit.Point)

                DataGridView1.Font = f

                DataGridView1.DataSource = ds
                DataGridView1.DataMember = ds.Tables(0).TableName

                DataGridView1.AutoResizeColumns()

                Me.bnCountItem.Text = "of " & DataGridView1.RowCount

            Else

                MsgBox("error 150206 " & a, MsgBoxStyle.Critical)

            End If


        Catch ex As Exception
            MsgBox("Error: 150117 " & "Populate Grid " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Function FormNotValid() As Boolean

        FormNotValid = True

        If Me.txtVehCode.Text = "" Then
            'Me.lbldispError.Text = "Enter Vehicle Name!"
            msWriteLM("Enter Vehicle Code")
            Me.txtVehCode.Focus()
            Exit Function
        End If

        If Not IsNumeric(Me.txtTareWt.Text) Then
            msWriteLM("Invalid Weight")
            Me.btnW1.Focus()
        End If

        Me.txtDriverMob.Text = Me.txtDriverMob.Text.Trim
        Me.txtDriverMob.Text = Me.txtDriverMob.Text.Replace(" ", "").Replace("-", "")

        If Not isMobileOk() Then
            Me.txtDriverMob.Focus()
            Exit Function
        End If

        FormNotValid = False

    End Function

    Private Sub txtSearch_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown

        If e.KeyCode = Keys.Down Then
            Me.DataGridView1.Focus()
        End If

    End Sub


    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        PopulateGrid()

    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSearch.TextChanged

        If Me.txtSearch.Text = "" Or (Me.txtSearch.Text.Length > 2 And Me.txtSearch.Text.Length Mod 2 = 1) Or Me.txtSearch.Text.Length > 7 Then
            PopulateGrid()
        End If

    End Sub

    Private Sub PopulateForm()

        If Me.DataGridView1.RowCount <= 0 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim enm As String
        enm = DataGridView1.CurrentRow.Cells("VehCode").Value

        If Me.txtVehCode.Text = enm Then Exit Sub ' same record no need to update

        enm = DataGridView1.CurrentRow.Cells("VehID").Value

        If Not IsNumeric(enm) Then Exit Sub


        Dim s As String
        s = "Select * from tblVehicles where VehID = " & Val(enm)

        Dim ds As DataSet
        Dim a As String
        a = mslCons.WebAuthCode

        Try
            ds = msWebGetDS(s, a)


            If a = mslCons.WebAuthCode Or IsNumeric(a) Then
                'ok
            Else
                Exit Try
            End If

            Dim dr As DataRow
            dr = ds.Tables(0).Rows(0)

            txtVehName.Text = dr("VehName").ToString
            txtVehCode.Text = dr("VehCode").ToString
            txtOwner.Text = dr("VehOwner").ToString
            txtTareWt.Text = dr("VehTareWt").ToString
            txtDriver.Text = dr("DriverName").ToString
            txtDriverMob.Text = dr("DriverMob").ToString
            Me.txtMTare.Text = dr("VehWtRemark").ToString
            
            Me.bnPositionItem.Text = DataGridView1.CurrentRow.Index + 1

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)

        End Try


    End Sub


    Private Sub DataGridView1_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEnter

        PopulateForm()

    End Sub


    Private Sub bnAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnAddNewItem.Click

        FormMode = FormModes.AddMode
        EnableEdits()
        ClearForm()
        Me.txtVehCode.Focus()


    End Sub

    Private Sub bnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnEdit.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        FormMode = FormModes.EditMode
        EnableEdits()
        Me.txtVehCode.ReadOnly = True
        Me.txtTareWt.ReadOnly = True
        Me.txtVehName.Focus()

    End Sub

    Private Sub bnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnCancel.Click

        DisableEdits()
        PopulateForm()

    End Sub


    Private Sub bnDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnDeleteItem.Click

        If FormMode = FormModes.NormalMode Or FormMode = FormModes.SearchMode Then
            ' ok
        Else
            Exit Sub
        End If

        If Me.DataGridView1.RowCount < 1 Then Exit Sub

        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        If Me.DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("Select a record to edit ....", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim envnum As String
        envnum = DataGridView1.CurrentRow.Cells("VehCode").Value

        If MsgBox("Are you sure you want to delete selected record from the database" & vbCrLf & "VehCode: " & envnum, MsgBoxStyle.DefaultButton2 + MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim ds As DataSet
        Try
            ww = mslCons.WebAuthCode
            ds = msWebGetDS("Select top 1 VehCode from tblWeighing where VehCode = '" & envnum & "'", ww)
            If ds.Tables(0).Rows.Count > 0 Then
                MsgBox("There are Weighing entries for this Vehicle" & vbCrLf & "Record can not be deleted", MsgBoxStyle.Exclamation)
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox("Error 150404 : " & ex.Message & vbCrLf & "Record can not be deleted", MsgBoxStyle.Critical)
            Exit Sub
        End Try

        Dim s As String
        s = "Delete from tblVehicles where VehCode = '" & envnum & "'"

        Dim a As String
        Dim w As String
        w = mslCons.WebAuthCode

        a = msWebProcessCommand(s, w)

        If IsNumeric(a) Then

            ' MsgBox(a & " records deleted", MsgBoxStyle.Exclamation)
            msWriteLM(a & " record/s deleted", "r")


            PopulateGrid()
        Else
            MsgBox("Error " & vbCrLf & a, MsgBoxStyle.Critical)

        End If


    End Sub

    Private Function isMobileOk() As Boolean

        If 1 = 1 Then
            isMobileOk = True
            Exit Function    '  no need to check mobile no
        End If

        isMobileOk = False

        If Me.txtDriverMob.Text = "" Then
            If MsgBox("Mobile no not enterred, do you want to continue?", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Question, "Attention") = MsgBoxResult.Yes Then
                isMobileOk = True
            End If
            Exit Function
        End If

        If Not Me.txtDriverMob.Text.StartsWith("05") Then
            'If MsgBox("Mobile no does not starts with 05, do you want to continue?", Emoticons.ConfusedIcon, "Attention", "", "No", "Yes") = "Yes" Then
            If MsgBox("Mobile no does not starts with 05, do you want to continue?", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.Question, "Attention") = MsgBoxResult.Yes Then
                isMobileOk = True
            End If
            Exit Function
        End If

        If Me.txtDriverMob.Text.Length <> 10 Then
            'msMessagebox("Mobile number must be 10 digits starting with 05", Emoticons.SadIcon)
            MsgBox("Mobile number must be 10 digits starting with 05", MsgBoxStyle.Exclamation)
            Exit Function
        End If


        If FormMode = FormModes.AddMode Then
            Dim mob As String
            ww = mslCons.WebAuthCode
            mob = msWebGetFieldValue("Select Mobile from tblCustomers where Mobile = '" & Me.txtDriverMob.Text & "'", "Mobile", ww)

            If mob <> "" Then
                MsgBox("Mobile no already exist, can not add duplicate", MsgBoxStyle.Exclamation)
                Exit Function
            End If

        End If

        isMobileOk = True

    End Function


    Private Sub bnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnSave.Click

        If FormNotValid() Then Exit Sub


        '''''''  using update statment
        Dim ArF As New List(Of String)
        Dim ArV As New List(Of String)
        Dim ArT As New List(Of String)

        ' following is required for multiple table updates or update in loop
        ArF.Clear()
        ArV.Clear()
        ArT.Clear()
        '==================================


        If FormMode = FormModes.AddMode Then
            ArF.Add("Vehcode")
            ArV.Add(Me.txtVehCode.Text)
            ArT.Add("s")  ' or S

            ArF.Add("VehDateAdded")
            ArV.Add("server date")
            ArT.Add("Sd")    '	"N") 

        End If

        arF.Add("LastUpdateAt")
        ArV.Add("server time")             ' Format(Date.Now, "yyyy-MM-dd HH:mm"))
        arT.Add("st")    ' st server time


        ArF.Add("VehName")
        ArV.Add(Me.txtVehName.Text)
        ArT.Add("s")  ' or S

        ArF.Add("VehOwner")
        ArV.Add(Me.txtOwner.Text)
        ArT.Add("s")  ' or S

        ArF.Add("VehTareWt")
        ArV.Add(Me.txtTareWt.Text)
        ArT.Add("n")  ' or S

        ArF.Add("DriverName")
        ArV.Add(Me.txtDriver.Text)
        ArT.Add("s")  ' or S

        ArF.Add("DriverMob")
        ArV.Add(Me.txtDriverMob.Text)
        ArT.Add("s")  ' or S

        ArF.Add("VehWtRemark")
        ArV.Add(Me.txtMTare.Text)
        ArT.Add("s")  ' or S

        If FormMode = FormModes.EditMode Then
            ArF.Add("SyncFlag")
            ArV.Add("2")
            ArT.Add("n")
        End If

        Dim a As String

        Try
            Me.bnSave.Enabled = False
            'a = msrv.getlictoolcode(arF.ToArray, arV.ToArray, arT.ToArray, arH.ToArray, Me.txtEmail.Text)
            If FormMode = FormModes.EditMode Then
                Dim wcls As String


                wcls = "VehID = " & Me.DataGridView1.CurrentRow.Cells("VehID").Value

                a = msWebUpdateArrayListInDB("tblVehicles", ArF.ToArray, ArV.ToArray, ArT.ToArray, wcls, mslCons.WebAuthcode)
                If IsNumeric(a) Then
                    MsgBox(a & " Record/s updated", MsgBoxStyle.Information)
                End If

            Else
                a = msWebInsertRecIntoDb("tblVehicles", ArF.ToArray, ArV.ToArray, ArT.ToArray, mslCons.WebAuthcode)

            End If

            If a <> "1" Then
                MsgBox("unable to save" & vbCrLf & a, MsgBoxStyle.Critical)
                Me.bnSave.Enabled = True
                Exit Sub
            End If

            If FormMode = FormModes.AddMode Then

                Me.txtSearch.Text = ""

            End If

            'ClearForm()

            PopulateGrid()

            If FormMode = FormModes.EditMode Then

                If curRecNo < DataGridView1.RowCount Then
                    'DataGridView1.Rows(curRecNo).Selected = True
                    DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
                End If

            End If

            DisableEdits()


        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical)

            Exit Sub

        End Try


    End Sub


    Private Sub bnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnClose.Click

        Me.Close()

    End Sub


    Private Sub btnManualTare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManualTare.Click

        Dim wt As String
        wt = InputBox("Input Tare Weight", "", Me.txtTareWt.Text)

        If IsNumeric(wt) AndAlso wt > 10 Then

            If MsgBox("Are you sure you want to enter tare weight Manually : " & wt, MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.Yes Then

                Me.txtTareWt.ReadOnly = False
                msWriteLM("Manual Tare")
                Me.txtMTare.Text = "MTW"
                Me.txtTareWt.Text = wt

            End If

        End If

    End Sub


    Private Sub tmrGetWT_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrGetWT.Tick

        Me.btnW1.Text = Sysvars.WeighA

    End Sub

    Private Sub btnW1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnW1.Click

        If IsNumeric(btnW1.Text) AndAlso Val(btnW1.Text) > 10 Then

            Me.txtTareWt.Text = btnW1.Text

        End If

    End Sub

    Private Sub bnMoveNextItem_Click(sender As Object, e As EventArgs) Handles bnMoveNextItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        If curRecNo < DataGridView1.RowCount - 1 Then
            curRecNo = curRecNo + 1
            DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
        End If

    End Sub


    Private Sub bnMoveLastItem_Click(sender As Object, e As EventArgs) Handles bnMoveLastItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub

        curRecNo = DataGridView1.RowCount - 1
        DataGridView1.CurrentCell = DataGridView1(0, curRecNo)

    End Sub

    Private Sub bnMovePreviousItem_Click(sender As Object, e As EventArgs) Handles bnMovePreviousItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        If curRecNo > 0 Then
            curRecNo = curRecNo - 1
            DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
        End If


    End Sub

    Private Sub bnMoveFirstItem_Click(sender As Object, e As EventArgs) Handles bnMoveFirstItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        curRecNo = 0
        DataGridView1.CurrentCell = DataGridView1(0, curRecNo)

    End Sub

End Class