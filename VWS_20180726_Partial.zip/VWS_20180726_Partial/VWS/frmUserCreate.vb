﻿Public Class frmUserCreate

    Dim EditUsr As Boolean

    Public Sub ShowDialog_modifyUser(ByRef dsuser As DataSet)

        Me.txtUserID.Text = dsuser.Tables(0).Rows(0)("UserID")
        Me.txtName.Text = dsuser.Tables(0).Rows(0)("UserName")
        Me.txtMobile.Text = dsuser.Tables(0).Rows(0)("MobileNo")
        Me.txtEmail.Text = dsuser.Tables(0).Rows(0)("Email")

        Me.txtUserID.Enabled = False


        EditUsr = True

        ShowDialog()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Me.Close()

    End Sub

    Private Sub msWriteLM(ByVal LmData As String, Optional ByVal rgbh As String = "0")

        Dim obj As Control
        obj = Me.txtLM

        If TypeOf obj Is TextBox Then
            If CType(obj, TextBox).Multiline Then
                Me.txtLM.Text = LmData & vbCrLf & Me.txtLM.Text
            Else
                Me.txtLM.Text = LmData
            End If

        Else
            Me.txtLM.Text = LmData
        End If

        'msDoEvents()

        Dim pColor As Color
        Select Case rgbh.ToLower
            Case "r"
                pColor = Color.Crimson
            Case "1"
                pColor = Color.Crimson
            Case "g"
                pColor = Color.Green
            Case "2"
                pColor = Color.Green
            Case "b"    ' blue
                pColor = Color.Blue
            Case "3"   ' blue
                pColor = Color.Blue
            Case "h"      ' highlight
                pColor = Color.DarkBlue
            Case "4"     ' highlight
                pColor = Color.DarkBlue
            Case Else
                pColor = Color.Black
        End Select


        txtLM.ForeColor = pColor

        If rgbh = "h" Or rgbh = "4" Then
            txtLM.BackColor = Color.Yellow
        Else
            txtLM.BackColor = Color.WhiteSmoke
        End If

    End Sub


    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click

        If Me.txtName.Text.Trim.Length < 5 Then
            msWriteLM("Please type full name", "r")
            Exit Sub
        End If

        If Me.txtUserID.Text.Trim.Length < 5 Then
            msWriteLM("User ID must be minimum 5 digits", "r")
            Exit Sub
        End If

        'If Me.txtMobile.Text.Length = 10 AndAlso Me.txtMobile.Text.StartsWith("05") Then
        '    ' ok
        'Else
        '    msWriteLM("incorrect mobile no.", "r")
        '    Exit Sub
        'End If

        'If msMessagebox("Your password will sent to your mobile." & vbCrLf & "is your mobile no. " & Me.txtMobile.Text & " correct?", Emoticons.QuestionIcon, "Create New User", "", "No", "Yes") = "No" Then
        '    Exit Sub
        'End If

        If txtUserID.Text.ToLower = "master" Then   '  Or txtUserID.Text.ToLower = "admin" Then
            msWriteLM("Used ID is reserved.", "b")
            Exit Sub
        End If

        Dim tmp As String
        Dim w As String

        If Not EditUsr Then
            w = mslCons.WebAuthcode
            tmp = msWebGetFieldValue("Select UserID from tblUsers where UserID = '" & Me.txtUserID.Text & "'", "UserID", w)
            If tmp.ToUpper = txtUserID.Text.ToUpper Then
                msWriteLM("User ID already taken", "r")
                Exit Sub
            End If
        End If

        'w = mslCons.WebAuthcode
        'tmp = msWebGetFieldValue("Select MobileNo from tblUsers where MobileNo = '" & Me.txtMobile.Text & "'", "MobileNo", w)
        'If tmp = txtUserID.Text Then
        '    msWriteLM("Mobile no already registerred", "r")
        '    Exit Sub
        'End If

        'Randomize(Date.Now.Second)
        'tmp = Chr(msRandomNo(65, 90)) & msStr(msRandomNo(1, 9999), 4)

        Dim ArF As New List(Of String)
        Dim ArV As New List(Of String)
        Dim ArT As New List(Of String)

        ' following is required for multiple table updates or update in loop
        ArF.Clear()
        ArV.Clear()
        ArT.Clear()
        '==================================

        ArF.Add("UserID")
        ArV.Add(txtUserID.Text)
        ArT.Add("s")

        ArF.Add("UserName")
        ArV.Add(txtName.Text)
        ArT.Add("s")

        ArF.Add("UserPW")
        ArV.Add(txtUserID.Text.ToLower)    '  tmp.ToLower)
        ArT.Add("s")  ' or S

        ArF.Add("MobileNo")
        ArV.Add(txtMobile.Text)
        ArT.Add("s")  ' or S

        ArF.Add("Email")
        ArV.Add(txtEmail.Text.ToLower)
        ArT.Add("s")  ' or S

        ArF.Add("LastUpdateAt")
        ArV.Add(msNow)
        ArT.Add("s")  ' or S

        Dim a As String
        w = mslCons.WebAuthcode

        a = ""
        If EditUsr Then
            a = msWebUpdateArrayListInDB("tblUsers", ArF.ToArray, ArV.ToArray, ArT.ToArray, "UserID = '" & Me.txtUserID.Text & "'", w)
        Else
            a = msWebInsertRecIntoDb("tblUsers", ArF.ToArray, ArV.ToArray, ArT.ToArray, w)
        End If

        If a = "1" Then

            'Dim sms As String
            'sms = "Mailing Simplified login details" & vbCrLf & vbCrLf & "User id : " & Me.txtUserID.Text & vbCrLf & "password : " & tmp
            'sms = sms & vbCrLf & vbCrLf & "You can change pw after login"
            'Send_XML_SMS(Sysvars.ModemComPort, Me.txtMobile.Text, sms)
            'WriteMailActivity("User", "New User", Me.txtUserID.Text, "system code: " & mslv.ProductCode, True)
            If EditUsr Then
                MsgBox("User record updated", MsgBoxStyle.Exclamation)
            Else
                MsgBox("User Created, Password and User ID is same. change Password after Login", MsgBoxStyle.Exclamation)
            End If

        Else
            MsgBox("Error 160326: " & a, MsgBoxStyle.Critical)

        End If

        Me.Close()

    End Sub


    Private Sub frmUserCreate_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim s As String
        s = "Please make sure your mobile no is correct. "
        s = s & vbCrLf & "Your password will be sent to your mobile. "
        If EditUsr Then
            s = "Modify User ...."
        Else
            s = "Create New User ....."
        End If

        msWriteLM(s, "b")

    End Sub

End Class