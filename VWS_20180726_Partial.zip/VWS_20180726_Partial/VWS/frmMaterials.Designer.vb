﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMaterials
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMaterials))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtMatName = New System.Windows.Forms.TextBox()
        Me.txtMatCode = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPriceA = New System.Windows.Forms.TextBox()
        Me.txtPriceB = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPriceC = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPriceE = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPriceD = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.bnAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.bnCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.bnDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.bnPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnEdit = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnRefresh = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnSave = New System.Windows.Forms.ToolStripButton()
        Me.bnCancel = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnDetails = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnClose = New System.Windows.Forms.ToolStripButton()
        Me.lbldispError = New System.Windows.Forms.ToolStripLabel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBoxSearch = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.txtLM = New System.Windows.Forms.Label()
        Me.txtDisable = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtScrapFlag = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxSearch.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(28, 130)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 14)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Material Name"
        '
        'txtMatName
        '
        Me.txtMatName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtMatName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtMatName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtMatName.Location = New System.Drawing.Point(151, 128)
        Me.txtMatName.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMatName.MaxLength = 50
        Me.txtMatName.Name = "txtMatName"
        Me.txtMatName.ReadOnly = True
        Me.txtMatName.Size = New System.Drawing.Size(444, 22)
        Me.txtMatName.TabIndex = 4
        '
        'txtMatCode
        '
        Me.txtMatCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtMatCode.Location = New System.Drawing.Point(151, 81)
        Me.txtMatCode.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMatCode.MaxLength = 50
        Me.txtMatCode.Name = "txtMatCode"
        Me.txtMatCode.ReadOnly = True
        Me.txtMatCode.Size = New System.Drawing.Size(145, 22)
        Me.txtMatCode.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(28, 83)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 14)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Material Code"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(28, 179)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 14)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Price A"
        '
        'txtPriceA
        '
        Me.txtPriceA.Location = New System.Drawing.Point(102, 176)
        Me.txtPriceA.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPriceA.MaxLength = 10
        Me.txtPriceA.Name = "txtPriceA"
        Me.txtPriceA.ReadOnly = True
        Me.txtPriceA.Size = New System.Drawing.Size(96, 22)
        Me.txtPriceA.TabIndex = 6
        '
        'txtPriceB
        '
        Me.txtPriceB.Location = New System.Drawing.Point(299, 176)
        Me.txtPriceB.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPriceB.MaxLength = 10
        Me.txtPriceB.Name = "txtPriceB"
        Me.txtPriceB.ReadOnly = True
        Me.txtPriceB.Size = New System.Drawing.Size(96, 22)
        Me.txtPriceB.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(228, 179)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 14)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Price B"
        '
        'txtPriceC
        '
        Me.txtPriceC.Location = New System.Drawing.Point(497, 176)
        Me.txtPriceC.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPriceC.MaxLength = 10
        Me.txtPriceC.Name = "txtPriceC"
        Me.txtPriceC.ReadOnly = True
        Me.txtPriceC.Size = New System.Drawing.Size(96, 22)
        Me.txtPriceC.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(426, 179)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 14)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Price C"
        '
        'txtPriceE
        '
        Me.txtPriceE.Location = New System.Drawing.Point(300, 218)
        Me.txtPriceE.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPriceE.MaxLength = 10
        Me.txtPriceE.Name = "txtPriceE"
        Me.txtPriceE.ReadOnly = True
        Me.txtPriceE.Size = New System.Drawing.Size(96, 22)
        Me.txtPriceE.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(229, 221)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 14)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Price E"
        '
        'txtPriceD
        '
        Me.txtPriceD.Location = New System.Drawing.Point(102, 218)
        Me.txtPriceD.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPriceD.MaxLength = 10
        Me.txtPriceD.Name = "txtPriceD"
        Me.txtPriceD.ReadOnly = True
        Me.txtPriceD.Size = New System.Drawing.Size(96, 22)
        Me.txtPriceD.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(28, 221)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(50, 14)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Price D"
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.bnAddNewItem
        Me.BindingNavigator1.CountItem = Me.bnCountItem
        Me.BindingNavigator1.DeleteItem = Me.bnDeleteItem
        Me.BindingNavigator1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.bnMoveFirstItem, Me.bnMovePreviousItem, Me.BindingNavigatorSeparator, Me.bnPositionItem, Me.bnCountItem, Me.BindingNavigatorSeparator1, Me.bnMoveNextItem, Me.bnMoveLastItem, Me.BindingNavigatorSeparator2, Me.bnAddNewItem, Me.bnEdit, Me.bnDeleteItem, Me.ToolStripSeparator1, Me.bnRefresh, Me.ToolStripSeparator2, Me.bnSave, Me.bnCancel, Me.ToolStripSeparator4, Me.bnDetails, Me.ToolStripSeparator3, Me.bnClose, Me.lbldispError})
        Me.BindingNavigator1.Location = New System.Drawing.Point(0, 302)
        Me.BindingNavigator1.MoveFirstItem = Me.bnMoveFirstItem
        Me.BindingNavigator1.MoveLastItem = Me.bnMoveLastItem
        Me.BindingNavigator1.MoveNextItem = Me.bnMoveNextItem
        Me.BindingNavigator1.MovePreviousItem = Me.bnMovePreviousItem
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.bnPositionItem
        Me.BindingNavigator1.Size = New System.Drawing.Size(643, 38)
        Me.BindingNavigator1.TabIndex = 19
        Me.BindingNavigator1.Text = "BindingNavigator1"
        '
        'bnAddNewItem
        '
        Me.bnAddNewItem.Image = CType(resources.GetObject("bnAddNewItem.Image"), System.Drawing.Image)
        Me.bnAddNewItem.Name = "bnAddNewItem"
        Me.bnAddNewItem.RightToLeftAutoMirrorImage = True
        Me.bnAddNewItem.Size = New System.Drawing.Size(35, 35)
        Me.bnAddNewItem.Text = "New"
        Me.bnAddNewItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'bnCountItem
        '
        Me.bnCountItem.Name = "bnCountItem"
        Me.bnCountItem.Size = New System.Drawing.Size(35, 35)
        Me.bnCountItem.Text = "of {0}"
        Me.bnCountItem.ToolTipText = "Total number of items"
        '
        'bnDeleteItem
        '
        Me.bnDeleteItem.Image = CType(resources.GetObject("bnDeleteItem.Image"), System.Drawing.Image)
        Me.bnDeleteItem.Name = "bnDeleteItem"
        Me.bnDeleteItem.RightToLeftAutoMirrorImage = True
        Me.bnDeleteItem.Size = New System.Drawing.Size(44, 35)
        Me.bnDeleteItem.Text = "Delete"
        Me.bnDeleteItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnDeleteItem.Visible = False
        '
        'bnMoveFirstItem
        '
        Me.bnMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveFirstItem.Image = CType(resources.GetObject("bnMoveFirstItem.Image"), System.Drawing.Image)
        Me.bnMoveFirstItem.Name = "bnMoveFirstItem"
        Me.bnMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveFirstItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveFirstItem.Text = "Move first"
        '
        'bnMovePreviousItem
        '
        Me.bnMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMovePreviousItem.Image = CType(resources.GetObject("bnMovePreviousItem.Image"), System.Drawing.Image)
        Me.bnMovePreviousItem.Name = "bnMovePreviousItem"
        Me.bnMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.bnMovePreviousItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 38)
        '
        'bnPositionItem
        '
        Me.bnPositionItem.AccessibleName = "Position"
        Me.bnPositionItem.Name = "bnPositionItem"
        Me.bnPositionItem.Size = New System.Drawing.Size(30, 38)
        Me.bnPositionItem.Text = "0"
        Me.bnPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'bnMoveNextItem
        '
        Me.bnMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveNextItem.Image = CType(resources.GetObject("bnMoveNextItem.Image"), System.Drawing.Image)
        Me.bnMoveNextItem.Name = "bnMoveNextItem"
        Me.bnMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveNextItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveNextItem.Text = "Move next"
        '
        'bnMoveLastItem
        '
        Me.bnMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveLastItem.Image = CType(resources.GetObject("bnMoveLastItem.Image"), System.Drawing.Image)
        Me.bnMoveLastItem.Name = "bnMoveLastItem"
        Me.bnMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveLastItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'bnEdit
        '
        Me.bnEdit.Image = CType(resources.GetObject("bnEdit.Image"), System.Drawing.Image)
        Me.bnEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnEdit.Name = "bnEdit"
        Me.bnEdit.Size = New System.Drawing.Size(31, 35)
        Me.bnEdit.Text = "Edit"
        Me.bnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'bnRefresh
        '
        Me.bnRefresh.Image = CType(resources.GetObject("bnRefresh.Image"), System.Drawing.Image)
        Me.bnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnRefresh.Name = "bnRefresh"
        Me.bnRefresh.Size = New System.Drawing.Size(50, 35)
        Me.bnRefresh.Text = "Refresh"
        Me.bnRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'bnSave
        '
        Me.bnSave.Image = CType(resources.GetObject("bnSave.Image"), System.Drawing.Image)
        Me.bnSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnSave.Name = "bnSave"
        Me.bnSave.Size = New System.Drawing.Size(35, 35)
        Me.bnSave.Text = "Save"
        Me.bnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnSave.ToolTipText = "Save"
        '
        'bnCancel
        '
        Me.bnCancel.Image = CType(resources.GetObject("bnCancel.Image"), System.Drawing.Image)
        Me.bnCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnCancel.Name = "bnCancel"
        Me.bnCancel.Size = New System.Drawing.Size(47, 35)
        Me.bnCancel.Text = "Cancel"
        Me.bnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnCancel.ToolTipText = "Cancel"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 38)
        '
        'bnDetails
        '
        Me.bnDetails.Image = CType(resources.GetObject("bnDetails.Image"), System.Drawing.Image)
        Me.bnDetails.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnDetails.Name = "bnDetails"
        Me.bnDetails.Size = New System.Drawing.Size(46, 35)
        Me.bnDetails.Text = "Details"
        Me.bnDetails.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnDetails.ToolTipText = "Transaction Details"
        Me.bnDetails.Visible = False
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 38)
        '
        'bnClose
        '
        Me.bnClose.Image = CType(resources.GetObject("bnClose.Image"), System.Drawing.Image)
        Me.bnClose.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnClose.Name = "bnClose"
        Me.bnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.bnClose.Size = New System.Drawing.Size(40, 35)
        Me.bnClose.Text = "Close"
        Me.bnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnClose.ToolTipText = "Close"
        '
        'lbldispError
        '
        Me.lbldispError.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldispError.ForeColor = System.Drawing.Color.Red
        Me.lbldispError.Name = "lbldispError"
        Me.lbldispError.Size = New System.Drawing.Size(0, 35)
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridView1.Location = New System.Drawing.Point(0, 340)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 26
        Me.DataGridView1.Size = New System.Drawing.Size(643, 214)
        Me.DataGridView1.TabIndex = 20
        '
        'GroupBoxSearch
        '
        Me.GroupBoxSearch.Controls.Add(Me.btnSearch)
        Me.GroupBoxSearch.Controls.Add(Me.txtSearch)
        Me.GroupBoxSearch.Location = New System.Drawing.Point(31, 11)
        Me.GroupBoxSearch.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBoxSearch.Name = "GroupBoxSearch"
        Me.GroupBoxSearch.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBoxSearch.Size = New System.Drawing.Size(357, 54)
        Me.GroupBoxSearch.TabIndex = 0
        Me.GroupBoxSearch.TabStop = False
        Me.GroupBoxSearch.Text = "Search"
        '
        'btnSearch
        '
        Me.btnSearch.Image = CType(resources.GetObject("btnSearch.Image"), System.Drawing.Image)
        Me.btnSearch.Location = New System.Drawing.Point(315, 22)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(24, 25)
        Me.btnSearch.TabIndex = 1
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSearch.Location = New System.Drawing.Point(19, 22)
        Me.txtSearch.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSearch.MaxLength = 20
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(291, 22)
        Me.txtSearch.TabIndex = 0
        '
        'txtLM
        '
        Me.txtLM.Location = New System.Drawing.Point(407, 43)
        Me.txtLM.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.txtLM.Name = "txtLM"
        Me.txtLM.Size = New System.Drawing.Size(226, 22)
        Me.txtLM.TabIndex = 21
        Me.txtLM.Text = "Material / Products"
        Me.txtLM.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDisable
        '
        Me.txtDisable.Location = New System.Drawing.Point(565, 218)
        Me.txtDisable.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDisable.MaxLength = 1
        Me.txtDisable.Name = "txtDisable"
        Me.txtDisable.ReadOnly = True
        Me.txtDisable.Size = New System.Drawing.Size(30, 22)
        Me.txtDisable.TabIndex = 16
        Me.txtDisable.TabStop = False
        Me.txtDisable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtDisable.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(426, 221)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 14)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Material Disable"
        Me.Label8.Visible = False
        '
        'txtScrapFlag
        '
        Me.txtScrapFlag.Location = New System.Drawing.Point(202, 257)
        Me.txtScrapFlag.Margin = New System.Windows.Forms.Padding(2)
        Me.txtScrapFlag.MaxLength = 1
        Me.txtScrapFlag.Name = "txtScrapFlag"
        Me.txtScrapFlag.ReadOnly = True
        Me.txtScrapFlag.Size = New System.Drawing.Size(30, 22)
        Me.txtScrapFlag.TabIndex = 18
        Me.txtScrapFlag.TabStop = False
        Me.txtScrapFlag.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(28, 260)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(160, 14)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Scrap flag (0-no / 1-yes)"
        '
        'frmMaterials
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(643, 554)
        Me.Controls.Add(Me.txtScrapFlag)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtDisable)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtLM)
        Me.Controls.Add(Me.GroupBoxSearch)
        Me.Controls.Add(Me.BindingNavigator1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.txtPriceE)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtPriceD)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtPriceC)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtPriceB)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtPriceA)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtMatCode)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtMatName)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "frmMaterials"
        Me.Text = "Materials / Products"
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxSearch.ResumeLayout(False)
        Me.GroupBoxSearch.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtMatName As System.Windows.Forms.TextBox
    Friend WithEvents txtMatCode As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtPriceA As System.Windows.Forms.TextBox
    Friend WithEvents txtPriceB As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtPriceC As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPriceE As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtPriceD As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents BindingNavigator1 As System.Windows.Forms.BindingNavigator
    Friend WithEvents bnAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents bnDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnEdit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnRefresh As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnCancel As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnDetails As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnClose As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbldispError As System.Windows.Forms.ToolStripLabel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBoxSearch As System.Windows.Forms.GroupBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents txtLM As System.Windows.Forms.Label
    Friend WithEvents txtDisable As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtScrapFlag As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
End Class
