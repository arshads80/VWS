﻿

Module msLibliteWS

    

#Region "db calls on WS"

    Public Function msWebGetFieldValue(ByVal prmStrSql As String, ByVal FieldName As String, ByRef prmWeber As String) As String

        If prmWeber <> webAuthCode Then
            msWebGetFieldValue = ""
            Exit Function
        End If

        msWebGetFieldValue = msGetFieldValue(prmStrSql, , FieldName, prmWeber)


    End Function

    Public Function msWebInsert3FieldsInDb(ByVal prmtbl As String, ByVal prmFld1 As String, ByVal prmVal1 As String, ByVal prmFld2 As String, ByVal prmVal2 As String, ByVal prmFld3 As String, ByVal prmVal3 As String, ByVal prmWeber As String) As String

        If prmWeber <> webAuthCode Then
            msWebInsert3FieldsInDb = ""
            Exit Function
        End If

        msWebInsert3FieldsInDb = msInsert3FieldsInDb(prmtbl, prmFld1, prmVal1, prmFld2, prmVal2, prmFld3, prmVal3)

    End Function

    Public Function msWebUpdate3FieldsInDb(ByVal prmtbl As String, ByVal prmFld1 As String, ByVal prmVal1 As String, ByVal prmFld2 As String, ByVal prmVal2 As String, ByVal prmFld3 As String, ByVal prmVal3 As String, ByVal prmWhere As String, ByVal prmWeber As String) As String

        ' 2016-03-19

        If prmWeber <> webAuthCode Then
            msWebUpdate3FieldsInDb = ""
            Exit Function
        End If

        msWebUpdate3FieldsInDb = msUpdate3FieldsInDb(prmtbl, prmFld1, prmVal1, prmFld2, prmVal2, prmFld3, prmFld3, prmWhere)

    End Function


    Public Function msWebInsertRecIntoDb(ByVal prmtblname As String, ByVal prmFields() As Object, ByVal prmValues() As Object, ByVal prmTypes() As Object, ByVal prmWebEr As String) As String

        If prmWebEr <> webAuthCode Then
            msWebInsertRecIntoDb = ""
            Exit Function
        End If


        Dim i As Integer
        Dim prmF As New List(Of String)
        For i = 0 To prmFields.Length - 1
            prmF.Add(prmFields(i).ToString)
        Next

        Dim prmV As New List(Of String)
        For i = 0 To prmValues.Length - 1
            prmV.Add(prmValues(i).ToString)
        Next

        Dim prmT As New List(Of String)
        For i = 0 To prmTypes.Length - 1
            prmT.Add(prmTypes(i).ToString)
        Next

        Dim a As String
        a = msInsertArrayListInDB(prmtblname, prmF, prmV, prmT)

        msWebInsertRecIntoDb = a

    End Function

    Public Function msWebUpdateArrayListInDB(ByVal prmtblname As String, ByVal prmFields() As Object, ByVal prmValues() As Object, ByVal prmTypes() As Object, ByVal prmWhere As String, ByVal prmWebEr As String) As String

        If prmWebEr <> webAuthCode Then
            msWebUpdateArrayListInDB = ""
            Exit Function
        End If

        Dim i As Integer
        Dim prmF As New List(Of String)
        For i = 0 To prmFields.Length - 1
            prmF.Add(prmFields(i).ToString)
        Next

        Dim prmV As New List(Of String)
        For i = 0 To prmValues.Length - 1
            prmV.Add(prmValues(i).ToString)
        Next

        Dim prmT As New List(Of String)
        For i = 0 To prmTypes.Length - 1
            prmT.Add(prmTypes(i).ToString)
        Next

        Dim a As String
        a = msUpdateArrayListInDB(prmtblname, prmF, prmV, prmT, prmWhere)

        msWebUpdateArrayListInDB = a


    End Function

    Public Function msWebUpdateFlagInDb(ByVal prmtbl As String, ByVal prmFld As String, ByVal prmVal As String, ByVal prmWhere As String, ByRef prmWeber As String) As String

        If prmWeber <> webAuthCode Then
            msWebUpdateFlagInDb = ""
            Exit Function
        End If

        msWebUpdateFlagInDb = msUpdateFlagInDb(prmtbl, prmFld, prmVal, prmWhere)

    End Function


#End Region

End Module
