﻿Public Class frmTrnReports


    Dim sordBy As String
    Dim ArF As List(Of String)
    Dim ArH As List(Of String)
    Dim ArT As List(Of String)

    Private Sub frmTrnReports_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Me.cmbCustType.Items.Clear()
        'cmbCustType.Items.Add("    All")
        'cmbCustType.Items.Add("0   Customer")
        'cmbCustType.Items.Add("1   Customer")
        'cmbCustType.Items.Add("2   Material shift")
        'cmbCustType.Items.Add("3   Hire trucks")
        'cmbCustType.Items.Add("4   Diesel")
        'cmbCustType.Items.Add("5   Sweet water")
        'cmbCustType.Items.Add("6   Sewerage")
        'cmbCustType.Items.Add("7   Scrap")
        'Me.cmbCustType.SelectedIndex = 0

        Me.cmbCustType.Items.Clear()
        cmbCustType.Items.Add("All")
        Dim ds As DataSet
        Dim w As String
        w = mslCons.WebAuthcode

        ds = msWebGetDS("Select * from tblCustTypes order by CustType", w)
        If ds.Tables.Count < 1 Then
            MsgBox("Can not retrieve CustTypes")
            Exit Sub
        End If

        Dim dr As DataRow
        Dim m As Integer

        For m = 0 To ds.Tables(0).Rows.Count - 1
            dr = ds.Tables(0).Rows(m)
            cmbCustType.Items.Add(dr("CustType") & "    " & dr("CustTypeDesc"))
        Next

        Me.cmbCustType.SelectedIndex = 0

        Me.cmbRptLook.Items.Add("0")
        Me.cmbRptLook.Items.Add("1")
        Me.cmbRptLook.Items.Add("2")
        Me.cmbRptLook.Items.Add("3")
        Me.cmbRptLook.Items.Add("4")
        'Me.cmbRptLook.Items.Add("5")

        Me.cmbRptLook.SelectedIndex = 3

        Me.dtpFrm.Value = Format(Date.Today, "dd/MMM/yyyy 00:00")
        Me.dtpTo.Value = Format(Date.Today, "dd/MMM/yyyy 23:59")
        Me.rbRepAllTickets.Checked = True

    End Sub

    Private Function FormNotValid() As Boolean

        FormNotValid = True

        Dim d As Integer
        d = DateDiff(DateInterval.Day, Me.dtpFrm.Value, Me.dtpTo.Value)

        If Me.txtCustcode.Text = "" And Me.txtLocCode.Text = "" And Me.txtMatCode.Text = "" And Me.txtSiteCode.Text = "" And Me.txtSoucode.Text = "" Then
            If d > 184 Then
                MsgBox("Date Range should not be more than six month", MsgBoxStyle.Exclamation)
                Exit Function
            End If
        Else
            If d > 366 Then
                MsgBox("Date Range should not be more than 1 year", MsgBoxStyle.Exclamation)
                Exit Function
            End If
        End If

        FormNotValid = False

    End Function

    Private Sub btnDeliveryReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeliveryReport.Click

        If FormNotValid() Then Exit Sub

        If Me.rbRepAllTickets.Checked Then

            GenerateAllTicketReport()

        ElseIf Me.rbRep1stTicket.Checked Then
            GenerateAllTicketReport()

        ElseIf Me.rbRepCustTick.Checked Then

            GenerateCustomerWiseReport()

        ElseIf Me.rbRepMatTick.Checked Then
            GenerateMaterialWiseReport()

        End If

    End Sub

    Private Sub PrepareReportArrays()

        ArF = New List(Of String)
        ArH = New List(Of String)
        ArT = New List(Of String)

        If Me.chkTicket.Checked Then
            ArF.Add("TicketNo")
            ArH.Add("TicketNo")
            ArT.Add("s")
        End If

        If Me.chkFirstTickNo.Checked Then
            ArF.Add("FirstTicketNo")
            ArH.Add("FirstTicketNo")
            ArT.Add("s")
        End If

        If Me.chkVehCode.Checked Then
            ArF.Add("VehCode")
            ArH.Add("Veh Code")
            ArT.Add("s")
        End If

        If Me.chkVehical.Checked Then
            ArF.Add("VehName")
            ArH.Add("Transporter")              ' "Vehical")
            ArT.Add("s")
        End If

        If Me.chkDriver.Checked Then
            ArF.Add("DriverName")
            ArH.Add("Driver")
            ArT.Add("s")
        End If

        If Me.chkDriverMob.Checked Then
            ArF.Add("DriverMob")
            ArH.Add("")         ' keep blank if header is same as field name
            ArT.Add("s")
        End If

        If Me.chkCustcode.Checked Then
            ArF.Add("CustCode")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkCustName.Checked Then
            ArF.Add("CustName")
            ArH.Add("Customer")
            ArT.Add("s")
        End If

        If Me.chkPriceGroup.Checked Then
            ArF.Add("PriceGroup")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkPrepaidFlag.Checked Then
            ArF.Add("PrepaidCust")
            ArH.Add("Prepaid")
            ArT.Add("s")
        End If

        If Me.chkMatCode.Checked Then
            ArF.Add("MatCode")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkMaterial.Checked Then
            ArF.Add("MatName")
            ArH.Add("Material")
            ArT.Add("s")
        End If

        If Me.chkSoucode.Checked Then
            ArF.Add("SouCode")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkSource.Checked Then
            ArF.Add("SouName")
            ArH.Add("Source")
            ArT.Add("s")
        End If

        If Me.chkLocCode.Checked Then
            ArF.Add("LocCode")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkLocation.Checked Then
            ArF.Add("LocName")
            ArH.Add("Location")
            ArT.Add("s")
        End If

        If Me.chkSiteCode.Checked Then
            ArF.Add("SiteCode")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkSite.Checked Then
            ArF.Add("SiteName")
            ArH.Add("Site")
            ArT.Add("s")
        End If

        If Me.chkInOut.Checked Then
            ArF.Add("InOut")
            ArH.Add("")
            ArT.Add("c")
        End If

        If Me.chkWtType.Checked Then
            ArF.Add("WeighType")
            ArH.Add("")
            ArT.Add("c")
        End If

        If Me.chkFirstWt.Checked Then
            ArF.Add("FWeight")
            ArH.Add("1st Wt Kgs")
            ArT.Add("n")
        End If

        If Me.chkSecondWt.Checked Then
            ArF.Add("SWeight")
            ArH.Add("2nd Wt Kgs")
            ArT.Add("n")
        End If

        If Me.chkNetWeight.Checked Then
            ArF.Add("NWeight")
            ArH.Add("Net Wt")
            ArT.Add("n")
        End If

        If Me.chkNetWeightTons.Checked Then
            ArF.Add("NetWeightTons")
            ArH.Add("Net Wt Tons")
            ArT.Add("f")
        End If

        If Me.chkFWdate.Checked Then
            ArF.Add("FWDateTime")
            ArH.Add("1st Wt Date")
            ArT.Add("d")
        End If

        If Me.chkFWdt.Checked Then
            ArF.Add("FWDateTime")
            ArH.Add("1st wt DateTime")
            ArT.Add("dt")
        End If

        If Me.chkSWdate.Checked Then
            ArF.Add("SWDateTime")
            ArH.Add("Transaction Date")
            ArT.Add("d")
        End If

        If Me.chkSWdt.Checked Then
            ArF.Add("SWDateTime")
            ArH.Add("Transaction DateTime")
            ArT.Add("dt")
        End If

        If Me.chkWtRemark.Checked Then
            ArF.Add("VehWtRemark")
            ArH.Add("Wt Rem")
            ArT.Add("s")
        End If

        If Me.chkDlvOrder.Checked Then
            ArF.Add("DeliveryOrder")
            ArH.Add("Dlv Order")
            ArT.Add("s")
        End If

        If Me.chkRemark.Checked Then
            ArF.Add("Remark")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkLastUpdate.Checked Then
            ArF.Add("LastUpdateAt")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkUserID.Checked Then
            ArF.Add("UserID")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkUserModified.Checked Then
            ArF.Add("UserModified")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkModifyRemark.Checked Then
            ArF.Add("ModifyRemark")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkUserCancelled.Checked Then
            ArF.Add("UserCancelled")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkCancelRemark.Checked Then
            ArF.Add("CancelRemark")
            ArH.Add("")
            ArT.Add("s")
        End If

        If Me.chkSyncFlag.Checked Then
            ArF.Add("SyncFlag")
            ArH.Add("")
            ArT.Add("c")
        End If

        ',[VehWtRemark]
        ',[CostPerTon]
        ',[Amount]
        ',[Commission]

    End Sub

    Private Sub GenerateMaterialWiseReport()

        Dim wh As String
        wh = getRepFilter()

        Dim sg As String
        sg = "Select MatCode, MatName "
        sg = sg & " from tblWeighing where CanFlag = 0 "
        sg = sg & " and SWDateTime >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd HH:mm") & "'"
        sg = sg & " and SWDateTime <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd HH:mm") & "9'"
        sg = sg & " and WeighType <> 1"
        If wh <> "" Then
            sg = sg & " and " & wh
        End If

        sg = sg & " Group by MatCode, MatName"
        sg = sg & " Order by MatCode, MatName"

        Dim s As String
        s = "Select *, (NWeight/1000) as NetWeightTons from tblWeighing where CanFlag = 0 "
        s = s & " and SWDateTime >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd HH:mm") & "'"
        s = s & " and SWDateTime <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd HH:mm") & "9'"
        s = s & " and WeighType <> 1 "
        If wh <> "" Then
            s = s & " and " & wh
        End If

        PrepareReportArrays()
        Dim fm As New frmStatus
        fm.Show("Preparing Report...")


        Dim hdglist As New List(Of String)

        ' open report
        Dim repFn As String
        repFn = msOpenReport(Me.cmbRptLook.Text, "", "Customer Report")

        ' loop through group header
        Dim dsg As DataSet
        Dim w As String
        w = mslCons.WebAuthcode
        dsg = msWebGetDS(sg, w)
        If dsg.Tables.Count < 1 Then
            fm.Close()
            Exit Sub
        End If

        If dsg.Tables(0).Rows.Count < 1 Then
            fm.Close()
            MsgBox("No records in selected criteria", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sr As String
        sr = ""
        Dim sDet As String

        Dim dsR As DataSet

        Dim sc As New List(Of String)
        Dim sf As New List(Of String)

        For g = 0 To dsg.Tables(0).Rows.Count - 1
            ' make header for each
            hdglist = New List(Of String)
            hdglist.Add("From")
            hdglist.Add(Format(Me.dtpFrm.Value, "dd/MM/yyyy HH:mm"))
            hdglist.Add("to")
            hdglist.Add(Format(Me.dtpTo.Value, "dd/MM/yyyy HH:mm"))
            hdglist.Add("Mat code")
            hdglist.Add(dsg.Tables(0).Rows(g)("Matcode"))
            hdglist.Add("Material")
            hdglist.Add(dsg.Tables(0).Rows(g)("MatName"))
            If wh <> "" Then
                If Me.txtCustcode.Text.Trim <> "" Then
                    hdglist.Add("CustCode")
                    hdglist.Add(Me.txtCustcode.Text)
                End If
                If Me.txtMatCode.Text.Trim <> "" Then
                    hdglist.Add("MatCode")
                    hdglist.Add(txtMatCode.Text)
                End If
                If Me.txtSoucode.Text.Trim <> "" Then
                    hdglist.Add("Source / Destination")
                    hdglist.Add(txtSoucode.Text)
                End If
                If Me.txtLocCode.Text.Trim <> "" Then
                    hdglist.Add("Location / Destination")
                    hdglist.Add(txtLocCode.Text)
                End If
                If Me.txtSiteCode.Text.Trim <> "" Then
                    hdglist.Add("Site")
                    hdglist.Add(txtSiteCode.Text)
                End If
                If Me.txtVehcode.Text.Trim <> "" Then
                    hdglist.Add("Vehicle")
                    hdglist.Add(txtVehcode.Text)
                End If
                hdglist.Add("cust Type")
                hdglist.Add(cmbCustType.Text)

            End If


            sr = msPrepareTableFromList(hdglist, 4, "60")
            My.Computer.FileSystem.WriteAllText(repFn, sr, True)


            ' make details and summary 
            sDet = s & " and MatCode = '" & dsg.Tables(0).Rows(g)("Matcode") & "'"
            sDet = sDet & " and MatName = '" & dsg.Tables(0).Rows(g)("MatName") & "'"
            sDet = sDet & " order by TicketNo"


            w = mslCons.WebAuthcode
            dsR = msWebGetDS(sDet, w)
            If w = mslCons.WebAuthcode Or IsNumeric(w) Then

                If dsR.Tables.Count < 1 Then
                    fm.Close()
                    MsgBox("Error retrieving data", MsgBoxStyle.Critical)
                    Exit Sub
                End If
            Else
                fm.Close()
                MsgBox("error 150206 " & w, MsgBoxStyle.Critical)
                Exit Sub
            End If

            ' add sum captions and sum fields here
            sc = New List(Of String)
            sf = New List(Of String)
            sc.Add("Total Net Weight in Tonns")
            sf.Add("NetWeightTons")

            w = ""
            w = msPrepareReportAndSummary(dsR, ArF, ArH, ArT, "Total Tickets", sc, sf, True, repFn)
            If w <> "" Then
                fm.Close()
                MsgBox(w, MsgBoxStyle.Critical)
                Exit Sub
            End If

            ' add group footer if required

        Next

        ' close html
        sr = msCloseReport()
        My.Computer.FileSystem.WriteAllText(repFn, sr, True)

        Dim frmRep As New frmReports
        frmRep.Show(repFn, "Material wise Reports - Vehical Weighing System")
        fm.Close()

    End Sub

    Private Sub GenerateCustomerWiseReport()

        Dim wh As String
        wh = getRepFilter()

        Dim sg As String
        sg = "Select CustCode, CustName, PriceGroup, PrepaidCust "
        sg = sg & " from tblWeighing where CanFlag = 0 "
        sg = sg & " and SWDateTime >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd HH:mm") & "'"
        sg = sg & " and SWDateTime <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd HH:mm") & "9'"
        sg = sg & " and WeighType <> 1 "
        If wh <> "" Then
            sg = sg & " and " & wh
        End If

        sg = sg & " Group by CustCode, CustName, PriceGroup, PrepaidCust"
        sg = sg & " Order by CustCode, CustName, PriceGroup, PrepaidCust"

        Dim s As String
        s = "Select *, (NWeight/1000) as NetWeightTons  from tblWeighing where CanFlag = 0 "
        s = s & " and SWDateTime >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd HH:mm") & "'"
        s = s & " and SWDateTime <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd HH:mm") & "9'"
        s = s & " and WeighType <> 1 "
        If wh <> "" Then
            s = s & " and " & wh
        End If
        


        PrepareReportArrays()
        Dim fm As New frmStatus
        fm.Show("Preparing Report...")


        Dim hdglist As New List(Of String)

        ' open report
        Dim repFn As String
        repFn = msOpenReport(Me.cmbRptLook.Text, "", "Customer Report")

        ' loop through group header
        Dim dsg As DataSet
        Dim w As String
        w = mslCons.WebAuthcode
        dsg = msWebGetDS(sg, w)
        If dsg.Tables.Count < 1 Then
            fm.Close()
            Exit Sub
        End If

        If dsg.Tables(0).Rows.Count < 1 Then
            fm.Close()
            MsgBox("No records in selected criteria", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sr As String
        sr = ""
        Dim sDet As String

        Dim dsR As DataSet

        Dim sc As New List(Of String)
        Dim sf As New List(Of String)

        For g = 0 To dsg.Tables(0).Rows.Count - 1
            ' make header for each
            hdglist = New List(Of String)
            hdglist.Add("From")
            hdglist.Add(Format(Me.dtpFrm.Value, "dd/MM/yyyy HH:mm"))
            hdglist.Add("to")
            hdglist.Add(Format(Me.dtpTo.Value, "dd/MM/yyyy HH:mm"))
            hdglist.Add("Cust code")
            hdglist.Add(dsg.Tables(0).Rows(g)("Custcode"))
            hdglist.Add("Customer")
            hdglist.Add(dsg.Tables(0).Rows(g)("CustName"))
            hdglist.Add("Price Group")
            hdglist.Add(dsg.Tables(0).Rows(g)("PriceGroup"))
            hdglist.Add("Prepaid Flag")
            hdglist.Add(dsg.Tables(0).Rows(g)("PrepaidCust"))

            If wh <> "" Then
                If Me.txtCustcode.Text.Trim <> "" Then
                    hdglist.Add("CustCode")
                    hdglist.Add(Me.txtCustcode.Text)
                End If
                If Me.txtMatCode.Text.Trim <> "" Then
                    hdglist.Add("MatCode")
                    hdglist.Add(txtMatCode.Text)
                End If
                If Me.txtSoucode.Text.Trim <> "" Then
                    hdglist.Add("Source / Destination")
                    hdglist.Add(txtSoucode.Text)
                End If
                If Me.txtLocCode.Text.Trim <> "" Then
                    hdglist.Add("Location / Destination")
                    hdglist.Add(txtLocCode.Text)
                End If
                If Me.txtSiteCode.Text.Trim <> "" Then
                    hdglist.Add("Site")
                    hdglist.Add(txtSiteCode.Text)
                End If
                If Me.txtVehcode.Text.Trim <> "" Then
                    hdglist.Add("Vehicle")
                    hdglist.Add(txtVehcode.Text)
                End If
                hdglist.Add("cust Type")
                hdglist.Add(cmbCustType.Text)

            End If

            sr = msPrepareTableFromList(hdglist, 4, "60")
            My.Computer.FileSystem.WriteAllText(repFn, sr, True)


            ' make details and summary 
            sDet = s & " and CustCode = '" & dsg.Tables(0).Rows(g)("Custcode") & "'"
            sDet = sDet & " and CustName = '" & dsg.Tables(0).Rows(g)("CustName") & "'"
            sDet = sDet & " and PriceGroup = '" & dsg.Tables(0).Rows(g)("PriceGroup") & "'"
            sDet = sDet & " and PrepaidCust = '" & dsg.Tables(0).Rows(g)("PrepaidCust") & "'"
            sDet = sDet & " order by TicketNo"


            w = mslCons.WebAuthcode
            dsR = msWebGetDS(sDet, w)
            If w = mslCons.WebAuthcode Or IsNumeric(w) Then

                If dsR.Tables.Count < 1 Then
                    fm.Close()
                    MsgBox("Error retrieving data", MsgBoxStyle.Critical)
                    Exit Sub
                End If
            Else
                fm.Close()
                MsgBox("error 150206 " & w, MsgBoxStyle.Critical)
                Exit Sub
            End If

            ' add sum captions and sum fields here
            sc = New List(Of String)
            sf = New List(Of String)
            sc.Add("Total Net Weight in Tonns")
            sf.Add("NetWeightTons")

            w = ""
            w = msPrepareReportAndSummary(dsR, ArF, ArH, ArT, "Total Tickets", sc, sf, True, repFn)
            If w <> "" Then
                fm.Close()
                MsgBox(w, MsgBoxStyle.Critical)
                Exit Sub
            End If

            ' add group footer if required

        Next

        ' close html
        sr = msCloseReport()
        My.Computer.FileSystem.WriteAllText(repFn, sr, True)

        Dim frmRep As New frmReports
        frmRep.Show(repFn, "Reports - Vehicle Weighing System")
        fm.Close()


    End Sub

    Private Function getRepFilter() As String

        getRepFilter = ""

        Dim wh As String

        If Me.txtCustcode.Text.Trim = "" And Me.txtLocCode.Text.Trim = "" And Me.txtMatCode.Text.Trim = "" And Me.txtSiteCode.Text.Trim = "" And Me.txtSoucode.Text.Trim = "" And cmbCustType.SelectedIndex = 0 Then

            wh = ""
            Exit Function


        Else

            wh = " WgID > 0 "

        End If

        If cmbCustType.SelectedIndex > 0 Then

            wh = wh & " and CustType = " & Mid(cmbCustType.Text, 1, 1)

        End If

        If Me.txtCustcode.Text.Trim <> "" Then

            wh = wh & " and CustCode >= '" & Me.txtCustcode.Text.Trim & "'" & " and CustCode <= '" & Me.txtCustcodeTo.Text.Trim & "'"

        End If

        If txtMatCode.Text.Trim <> "" Then

            wh = wh & " and MatCode >= '" & txtMatCode.Text.Trim & "'" & " and MatCode <= '" & txtMatCodeTo.Text.Trim & "'"

        End If

        If txtLocCode.Text.Trim <> "" Then

            wh = wh & " and LocCode >= '" & txtLocCode.Text.Trim & "'" & " and LocCode <= '" & txtLocCodeTo.Text.Trim & "'"

        End If

        If txtSiteCode.Text.Trim <> "" Then

            wh = wh & " and SiteCode >= '" & txtSiteCode.Text.Trim & "'" & " and SiteCode <= '" & txtSiteCodeTo.Text.Trim & "'"

        End If

        If txtSoucode.Text.Trim <> "" Then

            wh = wh & " and SouCode >= '" & txtSoucode.Text.Trim & "'" & " and SouCode <= '" & txtSoucodeTo.Text.Trim & "'"

        End If

        If txtVehcode.Text.Trim <> "" Then
            wh = wh & " and VehCode >= '" & txtVehcode.Text.Trim & "'" & " and VehCode <= '" & txtVehcodeTo.Text.Trim & "'"

        End If

        getRepFilter = wh


    End Function

    Private Sub GenerateAllTicketReport()

        Dim s As String
        s = "Select *, (NWeight/1000) as NetWeightTons from tblWeighing where CanFlag = 0 "
        If rbRep1stTicket.Checked Then
            's = s & " and FWDateTime >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd HH:mm") & "'"
            's = s & " and FWDateTime <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd HH:mm") & "9'"
            s = s & " and WeighType = 1 "
        Else
            s = s & " and SWDateTime >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd HH:mm") & "'"
            s = s & " and SWDateTime <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd HH:mm") & "9'"
            s = s & " and WeighType <> 1 "
        End If

        Dim wh As String
        wh = getRepFilter()

        If wh <> "" Then

            s = s & " and " & wh

        End If


        Dim hdglist As New List(Of String)
        hdglist.Add("From")
        hdglist.Add(Format(Me.dtpFrm.Value, "dd/MM/yyyy HH:mm"))
        hdglist.Add("to")
        hdglist.Add(Format(Me.dtpTo.Value, "dd/MM/yyyy HH:mm"))
        If Me.txtVehcode.Text.Trim <> "" Then
            hdglist.Add("Vehicle")
            hdglist.Add(txtVehcode.Text)
        End If
        hdglist.Add("cust Type")
        hdglist.Add(cmbCustType.Text)


        s = s & " order by "

        s = s & " TicketNo"

        PrepareReportArrays()

        Dim fm As New frmStatus
        fm.Show("Preparing Report...")

        Dim repFn As String   ' report file name
        If Me.rbRep1stTicket.Checked Then
            repFn = msOpenReport(Me.cmbRptLook.Text, "", "1st Weighing report")
        Else
            repFn = msOpenReport(Me.cmbRptLook.Text, "", "Weighing report")
        End If


        Dim sr As String
        sr = msPrepareTableFromList(hdglist, 4, "60")       ' returns with para gap

        My.Computer.FileSystem.WriteAllText(repFn, sr, True)

        ' make details and summary
        Dim dsr As DataSet
        Dim w As String
        w = mslCons.WebAuthcode
        dsr = msWebGetDS(s, w)

        If w = mslCons.WebAuthcode Or IsNumeric(w) Then

            If dsr.Tables.Count < 1 Then
                fm.Close()
                MsgBox("Error retrieving data", MsgBoxStyle.Critical)
                Exit Sub
            End If
        Else
            MsgBox("error 150206 " & w, MsgBoxStyle.Critical)
        End If

        Dim sc As New List(Of String)
        Dim sf As New List(Of String)
        ' add sum captions and sum fields here
        sc.Add("Total Net Weight in Tons")
        sf.Add("NetWeightTons")

        w = ""
        w = msPrepareReportAndSummary(dsr, ArF, ArH, ArT, "Total Tickets", sc, sf, True, repFn)
        If w <> "" Then
            MsgBox(w, MsgBoxStyle.Critical)
            Exit Sub
        End If

        ' add footer if required

        ' close html
        sr = msCloseReport()
        My.Computer.FileSystem.WriteAllText(repFn, sr, True)

        Dim frmRep As New frmReports
        frmRep.Show(repFn, "Reports - Vehicle Weighing System")
        fm.Close()


    End Sub

    

    Private Sub rbRepAllTickets_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbRepAllTickets.CheckedChanged

        If rbRepAllTickets.Checked Then

            Me.rbObTicket.Checked = True
            Me.rbObEntry.Checked = False
            Me.rbObCustTick.Checked = False
            Me.rbOb2ndDT.Checked = False
            Me.rbObMatTick.Checked = False

            chkTicket.Checked = True
            chkFirstTickNo.Checked = False
            chkVehCode.Checked = True
            chkVehical.Checked = True
            chkDriver.Checked = False
            chkDriverMob.Checked = False
            chkCustcode.Checked = True
            chkCustName.Checked = True
            chkPriceGroup.Checked = False
            chkPrepaidFlag.Checked = True
            chkMatCode.Checked = True
            chkMaterial.Checked = True
            chkSoucode.Checked = False
            chkSource.Checked = False
            chkLocCode.Checked = False
            chkLocation.Checked = False
            Me.chkSiteCode.Checked = False
            Me.chkSite.Checked = False
            Me.chkInOut.Checked = False
            Me.chkWtType.Checked = False
            Me.chkFirstWt.Checked = True
            Me.chkSecondWt.Checked = True
            Me.chkNetWeight.Checked = False
            chkNetWeightTons.Checked = True
            Me.chkFWdate.Checked = False
            Me.chkFWdt.Checked = False
            chkSWdate.Checked = True
            chkSWdt.Checked = False
            chkWtRemark.Checked = False
            chkDlvOrder.Checked = False
            chkRemark.Checked = False
            chkLastUpdate.Checked = False
            chkUserID.Checked = True
            chkUserModified.Checked = False
            chkModifyRemark.Checked = False
            chkUserCancelled.Checked = False
            chkCancelRemark.Checked = False
            chkSyncFlag.Checked = False

        End If



    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()

    End Sub

    Private Sub rbRep1stTicket_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbRep1stTicket.CheckedChanged

        If rbRep1stTicket.Checked Then

            Me.rbObTicket.Checked = True

            chkTicket.Checked = False
            chkFirstTickNo.Checked = True
            chkVehCode.Checked = True
            chkVehical.Checked = True
            chkDriver.Checked = True
            chkDriverMob.Checked = True
            chkCustcode.Checked = True
            chkCustName.Checked = True
            chkPriceGroup.Checked = False
            chkPrepaidFlag.Checked = True
            chkMatCode.Checked = True
            chkMaterial.Checked = True
            chkSoucode.Checked = False
            chkSource.Checked = False
            chkLocCode.Checked = False
            chkLocation.Checked = False
            Me.chkSiteCode.Checked = False
            Me.chkSite.Checked = False
            Me.chkInOut.Checked = False
            Me.chkWtType.Checked = False
            Me.chkFirstWt.Checked = True
            Me.chkSecondWt.Checked = False
            Me.chkNetWeightTons.Checked = True
            Me.chkFWdate.Checked = False
            Me.chkFWdt.Checked = True
            chkSWdate.Checked = False
            chkSWdt.Checked = False
            chkWtRemark.Checked = False
            chkDlvOrder.Checked = False
            chkRemark.Checked = False
            chkLastUpdate.Checked = False
            chkUserID.Checked = True
            chkUserModified.Checked = False
            chkModifyRemark.Checked = False
            chkUserCancelled.Checked = False
            chkCancelRemark.Checked = False
            chkSyncFlag.Checked = False

        End If

    End Sub

    Private Sub rbRepCustTick_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbRepCustTick.CheckedChanged

        If rbRepCustTick.Checked Then

            Me.rbObTicket.Checked = True
            Me.rbObEntry.Checked = False
            Me.rbObCustTick.Checked = False
            Me.rbOb2ndDT.Checked = False
            Me.rbObMatTick.Checked = False

            chkTicket.Checked = True
            chkFirstTickNo.Checked = False
            chkVehCode.Checked = True
            chkVehical.Checked = True
            chkDriver.Checked = False
            chkDriverMob.Checked = False

            ' this should go on header as it is grouped report
            chkCustcode.Checked = False
            chkCustName.Checked = False
            chkPriceGroup.Checked = False
            chkPrepaidFlag.Checked = False

            chkMatCode.Checked = True
            chkMaterial.Checked = True
            chkSoucode.Checked = False
            chkSource.Checked = False
            chkLocCode.Checked = False
            chkLocation.Checked = False
            chkSiteCode.Checked = False
            chkSite.Checked = False
            chkInOut.Checked = False
            chkWtType.Checked = False
            chkFirstWt.Checked = True
            chkSecondWt.Checked = True
            chkNetWeightTons.Checked = True
            chkFWdate.Checked = False
            chkFWdt.Checked = False
            chkSWdate.Checked = True
            chkSWdt.Checked = False
            chkWtRemark.Checked = False
            chkDlvOrder.Checked = False
            chkRemark.Checked = False
            chkLastUpdate.Checked = False
            chkUserID.Checked = True
            chkUserModified.Checked = False
            chkModifyRemark.Checked = False
            chkUserCancelled.Checked = False
            chkCancelRemark.Checked = False
            chkSyncFlag.Checked = False

        End If

    End Sub

    Private Sub btnSelCust_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelCust.Click

        Dim frmc As New frmPartySearch

        Dim cs As String

        cs = frmc.ShowDialog_PartySearch("", "", True, False)
        Me.txtCustcode.Text = cs
        Me.txtCustcodeTo.Text = cs


    End Sub

    Private Sub btnMat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim frmc As New frmMaterialSearch

        Dim mcs As String

        mcs = frmc.ShowDialog_MatSearch("", txtCustcode.Text, True, False)

        Me.txtMatCode.Text = mcs

    End Sub


    Private Sub btnSelsou_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelsou.Click

        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        cs = frmc.ShowDialog_OtherMasterSearch("tblSource", "Soucode", "SouName", "", "", True, False)
        Me.txtSoucode.Text = cs
        Me.txtSoucodeTo.Text = cs

    End Sub

    Private Sub btnSelLoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelLoc.Click

        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        cs = frmc.ShowDialog_OtherMasterSearch("tblLocations", "Loccode", "LocName", "", "", True, False)
        Me.txtLocCode.Text = cs
        Me.txtLocCodeTo.Text = cs

    End Sub

    Private Sub btnSelSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelSite.Click

        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        cs = frmc.ShowDialog_OtherMasterSearch("tblSites", "Sitecode", "SiteName", "", "", True, False)
        Me.txtSiteCode.Text = cs
        Me.txtSiteCodeTo.Text = cs

    End Sub

    Private Sub rbRepMatTick_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbRepMatTick.CheckedChanged

        If rbRepMatTick.Checked Then

            Me.rbObTicket.Checked = True
            Me.rbObEntry.Checked = False
            Me.rbObCustTick.Checked = False
            Me.rbOb2ndDT.Checked = False
            Me.rbObMatTick.Checked = False

            chkTicket.Checked = True
            chkFirstTickNo.Checked = False
            chkVehCode.Checked = True
            chkVehical.Checked = True
            chkDriver.Checked = False
            chkDriverMob.Checked = False

            ' this should go on header as it is grouped report
            chkMatCode.Checked = False
            chkMaterial.Checked = False

            chkCustcode.Checked = True
            chkCustName.Checked = True
            chkPriceGroup.Checked = False
            chkPrepaidFlag.Checked = False

            chkSoucode.Checked = False
            chkSource.Checked = False
            chkLocCode.Checked = False
            chkLocation.Checked = False
            chkSiteCode.Checked = False
            chkSite.Checked = False
            chkInOut.Checked = False
            chkWtType.Checked = False
            chkFirstWt.Checked = True
            chkSecondWt.Checked = True
            chkNetWeightTons.Checked = True
            chkFWdate.Checked = False
            chkFWdt.Checked = False
            chkSWdate.Checked = True
            chkSWdt.Checked = False
            chkWtRemark.Checked = False
            chkDlvOrder.Checked = False
            chkRemark.Checked = False
            chkLastUpdate.Checked = False
            chkUserID.Checked = True
            chkUserModified.Checked = False
            chkModifyRemark.Checked = False
            chkUserCancelled.Checked = False
            chkCancelRemark.Checked = False
            chkSyncFlag.Checked = False

        End If


    End Sub

    Private Sub btnSelVeh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelVeh.Click

        Dim frmc As New frmVehicalSearch

        Dim cs As String

        cs = frmc.ShowDialog_VehicleSearch("", True, False)
        Me.txtVehcode.Text = cs
        Me.txtVehcodeTo.Text = cs

    End Sub


    Private Sub btnCustMatCrReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCustMatCrReport.Click

        Dim wh As String
        wh = getRepFilter()

        Dim sStr As String
        sStr = "Select * from tblweighing where canflag = 0 and WeighType <> 1 "
        sStr = sStr & " and SWDateTime >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd HH:mm") & "'"
        sStr = sStr & " and SWDateTime <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd HH:mm") & "9'"
        If wh <> "" Then
            sStr = sStr & " and " & wh
        End If
        sStr = sStr & " order by TicketNo"


        Dim hdg As String
        hdg = "From: " & Me.dtpFrm.Value & "  To: " & Me.dtpTo.Value
        hdg = hdg & "  CustType: " & cmbCustType.Text

        If wh <> "" Then
            If Me.txtCustcode.Text.Trim <> "" Then
                hdg = hdg & "  CustCode: " & txtCustcode.Text
            End If
            If Me.txtMatCode.Text.Trim <> "" Then
                hdg = hdg & "  MatCode: " & txtMatCode.Text
            End If
            If Me.txtSoucode.Text.Trim <> "" Then
                hdg = hdg & "  Source / Destination: " & txtSoucode.Text
            End If
            If Me.txtLocCode.Text.Trim <> "" Then
                hdg = hdg & "  Location / Destination: " & txtLocCode.Text
            End If
            If Me.txtSiteCode.Text.Trim <> "" Then
                hdg = hdg & "  Site: " & txtSiteCode.Text
            End If
            If Me.txtVehcode.Text.Trim <> "" Then
                hdg = hdg & "  Vehicle: " & txtVehcode.Text
            End If

        End If

        Dim fm As New frmStatus
        fm.Show("Preparing Report...")


        ' loop through group header
        Dim dsg As DataSet
        Dim w As String
        w = mslCons.WebAuthcode
        dsg = msWebGetDS(sStr, w)
        If dsg.Tables.Count < 1 Then
            fm.Close()
            Exit Sub
        End If

        'If dsg.Tables(0).Rows.Count < 1 Then
        '    fm.Close()
        '    MsgBox("No records in selected criteria", MsgBoxStyle.Exclamation)
        '    Exit Sub
        'End If

        fm.Close()

        Dim frmcr As New frmCrysReport
        frmcr.Showdialog_frmCryReport(dsg, mslv.ReportsPath & "\CustMatReport.rpt", "headg", hdg, , , True, )



    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles chkAllCust.CheckedChanged
        Me.GpBoxCust.Enabled = Not Me.chkAllCust.Checked
        If Me.chkAllCust.Checked Then
            Me.txtCustcode.Text = ""
            Me.txtCustcodeTo.Text = ""
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnSelCustTo.Click
        Dim frmc As New frmPartySearch

        Dim cs As String

        cs = frmc.ShowDialog_PartySearch("", "", True, False)
        Me.txtCustcodeTo.Text = cs
    End Sub

    Private Sub btnMat_Click_1(sender As Object, e As EventArgs) Handles btnMat.Click

        Dim frmc As New frmMaterialSearch

        Dim mcs As String

        mcs = frmc.ShowDialog_MatSearch("", txtCustcode.Text, True, False)

        Me.txtMatCode.Text = mcs
        Me.txtMatCodeTo.Text = mcs
    End Sub

    Private Sub btnMatTo_Click(sender As Object, e As EventArgs) Handles btnMatTo.Click
        Dim frmc As New frmMaterialSearch

        Dim mcs As String

        mcs = frmc.ShowDialog_MatSearch("", txtCustcode.Text, True, False)

        Me.txtMatCodeTo.Text = mcs
    End Sub

    Private Sub chkAllMat_CheckedChanged(sender As Object, e As EventArgs) Handles chkAllMat.CheckedChanged
        Me.gpBoxMat.Enabled = Not Me.chkAllMat.Checked
    End Sub

    Private Sub chkAllSou_CheckedChanged(sender As Object, e As EventArgs) Handles chkAllSou.CheckedChanged
        Me.gpBoxSoucode.Enabled = Not Me.chkAllSou.Checked
    End Sub

    Private Sub btnSelsouTo_Click(sender As Object, e As EventArgs) Handles btnSelsouTo.Click
        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        cs = frmc.ShowDialog_OtherMasterSearch("tblSource", "Soucode", "SouName", "", "", True, False)

        Me.txtSoucodeTo.Text = cs
    End Sub

    Private Sub btnSelLocTo_Click(sender As Object, e As EventArgs) Handles btnSelLocTo.Click
        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        cs = frmc.ShowDialog_OtherMasterSearch("tblLocations", "Loccode", "LocName", "", "", True, False)

        Me.txtLocCodeTo.Text = cs
    End Sub

    Private Sub CheckBox1_CheckedChanged_1(sender As Object, e As EventArgs) Handles chkAllLoc.CheckedChanged
        Me.gpBoxLoc.Enabled = Not Me.chkAllLoc.Checked
    End Sub

    Private Sub chkAllSite_CheckedChanged(sender As Object, e As EventArgs) Handles chkAllSite.CheckedChanged
        Me.gpBoxSite.Enabled = Not Me.chkAllSite.Checked
    End Sub

    Private Sub btnSelSiteTo_Click(sender As Object, e As EventArgs) Handles btnSelSiteTo.Click
        Dim frmc As New frmOtherMastersSearch

        Dim cs As String

        cs = frmc.ShowDialog_OtherMasterSearch("tblSites", "Sitecode", "SiteName", "", "", True, False)
        Me.txtSiteCodeTo.Text = cs
    End Sub

    Private Sub btnSelVehTo_Click(sender As Object, e As EventArgs) Handles btnSelVehTo.Click
        Dim frmc As New frmVehicalSearch

        Dim cs As String

        cs = frmc.ShowDialog_VehicleSearch("", True, False)
        Me.txtVehcodeTo.Text = cs
    End Sub

    Private Sub chkAllVehicles_CheckedChanged(sender As Object, e As EventArgs) Handles chkAllVeh.CheckedChanged
        Me.gpBoxVeh.Enabled = Not Me.chkAllVeh.Checked
    End Sub
End Class