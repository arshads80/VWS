﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmParties
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmParties))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtcustName = New System.Windows.Forms.TextBox()
        Me.cmbPriceGroup = New System.Windows.Forms.ComboBox()
        Me.txtNote = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtMobile = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTel = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtWebsite = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtCompanyEmail = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtCountry = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCustCode = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBoxSearch = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.bnAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.bnCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.bnDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.bnPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.bnMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnEdit = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnRefresh = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnSave = New System.Windows.Forms.ToolStripButton()
        Me.bnCancel = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.bnClose = New System.Windows.Forms.ToolStripButton()
        Me.lbldispError = New System.Windows.Forms.ToolStripLabel()
        Me.txtLM = New System.Windows.Forms.Label()
        Me.btnSelect = New System.Windows.Forms.Button()
        Me.txtDisable = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtPrepaidCust = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.pnlInvisible = New System.Windows.Forms.Panel()
        Me.pnlPrepaidCust = New System.Windows.Forms.Panel()
        Me.btnManageCredit = New System.Windows.Forms.Button()
        Me.lblBalance = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.lblTotAmtUsed = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lbltotAmtIn = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.cmbCustType = New System.Windows.Forms.ComboBox()
        Me.GroupBoxSearch.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        Me.pnlInvisible.SuspendLayout()
        Me.pnlPrepaidCust.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 81)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Customer Name"
        '
        'txtcustName
        '
        Me.txtcustName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtcustName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtcustName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtcustName.Location = New System.Drawing.Point(200, 78)
        Me.txtcustName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtcustName.MaxLength = 50
        Me.txtcustName.Name = "txtcustName"
        Me.txtcustName.Size = New System.Drawing.Size(434, 24)
        Me.txtcustName.TabIndex = 2
        '
        'cmbPriceGroup
        '
        Me.cmbPriceGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPriceGroup.FormattingEnabled = True
        Me.cmbPriceGroup.Location = New System.Drawing.Point(200, 266)
        Me.cmbPriceGroup.MaxLength = 20
        Me.cmbPriceGroup.Name = "cmbPriceGroup"
        Me.cmbPriceGroup.Size = New System.Drawing.Size(141, 25)
        Me.cmbPriceGroup.TabIndex = 15
        '
        'txtNote
        '
        Me.txtNote.Location = New System.Drawing.Point(204, 127)
        Me.txtNote.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtNote.MaxLength = 50
        Me.txtNote.Name = "txtNote"
        Me.txtNote.Size = New System.Drawing.Size(434, 24)
        Me.txtNote.TabIndex = 31
        Me.txtNote.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(49, 130)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(41, 17)
        Me.Label15.TabIndex = 30
        Me.Label15.Text = "Note"
        Me.Label15.Visible = False
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(131, 90)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtEmail.MaxLength = 50
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(188, 24)
        Me.txtEmail.TabIndex = 23
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(49, 93)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 17)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Email"
        '
        'txtMobile
        '
        Me.txtMobile.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtMobile.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtMobile.Location = New System.Drawing.Point(200, 231)
        Me.txtMobile.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMobile.MaxLength = 20
        Me.txtMobile.Name = "txtMobile"
        Me.txtMobile.Size = New System.Drawing.Size(187, 24)
        Me.txtMobile.TabIndex = 13
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 234)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 17)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Mobile"
        '
        'txtContact
        '
        Me.txtContact.Location = New System.Drawing.Point(200, 195)
        Me.txtContact.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtContact.MaxLength = 50
        Me.txtContact.Name = "txtContact"
        Me.txtContact.Size = New System.Drawing.Size(434, 24)
        Me.txtContact.TabIndex = 11
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 198)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 17)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Contact Person"
        '
        'txtTel
        '
        Me.txtTel.Location = New System.Drawing.Point(200, 154)
        Me.txtTel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTel.MaxLength = 30
        Me.txtTel.Name = "txtTel"
        Me.txtTel.Size = New System.Drawing.Size(241, 24)
        Me.txtTel.TabIndex = 9
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(33, 157)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(78, 17)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Telephone"
        '
        'txtWebsite
        '
        Me.txtWebsite.Location = New System.Drawing.Point(417, 93)
        Me.txtWebsite.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtWebsite.MaxLength = 50
        Me.txtWebsite.Name = "txtWebsite"
        Me.txtWebsite.Size = New System.Drawing.Size(369, 24)
        Me.txtWebsite.TabIndex = 20
        Me.txtWebsite.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(334, 96)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(64, 17)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Website"
        Me.Label12.Visible = False
        '
        'txtCompanyEmail
        '
        Me.txtCompanyEmail.Location = New System.Drawing.Point(174, 55)
        Me.txtCompanyEmail.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCompanyEmail.MaxLength = 50
        Me.txtCompanyEmail.Name = "txtCompanyEmail"
        Me.txtCompanyEmail.Size = New System.Drawing.Size(434, 24)
        Me.txtCompanyEmail.TabIndex = 15
        Me.txtCompanyEmail.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(19, 58)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(115, 17)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Company Email"
        Me.Label11.Visible = False
        '
        'txtCountry
        '
        Me.txtCountry.Location = New System.Drawing.Point(641, 10)
        Me.txtCountry.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCountry.MaxLength = 20
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.Size = New System.Drawing.Size(187, 24)
        Me.txtCountry.TabIndex = 13
        Me.txtCountry.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(558, 13)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 17)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "Country"
        Me.Label10.Visible = False
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(411, 10)
        Me.txtState.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtState.MaxLength = 16
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(141, 24)
        Me.txtState.TabIndex = 11
        Me.txtState.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(340, 13)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 17)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "State"
        Me.Label9.Visible = False
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(175, 5)
        Me.txtCity.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCity.MaxLength = 16
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(141, 24)
        Me.txtCity.TabIndex = 9
        Me.txtCity.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(81, 10)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 17)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "City"
        Me.Label8.Visible = False
        '
        'btnCheck
        '
        Me.btnCheck.Enabled = False
        Me.btnCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCheck.Font = New System.Drawing.Font("Verdana", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheck.ForeColor = System.Drawing.Color.Purple
        Me.btnCheck.Location = New System.Drawing.Point(837, 78)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(126, 28)
        Me.btnCheck.TabIndex = 5
        Me.btnCheck.Text = "Check Code"
        Me.btnCheck.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(656, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Cust Code"
        '
        'txtCustCode
        '
        Me.txtCustCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCustCode.Location = New System.Drawing.Point(748, 78)
        Me.txtCustCode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCustCode.MaxLength = 10
        Me.txtCustCode.Name = "txtCustCode"
        Me.txtCustCode.Size = New System.Drawing.Size(83, 24)
        Me.txtCustCode.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(35, 268)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 17)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Price Group"
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(200, 114)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtAddress.MaxLength = 50
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(434, 24)
        Me.txtAddress.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(33, 117)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Address"
        '
        'GroupBoxSearch
        '
        Me.GroupBoxSearch.Controls.Add(Me.btnSearch)
        Me.GroupBoxSearch.Controls.Add(Me.txtSearch)
        Me.GroupBoxSearch.Location = New System.Drawing.Point(92, 11)
        Me.GroupBoxSearch.Name = "GroupBoxSearch"
        Me.GroupBoxSearch.Size = New System.Drawing.Size(436, 60)
        Me.GroupBoxSearch.TabIndex = 0
        Me.GroupBoxSearch.TabStop = False
        Me.GroupBoxSearch.Text = "Search"
        '
        'btnSearch
        '
        Me.btnSearch.Image = CType(resources.GetObject("btnSearch.Image"), System.Drawing.Image)
        Me.btnSearch.Location = New System.Drawing.Point(385, 24)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(29, 27)
        Me.btnSearch.TabIndex = 1
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSearch.Location = New System.Drawing.Point(24, 25)
        Me.txtSearch.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSearch.MaxLength = 20
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(355, 24)
        Me.txtSearch.TabIndex = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridView1.Location = New System.Drawing.Point(0, 429)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 26
        Me.DataGridView1.Size = New System.Drawing.Size(1033, 200)
        Me.DataGridView1.TabIndex = 21
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.bnAddNewItem
        Me.BindingNavigator1.CountItem = Me.bnCountItem
        Me.BindingNavigator1.DeleteItem = Me.bnDeleteItem
        Me.BindingNavigator1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.bnMoveFirstItem, Me.bnMovePreviousItem, Me.BindingNavigatorSeparator, Me.bnPositionItem, Me.bnCountItem, Me.BindingNavigatorSeparator1, Me.bnMoveNextItem, Me.bnMoveLastItem, Me.BindingNavigatorSeparator2, Me.bnAddNewItem, Me.bnEdit, Me.bnDeleteItem, Me.ToolStripSeparator1, Me.bnRefresh, Me.ToolStripSeparator2, Me.bnSave, Me.bnCancel, Me.ToolStripSeparator3, Me.bnClose, Me.lbldispError})
        Me.BindingNavigator1.Location = New System.Drawing.Point(0, 385)
        Me.BindingNavigator1.MoveFirstItem = Me.bnMoveFirstItem
        Me.BindingNavigator1.MoveLastItem = Me.bnMoveLastItem
        Me.BindingNavigator1.MoveNextItem = Me.bnMoveNextItem
        Me.BindingNavigator1.MovePreviousItem = Me.bnMovePreviousItem
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.bnPositionItem
        Me.BindingNavigator1.Size = New System.Drawing.Size(1033, 38)
        Me.BindingNavigator1.TabIndex = 20
        Me.BindingNavigator1.Text = "BindingNavigator1"
        '
        'bnAddNewItem
        '
        Me.bnAddNewItem.Image = CType(resources.GetObject("bnAddNewItem.Image"), System.Drawing.Image)
        Me.bnAddNewItem.Name = "bnAddNewItem"
        Me.bnAddNewItem.RightToLeftAutoMirrorImage = True
        Me.bnAddNewItem.Size = New System.Drawing.Size(35, 35)
        Me.bnAddNewItem.Text = "New"
        Me.bnAddNewItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'bnCountItem
        '
        Me.bnCountItem.Name = "bnCountItem"
        Me.bnCountItem.Size = New System.Drawing.Size(35, 35)
        Me.bnCountItem.Text = "of {0}"
        Me.bnCountItem.ToolTipText = "Total number of items"
        '
        'bnDeleteItem
        '
        Me.bnDeleteItem.Image = CType(resources.GetObject("bnDeleteItem.Image"), System.Drawing.Image)
        Me.bnDeleteItem.Name = "bnDeleteItem"
        Me.bnDeleteItem.RightToLeftAutoMirrorImage = True
        Me.bnDeleteItem.Size = New System.Drawing.Size(44, 35)
        Me.bnDeleteItem.Text = "Delete"
        Me.bnDeleteItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnDeleteItem.Visible = False
        '
        'bnMoveFirstItem
        '
        Me.bnMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveFirstItem.Image = CType(resources.GetObject("bnMoveFirstItem.Image"), System.Drawing.Image)
        Me.bnMoveFirstItem.Name = "bnMoveFirstItem"
        Me.bnMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveFirstItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveFirstItem.Text = "Move first"
        '
        'bnMovePreviousItem
        '
        Me.bnMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMovePreviousItem.Image = CType(resources.GetObject("bnMovePreviousItem.Image"), System.Drawing.Image)
        Me.bnMovePreviousItem.Name = "bnMovePreviousItem"
        Me.bnMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.bnMovePreviousItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 38)
        '
        'bnPositionItem
        '
        Me.bnPositionItem.AccessibleName = "Position"
        Me.bnPositionItem.Name = "bnPositionItem"
        Me.bnPositionItem.Size = New System.Drawing.Size(36, 38)
        Me.bnPositionItem.Text = "0"
        Me.bnPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'bnMoveNextItem
        '
        Me.bnMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveNextItem.Image = CType(resources.GetObject("bnMoveNextItem.Image"), System.Drawing.Image)
        Me.bnMoveNextItem.Name = "bnMoveNextItem"
        Me.bnMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveNextItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveNextItem.Text = "Move next"
        '
        'bnMoveLastItem
        '
        Me.bnMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.bnMoveLastItem.Image = CType(resources.GetObject("bnMoveLastItem.Image"), System.Drawing.Image)
        Me.bnMoveLastItem.Name = "bnMoveLastItem"
        Me.bnMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.bnMoveLastItem.Size = New System.Drawing.Size(23, 35)
        Me.bnMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'bnEdit
        '
        Me.bnEdit.Image = CType(resources.GetObject("bnEdit.Image"), System.Drawing.Image)
        Me.bnEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnEdit.Name = "bnEdit"
        Me.bnEdit.Size = New System.Drawing.Size(31, 35)
        Me.bnEdit.Text = "Edit"
        Me.bnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'bnRefresh
        '
        Me.bnRefresh.Image = CType(resources.GetObject("bnRefresh.Image"), System.Drawing.Image)
        Me.bnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnRefresh.Name = "bnRefresh"
        Me.bnRefresh.Size = New System.Drawing.Size(50, 35)
        Me.bnRefresh.Text = "Refresh"
        Me.bnRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 38)
        '
        'bnSave
        '
        Me.bnSave.Image = CType(resources.GetObject("bnSave.Image"), System.Drawing.Image)
        Me.bnSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnSave.Name = "bnSave"
        Me.bnSave.Size = New System.Drawing.Size(35, 35)
        Me.bnSave.Text = "Save"
        Me.bnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnSave.ToolTipText = "Save"
        '
        'bnCancel
        '
        Me.bnCancel.Image = CType(resources.GetObject("bnCancel.Image"), System.Drawing.Image)
        Me.bnCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnCancel.Name = "bnCancel"
        Me.bnCancel.Size = New System.Drawing.Size(47, 35)
        Me.bnCancel.Text = "Cancel"
        Me.bnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnCancel.ToolTipText = "Cancel"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 38)
        '
        'bnClose
        '
        Me.bnClose.Image = CType(resources.GetObject("bnClose.Image"), System.Drawing.Image)
        Me.bnClose.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bnClose.Name = "bnClose"
        Me.bnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.bnClose.Size = New System.Drawing.Size(40, 35)
        Me.bnClose.Text = "Close"
        Me.bnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.bnClose.ToolTipText = "Close"
        '
        'lbldispError
        '
        Me.lbldispError.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldispError.ForeColor = System.Drawing.Color.Red
        Me.lbldispError.Name = "lbldispError"
        Me.lbldispError.Size = New System.Drawing.Size(0, 35)
        '
        'txtLM
        '
        Me.txtLM.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLM.Location = New System.Drawing.Point(555, 3)
        Me.txtLM.Name = "txtLM"
        Me.txtLM.Size = New System.Drawing.Size(463, 39)
        Me.txtLM.TabIndex = 35
        Me.txtLM.Text = "Customer / Suppliers"
        Me.txtLM.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnSelect
        '
        Me.btnSelect.Location = New System.Drawing.Point(534, 245)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.Size = New System.Drawing.Size(100, 37)
        Me.btnSelect.TabIndex = 22
        Me.btnSelect.Text = "Select"
        Me.btnSelect.UseVisualStyleBackColor = True
        Me.btnSelect.Visible = False
        '
        'txtDisable
        '
        Me.txtDisable.Location = New System.Drawing.Point(200, 341)
        Me.txtDisable.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDisable.MaxLength = 1
        Me.txtDisable.Name = "txtDisable"
        Me.txtDisable.ReadOnly = True
        Me.txtDisable.Size = New System.Drawing.Size(30, 24)
        Me.txtDisable.TabIndex = 19
        Me.txtDisable.TabStop = False
        Me.txtDisable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtDisable.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(33, 344)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(132, 17)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "Customer Disable"
        Me.Label14.Visible = False
        '
        'txtPrepaidCust
        '
        Me.txtPrepaidCust.Location = New System.Drawing.Point(200, 303)
        Me.txtPrepaidCust.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPrepaidCust.MaxLength = 1
        Me.txtPrepaidCust.Name = "txtPrepaidCust"
        Me.txtPrepaidCust.ReadOnly = True
        Me.txtPrepaidCust.Size = New System.Drawing.Size(30, 24)
        Me.txtPrepaidCust.TabIndex = 17
        Me.txtPrepaidCust.TabStop = False
        Me.txtPrepaidCust.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(33, 306)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(133, 17)
        Me.Label16.TabIndex = 16
        Me.Label16.Text = "Prepaid Customer"
        '
        'pnlInvisible
        '
        Me.pnlInvisible.Controls.Add(Me.Label8)
        Me.pnlInvisible.Controls.Add(Me.txtCity)
        Me.pnlInvisible.Controls.Add(Me.Label9)
        Me.pnlInvisible.Controls.Add(Me.txtState)
        Me.pnlInvisible.Controls.Add(Me.Label10)
        Me.pnlInvisible.Controls.Add(Me.txtCountry)
        Me.pnlInvisible.Controls.Add(Me.Label11)
        Me.pnlInvisible.Controls.Add(Me.txtCompanyEmail)
        Me.pnlInvisible.Controls.Add(Me.Label12)
        Me.pnlInvisible.Controls.Add(Me.txtWebsite)
        Me.pnlInvisible.Controls.Add(Me.txtNote)
        Me.pnlInvisible.Controls.Add(Me.Label15)
        Me.pnlInvisible.Controls.Add(Me.Label7)
        Me.pnlInvisible.Controls.Add(Me.txtEmail)
        Me.pnlInvisible.Location = New System.Drawing.Point(997, 202)
        Me.pnlInvisible.Name = "pnlInvisible"
        Me.pnlInvisible.Size = New System.Drawing.Size(861, 159)
        Me.pnlInvisible.TabIndex = 24
        Me.pnlInvisible.Visible = False
        '
        'pnlPrepaidCust
        '
        Me.pnlPrepaidCust.BackColor = System.Drawing.Color.LightGreen
        Me.pnlPrepaidCust.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlPrepaidCust.Controls.Add(Me.btnManageCredit)
        Me.pnlPrepaidCust.Controls.Add(Me.lblBalance)
        Me.pnlPrepaidCust.Controls.Add(Me.Label21)
        Me.pnlPrepaidCust.Controls.Add(Me.lblTotAmtUsed)
        Me.pnlPrepaidCust.Controls.Add(Me.Label19)
        Me.pnlPrepaidCust.Controls.Add(Me.lbltotAmtIn)
        Me.pnlPrepaidCust.Controls.Add(Me.Label17)
        Me.pnlPrepaidCust.Location = New System.Drawing.Point(659, 146)
        Me.pnlPrepaidCust.Name = "pnlPrepaidCust"
        Me.pnlPrepaidCust.Size = New System.Drawing.Size(319, 215)
        Me.pnlPrepaidCust.TabIndex = 23
        '
        'btnManageCredit
        '
        Me.btnManageCredit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnManageCredit.Location = New System.Drawing.Point(106, 155)
        Me.btnManageCredit.Name = "btnManageCredit"
        Me.btnManageCredit.Size = New System.Drawing.Size(197, 39)
        Me.btnManageCredit.TabIndex = 6
        Me.btnManageCredit.Text = "Manage Credit"
        Me.btnManageCredit.UseVisualStyleBackColor = True
        '
        'lblBalance
        '
        Me.lblBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBalance.Location = New System.Drawing.Point(161, 104)
        Me.lblBalance.Name = "lblBalance"
        Me.lblBalance.Size = New System.Drawing.Size(142, 28)
        Me.lblBalance.TabIndex = 5
        Me.lblBalance.Text = "0"
        Me.lblBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(31, 108)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(61, 17)
        Me.Label21.TabIndex = 4
        Me.Label21.Text = "Balance"
        '
        'lblTotAmtUsed
        '
        Me.lblTotAmtUsed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotAmtUsed.Location = New System.Drawing.Point(161, 64)
        Me.lblTotAmtUsed.Name = "lblTotAmtUsed"
        Me.lblTotAmtUsed.Size = New System.Drawing.Size(142, 28)
        Me.lblTotAmtUsed.TabIndex = 3
        Me.lblTotAmtUsed.Text = "0"
        Me.lblTotAmtUsed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(31, 68)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(104, 17)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Tot Amt Used"
        '
        'lbltotAmtIn
        '
        Me.lbltotAmtIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbltotAmtIn.Location = New System.Drawing.Point(161, 25)
        Me.lbltotAmtIn.Name = "lbltotAmtIn"
        Me.lbltotAmtIn.Size = New System.Drawing.Size(142, 28)
        Me.lbltotAmtIn.TabIndex = 1
        Me.lbltotAmtIn.Text = "0"
        Me.lbltotAmtIn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(28, 29)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(84, 17)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Tot Amt IN"
        '
        'Splitter1
        '
        Me.Splitter1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Splitter1.Location = New System.Drawing.Point(0, 423)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(1033, 6)
        Me.Splitter1.TabIndex = 36
        Me.Splitter1.TabStop = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(305, 306)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(79, 17)
        Me.Label18.TabIndex = 37
        Me.Label18.Text = "Cust Type"
        '
        'cmbCustType
        '
        Me.cmbCustType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCustType.FormattingEnabled = True
        Me.cmbCustType.Location = New System.Drawing.Point(399, 302)
        Me.cmbCustType.Name = "cmbCustType"
        Me.cmbCustType.Size = New System.Drawing.Size(234, 25)
        Me.cmbCustType.TabIndex = 38
        '
        'frmParties
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1033, 629)
        Me.Controls.Add(Me.cmbCustType)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.pnlPrepaidCust)
        Me.Controls.Add(Me.pnlInvisible)
        Me.Controls.Add(Me.txtPrepaidCust)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txtDisable)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.btnSelect)
        Me.Controls.Add(Me.txtLM)
        Me.Controls.Add(Me.txtMobile)
        Me.Controls.Add(Me.BindingNavigator1)
        Me.Controls.Add(Me.GroupBoxSearch)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cmbPriceGroup)
        Me.Controls.Add(Me.txtContact)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtTel)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtCustCode)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtcustName)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "frmParties"
        Me.Text = "Customers File"
        Me.GroupBoxSearch.ResumeLayout(False)
        Me.GroupBoxSearch.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        Me.pnlInvisible.ResumeLayout(False)
        Me.pnlInvisible.PerformLayout()
        Me.pnlPrepaidCust.ResumeLayout(False)
        Me.pnlPrepaidCust.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtcustName As System.Windows.Forms.TextBox
    Friend WithEvents cmbPriceGroup As System.Windows.Forms.ComboBox
    Friend WithEvents txtNote As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtMobile As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTel As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtWebsite As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtCompanyEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtCountry As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtState As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtCustCode As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBoxSearch As System.Windows.Forms.GroupBox
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents BindingNavigator1 As System.Windows.Forms.BindingNavigator
    Friend WithEvents bnAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents bnDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnEdit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnRefresh As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents bnCancel As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bnClose As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbldispError As System.Windows.Forms.ToolStripLabel
    Friend WithEvents txtLM As System.Windows.Forms.Label
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents btnSelect As System.Windows.Forms.Button
    Friend WithEvents txtDisable As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtPrepaidCust As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents pnlInvisible As System.Windows.Forms.Panel
    Friend WithEvents pnlPrepaidCust As System.Windows.Forms.Panel
    Friend WithEvents lblBalance As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents lblTotAmtUsed As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lbltotAmtIn As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents btnManageCredit As System.Windows.Forms.Button
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents cmbCustType As System.Windows.Forms.ComboBox
End Class
