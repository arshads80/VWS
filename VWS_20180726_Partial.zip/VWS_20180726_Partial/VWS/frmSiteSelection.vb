﻿Public Class frmSiteSelection

    Dim retval As String

    Public Function Showdialog_siteselection() As String

        ShowDialog()
        Showdialog_siteselection = retval

    End Function

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        mslv.OleconStr = mslv.OleconStrA
        retval = "Site A"
        Close()

    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        mslv.OleconStr = mslv.OleconStrB
        retval = "Site B"
        Close()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        mslv.OleconStr = mslv.OleconStrC
        retval = "Site C"
        Close()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        mslv.OleconStr = mslv.OleconStrD
        retval = "Site D"
        Close()

    End Sub

End Class