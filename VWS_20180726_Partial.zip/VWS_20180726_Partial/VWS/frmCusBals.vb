﻿Public Class frmCusBals

    Private Sub btnSelCust_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelCust.Click

        Dim frmc As New frmPartySearch

        Dim cs As String

        cs = frmc.ShowDialog_PartySearch("", "", True, False)

        Me.txtCustcode.Text = cs

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

    Private Sub btnBalances_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBalances.Click

     
        
        ' hdg = "From: " & Me.dtpFrm.Value & "  To: " & Me.dtpTo.Value
        Dim s As String

        s = "SELECT CustCode, CustName, totAmtIn, totAmtOut, totAmtIn - totAmtOut AS CustBalance"
        s = s & " FROM (SELECT tblCustomers.CustCode, tblCustomers.CustName, SUM(tblCustPayments.AmtIN) AS totAmtIn, SUM(tblCustPayments.AmtOut) AS totAmtOut"
        s = s & " FROM tblCustPayments INNER JOIN"
        s = s & " tblCustomers ON dbo.tblCustPayments.CustCode = dbo.tblCustomers.CustCode"
        s = s & " where  tblCustPayments.CanFlag = 0 "
        s = s & " GROUP BY dbo.tblCustomers.CustCode, dbo.tblCustomers.CustName) AS tblA"
        s = s & " ORDER BY CustName"

        Dim arf As New List(Of String)
        Dim arh As New List(Of String)
        Dim art As New List(Of String)

        arf.Add("CustCode")
        arh.Add("CustCode")
        art.Add("s")

        arf.Add("CustName")
        arh.Add("CustName")
        art.Add("s")

        arf.Add("totAmtIn")
        arh.Add("Tot Amt In")
        art.Add("f")

        arf.Add("totAmtOut")
        arh.Add("Tot Amt Out")
        art.Add("f")

        arf.Add("CustBalance")
        arh.Add("Balance")
        art.Add("f")

        Dim hdgList As New List(Of String)


        Dim hdg As String
        hdg = ""        ' msPrepareHeader(hdgList)

        Dim sc As New List(Of String)
        Dim sf As New List(Of String)

        sc.Add("Total Amount In")
        sf.Add("totAmtIn")

        sc.Add("Total Amount Out")
        sf.Add("totAmtOut")

        sc.Add("Total Balance")
        sf.Add("CustBalance")

        Dim fm As New frmStatus
        fm.Show("Preparing report, Please wait ...")

        Dim dsr As New DataSet
        Dim w As String
        w = msFillDS(s, dsr)

        If IsNumeric(w) AndAlso w > "0" Then
            ' ok
        Else
            fm.Close()
            MsgBox("Error : " & w, MsgBoxStyle.Critical)
            Exit Sub
        End If

        If dsr.Tables.Count < 1 Then
            fm.Close()
            MsgBox("Error retrieving data", MsgBoxStyle.Critical)
            Exit Sub
        End If

        Dim fn As String
        fn = ""

        fn = msReturnBasicReport(dsr, arf, arh, art, "Customer Balance Summary", hdg, "", "Total Records", sc, sf, True, " ", 2, True)

        Dim frmRep As New frmReports

        'frmRep.MdiParent = mdiMS
        'frmRep.Show(fn)

        fm.Close()

        If My.Computer.FileSystem.FileExists(fn) Then

            frmRep.ShowDialog(fn, "Reports - " & mslv.ProjName)
        Else
            MsgBox("Error " & fn, MsgBoxStyle.Critical)
        End If


    End Sub

    Private Sub btnTrnDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTrnDetails.Click


        If txtCustcode.Text.Trim.Length < 4 Then

            MsgBox("Please enter or select a customer", MsgBoxStyle.Exclamation)
            Exit Sub

        End If

        Dim arf As New List(Of String)
        Dim arh As New List(Of String)
        Dim art As New List(Of String)

        arf.Add("EntryDatetime")
        arh.Add("EntryDatetime")
        art.Add("dt")

        arf.Add("AmtIN")
        arh.Add("AmtIN")
        art.Add("f")

        arf.Add("AmtOut")
        arh.Add("AmtOut")
        art.Add("f")

        arf.Add("AmtBal")
        arh.Add("AmtBal")
        art.Add("h")

        arf.Add("TicketNo")
        arh.Add("TicketNo")
        art.Add("s")

        Dim hdgList As New List(Of String)

        hdgList.Add("Cust Code")
        hdgList.Add(Me.txtCustcode.Text)

        Dim s As String
        Dim w As String
        w = mslCons.WebAuthcode

        s = msWebGetFieldValue("Select CustName from tblCustomers where CustCode = '" & Me.txtCustcode.Text & "' ", "CustName", w)

        hdgList.Add("Name")
        hdgList.Add(s)


        Dim hdg As String
        hdg = msPrepareHeader(hdgList)

        Dim sc As New List(Of String)
        Dim sf As New List(Of String)
        sc.Add("Total AmtIN")
        sf.Add("AmtIN")

        sc.Add("Total AmtOut")
        sf.Add("AmtOut")

        sc.Add("Balance")
        sf.Add("AmtBal")

        s = "select *, (amtIN - AmtOut) as AmtBal from tblCustPayments where CustCode = '" & Me.txtCustcode.Text & "' and CanFlag = 0 order by EntryDatetime"

        Dim fm As New frmStatus
        fm.Show("Preparing report, Please wait ...")

        Dim dsr As DataSet
        dsr = msWebGetDS(s, w)

        If dsr.Tables.Count < 1 Then
            fm.Close()
            MsgBox("Error retrieving data", MsgBoxStyle.Critical)
            Exit Sub
        End If

        Dim fn As String
        fn = ""

        fn = msReturnBasicReport(dsr, arf, arh, art, "Customer Credit Details", hdg, "", "Total Transactions", sc, sf, False, mslv.CompanyName, 1, True)

        Dim frmRep As New frmReports

        'frmRep.MdiParent = mdiMS
        'frmRep.ShowDialog(fn, "Reports - Vehical Weighing System")

        fm.Close()

        If My.Computer.FileSystem.FileExists(fn) Then

            frmRep.ShowDialog(fn, "Reports - Vehical Weighing System")
            Try
                My.Computer.FileSystem.DeleteFile(fn)
            Catch ex As Exception

            End Try
        Else
            MsgBox("Error " & fn, MsgBoxStyle.Critical)
        End If


    End Sub

    Private Sub btnTrnMoreDet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTrnMoreDet.Click

        If txtCustcode.Text.Trim.Length < 4 Then

            MsgBox("Please enter or select a customer", MsgBoxStyle.Exclamation)
            Exit Sub

        End If

        Dim arf As New List(Of String)
        Dim arh As New List(Of String)
        Dim art As New List(Of String)

        arf.Add("EntryDatetime")
        arh.Add("EntryDatetime")
        art.Add("dt")

        'arf.Add("AmtIN")
        'arh.Add("AmtIN")
        'art.Add("f")

        arf.Add("AmtOut")
        arh.Add("AmtOut")
        art.Add("f")

        'arf.Add("AmtBal")
        'arh.Add("AmtBal")
        'art.Add("f")

        arf.Add("TicketNo")
        arh.Add("TicketNo")
        art.Add("s")

        arf.Add("MatCode")
        arh.Add("MatCode")
        art.Add("s")

        arf.Add("MatName")
        arh.Add("MatName")
        art.Add("s")

        arf.Add("NWeight")
        arh.Add("NWeight")
        art.Add("n")

        Dim hdgList As New List(Of String)

        hdgList.Add("Cust Code")
        hdgList.Add(Me.txtCustcode.Text)

        Dim s As String
        Dim w As String
        w = mslCons.WebAuthcode

        s = msWebGetFieldValue("Select CustName from tblCustomers where CustCode = '" & Me.txtCustcode.Text & "' ", "CustName", w)

        hdgList.Add("Name")
        hdgList.Add(s)

        Dim hdg As String
        hdg = msPrepareHeader(hdgList)

        Dim sc As New List(Of String)
        Dim sf As New List(Of String)
        'sc.Add("Total AmtIN")
        'sf.Add("AmtIN")

        sc.Add("Total AmtOut")
        sf.Add("AmtOut")

        'sc.Add("Balance")
        'sf.Add("AmtBal")

        's = "select *, (amtIN - AmtOut) as AmtBal from tblCustPayments where CustCode = '" & Me.txtCustcode.Text & "' order by EntryDatetime"

        s = "SELECT tblCustPayments.EntryDatetime, tblCustomers.CustCode, tblCustomers.CustName, tblCustPayments.AmtIN, "
        s = s & " tblCustPayments.AmtOut, tblCustPayments.TicketNo, tblWeighing.MatCode, tblWeighing.MatName, "
        s = s & " tblWeighing.NWeight, tblWeighing.canflag FROM tblCustPayments INNER JOIN"
        s = s & " tblWeighing ON tblCustPayments.TicketNo = dbo.tblWeighing.TicketNo INNER JOIN "
        s = s & " tblCustomers ON tblCustPayments.CustCode = dbo.tblCustomers.CustCode"

        '  s = "Select *, (amtIN - AmtOut) as AmtBal from ( " & s & ") as tblA where CustCode = '" & Me.txtCustcode.Text & "' and CanFlag = 0  order by EntryDatetime"

        s = "Select * from ( " & s & ") as tblA where CustCode = '" & Me.txtCustcode.Text & "' and CanFlag = 0  order by EntryDatetime"

        Dim fm As New frmStatus
        fm.Show("Preparing report, Please wait ...")

        Dim dsr As DataSet
        dsr = msWebGetDS(s, w)

        If dsr.Tables.Count < 1 Then
            fm.Close()
            MsgBox("Error retrieving data", MsgBoxStyle.Critical)
            Exit Sub
        End If

        Dim fn As String
        fn = ""

        fn = msReturnBasicReport(dsr, arf, arh, art, "Customer Credit Details", hdg, "", "Total Transactions", sc, sf, False, mslv.CompanyName, 1, True)

        Dim frmRep As New frmReports

        'frmRep.MdiParent = mdiMS
        'frmRep.ShowDialog(fn, "Reports - Vehical Weighing System")

        fm.Close()

        If My.Computer.FileSystem.FileExists(fn) Then

            frmRep.ShowDialog(fn, "Reports - Vehical Weighing System")
            Try
                My.Computer.FileSystem.DeleteFile(fn)
            Catch ex As Exception

            End Try
        Else
            MsgBox("Error " & fn, MsgBoxStyle.Critical)
        End If


    End Sub
End Class