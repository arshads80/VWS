﻿Imports System.Data
Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports System.Drawing.Printing

Public Class frmCrysReport

    Dim rName As String
    Dim pName1 As String
    Dim pVal1 As String
    Dim pName2 As String
    Dim pVal2 As String
    Dim bShowExport As Boolean
    Dim prepSql As String

    Dim dsReport As DataSet

    Dim cr As New ReportDocument        ' required here to print report

    Public Sub Showdialog_frmCryReport(ByRef dsCrRep As DataSet, ByVal repName As String, Optional ByVal ParamName1 As String = "", Optional ByVal ParamValue1 As String = "", Optional ByVal ParamName2 As String = "", Optional ByVal ParamValue2 As String = "", Optional ByVal bprmShowExport As Boolean = False, Optional ByVal repSql As String = "")

        dsReport = dsCrRep

        rName = repName

        pName1 = ParamName1
        pName2 = ParamName2
        pVal1 = ParamValue1
        pVal2 = ParamValue2

        bShowExport = bprmShowExport

        prepSql = repSql

        ShowDialog()

    End Sub

    Public Sub Show_frmCryReport(ByRef dsCrRep As DataSet, ByVal repName As String, Optional ByVal ParamName1 As String = "", Optional ByVal ParamValue1 As String = "", Optional ByVal ParamName2 As String = "", Optional ByVal ParamValue2 As String = "", Optional ByVal bprmShowExport As Boolean = False, Optional ByVal repSql As String = "")

        dsReport = dsCrRep

        rName = repName

        pName1 = ParamName1
        pName2 = ParamName2
        pVal1 = ParamValue1
        pVal2 = ParamValue2

        bShowExport = bprmShowExport

        prepSql = repSql

        Me.WindowState = FormWindowState.Normal

        Show()

    End Sub

    Private Sub frmCrysReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.Text = mslv.ProjName

        Dim prtdoc As New PrintDocument
        '  Dim strDefP As String = prtdoc.PrinterSettings.PrinterName

        Dim strP As String
        For Each strP In Printing.PrinterSettings.InstalledPrinters
            Me.cmbPrinters.Items.Add(strP)
            'If Sysvars.wtType = 2 Then
            '    If InStr(strP, "IN") > 0 Then
            '        Me.cmbPrinters.SelectedIndex = Me.cmbPrinters.Items.IndexOf(strP)
            '    End If
            'Else
            If InStr(strP, "OUT") > 0 Then
                Me.cmbPrinters.SelectedIndex = Me.cmbPrinters.Items.IndexOf(strP)
            End If
            'End If
        Next


        If cmbPrinters.Items.Count > 0 Then
            If Me.cmbPrinters.SelectedIndex < 0 Then
                Me.cmbPrinters.SelectedIndex = 0
            End If
        End If


        LoadReportFromDS()
        
        If prepSql.Length > 15 Then
            Me.btnReload.Visible = True
        End If

    End Sub

    Private Sub LoadReportFromDS()

        Dim frmS As New frmStatus
        frmS.Show("Opening Report ... ")

        Try

            ' report path

            ' If Not IO.File.Exists(rName) Then
            If My.Computer.FileSystem.FileExists(rName) Then
                'ok
            Else

                'Throw (New Exception("Unable to locate report file:" & vbCrLf & repPath))
                MsgBox("report file not found")
                frmS.Close()
                Exit Sub

            End If



            cr.Load(rName)
            cr.SetDataSource(dsReport.Tables(0))
            'cr.SetDataSource(dS)

            '''''' set parameters
            If pName1 <> "" Then
                cr.SetParameterValue(pName1, pVal1)
            End If

            If pName2 <> "" Then
                cr.SetParameterValue(pName2, pVal2)
            End If

            With CrystalReportViewer1
                .ShowRefreshButton = False
                .ShowCloseButton = True
                .ShowGroupTreeButton = True
                .ShowExportButton = False
                .ShowGotoPageButton = True
                .ShowPrintButton = True
                .ShowTextSearchButton = True
                .ShowExportButton = bShowExport

                '.ShowGroupTree 
                '.DisplayGroupTree = False
                '.ShowGroupTree()

                .ReportSource = cr

            End With

        Catch ex As Exception
            MsgBox("Report Opening Err: " & ex.Message, MsgBoxStyle.Critical)

        End Try

        frmS.Close()


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()

    End Sub

    Private Sub btnReload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReload.Click

        Dim w As String
        w = mslCons.WebAuthcode

        dsReport.Clear()

        dsReport = New DataSet

        dsReport = msWebGetDS(prepSql, w)

        If IsNumeric(w) Or w = mslCons.WebAuthcode Then
            'ok
        Else
            MsgBox("Error 160626 " & w, MsgBoxStyle.Critical)
            Exit Sub
        End If

        If dsReport.Tables.Count < 0 Then
            MsgBox("unable to retrieve data", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If dsReport.Tables(0).Rows.Count < 0 Then
            MsgBox("Record not found", MsgBoxStyle.Exclamation)
        End If

        LoadReportFromDS()

    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click

        'CrystalReportViewer1.PrintReport()
        cr.PrintOptions.PrinterName = Me.cmbPrinters.Items(Me.cmbPrinters.SelectedIndex).ToString
        cr.PrintToPrinter(1, False, 1, 99)

    End Sub


End Class