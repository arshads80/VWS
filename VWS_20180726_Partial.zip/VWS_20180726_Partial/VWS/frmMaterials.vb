﻿Public Class frmMaterials

    Private FormMode As FormModes

    Dim curRecNo As Integer

    
    'Dim pOpenfTime As Boolean
    'Dim popProcess As Boolean

    Private Sub frmMaterials_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '  pOpenfTime = True

        '       popProcess = False

        If arUserAccess(enUAcs.Edit_Material) = 1 Then
            Me.bnEdit.Visible = True
        Else
            Me.bnEdit.Visible = False
        End If

        If arUserAccess(enUAcs.Delete_Material) = "1" Then
            Me.bnDeleteItem.Visible = True
        Else
            Me.bnDeleteItem.Visible = False
        End If

        Dim alist As New AutoCompleteStringCollection
        Dim sSql As String
        sSql = "Select MatName from tblMaterials where MatDisable = 0 order by MatID DESC"
        alist = msPopulateAutoCompleteListDS(sSql, 3000, 1)
        txtMatName.AutoCompleteCustomSource = alist

        DisableEdits()
        Populategrid()

    End Sub

    Private Sub msWriteLM(ByVal LmData As String, Optional ByVal rgbh As String = "0")

        Dim obj As Control
        obj = Me.txtLM

        If TypeOf obj Is TextBox Then
            If CType(obj, TextBox).Multiline Then
                Me.txtLM.Text = LmData & vbCrLf & Me.txtLM.Text
            Else
                Me.txtLM.Text = LmData
            End If

        Else
            Me.txtLM.Text = LmData
        End If

        'msDoEvents()

        Dim pColor As Color
        Select Case rgbh.ToLower
            Case "r"
                pColor = Color.Crimson
            Case "b"    ' blue
                pColor = Color.Blue
            Case "g"
                pColor = Color.Green
            Case "h"  ' highlight
                pColor = Color.DarkBlue
            Case Else
                pColor = Color.Black
        End Select


        txtLM.ForeColor = pColor

        If rgbh = "h" Then
            txtLM.BackColor = Color.Yellow
        Else
            txtLM.BackColor = Color.WhiteSmoke
        End If

    End Sub


    Private Sub DisableEdits()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls    ' Me.pnlMatMaster.Controls
            If TypeOf ctr Is TextBox Then
                CType(ctr, TextBox).ReadOnly = True
                CType(ctr, TextBox).Text = Trim(ctr.Text)
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Enabled = False
            ElseIf TypeOf ctr Is ComboBox Then
                CType(ctr, ComboBox).Enabled = False
            End If
        Next

        ' disable navigation controls

        Me.GroupBoxSearch.Enabled = True
        Me.DataGridView1.Enabled = True
        Me.bnMoveFirstItem.Enabled = True
        Me.txtSearch.ReadOnly = False

        Me.bnMoveFirstItem.Enabled = True
        Me.bnMovePreviousItem.Enabled = True
        Me.bnMoveNextItem.Enabled = True
        Me.bnMoveLastItem.Enabled = True
        Me.bnAddNewItem.Enabled = True
        Me.bnCancel.Enabled = False
        Me.bnDeleteItem.Enabled = True
        Me.bnEdit.Enabled = True
        Me.bnRefresh.Enabled = True
        Me.bnSave.Enabled = False

        FormMode = FormModes.SearchMode


    End Sub

    Private Sub EnableEdits()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls
            If TypeOf ctr Is TextBox Then
                CType(ctr, TextBox).ReadOnly = False
                CType(ctr, TextBox).Text = Trim(ctr.Text)
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Enabled = True
            ElseIf TypeOf ctr Is ComboBox Then
                CType(ctr, ComboBox).Enabled = True
            End If
        Next

        ' disable navigation controls

        Me.GroupBoxSearch.Enabled = False
        Me.DataGridView1.Enabled = False
        Me.bnMoveFirstItem.Enabled = False
        Me.txtSearch.ReadOnly = True

        Me.bnMoveFirstItem.Enabled = False
        Me.bnMovePreviousItem.Enabled = False
        Me.bnMoveNextItem.Enabled = False
        Me.bnMoveLastItem.Enabled = False
        Me.bnAddNewItem.Enabled = False
        Me.bnCancel.Enabled = True
        Me.bnDeleteItem.Enabled = False
        Me.bnEdit.Enabled = False
        Me.bnRefresh.Enabled = False
        Me.bnSave.Enabled = True

        Me.txtDisable.ReadOnly = True
        Me.txtScrapFlag.ReadOnly = True

    End Sub


    Private Sub ClearForm()

        Dim ctr As System.Windows.Forms.Control
        For Each ctr In Controls
            If TypeOf ctr Is TextBox Then
                ctr.Text = ""
            ElseIf TypeOf ctr Is CheckBox Then
                CType(ctr, CheckBox).Checked = False
            End If
        Next

        Me.txtScrapFlag.Text = 0
        Me.txtDisable.Text = "N"

    End Sub

    Private Sub PopulateGrid()

        Dim webEr As String
        Dim s As String
        Dim ser As String
        Dim wh As String
        wh = ""

        If Me.txtSearch.Text.Trim <> "" Then
            ser = Me.txtSearch.Text.Trim
            ser = ser.Replace(" ", "% ")
            wh = wh & " MatName Like '%" & ser & "%'"
            wh = wh & " or MatCode = '" & ser & "'"

        End If

        webEr = ""

        s = "Select top 100 * from tblMaterials where MatID > 0 "   ' and ActiveProduct = 'Y'"

        If wh <> "" Then
            s = s & " and (" & wh & ")"
            s = s & " order by MatDisable, MatName "
        Else
            s = s & " order by MatDisable, LastUpdateAt DESC"
        End If

        Dim ds As New DataSet
        Dim a As String
        a = mslCons.WebAuthCode
        Try

            ds = msWebGetDS(s, a)

            If a = mslCons.WebAuthCode Or IsNumeric(a) Then
                Dim f As Font
                f = New Font("Verdana", 8, FontStyle.Regular, GraphicsUnit.Point)

                DataGridView1.Font = f

                DataGridView1.DataSource = ds
                DataGridView1.DataMember = ds.Tables(0).TableName

                'If pOpenfTime Then
                '    Dim i As Integer
                '    For i = 0 To DataGridView1.Columns.Count - 1
                '        DataGridView1.Columns(i).Visible = False
                '    Next
                '    DataGridView1.Columns("ProdID").Visible = True
                '    DataGridView1.Columns("ProdCode").Visible = True
                '    DataGridView1.Columns("ProductName").Visible = True
                '    pOpenfTime = False
                'End If

                DataGridView1.AutoResizeColumns()

                Me.bnCountItem.Text = "of " & DataGridView1.RowCount


            Else

                MsgBox("error 150206 " & a, MsgBoxStyle.Critical)

            End If

        Catch ex As Exception
            MsgBox("Error: 150409 " & "Populate Grid " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Function FormNotValid() As Boolean

        FormNotValid = True

        If Me.txtMatName.Text = "" Then
            msWriteLM("Enter Material Name!", "r")
            Me.txtMatName.Focus()
            Exit Function
        End If

        If Not IsNumeric(Me.txtPriceA.Text) Then
            Me.txtPriceA.Text = 0
        End If

        If Not IsNumeric(Me.txtPriceB.Text) Then
            Me.txtPriceB.Text = 0
        End If

        If Not IsNumeric(Me.txtPriceC.Text) Then
            Me.txtPriceC.Text = 0
        End If

        If Not IsNumeric(Me.txtPriceD.Text) Then
            Me.txtPriceD.Text = 0
        End If

        If Not IsNumeric(Me.txtPriceE.Text) Then
            Me.txtPriceE.Text = 0
        End If


        FormNotValid = False


    End Function

    Private Sub txtSearch_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown

        If e.KeyCode = Keys.Down Then
            Me.DataGridView1.Focus()
        End If

    End Sub


    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        PopulateGrid()

    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSearch.TextChanged

        If Me.txtSearch.Text = "" Or Me.txtSearch.Text.Length > 2 Then
            PopulateGrid()
        End If

    End Sub


    Private Sub PopulateForm()

        If Me.DataGridView1.RowCount <= 0 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        Dim enm As String
        'enm = DataGridView1.CurrentRow.Cells("MatCode").Value

        'If Me.txtMatCode.Text = enm Then Exit Sub ' same record no need to update

        enm = DataGridView1.CurrentRow.Cells("MatID").Value

        If Not IsNumeric(enm) Then Exit Sub

        Dim s As String
        s = "Select * from tblMaterials where MatID = " & Val(enm)

        Dim ds As DataSet
        
        Try

            ds = msWebGetDsFt(s)

            If ds.Tables.Count < 1 Then Exit Sub
            If ds.Tables(0).Rows.Count < 1 Then Exit Sub


            Dim dr As DataRow
            dr = ds.Tables(0).Rows(0)

            Me.txtMatName.Text = dr("MatName")
            Me.txtMatCode.Text = dr("MatCode")

            Me.txtPriceA.Text = dr("PriceA")
            Me.txtPriceB.Text = dr("PriceB")
            Me.txtPriceC.Text = dr("PriceC")
            Me.txtPriceD.Text = dr("PriceD")
            Me.txtPriceE.Text = dr("PriceE")
            Me.txtDisable.Text = dr("MatDisable")
            Me.txtScrapFlag.Text = dr("Scrapflag")

            Me.bnPositionItem.Text = DataGridView1.CurrentRow.Index + 1


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)

        End Try
        
    End Sub

    Private Sub DataGridView1_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEnter

        If DataGridView1.RowCount < 1 Then Exit Sub

        If DataGridView1.CurrentRow Is Nothing Then Exit Sub
        '  If popProcess Then Exit Sub

        PopulateForm()

    End Sub


    Private Sub bnAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnAddNewItem.Click

        FormMode = FormModes.AddMode
        EnableEdits()
        ClearForm()
        Me.txtDisable.Text = 0
        Me.txtMatName.Focus()


    End Sub

    Private Sub bnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnEdit.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        FormMode = FormModes.EditMode
        EnableEdits()

        Me.txtMatName.Focus()

    End Sub

    Private Sub bnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnCancel.Click

        DisableEdits()
        PopulateForm()

    End Sub


    Private Sub bnDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnDeleteItem.Click

        If FormMode = FormModes.NormalMode Or FormMode = FormModes.SearchMode Then
            ' ok
        Else
            Exit Sub
        End If

        If Me.DataGridView1.RowCount < 1 Then Exit Sub

        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        If Me.DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("Select a record to edit ....", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim envnum As String
        envnum = DataGridView1.CurrentRow.Cells("MatCode").Value

        If MsgBox("Are you sure you want to delete selected record from the database" & vbCrLf & "Material Code: " & envnum, MsgBoxStyle.DefaultButton2 + MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim ds As DataSet
        Dim ww As String
        Try
            ww = mslCons.WebAuthCode
            ds = msWebGetDS("Select top 1 TicketNo from tblWeighing where MatCode = '" & envnum & "'", ww)
            If ds.Tables(0).Rows.Count > 0 Then
                MsgBox("There are transactions for this Material" & vbCrLf & "Record can not be deleted", MsgBoxStyle.Exclamation)
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox("Error 150404 : " & ex.Message & vbCrLf & "Record can not be deleted", MsgBoxStyle.Critical)
            Exit Sub
        End Try

        Dim s As String
        s = "Delete from tblMaterials where MatCode = '" & envnum & "'"

        Dim a As String
        Dim w As String
        w = mslCons.WebAuthCode

        a = msWebProcessCommand(s, w)

        If IsNumeric(a) Then

            'MsgBox(a & " records deleted", MsgBoxStyle.Exclamation)
            msWriteLM(a & " record/s deleted", "r")
            PopulateGrid()

        Else
            MsgBox("Error " & vbCrLf & a, MsgBoxStyle.Critical)

        End If


    End Sub


    Private Sub bnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnSave.Click

        If FormNotValid() Then Exit Sub


        '''''''  using update statment
        Dim ArF As New List(Of String)
        Dim ArV As New List(Of String)
        Dim ArT As New List(Of String)

        ' following is required for multiple table updates or update in loop
        ArF.Clear()
        ArV.Clear()
        ArT.Clear()
        '==================================


        If FormMode = FormModes.AddMode Then
            ArF.Add("Matcode")
            If Me.txtMatCode.Text = "" Then
                Me.txtMatCode.Text = getNewMatCode(Me.txtMatName.Text)
            End If
            ArV.Add(Me.txtMatCode.Text.ToUpper)
            ArT.Add("s")  ' or S

        End If

        '=============================


        ArF.Add("LastUpdateAt")
        ArV.Add("server time")             ' Format(Date.Now, "yyyy-MM-dd HH:mm"))
        ArT.Add("st")    ' st server time


        ArF.Add("MatName")
        ArV.Add(txtMatName.Text.ToUpper)
        ArT.Add("s")

        ArF.Add("PriceA")
        ArV.Add(Me.txtPriceA.Text)
        ArT.Add("n")

        ArF.Add("PriceB")
        ArV.Add(Me.txtPriceB.Text)
        ArT.Add("n")

        ArF.Add("PriceC")
        ArV.Add(Me.txtPriceC.Text)
        ArT.Add("n")

        ArF.Add("PriceD")
        ArV.Add(Me.txtPriceD.Text)
        ArT.Add("n")

        ArF.Add("PriceE")
        ArV.Add(Me.txtPriceE.Text)
        ArT.Add("n")

        ArF.Add("MatDisable")
        ArV.Add(Me.txtDisable.Text)
        ArT.Add("n")

        ArF.Add("Scrapflag")
        ArV.Add(Me.txtScrapFlag.Text)
        ArT.Add("n")



        ArF.Add("SyncFlag")
        If FormMode = FormModes.EditMode Then
            ArV.Add("2")
        Else
            ArV.Add("1")        ' addmode  1    record synced = 0 
        End If
        ArT.Add("n")


        Dim ww As String
        ww = mslCons.WebAuthcode

        '=============================

        Dim a As String

        Try
            Me.bnSave.Enabled = False
            'a = msrv.getlictoolcode(arF.ToArray, arV.ToArray, arT.ToArray, arH.ToArray, Me.txtEmail.Text)
            If FormMode = FormModes.EditMode Then
                Dim wcls As String


                wcls = "MatID = " & Me.DataGridView1.CurrentRow.Cells("MatID").Value

                a = msWebUpdateArrayListInDB("tblMaterials", ArF.ToArray, ArV.ToArray, ArT.ToArray, wcls, ww)
                If IsNumeric(a) Then
                    MsgBox(a & " Record/s updated", MsgBoxStyle.Information)
                End If

            Else
                a = msWebInsertRecIntoDb("tblMaterials", ArF.ToArray, ArV.ToArray, ArT.ToArray, ww)
            End If

            If a <> "1" Then
                MsgBox("Error 508112 unable to save Material" & vbCrLf & a, MsgBoxStyle.Critical)
                Me.bnSave.Enabled = True
                Exit Sub
            End If

            If FormMode = FormModes.AddMode Then

                Me.txtSearch.Text = ""

            End If

            'ClearForm()

            PopulateGrid()

            If FormMode = FormModes.EditMode Then

                If curRecNo < DataGridView1.RowCount Then
                    'DataGridView1.Rows(curRecNo).Selected = True
                    DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
                End If

            End If

            DisableEdits()


        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical)

            Exit Sub

        End Try


    End Sub

    Private Function getNewMatCode(ByVal mname As String) As String

        getNewMatCode = ""

        Dim fc As String    ' first char
        Dim s As String
        fc = UCase(Mid(mname, 1, 1))

        If fc < "A" Or fc > "Z" Then
            fc = "#"
        End If

        Dim l As Long
        Dim sStr As String
        sStr = "select Alpha, pnum from tblNextCode where Alpha = '" & fc & "'"

        Dim ds As DataSet

        Dim ww As String

        Try

            ww = mslCons.WebAuthCode
            ds = msWebGetDS(sStr, ww)

            Dim dr As DataRow

            dr = ds.Tables(0).Rows(0)

            '------------
            If dr IsNot Nothing Then
                l = CLng(dr("pnum"))
                l = l + 1
                If fc = "#" Then
                    If l < 10000 Then
                        s = msStr(CStr(l), 4)
                    Else
                        s = l
                    End If
                Else
                    If l < 1000 Then
                        s = fc & msStr(CStr(l), 3)
                    Else
                        s = fc & l
                    End If
                End If
                
                s = mslv.WeighingSiteCode & s

                ww = mslCons.WebAuthCode

                sStr = "Update tblnextcode set pnum = " & l & " where Alpha = '" & fc & "'"

                Dim a As String
                a = msWebProcessCommand(sStr, ww)

                If IsNumeric(a) Then
                    If Val(a) > 0 Then
                        getNewMatCode = s
                    Else
                        MsgBox("Can not update next product code", MsgBoxStyle.Critical, "Update Error")
                    End If

                End If

            End If
            ';--------------

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try


    End Function


    Private Sub bnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnClose.Click

        Me.Close()

    End Sub

    Private Sub txtDisable_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDisable.DoubleClick

        'If FormMode = FormModes.AddMode Or FormMode = FormModes.EditMode Then
        '    If arUserAccess(enUAcs.Disable_Material) = 1 Then
        '        If Me.txtDisable.Text = "0" Then
        '            Me.txtDisable.Text = "1"
        '        Else
        '            Me.txtDisable.Text = "0"
        '        End If
        '    End If
        'End If

    End Sub

    Private Sub txtScrapFlag_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtScrapFlag.DoubleClick

        If FormMode = FormModes.AddMode Or FormMode = FormModes.EditMode Then
            If Me.txtScrapFlag.Text = "0" Then
                Me.txtScrapFlag.Text = "1"
            Else
                Me.txtScrapFlag.Text = "0"
            End If
        End If


    End Sub

    Private Sub bnMoveNextItem_Click(sender As Object, e As EventArgs) Handles bnMoveNextItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        If curRecNo < DataGridView1.RowCount - 1 Then
            curRecNo = curRecNo + 1
            DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
        End If

    End Sub


    Private Sub bnMoveLastItem_Click(sender As Object, e As EventArgs) Handles bnMoveLastItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub

        curRecNo = DataGridView1.RowCount - 1
        DataGridView1.CurrentCell = DataGridView1(0, curRecNo)

    End Sub

    Private Sub bnMovePreviousItem_Click(sender As Object, e As EventArgs) Handles bnMovePreviousItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        If DataGridView1.CurrentRow Is Nothing Then Exit Sub

        curRecNo = DataGridView1.CurrentRow.Index

        If curRecNo > 0 Then
            curRecNo = curRecNo - 1
            DataGridView1.CurrentCell = DataGridView1(0, curRecNo)
        End If


    End Sub

    Private Sub bnMoveFirstItem_Click(sender As Object, e As EventArgs) Handles bnMoveFirstItem.Click

        If DataGridView1.RowCount < 1 Then Exit Sub
        curRecNo = 0
        DataGridView1.CurrentCell = DataGridView1(0, curRecNo)

    End Sub

End Class