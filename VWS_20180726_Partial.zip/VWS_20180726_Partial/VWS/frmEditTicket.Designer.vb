﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEditTicket
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlWeighentry = New System.Windows.Forms.Panel
        Me.txtTicketNo = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.cmbRemark = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.lblCustType = New System.Windows.Forms.Label
        Me.txtLM = New System.Windows.Forms.Label
        Me.btnCancel = New System.Windows.Forms.Button
        Me.btnSave = New System.Windows.Forms.Button
        Me.txtRemark = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtDlvOrder = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.lblSiteName = New System.Windows.Forms.Label
        Me.txtSiteCode = New System.Windows.Forms.TextBox
        Me.btnSelSite = New System.Windows.Forms.Button
        Me.lblLocName = New System.Windows.Forms.Label
        Me.txtLocCode = New System.Windows.Forms.TextBox
        Me.btnSelLoc = New System.Windows.Forms.Button
        Me.lblSouName = New System.Windows.Forms.Label
        Me.txtSouCode = New System.Windows.Forms.TextBox
        Me.btnSelSource = New System.Windows.Forms.Button
        Me.lblMatName = New System.Windows.Forms.Label
        Me.txtMatCode = New System.Windows.Forms.TextBox
        Me.btnSelMat = New System.Windows.Forms.Button
        Me.lblCustName = New System.Windows.Forms.Label
        Me.txtCustcode = New System.Windows.Forms.TextBox
        Me.btnSelCust = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.rbOut = New System.Windows.Forms.RadioButton
        Me.rbIn = New System.Windows.Forms.RadioButton
        Me.txtMobile = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtDriver = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblVehical = New System.Windows.Forms.Label
        Me.txtVehCode = New System.Windows.Forms.TextBox
        Me.btnSelVeh = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lbltobeNet = New System.Windows.Forms.Label
        Me.lblManualTare = New System.Windows.Forms.Label
        Me.btnWB2 = New System.Windows.Forms.Button
        Me.btnWB1 = New System.Windows.Forms.Button
        Me.txtNwt = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtSwt = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtFwt = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.pnlInfo = New System.Windows.Forms.Panel
        Me.lblRate = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.btnClose = New System.Windows.Forms.Button
        Me.lblAmount = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.lblBalance = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.lblCustGroup = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.lblPrePaidCust = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.pnlWeighentry.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.pnlInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlWeighentry
        '
        Me.pnlWeighentry.BackColor = System.Drawing.Color.Tan
        Me.pnlWeighentry.Controls.Add(Me.txtTicketNo)
        Me.pnlWeighentry.Controls.Add(Me.Label8)
        Me.pnlWeighentry.Controls.Add(Me.cmbRemark)
        Me.pnlWeighentry.Controls.Add(Me.Label3)
        Me.pnlWeighentry.Controls.Add(Me.lblCustType)
        Me.pnlWeighentry.Controls.Add(Me.txtLM)
        Me.pnlWeighentry.Controls.Add(Me.btnCancel)
        Me.pnlWeighentry.Controls.Add(Me.btnSave)
        Me.pnlWeighentry.Controls.Add(Me.txtRemark)
        Me.pnlWeighentry.Controls.Add(Me.Label14)
        Me.pnlWeighentry.Controls.Add(Me.txtDlvOrder)
        Me.pnlWeighentry.Controls.Add(Me.Label13)
        Me.pnlWeighentry.Controls.Add(Me.lblSiteName)
        Me.pnlWeighentry.Controls.Add(Me.txtSiteCode)
        Me.pnlWeighentry.Controls.Add(Me.btnSelSite)
        Me.pnlWeighentry.Controls.Add(Me.lblLocName)
        Me.pnlWeighentry.Controls.Add(Me.txtLocCode)
        Me.pnlWeighentry.Controls.Add(Me.btnSelLoc)
        Me.pnlWeighentry.Controls.Add(Me.lblSouName)
        Me.pnlWeighentry.Controls.Add(Me.txtSouCode)
        Me.pnlWeighentry.Controls.Add(Me.btnSelSource)
        Me.pnlWeighentry.Controls.Add(Me.lblMatName)
        Me.pnlWeighentry.Controls.Add(Me.txtMatCode)
        Me.pnlWeighentry.Controls.Add(Me.btnSelMat)
        Me.pnlWeighentry.Controls.Add(Me.lblCustName)
        Me.pnlWeighentry.Controls.Add(Me.txtCustcode)
        Me.pnlWeighentry.Controls.Add(Me.btnSelCust)
        Me.pnlWeighentry.Controls.Add(Me.Label4)
        Me.pnlWeighentry.Controls.Add(Me.GroupBox1)
        Me.pnlWeighentry.Controls.Add(Me.txtMobile)
        Me.pnlWeighentry.Controls.Add(Me.Label2)
        Me.pnlWeighentry.Controls.Add(Me.txtDriver)
        Me.pnlWeighentry.Controls.Add(Me.Label1)
        Me.pnlWeighentry.Controls.Add(Me.lblVehical)
        Me.pnlWeighentry.Controls.Add(Me.txtVehCode)
        Me.pnlWeighentry.Controls.Add(Me.btnSelVeh)
        Me.pnlWeighentry.Controls.Add(Me.GroupBox2)
        Me.pnlWeighentry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlWeighentry.Location = New System.Drawing.Point(0, 0)
        Me.pnlWeighentry.Name = "pnlWeighentry"
        Me.pnlWeighentry.Size = New System.Drawing.Size(841, 591)
        Me.pnlWeighentry.TabIndex = 73
        '
        'txtTicketNo
        '
        Me.txtTicketNo.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTicketNo.Location = New System.Drawing.Point(118, 134)
        Me.txtTicketNo.MaxLength = 20
        Me.txtTicketNo.Name = "txtTicketNo"
        Me.txtTicketNo.Size = New System.Drawing.Size(99, 23)
        Me.txtTicketNo.TabIndex = 79
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(36, 138)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(66, 16)
        Me.Label8.TabIndex = 78
        Me.Label8.Text = "Ticket No"
        '
        'cmbRemark
        '
        Me.cmbRemark.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRemark.FormattingEnabled = True
        Me.cmbRemark.Location = New System.Drawing.Point(159, 544)
        Me.cmbRemark.Name = "cmbRemark"
        Me.cmbRemark.Size = New System.Drawing.Size(282, 24)
        Me.cmbRemark.TabIndex = 77
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 547)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 16)
        Me.Label3.TabIndex = 76
        Me.Label3.Text = "Reason to Modify"
        '
        'lblCustType
        '
        Me.lblCustType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCustType.Location = New System.Drawing.Point(790, 301)
        Me.lblCustType.Name = "lblCustType"
        Me.lblCustType.Size = New System.Drawing.Size(22, 27)
        Me.lblCustType.TabIndex = 75
        Me.lblCustType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtLM
        '
        Me.txtLM.BackColor = System.Drawing.Color.Transparent
        Me.txtLM.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLM.ForeColor = System.Drawing.Color.DarkViolet
        Me.txtLM.Location = New System.Drawing.Point(30, 27)
        Me.txtLM.Name = "txtLM"
        Me.txtLM.Size = New System.Drawing.Size(299, 82)
        Me.txtLM.TabIndex = 74
        Me.txtLM.Text = "Weighing - Edit Ticket"
        Me.txtLM.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(702, 524)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(107, 42)
        Me.btnCancel.TabIndex = 73
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(555, 524)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(107, 42)
        Me.btnSave.TabIndex = 72
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'txtRemark
        '
        Me.txtRemark.Location = New System.Drawing.Point(159, 516)
        Me.txtRemark.MaxLength = 30
        Me.txtRemark.Name = "txtRemark"
        Me.txtRemark.Size = New System.Drawing.Size(352, 23)
        Me.txtRemark.TabIndex = 71
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(32, 518)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(52, 16)
        Me.Label14.TabIndex = 70
        Me.Label14.Text = "Remark"
        '
        'txtDlvOrder
        '
        Me.txtDlvOrder.Location = New System.Drawing.Point(159, 485)
        Me.txtDlvOrder.MaxLength = 30
        Me.txtDlvOrder.Name = "txtDlvOrder"
        Me.txtDlvOrder.Size = New System.Drawing.Size(352, 23)
        Me.txtDlvOrder.TabIndex = 69
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(32, 488)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 16)
        Me.Label13.TabIndex = 68
        Me.Label13.Text = "Delivery Order"
        '
        'lblSiteName
        '
        Me.lblSiteName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSiteName.Location = New System.Drawing.Point(434, 444)
        Me.lblSiteName.Name = "lblSiteName"
        Me.lblSiteName.Size = New System.Drawing.Size(375, 27)
        Me.lblSiteName.TabIndex = 65
        Me.lblSiteName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtSiteCode
        '
        Me.txtSiteCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtSiteCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSiteCode.Location = New System.Drawing.Point(284, 444)
        Me.txtSiteCode.MaxLength = 10
        Me.txtSiteCode.Name = "txtSiteCode"
        Me.txtSiteCode.ReadOnly = True
        Me.txtSiteCode.Size = New System.Drawing.Size(144, 23)
        Me.txtSiteCode.TabIndex = 64
        '
        'btnSelSite
        '
        Me.btnSelSite.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSelSite.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSelSite.Location = New System.Drawing.Point(35, 444)
        Me.btnSelSite.Name = "btnSelSite"
        Me.btnSelSite.Size = New System.Drawing.Size(237, 27)
        Me.btnSelSite.TabIndex = 63
        Me.btnSelSite.Text = "Site"
        '
        'lblLocName
        '
        Me.lblLocName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblLocName.Location = New System.Drawing.Point(434, 409)
        Me.lblLocName.Name = "lblLocName"
        Me.lblLocName.Size = New System.Drawing.Size(375, 27)
        Me.lblLocName.TabIndex = 62
        Me.lblLocName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtLocCode
        '
        Me.txtLocCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtLocCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtLocCode.Location = New System.Drawing.Point(284, 409)
        Me.txtLocCode.MaxLength = 10
        Me.txtLocCode.Name = "txtLocCode"
        Me.txtLocCode.ReadOnly = True
        Me.txtLocCode.Size = New System.Drawing.Size(144, 23)
        Me.txtLocCode.TabIndex = 61
        '
        'btnSelLoc
        '
        Me.btnSelLoc.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSelLoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSelLoc.Location = New System.Drawing.Point(35, 409)
        Me.btnSelLoc.Name = "btnSelLoc"
        Me.btnSelLoc.Size = New System.Drawing.Size(237, 27)
        Me.btnSelLoc.TabIndex = 60
        Me.btnSelLoc.Text = "Location / Destination"
        '
        'lblSouName
        '
        Me.lblSouName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSouName.Location = New System.Drawing.Point(434, 374)
        Me.lblSouName.Name = "lblSouName"
        Me.lblSouName.Size = New System.Drawing.Size(375, 27)
        Me.lblSouName.TabIndex = 59
        Me.lblSouName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtSouCode
        '
        Me.txtSouCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtSouCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSouCode.Location = New System.Drawing.Point(284, 374)
        Me.txtSouCode.MaxLength = 10
        Me.txtSouCode.Name = "txtSouCode"
        Me.txtSouCode.ReadOnly = True
        Me.txtSouCode.Size = New System.Drawing.Size(144, 23)
        Me.txtSouCode.TabIndex = 58
        '
        'btnSelSource
        '
        Me.btnSelSource.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSelSource.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSelSource.Location = New System.Drawing.Point(35, 374)
        Me.btnSelSource.Name = "btnSelSource"
        Me.btnSelSource.Size = New System.Drawing.Size(237, 27)
        Me.btnSelSource.TabIndex = 57
        Me.btnSelSource.Text = "Source / Transporter"
        '
        'lblMatName
        '
        Me.lblMatName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMatName.Location = New System.Drawing.Point(434, 339)
        Me.lblMatName.Name = "lblMatName"
        Me.lblMatName.Size = New System.Drawing.Size(375, 27)
        Me.lblMatName.TabIndex = 56
        Me.lblMatName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtMatCode
        '
        Me.txtMatCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtMatCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtMatCode.Location = New System.Drawing.Point(284, 339)
        Me.txtMatCode.MaxLength = 10
        Me.txtMatCode.Name = "txtMatCode"
        Me.txtMatCode.ReadOnly = True
        Me.txtMatCode.Size = New System.Drawing.Size(144, 23)
        Me.txtMatCode.TabIndex = 55
        '
        'btnSelMat
        '
        Me.btnSelMat.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSelMat.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSelMat.Location = New System.Drawing.Point(35, 339)
        Me.btnSelMat.Name = "btnSelMat"
        Me.btnSelMat.Size = New System.Drawing.Size(237, 27)
        Me.btnSelMat.TabIndex = 54
        Me.btnSelMat.Text = "Material"
        '
        'lblCustName
        '
        Me.lblCustName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCustName.Location = New System.Drawing.Point(434, 301)
        Me.lblCustName.Name = "lblCustName"
        Me.lblCustName.Size = New System.Drawing.Size(350, 27)
        Me.lblCustName.TabIndex = 53
        Me.lblCustName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCustcode
        '
        Me.txtCustcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtCustcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtCustcode.Location = New System.Drawing.Point(284, 301)
        Me.txtCustcode.MaxLength = 10
        Me.txtCustcode.Name = "txtCustcode"
        Me.txtCustcode.ReadOnly = True
        Me.txtCustcode.Size = New System.Drawing.Size(144, 23)
        Me.txtCustcode.TabIndex = 52
        '
        'btnSelCust
        '
        Me.btnSelCust.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSelCust.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSelCust.Location = New System.Drawing.Point(35, 301)
        Me.btnSelCust.Name = "btnSelCust"
        Me.btnSelCust.Size = New System.Drawing.Size(237, 27)
        Me.btnSelCust.TabIndex = 51
        Me.btnSelCust.Text = "Customer / Supplier"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(32, 264)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(157, 19)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "Material In / Out"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbOut)
        Me.GroupBox1.Controls.Add(Me.rbIn)
        Me.GroupBox1.Enabled = False
        Me.GroupBox1.Location = New System.Drawing.Point(202, 240)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(247, 49)
        Me.GroupBox1.TabIndex = 50
        Me.GroupBox1.TabStop = False
        '
        'rbOut
        '
        Me.rbOut.Location = New System.Drawing.Point(134, 19)
        Me.rbOut.Name = "rbOut"
        Me.rbOut.Size = New System.Drawing.Size(92, 20)
        Me.rbOut.TabIndex = 1
        Me.rbOut.Text = "Out"
        '
        'rbIn
        '
        Me.rbIn.Location = New System.Drawing.Point(31, 19)
        Me.rbIn.Name = "rbIn"
        Me.rbIn.Size = New System.Drawing.Size(72, 20)
        Me.rbIn.TabIndex = 0
        Me.rbIn.Text = "In"
        '
        'txtMobile
        '
        Me.txtMobile.Location = New System.Drawing.Point(572, 212)
        Me.txtMobile.MaxLength = 20
        Me.txtMobile.Name = "txtMobile"
        Me.txtMobile.Size = New System.Drawing.Size(237, 23)
        Me.txtMobile.TabIndex = 48
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(507, 215)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 16)
        Me.Label2.TabIndex = 47
        Me.Label2.Text = "Mobile"
        '
        'txtDriver
        '
        Me.txtDriver.Location = New System.Drawing.Point(97, 212)
        Me.txtDriver.MaxLength = 30
        Me.txtDriver.Name = "txtDriver"
        Me.txtDriver.Size = New System.Drawing.Size(352, 23)
        Me.txtDriver.TabIndex = 46
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 214)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 16)
        Me.Label1.TabIndex = 45
        Me.Label1.Text = "Driver"
        '
        'lblVehical
        '
        Me.lblVehical.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblVehical.Location = New System.Drawing.Point(434, 175)
        Me.lblVehical.Name = "lblVehical"
        Me.lblVehical.Size = New System.Drawing.Size(375, 27)
        Me.lblVehical.TabIndex = 44
        Me.lblVehical.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtVehCode
        '
        Me.txtVehCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtVehCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtVehCode.Location = New System.Drawing.Point(284, 175)
        Me.txtVehCode.MaxLength = 10
        Me.txtVehCode.Name = "txtVehCode"
        Me.txtVehCode.ReadOnly = True
        Me.txtVehCode.Size = New System.Drawing.Size(144, 23)
        Me.txtVehCode.TabIndex = 43
        '
        'btnSelVeh
        '
        Me.btnSelVeh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSelVeh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSelVeh.Location = New System.Drawing.Point(35, 175)
        Me.btnSelVeh.Name = "btnSelVeh"
        Me.btnSelVeh.Size = New System.Drawing.Size(237, 27)
        Me.btnSelVeh.TabIndex = 42
        Me.btnSelVeh.Text = "Vehicle"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lbltobeNet)
        Me.GroupBox2.Controls.Add(Me.lblManualTare)
        Me.GroupBox2.Controls.Add(Me.btnWB2)
        Me.GroupBox2.Controls.Add(Me.btnWB1)
        Me.GroupBox2.Controls.Add(Me.txtNwt)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.txtSwt)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.txtFwt)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Enabled = False
        Me.GroupBox2.Location = New System.Drawing.Point(358, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(454, 150)
        Me.GroupBox2.TabIndex = 41
        Me.GroupBox2.TabStop = False
        '
        'lbltobeNet
        '
        Me.lbltobeNet.AutoSize = True
        Me.lbltobeNet.ForeColor = System.Drawing.Color.Firebrick
        Me.lbltobeNet.Location = New System.Drawing.Point(29, 126)
        Me.lbltobeNet.Name = "lbltobeNet"
        Me.lbltobeNet.Size = New System.Drawing.Size(15, 16)
        Me.lbltobeNet.TabIndex = 9
        Me.lbltobeNet.Text = "0"
        '
        'lblManualTare
        '
        Me.lblManualTare.AutoSize = True
        Me.lblManualTare.ForeColor = System.Drawing.Color.Red
        Me.lblManualTare.Location = New System.Drawing.Point(305, 23)
        Me.lblManualTare.Name = "lblManualTare"
        Me.lblManualTare.Size = New System.Drawing.Size(80, 16)
        Me.lblManualTare.TabIndex = 2
        Me.lblManualTare.Text = "Manual Tare"
        '
        'btnWB2
        '
        Me.btnWB2.BackColor = System.Drawing.Color.LightBlue
        Me.btnWB2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnWB2.FlatAppearance.BorderSize = 0
        Me.btnWB2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWB2.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWB2.ForeColor = System.Drawing.Color.White
        Me.btnWB2.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnWB2.Location = New System.Drawing.Point(124, 130)
        Me.btnWB2.Name = "btnWB2"
        Me.btnWB2.Size = New System.Drawing.Size(162, 75)
        Me.btnWB2.TabIndex = 8
        Me.btnWB2.Text = "W / B 2"
        Me.btnWB2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnWB2.UseVisualStyleBackColor = False
        Me.btnWB2.Visible = False
        '
        'btnWB1
        '
        Me.btnWB1.BackColor = System.Drawing.Color.LightCyan
        Me.btnWB1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnWB1.FlatAppearance.BorderSize = 0
        Me.btnWB1.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWB1.ForeColor = System.Drawing.Color.White
        Me.btnWB1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnWB1.Location = New System.Drawing.Point(308, 57)
        Me.btnWB1.Name = "btnWB1"
        Me.btnWB1.Size = New System.Drawing.Size(131, 58)
        Me.btnWB1.TabIndex = 7
        Me.btnWB1.Text = "000000"
        Me.btnWB1.UseVisualStyleBackColor = False
        Me.btnWB1.Visible = False
        '
        'txtNwt
        '
        Me.txtNwt.Location = New System.Drawing.Point(163, 86)
        Me.txtNwt.Name = "txtNwt"
        Me.txtNwt.ReadOnly = True
        Me.txtNwt.Size = New System.Drawing.Size(123, 23)
        Me.txtNwt.TabIndex = 6
        Me.txtNwt.TabStop = False
        Me.txtNwt.Text = "0"
        Me.txtNwt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(29, 96)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(103, 19)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Net weight"
        '
        'txtSwt
        '
        Me.txtSwt.Location = New System.Drawing.Point(163, 53)
        Me.txtSwt.Name = "txtSwt"
        Me.txtSwt.Size = New System.Drawing.Size(123, 23)
        Me.txtSwt.TabIndex = 4
        Me.txtSwt.Text = "0"
        Me.txtSwt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(29, 63)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(103, 19)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "2nd weight"
        '
        'txtFwt
        '
        Me.txtFwt.Location = New System.Drawing.Point(163, 20)
        Me.txtFwt.Name = "txtFwt"
        Me.txtFwt.Size = New System.Drawing.Size(123, 23)
        Me.txtFwt.TabIndex = 1
        Me.txtFwt.Text = "0"
        Me.txtFwt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(29, 30)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(103, 20)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "1st weight"
        '
        'pnlInfo
        '
        Me.pnlInfo.BackColor = System.Drawing.Color.SandyBrown
        Me.pnlInfo.Controls.Add(Me.lblRate)
        Me.pnlInfo.Controls.Add(Me.Label9)
        Me.pnlInfo.Controls.Add(Me.btnClose)
        Me.pnlInfo.Controls.Add(Me.lblAmount)
        Me.pnlInfo.Controls.Add(Me.Label17)
        Me.pnlInfo.Controls.Add(Me.lblBalance)
        Me.pnlInfo.Controls.Add(Me.Label15)
        Me.pnlInfo.Controls.Add(Me.lblCustGroup)
        Me.pnlInfo.Controls.Add(Me.Label10)
        Me.pnlInfo.Controls.Add(Me.lblPrePaidCust)
        Me.pnlInfo.Controls.Add(Me.Label11)
        Me.pnlInfo.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlInfo.Location = New System.Drawing.Point(841, 0)
        Me.pnlInfo.Name = "pnlInfo"
        Me.pnlInfo.Size = New System.Drawing.Size(228, 591)
        Me.pnlInfo.TabIndex = 74
        '
        'lblRate
        '
        Me.lblRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRate.Location = New System.Drawing.Point(108, 220)
        Me.lblRate.Name = "lblRate"
        Me.lblRate.Size = New System.Drawing.Size(96, 27)
        Me.lblRate.TabIndex = 78
        Me.lblRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(24, 224)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 16)
        Me.Label9.TabIndex = 77
        Me.Label9.Text = "Rate/Ton"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(84, 600)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(107, 42)
        Me.btnClose.TabIndex = 76
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblAmount
        '
        Me.lblAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAmount.Location = New System.Drawing.Point(108, 266)
        Me.lblAmount.Name = "lblAmount"
        Me.lblAmount.Size = New System.Drawing.Size(96, 27)
        Me.lblAmount.TabIndex = 75
        Me.lblAmount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(24, 270)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(52, 16)
        Me.Label17.TabIndex = 74
        Me.Label17.Text = "Amount"
        '
        'lblBalance
        '
        Me.lblBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBalance.Location = New System.Drawing.Point(108, 178)
        Me.lblBalance.Name = "lblBalance"
        Me.lblBalance.Size = New System.Drawing.Size(96, 27)
        Me.lblBalance.TabIndex = 73
        Me.lblBalance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(24, 182)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(52, 16)
        Me.Label15.TabIndex = 72
        Me.Label15.Text = "Balance"
        '
        'lblCustGroup
        '
        Me.lblCustGroup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCustGroup.Location = New System.Drawing.Point(164, 137)
        Me.lblCustGroup.Name = "lblCustGroup"
        Me.lblCustGroup.Size = New System.Drawing.Size(40, 27)
        Me.lblCustGroup.TabIndex = 71
        Me.lblCustGroup.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(24, 141)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(101, 16)
        Me.Label10.TabIndex = 70
        Me.Label10.Text = "Customer Group"
        '
        'lblPrePaidCust
        '
        Me.lblPrePaidCust.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPrePaidCust.Location = New System.Drawing.Point(164, 91)
        Me.lblPrePaidCust.Name = "lblPrePaidCust"
        Me.lblPrePaidCust.Size = New System.Drawing.Size(40, 27)
        Me.lblPrePaidCust.TabIndex = 69
        Me.lblPrePaidCust.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(24, 95)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(80, 16)
        Me.Label11.TabIndex = 68
        Me.Label11.Text = "Prepaid Cust"
        '
        'frmEditTicket
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1069, 591)
        Me.Controls.Add(Me.pnlWeighentry)
        Me.Controls.Add(Me.pnlInfo)
        Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmEditTicket"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Edit / Modify Ticket"
        Me.pnlWeighentry.ResumeLayout(False)
        Me.pnlWeighentry.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.pnlInfo.ResumeLayout(False)
        Me.pnlInfo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlWeighentry As System.Windows.Forms.Panel
    Friend WithEvents lblCustType As System.Windows.Forms.Label
    Friend WithEvents txtLM As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents txtRemark As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtDlvOrder As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lblSiteName As System.Windows.Forms.Label
    Friend WithEvents txtSiteCode As System.Windows.Forms.TextBox
    Friend WithEvents btnSelSite As System.Windows.Forms.Button
    Friend WithEvents lblLocName As System.Windows.Forms.Label
    Friend WithEvents txtLocCode As System.Windows.Forms.TextBox
    Friend WithEvents btnSelLoc As System.Windows.Forms.Button
    Friend WithEvents lblSouName As System.Windows.Forms.Label
    Friend WithEvents txtSouCode As System.Windows.Forms.TextBox
    Friend WithEvents btnSelSource As System.Windows.Forms.Button
    Friend WithEvents lblMatName As System.Windows.Forms.Label
    Friend WithEvents txtMatCode As System.Windows.Forms.TextBox
    Friend WithEvents btnSelMat As System.Windows.Forms.Button
    Friend WithEvents lblCustName As System.Windows.Forms.Label
    Friend WithEvents txtCustcode As System.Windows.Forms.TextBox
    Friend WithEvents btnSelCust As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbOut As System.Windows.Forms.RadioButton
    Friend WithEvents rbIn As System.Windows.Forms.RadioButton
    Friend WithEvents txtMobile As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtDriver As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblVehical As System.Windows.Forms.Label
    Friend WithEvents txtVehCode As System.Windows.Forms.TextBox
    Friend WithEvents btnSelVeh As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lbltobeNet As System.Windows.Forms.Label
    Friend WithEvents lblManualTare As System.Windows.Forms.Label
    Friend WithEvents btnWB2 As System.Windows.Forms.Button
    Friend WithEvents btnWB1 As System.Windows.Forms.Button
    Friend WithEvents txtNwt As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtSwt As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtFwt As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmbRemark As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTicketNo As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents pnlInfo As System.Windows.Forms.Panel
    Friend WithEvents lblRate As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblAmount As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblBalance As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lblCustGroup As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblPrePaidCust As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
