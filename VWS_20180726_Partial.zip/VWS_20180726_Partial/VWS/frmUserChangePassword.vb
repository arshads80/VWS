﻿Public Class frmUserChangePassword


    Dim ulst As New List(Of String)

    Public Function ShowDialog_ChangePassword(Optional ByVal ustid As String = "") As List(Of String)

        If ustid <> "" Then

            Me.txtUserID.Text = ustid

            Me.txtUserID.ReadOnly = True

        End If

        Me.txtPword.Text = ""
        Me.txtRepeat.Text = ""
        Me.txtNewPword.Text = ""

        ShowDialog()

        ShowDialog_ChangePassword = ulst

    End Function


    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

      
        Me.Close()

    End Sub

    Private Function FormNotValid() As Boolean

        FormNotValid = True

        If Me.txtUserID.Text.Length < 5 Then

            msWriteLM("invalid user id", "r")
            Me.txtUserID.Focus()
            Exit Function

        End If

        If Me.txtPword.Text.Length < 5 Then

            msWriteLM("invalid password", "r")
            Me.txtPword.Focus()
            Exit Function

        End If

        If Me.txtNewPword.Text.Length < 5 Then

            msWriteLM("password must be minimum 5 digits", "r")
            Me.txtNewPword.Focus()
            Exit Function

        End If


        If Me.txtNewPword.Text <> Me.txtRepeat.Text Then

            msWriteLM("2 password entries are not same", "r")
            Me.txtRepeat.Focus()
            Exit Function

        End If

        FormNotValid = False

    End Function


    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click

        If FormNotValid() Then Exit Sub

        ulst(0) = Me.txtUserID.Text
        ulst(1) = Me.txtPword.Text
        ulst(2) = Me.txtNewPword.Text

        Dim s As String
        s = "Select * from tblUsers where UserID = '" & txtUserID.Text & "'"

        Dim ds As New DataSet
        Dim w As String
        w = mslCons.WebAuthcode

        ds = msWebGetDS(s, w)

        If ds.Tables.Count < 1 Then
            MsgBox("Can not retrieve record")
            Exit Sub
        End If

        If ds.Tables(0).Rows.Count < 1 Then
            MsgBox("Invalid user id")
            Exit Sub
        End If

        Dim pw As String
        pw = ds.Tables(0).Rows(0)("UserPW").ToString.ToLower

        If txtPword.Text.ToLower <> pw Then
            MsgBox("Incorrect Password")
            Exit Sub
        End If

        ' update record 
        Dim a As String

        w = mslCons.WebAuthcode
        a = msWebUpdate3FieldsInDb("tblUsers", "UserPW", "'" & txtNewPword.Text.ToLower & "'", "LastUpdateAt", "'" & msNow() & "'", "", "", "UserID = '" & txtUserID.Text & "'", w)

        If a = "1" Then
            MsgBox("Password changed")

        Else
            MsgBox("Error : 161015 " & a)
        End If

        Me.Close()

    End Sub

    Private Sub msWriteLM(ByVal LmData As String, Optional ByVal rgbh As String = "0")

        Dim obj As Control
        obj = Me.txtLM

        If TypeOf obj Is TextBox Then
            If CType(obj, TextBox).Multiline Then
                Me.txtLM.Text = LmData & vbCrLf & Me.txtLM.Text
            Else
                Me.txtLM.Text = LmData
            End If

        Else
            Me.txtLM.Text = LmData
        End If

        'msDoEvents()

        Dim pColor As Color
        Select Case rgbh.ToLower
            Case "r"
                pColor = Color.Crimson
            Case "b"    ' blue
                pColor = Color.Blue
            Case "g"
                pColor = Color.Green
            Case "h"  ' highlight
                pColor = Color.DarkBlue
            Case Else
                pColor = Color.Black
        End Select


        txtLM.ForeColor = pColor

        If rgbh = "h" Then
            txtLM.BackColor = Color.Yellow
        Else
            txtLM.BackColor = Color.WhiteSmoke
        End If

    End Sub

    Private Sub frmChangePassword_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        msWriteLM("change Passcode...", "g")

        ulst.Add("")
        ulst.Add("")
        ulst.Add("")

    End Sub

End Class