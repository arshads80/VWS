﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWeighmentReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.lblWait = New System.Windows.Forms.Label
        Me.lblTotWg = New System.Windows.Forms.Label
        Me.btnClose = New System.Windows.Forms.Button
        Me.btnOpenWithExcel = New System.Windows.Forms.Button
        Me.btnWeigment = New System.Windows.Forms.Button
        Me.btnSelCust = New System.Windows.Forms.Button
        Me.txtCustcode = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.dtpFrm = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser
        Me.cmbCustType = New System.Windows.Forms.ComboBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Panel1.Controls.Add(Me.cmbCustType)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.lblWait)
        Me.Panel1.Controls.Add(Me.lblTotWg)
        Me.Panel1.Controls.Add(Me.btnClose)
        Me.Panel1.Controls.Add(Me.btnOpenWithExcel)
        Me.Panel1.Controls.Add(Me.btnWeigment)
        Me.Panel1.Controls.Add(Me.btnSelCust)
        Me.Panel1.Controls.Add(Me.txtCustcode)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.dtpFrm)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1229, 70)
        Me.Panel1.TabIndex = 0
        '
        'lblWait
        '
        Me.lblWait.AutoSize = True
        Me.lblWait.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWait.ForeColor = System.Drawing.Color.Red
        Me.lblWait.Location = New System.Drawing.Point(712, 53)
        Me.lblWait.Name = "lblWait"
        Me.lblWait.Size = New System.Drawing.Size(106, 16)
        Me.lblWait.TabIndex = 18
        Me.lblWait.Text = "Please wait ....."
        Me.lblWait.Visible = False
        '
        'lblTotWg
        '
        Me.lblTotWg.AutoSize = True
        Me.lblTotWg.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotWg.Location = New System.Drawing.Point(1049, 22)
        Me.lblTotWg.Name = "lblTotWg"
        Me.lblTotWg.Size = New System.Drawing.Size(25, 25)
        Me.lblTotWg.TabIndex = 17
        Me.lblTotWg.Text = "0"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(1139, 18)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(87, 29)
        Me.btnClose.TabIndex = 16
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnOpenWithExcel
        '
        Me.btnOpenWithExcel.Location = New System.Drawing.Point(882, 15)
        Me.btnOpenWithExcel.Name = "btnOpenWithExcel"
        Me.btnOpenWithExcel.Size = New System.Drawing.Size(161, 35)
        Me.btnOpenWithExcel.TabIndex = 15
        Me.btnOpenWithExcel.Text = "Open with Excel"
        Me.btnOpenWithExcel.UseVisualStyleBackColor = True
        '
        'btnWeigment
        '
        Me.btnWeigment.Location = New System.Drawing.Point(715, 15)
        Me.btnWeigment.Name = "btnWeigment"
        Me.btnWeigment.Size = New System.Drawing.Size(161, 35)
        Me.btnWeigment.TabIndex = 14
        Me.btnWeigment.Text = "Online Weighment"
        Me.btnWeigment.UseVisualStyleBackColor = True
        '
        'btnSelCust
        '
        Me.btnSelCust.Location = New System.Drawing.Point(661, 20)
        Me.btnSelCust.Name = "btnSelCust"
        Me.btnSelCust.Size = New System.Drawing.Size(45, 27)
        Me.btnSelCust.TabIndex = 13
        Me.btnSelCust.Text = "---"
        Me.btnSelCust.UseVisualStyleBackColor = True
        '
        'txtCustcode
        '
        Me.txtCustcode.Location = New System.Drawing.Point(564, 22)
        Me.txtCustcode.Name = "txtCustcode"
        Me.txtCustcode.Size = New System.Drawing.Size(91, 22)
        Me.txtCustcode.TabIndex = 12
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(490, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 14)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Customer"
        '
        'dtpFrm
        '
        Me.dtpFrm.CustomFormat = "dd/MMM/yyyy"
        Me.dtpFrm.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFrm.Location = New System.Drawing.Point(59, 23)
        Me.dtpFrm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dtpFrm.Name = "dtpFrm"
        Me.dtpFrm.Size = New System.Drawing.Size(139, 22)
        Me.dtpFrm.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 14)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Date"
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 70)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(1229, 560)
        Me.WebBrowser1.TabIndex = 1
        '
        'cmbCustType
        '
        Me.cmbCustType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCustType.FormattingEnabled = True
        Me.cmbCustType.Location = New System.Drawing.Point(293, 22)
        Me.cmbCustType.Name = "cmbCustType"
        Me.cmbCustType.Size = New System.Drawing.Size(191, 22)
        Me.cmbCustType.TabIndex = 42
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(216, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(69, 14)
        Me.Label18.TabIndex = 41
        Me.Label18.Text = "Cust Type"
        '
        'frmWeighmentReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1229, 630)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "frmWeighmentReport"
        Me.Text = "Online Weighment Report"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dtpFrm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnSelCust As System.Windows.Forms.Button
    Friend WithEvents txtCustcode As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnWeigment As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnOpenWithExcel As System.Windows.Forms.Button
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents lblTotWg As System.Windows.Forms.Label
    Friend WithEvents lblWait As System.Windows.Forms.Label
    Friend WithEvents cmbCustType As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
End Class
