﻿Public Class mdiVWS

    Private Sub mdiVWS_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        TestMode = False
        Dim testmodeStartTime As String
        testmodeStartTime = "2018-07-24 19:20"
        Dim testmodeEndTime As String
        testmodeEndTime = Format(DateAdd(DateInterval.Minute, 10000, CDate(testmodeStartTime)), "yyyy-MM-dd HH:mm")

        Dim curTime As String
        curTime = Format(Date.Now, "yyyy-MM-dd HH:mm")

        If curTime >= testmodeStartTime And curTime < testmodeEndTime Then
            TestMode = True
        End If

        msDoEvents()

        Init_mslvs()

        '        msGetAllMacIDs()

        ReadRegVars()

        Me.lblSite.Text = "Site : " & mslv.WeighingSiteCode & " / " & mslv.WeighingPCcode

        If mslv.SiteSelection = "Y" Then

            Dim frmsts As New frmSiteSelection
            '  Me.lblSiteSelected.Text = frmsts.Showdialog_siteselection()
            Me.lblSite.Text = frmsts.Showdialog_siteselection() & " / " & mslv.WeighingPCcode

        End If

        ReadSysVars()

        For k = 0 To 2
            If CheckUser() Then Exit For
            If User.ID <> "" Then Exit For
        Next
        If User.ID = "" Then
            Me.Close()
            End
            Exit Sub
        End If

        Me.lblUserName.Text = "User ID : " & User.ID

        'WritelActivity("User", "Login", User.ID, "system code: " & mslv.ProductCode)
        msWriteActivity("Login", "Login at System: " & mslv.ProductCode)

        AdjustUserAccessMenu()

    End Sub

    Private Sub AdjustUserAccessMenu()

        If arUserAccess(enUAcs.Change_Password) = 0 Then
            Me.mnuChangePassword.Visible = False
        End If

        If arUserAccess(enUAcs.User_Adminstration) = 0 Then
            Me.mnuUserAdmin.Visible = False
        End If

        If arUserAccess(enUAcs.Open_Material_file) = 0 Then
            Me.mnuMaterials.Visible = False
        End If

        If arUserAccess(enUAcs.Open_Customer_file) = 0 Then
            Me.mnuCustomers.Visible = False
            Me.btnCust.Enabled = False
        End If

        If arUserAccess(enUAcs.Open_Vehicle_file) = 0 Then
            Me.mnuVehicles.Visible = False
            Me.btnVehicle.Enabled = False
        End If

        If arUserAccess(enUAcs.Reports) = 0 Then
            Me.mnuReports.Visible = False
            Me.btnTrnReports.Enabled = False
            mnuSummaryReport.Visible = False
            Me.btnSummaryReports.Enabled = False
            mnuPrepaidCustReport.Visible = False
        End If

        If arUserAccess(enUAcs.Weighment_Report) = 0 Then
            mnuOnlineWeighment.Visible = False
        End If

        If arUserAccess(enUAcs.Reprint_Ticket) = 0 Then
            mnuReprint1stTick.Enabled = False
            mnuReprintTick.Enabled = False
        End If

        If arUserAccess(enUAcs.System_Settings) = 0 Then
            Me.mnuSystemSettings.Visible = False
        End If

        ' If arUserAccess(enUAcs.Global_Settings) = 0 Then
        Me.mnuGlobalSettings.Visible = False
        'End If

        If arUserAccess(enUAcs.Weighing) = 0 Then
            Me.mnuWeighing.Enabled = False
            Me.btnWeighing.Enabled = False
        End If

        If arUserAccess(enUAcs.Open_Other_Masters) = 0 Then
            Me.mnuOtherMasters.Visible = False
            Me.btnSource.Enabled = False
            Me.btnLoc.Enabled = False
            Me.btnSite.Enabled = False
        End If

        If arUserAccess(enUAcs.Delete_1st_Ticket) = 0 Then
            Me.mnuDel1stTick.Visible = False
        End If

        If arUserAccess(enUAcs.Delete_Ticket) = 0 Then
            Me.mnuDeleteTicket.Visible = False
        End If

        If arUserAccess(enUAcs.Edit_1st_ticket) = 0 Then
            mnuEdit1stTicket.Visible = False
        End If

        If arUserAccess(enUAcs.Edit_Ticket) = 0 Then
            mnuEditTicket.Visible = False
        End If


    End Sub


    Private Sub ReadRegVars()

        ' reading from file

        Dim tmp As String

        tmp = mslv.CurPath & "\Reports"
        tmp = msReadRegXML("ReportsPath", tmp, "011", "Reports Path")
        mslv.ReportsPath = tmp

        tmp = "A"
        tmp = msReadRegXML("WeighingSiteCode", tmp, "011", "Weighing Site Code")
        mslv.WeighingSiteCode = tmp

        tmp = "PC-A"
        tmp = msReadRegXML("WeighingPCcode", tmp, "011", "Weighing PC code")
        mslv.WeighingPCcode = tmp

        tmp = "N"
        tmp = msReadRegXML("SiteSelection", tmp, "012", "Site Selection (Y/N)")
        mslv.SiteSelection = tmp


        tmp = "fticket.rpt"
        tmp = msReadRegXML("FTicketFormat", tmp, "021", "First ticket Format")
        Sysvars.FTicketFormat = tmp

        tmp = "sticket.rpt"
        tmp = msReadRegXML("STicketFormat", tmp, "022", "2nd ticket Format")
        Sysvars.STicketFormat = tmp

        tmp = "nticket.rpt"
        tmp = msReadRegXML("NTicketFormat", tmp, "023", "net ticket Format")
        Sysvars.NTicketFormat = tmp

        tmp = "Provider=SQLOLEDB;Data Source=(Local);Initial Catalog=db_MAILNPP;Integrated Security=SSPI;"
        tmp = msReadRegXML("DBConStr", tmp, "009", "db connection string")
        mslv.OleconStr = tmp

        tmp = "Provider=SQLOLEDB;Data Source=(Local);Initial Catalog=db_MAILNPP;Integrated Security=SSPI;"
        tmp = msReadRegXML("DBConStrA", tmp, "009", "db connection string Site A")
        mslv.OleconStrA = tmp

        tmp = "Provider=SQLOLEDB;Data Source=(Local);Initial Catalog=db_MAILNPP;Integrated Security=SSPI;"
        tmp = msReadRegXML("DBConStrB", tmp, "009", "db connection string Site B")
        mslv.OleconStrB = tmp

        tmp = "Provider=SQLOLEDB;Data Source=(Local);Initial Catalog=db_MAILNPP;Integrated Security=SSPI;"
        tmp = msReadRegXML("DBConStrC", tmp, "009", "db connection string Site C")
        mslv.OleconStrC = tmp

        tmp = "Provider=SQLOLEDB;Data Source=(Local);Initial Catalog=db_MAILNPP;Integrated Security=SSPI;"
        tmp = msReadRegXML("DBConStrD", tmp, "009", "db connection string Site D")
        mslv.OleconStrD = tmp

        mslv.inputValue = msReadRegXML("InputValue", "0", "001", "Input Value")


        ' Indicator A
        Sysvars.UseWA = msReadRegXML("UseWA", "0", "101", "Use Indicator (0-No/1-Yes)")

        Sysvars.WComA = msReadRegXML("WComA", "1", "111", "Com port")
        Sysvars.WBaudRateA = msReadRegXML("WBaudRateA", "9600", "111", "Baud Rate")
        Sysvars.WParityA = msReadRegXML("WParityA", "N", "111", "Parity (O, E, M, S, N)")
        Sysvars.WDataBitsA = msReadRegXML("WDataBitsA", "8", "111", "Data bits (5, 6, 7, 8)")
        Sysvars.WStopBitsA = msReadRegXML("WStopBitsA", "1", "111", "Stop Bits (0, 1, 1.5, 2)")

        Sysvars.IndMaxLenA = msReadRegXML("IndMaxLenA", "13", "122", "Ind Max Len")
        Sysvars.IndWtStartsAtA = msReadRegXML("IndWtStartsAtA", "0", "122", "Ind Weight Start At")
        Sysvars.IndWtLenA = msReadRegXML("IndWtLenA", "0", "122", "Ind Weight Len")
        Sysvars.IndUnitStartsAtA = msReadRegXML("IndUnitStartsAtA", "0", "122", "Ind Unit Starts At")
        Sysvars.IndUnitLenA = msReadRegXML("IndUnitLenA", "0", "122", "Ind Unit Len")
        Sysvars.IndStatusStartsAtA = msReadRegXML("IndStatusStartsAtA", "0", "122", "Ind Status Starts At")
        Sysvars.IndStatusLenA = msReadRegXML("IndStatusA", "0", "122", "Ind Status Len")
        Sysvars.StCharA = msReadRegXML("StCharA", "P", "122", "Ind Start Char")

        ' -------------------------

        Sysvars.DefaultInOut = msReadRegXML("DefaultInOut", "O", "131", "DefaultInOut I / O")

    End Sub


    Public Sub ReadSysVars()

        msReadSetTable()

        Sysvars.CompanyName = msGetSysValue("CompanyName", "0")

        Sysvars.VerShouldBe = msGetSysValue("VerShouldBe", "2016-06-01")
        Sysvars.VersionMessage = msGetSysValue("VersionMessage", "newer software version is available, do you want to download?")
        Sysvars.VersionStop = msGetSysValue("VersionStop", "S")
        
    End Sub


    Private Function checkInVal(ByVal inval As String) As Boolean

        checkInVal = False

        Dim sa As String

        Dim la As Long
        la = Int(Val(mslv.ProductCode) * 3)
        la = System.Math.Abs(la - 8765432)

        sa = Int(la / 4.91)

        If sa = inval Then
            checkInVal = True
        End If

    End Function

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click

        Me.Close()

    End Sub


    Private Function CheckUser() As Boolean

        CheckUser = False
        User.ID = ""
        User.Access = "0"

        Dim uList As New List(Of String)

        Dim frmgn As New frmUserLogin
        uList = frmgn.ShowDialog_Login()

        '  MsgBox(mslv.ProductCode)

        If (mslv.ProductCode = "0171228" Or mslv.ProductCode = "2101219" Or mslv.ProductCode = "0668700" Or mslv.ProductCode = "8498774") And (uList(0) = "" Or uList(1) = "") Then    ' ms pc
            uList(0) = "master"
            uList(1) = "vws2016%"
            User.Access = StrDup(100, "1")
        End If


        If uList(0) = "" Or uList(1) = "" Then
            MsgBox("User Cancelled " & mslv.ProductCode)
            CheckUser = True               ' user cancels
            Exit Function
        End If

        ' check for master pw


        If uList(0).ToLower = "master" And uList(1).ToLower = "vws2016%" Then
            User.ID = "master".ToUpper
            User.Access = StrDup(100, "1")       ' "111111111111111111111111111111"

        Else
            Dim ds As DataSet
            Dim w As String
            w = mslCons.WebAuthcode

            Dim s As String
            s = "Select * from tblUsers where UserID = '" & uList(0) & "' and UserPW = '" & uList(1) & "'"
            Try
                ds = msWebGetDS(s, w)

                If ds.Tables.Count < 1 Then
                    MsgBox("can not retrieve user data", MsgBoxStyle.Critical)
                    Exit Function
                End If

                If ds.Tables(0).Rows.Count < 1 Then
                    MsgBox("Incorrect user ID or password", MsgBoxStyle.Exclamation)
                    Exit Function
                End If

                Dim dr As DataRow
                dr = ds.Tables(0).Rows(0)
                If dr("UserDisabled") = "Y" Then
                    MsgBox("Not Authorised. disabled", MsgBoxStyle.Exclamation)
                    Exit Function
                End If

                User.ID = uList(0)
                User.Access = dr("UserAccess")

            Catch ex As Exception
                MsgBox("Error 160411 " & ex.Message)
                Exit Function
            End Try

        End If

        For i = 1 To User.Access.Length
            arUserAccess(i) = Mid(User.Access, i, 1)
        Next

    End Function


    Private Sub mnuChangePassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuChangePassword.Click

        Dim frmch As New frmUserChangePassword
        frmch.ShowDialog_ChangePassword(User.ID)

    End Sub

    Private Sub mnuUserAdmin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuUserAdmin.Click

        Dim frmuserAdm As New frmUserAdmin
        frmUserAdmin.ShowDialog()


    End Sub

    Private Sub mnuMaterials_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMaterials.Click

        Dim frmm As New frmMaterials
        frmm.MdiParent = Me
        frmm.Show()

    End Sub


    Private Sub mnuCustomers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCustomers.Click

        Dim frmc As New frmParties
        frmc.MdiParent = Me
        frmc.Show()

    End Sub

    Private Sub mnuVehicles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuVehicles.Click

        Dim frmv As New frmVehicles
        frmv.MdiParent = Me
        frmv.Show()

    End Sub

    Private Sub SystemSettingsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSystemSettings.Click

        ' Dim frmsx As New frmRegSettings
        ' frmsx.ShowDialog()

    End Sub

    Private Sub WeighingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWeighing.Click

        If btnWeighing.Enabled Then
            btnWeighing.PerformClick()
        End If

        'Dim frmwt As New frmWeighing
        'frmwt.MdiParent = Me
        'frmwt.Show()

    End Sub

    Private Sub btnVehicle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVehicle.Click

        Dim frmv As New frmVehicles
        If msChildFormNotOpened(frmv) Then
            frmv.MdiParent = Me
            frmv.Show()
        End If

    End Sub

    Private Sub btnMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMaterial.Click

        Dim frmm As New frmMaterials
        If msChildFormNotOpened(frmm) Then
            frmm.MdiParent = Me
            frmm.Show()
        End If

    End Sub

    Private Sub btnCust_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCust.Click

        Dim frmc As New frmParties
        If msChildFormNotOpened(frmc) Then
            frmc.MdiParent = Me
            frmc.Show()
        End If

    End Sub

    Private Sub btnWeighing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWeighing.Click

        If checkInVal(mslv.inputValue) Then
            ' ok 
        Else
            Dim sa As String
            sa = frmmsInputBox2015_16.ShowDialog_InputBox("Registration code ( " & mslv.ProductCode & " ) : ", "")
            If sa <> "" AndAlso IsNumeric(sa) Then
                If checkInVal(sa) Then
                    msWriteRegXML("InputValue", sa, "001", "Input Value")
                    mslv.inputValue = sa

                Else
                    MsgBox("Invalid code", MsgBoxStyle.Exclamation)
                    Exit Sub
                End If
            End If
        End If

        'Dim frmwt As New frmWeighing
        'If msChildFormNotOpened(frmwt) Then
        '    frmwt.MdiParent = Me
        '    frmwt.Show()
        'End If

    End Sub

    Private Function msChildFormNotOpened(ByVal ThisFrm As Form) As Boolean

        Dim xfrm As Form

        msChildFormNotOpened = True

        For Each xfrm In Me.MdiChildren

            If xfrm.Name = ThisFrm.Name Then

                ' MsgBox(" !!! Already Opened !!! ", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation)
                xfrm.Activate()
                'Return True
                msChildFormNotOpened = False
                Exit Function

            End If
        Next


    End Function

    Private Sub btnSource_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSource.Click

        Dim frmkt As New frmOtherMasters
        frmkt.ShowDialog_OtherMasters("tblSource", "soucode", "Souname")

    End Sub

    Private Sub TransportersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TransportersToolStripMenuItem.Click

        Dim frmkt As New frmOtherMasters
        frmkt.ShowDialog_OtherMasters("tblSource", "soucode", "Souname")


    End Sub

    Private Sub DestinationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DestinationToolStripMenuItem.Click

        Dim frmkt As New frmOtherMasters
        frmkt.ShowDialog_OtherMasters("tblLocations", "loccode", "locname")


    End Sub

    Private Sub btnLoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoc.Click

        Dim frmkt As New frmOtherMasters
        frmkt.ShowDialog_OtherMasters("tblLocations", "loccode", "locname")


    End Sub


    Private Sub btnSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSite.Click

        Dim frmkt As New frmOtherMasters
        frmkt.ShowDialog_OtherMasters("tblSites", "sitecode", "sitename")


    End Sub

    Private Sub mnuSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSite.Click

        Dim frmkt As New frmOtherMasters
        frmkt.ShowDialog_OtherMasters("tblSites", "sitecode", "sitename")

    End Sub


    Private Sub btnTrnReports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTrnReports.Click

       
        Dim frmtr As New frmTrnReports
        frmtr.MdiParent = Me
        frmtr.Show()


    End Sub

    Private Sub lblUserName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblUserName.Click

        '   Dim frm As New Form1
        '  frm.MdiParent = Me
        ' frm.Show()

    End Sub

    Private Sub TransactionReportsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTrnReport.Click

        Dim frmtr As New frmTrnReports
        frmtr.MdiParent = Me
        frmtr.Show()

    End Sub

    Private Sub btnSummaryReports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSummaryReports.Click

        Dim frmtr As New frmSummaryReport
        frmtr.MdiParent = Me
        frmtr.Show()

    End Sub

    Private Sub PrepaidCustomersReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPrepaidCustReport.Click

        Dim frmg As New frmCusBals
        frmg.MdiParent = Me
        frmg.Show()

    End Sub

    Private Sub mnuSummaryReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSummaryReport.Click

        Dim frmtr As New frmSummaryReport
        frmtr.MdiParent = Me
        frmtr.Show()

    End Sub

    Private Sub mnuDel1stTick_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDel1stTick.Click

        Dim frmd As New frmDel1stWt
        frmd.ShowDialog()

    End Sub

    Private Sub mnuDeleteTicket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDeleteTicket.Click

        Dim frmd As New frmDelTick
        frmd.ShowDialog()

    End Sub

    Private Sub mnuOnlineWeighment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuOnlineWeighment.Click

        frmWeighmentReport.ShowDialog()

    End Sub

    Private Sub mnuEdit1stTicket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEdit1stTicket.Click

        Dim tik As String
        tik = frmmsInputBox2015_16.ShowDialog_InputBox("First Ticket No. ", "", 8)

        If IsNumeric(tik) AndAlso Val(tik) > 0 Then
            Dim frmedti As New frmEditTicket
            frmedti.ShowDialog_EditTicket(tik, True)
        End If

    End Sub

    Private Sub mnuEditTicket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditTicket.Click

        Dim tik As String
        tik = frmmsInputBox2015_16.ShowDialog_InputBox("Ticket No. ", "", 8)

        If IsNumeric(tik) AndAlso Val(tik) > 0 Then
            Dim frmedti As New frmEditTicket
            frmedti.ShowDialog_EditTicket(tik, False)
        End If

    End Sub

    Private Sub mnuReprintTick_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuReprintTick.Click

        Dim tickn As String
        tickn = frmmsInputBox2015_16.ShowDialog_InputBox("Ticket No", "", 8)
        If tickn <> "" AndAlso IsNumeric(tickn) Then
            PrintTicket(tickn, 3)
        End If


    End Sub

    Private Sub PrintTicket(ByVal prmTickNo As Long, ByVal WType As Integer)

        Dim frmT As New frmCrysReport
        Dim sStr As String

        sStr = "Select top 1 * from tblWeighing where WeighType = "
        sStr = sStr & WType
        sStr = sStr & " and canflag = 0 "
        If WType = 1 Then
            sStr = sStr & " and FirstTicketNo = " & prmTickNo
        Else
            sStr = sStr & " and TicketNo = " & prmTickNo
        End If

        sStr = sStr & " order by TicketNo DESC"

        Dim dsr As New DataSet

        Dim w As String
        w = mslCons.WebAuthcode

        dsr = msWebGetDS(sStr, w)

        If IsNumeric(w) Or w = mslCons.WebAuthcode Then
            'ok
        Else
            MsgBox("Error 160626 " & w, MsgBoxStyle.Critical)
            Exit Sub
        End If

        'If dsr.Tables.Count < 0 Then
        '    MsgBox("unable to retrieve data", MsgBoxStyle.Exclamation)
        '    Exit Sub
        'End If

        If dsr.Tables(0).Rows.Count < 1 Then
            MsgBox("Record not found", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If WType = 1 Then
            frmT.Show_frmCryReport(dsr, mslv.ReportsPath & "\" & Sysvars.FTicketFormat, , , , , , sStr)
        ElseIf WType = 2 Then
            frmT.Show_frmCryReport(dsr, mslv.ReportsPath & "\" & Sysvars.STicketFormat, , , , , , sStr)
        Else            ' If WType = 3 Then
            frmT.Show_frmCryReport(dsr, mslv.ReportsPath & "\" & Sysvars.NTicketFormat, , , , , , sStr)
        End If

    End Sub

    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuReprint1stTick.Click

        Dim tickn As String
        tickn = frmmsInputBox2015_16.ShowDialog_InputBox("Ticket 1st No", "", 8)

        If tickn <> "" AndAlso IsNumeric(tickn) Then
            PrintTicket(tickn, 1)

        End If

    End Sub


End Class