﻿Public Class frmUserLogin

    Dim rtlist As New List(Of String)

    Public Function ShowDialog_Login(Optional ByVal UsrName As String = "") As List(Of String)

        Me.txtUsrID.Text = UsrName
        Me.txtPasscode.Text = ""

        ShowDialog()

        ShowDialog_Login = rtlist

    End Function

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        Me.Close()

    End Sub


    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click

        rtlist(0) = Me.txtUsrID.Text
        rtlist(1) = txtPasscode.Text

        Me.Close()

    End Sub


    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Text = mslv.ProjName & " Login"

        Me.lblComName.Text = mslv.CompanyName

        rtlist.Add("")
        rtlist.Add("")

    End Sub

    Private Sub btnNewUser_Click(sender As Object, e As EventArgs) Handles btnNewUser.Click

        Dim ftc As New frmUserCreate
        ftc.ShowDialog()

    End Sub

End Class