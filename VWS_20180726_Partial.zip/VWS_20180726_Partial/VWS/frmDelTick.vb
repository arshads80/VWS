﻿Public Class frmDelTick

    Private Sub frmDelTick_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim s As String
        s = "Select RemDescription from tblRemarks order by RemDescription"

        msFillGroupCombo(s, Me.cmbRemark, 0, , True)

        Me.cmbRemark.Items.Insert(0, " ")

        Me.cmbRemark.SelectedIndex = 0

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub


    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click

        If Me.txtTickNo.Text.Trim <> "" AndAlso IsNumeric(txtTickNo.Text) Then

            Dim sstr As String
            sstr = "Select * from tblweighing where TicketNo = " & Val(txtTickNo.Text.Trim) & " and WeighType <> 1 and CanFlag = 0"
            Dim w As String

            Dim ds As New DataSet

            Try
                w = msFillDS(sstr, ds)
                If w = "" Then

                    If ds.Tables(0).Rows.Count < 1 Then

                        Me.lblTickInfo.Text = "Record not found"
                        Exit Sub

                    End If

                    Dim dr As DataRow
                    dr = ds.Tables(0).Rows(0)
                    Me.lblTickInfo.Text = "Customer : " & dr("CustCode") & "  " & dr("CustName") & vbCrLf
                    Me.lblTickInfo.Text = Me.lblTickInfo.Text & "Material : " & dr("MatCode") & "  " & dr("MatName") & vbCrLf

                    Me.lblTickInfo.Text = Me.lblTickInfo.Text & "First  Weight : " & dr("FWeight") & vbCrLf
                    Me.lblTickInfo.Text = Me.lblTickInfo.Text & "Second Weight : " & dr("SWeight") & vbCrLf
                    Me.lblTickInfo.Text = Me.lblTickInfo.Text & "Net    Weight : " & dr("NWeight") & vbCrLf

                    Me.btnDel.Enabled = True

                End If

            Catch ex As Exception

                MsgBox("Error 160821 " & ex.Message, MsgBoxStyle.Critical)

            End Try

        End If

    End Sub

    Private Sub btnDel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDel.Click

        If Me.cmbRemark.Text.Trim = "" Then
            MsgBox("Please select Remark")
            Exit Sub
        End If

        If MsgBox("Are you sure you want to delete selected record? " & vbCrLf & "If you click Yes then you can not undo the operation", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.Yes Then

            Dim a As String
            a = msUpdate3FieldsInDb("tblWeighing", "CanFlag", "1", "CancelRemark", "'" & Me.cmbRemark.Text & "'", "UserCancelled", "'" & User.ID & "'", "TicketNo = " & Me.txtTickNo.Text)

            If IsNumeric(a) Then

                MsgBox(a & " records cancelled from weighing", MsgBoxStyle.Exclamation)

                a = msUpdateFlagInDb("tblCustPayments", "CanFlag", "1", "TicketNo = " & Me.txtTickNo.Text)

                MsgBox(a & " records cancelled from Cust payments", MsgBoxStyle.Exclamation)

            Else
                MsgBox("Error 160822 " & a, MsgBoxStyle.Critical)

            End If

        End If

    End Sub

End Class