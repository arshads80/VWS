﻿Public Class frmWeighmentReport

    Dim nfile As String

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub btnSelCust_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelCust.Click

        Dim frmc As New frmPartySearch

        Dim cs As String

        cs = frmc.ShowDialog_PartySearch("", "", True, False)

        Me.txtCustcode.Text = cs

    End Sub

    Private Sub btnOnlineWeighment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWeigment.Click

        Dim CellPrintWidth = 100

        Dim ComName As String
        Dim ComCode As String
        Dim ComMats(6) As String
        Dim MatNames(6) As String
        Dim oldCom As String

        Dim serr As String

        Dim w(5, 200) As Single
        Dim wTot(5) As Double
        Dim gTot As Double

        Dim MatCode As String

        Dim i As Integer
        Dim j As Integer
        oldCom = ""
        Dim f1 As String
        Dim f2 As String
        f1 = Format(Me.dtpFrm.Value, "yyMMdd")
        f2 = f1 & "3"

        Me.btnWeigment.Enabled = False
        System.Windows.Forms.Application.DoEvents()


        Me.lblWait.Visible = True
        System.Windows.Forms.Application.DoEvents()
        Me.lblTotWg.Text = "0"

        Try
            Kill(nFile)

        Catch ex As Exception

        End Try

        Dim repFile As String

        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "yyMMddHHmmss")
        repFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\WRep" & subFn & ".html"

        nfile = repFile

        Dim sH As String

        sH = "<html>"
        sH = sH & "<head>"
        sH = sH & "<meta http-equiv='Content-Language' content='en-us'>"
        sH = sH & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        sH = sH & "<title>Wighment Report</title>"
        sH = sH & "</head>"
        sH = sH & "<body>"
        sH = sH & "<B><font = 'Arial' size = '14'><I> Online Weighment </I></font></B>"

        My.Computer.FileSystem.WriteAllText(repFile, sH, False)

        Dim sCus As String
        Dim sW As String

        sCus = "Select Custcode from tblWeighing where "
        sCus = sCus & " weightype <> 1 and CanFlag = 0 "

        If cmbCustType.SelectedIndex > 0 Then

            sCus = sCus & " and CustType = " & Mid(cmbCustType.Text, 1, 1)

        End If

        'sCus = sCus & " custType = 0 "


        sCus = sCus & " and SWDateTime >= '" & Format(dtpFrm.Value, "yyyy-MM-dd") & "'"
        sCus = sCus & " and SWDateTime <= '" & Format(dtpFrm.Value, "yyyy-MM-dd9") & "'"

        If txtCustcode.Text > "0" Then
            sCus = sCus & " and Custcode = '" & txtCustcode.Text & "'"
        End If

        sCus = sCus & " Group by CustCode order by Custcode"

        Dim dscus As New DataSet
        serr = msFillDS(sCus, dscus)

        If serr = "1" Then   ' ok
            If dscus.Tables(0).Rows.Count < 1 Then
                MsgBox("no transactions for the selected date")
                Me.btnWeigment.Enabled = True
                Exit Sub
            End If

        Else
            MsgBox("Error 160910 " & serr, MsgBoxStyle.Critical)
            Me.btnWeigment.Enabled = True
            Exit Sub
        End If

        Dim dsMat As DataSet
        Dim drCus As DataRow
        Dim sMat As String

        Dim dsWg As DataSet
        Dim drW As DataRow

        For Each drCus In dscus.Tables(0).Rows
            dsMat = New DataSet
            ComCode = drCus("Custcode")

            sMat = "Select CustName, MatCode, MatName from tblWeighing where "
            sMat = sMat & " custType = 0 "

            If cmbCustType.SelectedIndex > 0 Then

                sMat = sMat & " and CustType = " & Mid(cmbCustType.Text, 1, 1)

            End If

            sMat = sMat & " and weightype <> 1 and CanFlag = 0 "

            sMat = sMat & " and SWDateTime >= '" & Format(dtpFrm.Value, "yyyy-MM-dd") & "'"
            sMat = sMat & " and SWDateTime <= '" & Format(dtpFrm.Value, "yyyy-MM-dd9") & "'"

            sMat = sMat & " and Custcode = '" & ComCode & "'"
            sMat = sMat & " Group by CustName, MatCode, MatName order by CustName, MatCode, MatName"

            serr = ""
            serr = msFillDS(sMat, dsMat)
            If serr <> "1" Then
                Continue For
            End If

            If dsMat.Tables(0).Rows.Count < 1 Then
                Continue For
            End If

            ComName = dsMat.Tables(0).Rows(0)("CustName").ToString

            For mat_header = 0 To dsMat.Tables(0).Rows.Count - 1     ' to take maximum 5 materials

                ComMats(mat_header) = dsMat.Tables(0).Rows(mat_header)("MatName").ToString.Trim

                If mat_header >= 5 Then
                    Exit For
                End If
            Next

            ' reset array
            For j = 0 To 4
                wTot(j) = 0
                For i = 0 To 199
                    w(j, i) = 0
                Next
            Next

            dsWg = New DataSet
            serr = ""

            oldCom = ""
            sW = "Select MatCode, MatName, NWeight from tblWeighing where "
            sW = sW & " custType = 0 and weightype <> 1 and CanFlag = 0 "

            sW = sW & " and SWDateTime >= '" & Format(dtpFrm.Value, "yyyy-MM-dd") & "'"
            sW = sW & " and SWDateTime <= '" & Format(dtpFrm.Value, "yyyy-MM-dd9") & "'"

            sW = sW & " and Custcode = '" & ComCode & "'"
            sW = sW & " order by SWDatetime, WgID "

            serr = msFillDS(sW, dsWg)

            If serr <> "1" Then
                Continue For
            End If

            If dsWg.Tables(0).Rows.Count < 1 Then
                Continue For
            End If

            For Each drW In dsWg.Tables(0).Rows

                MatCode = drW("MatName").ToString.Trim
                If MatCode = ComMats(0) Then
                    j = 0
                ElseIf MatCode = ComMats(1) Then
                    j = 1
                ElseIf MatCode = ComMats(2) Then
                    j = 2
                ElseIf MatCode = ComMats(3) Then
                    j = 3
                ElseIf MatCode = ComMats(4) Then
                    j = 4
                Else
                    j = 9
                End If

                If j < 9 Then
                    wTot(j) = wTot(j) + drW("NWeight")
                    MatNames(j) = drW("MatName").ToString.Trim
                    Me.lblTotWg.Text = Val(Me.lblTotWg.Text) + drW("NWeight")
                    For i = 0 To 199
                        If w(j, i) = 0 Then
                            w(j, i) = drW.Item("NWeight")
                            Exit For
                        End If
                    Next
                End If

            Next

            ' make html table here
            sH = ""
            '                    If oldCom <> ComName Then
            oldCom = ComName
            sH = sH & "         <table border='1' width='100%' id='table1'>"
            sH = sH & "<tr>"
            sH = sH & "<td colspan='6' bgcolor='#FFFF00'>"
            sH = sH & "<p align='center'><b>" & ComName & "</b></td>"
            sH = sH & "</tr>"
            sH = sH & "<tr>"
            My.Computer.FileSystem.WriteAllText(repFile, sH, True)

            sH = "<td align='center'><font color='#0000FF'><b>Sr No</b></font></td>"
            For j = 0 To 4
                sH = sH & "<td align='center'><font color='#0000FF'><b>" & MatNames(j) & "&nbsp;</b></font></td>"
            Next
            sH = sH & "</tr>"
            My.Computer.FileSystem.WriteAllText(repFile, sH, True)

            'End If

            For i = 0 To 199
                sH = "<tr>"

                If w(0, i) = 0 And w(1, i) = 0 And w(2, i) = 0 And w(3, i) = 0 And w(4, i) = 0 Then
                    Exit For
                End If
                sH = sH & "<td   align='center'>" & (i + 1) & "</td>"

                For j = 0 To 4
                    sH = sH & "<td align='center'>" & w(j, i) & "</td>"
                Next


                sH = sH & "</tr>"
                My.Computer.FileSystem.WriteAllText(repFile, sH, True)

            Next

            sH = "<tr>"

            sH = sH & "<td align='center'><font color='#800080'><b>Total</b></font></td>"

            For j = 0 To 4
                sH = sH & "<td align='center' align='center'><font color='#800080'><b>" & wTot(j) & " </b></font></td>"

            Next

            sH = sH & "</tr>"

            My.Computer.FileSystem.WriteAllText(repFile, sH, True)

            gTot = wTot(0) + wTot(1) + wTot(2) + wTot(3) + wTot(4)

            sH = "<tr><td colspan='6' bgcolor='#dddddd'>"
            sH = sH & "<p align='center'><b>" & gTot & "</b></td>"
            sH = sH & "</tr>"

            sH = sH & "</table>"
            sH = sH & "<P>"
            My.Computer.FileSystem.WriteAllText(repFile, sH, True)

        Next


        sH = "<font color='#800080' size = '4'><b>Total Sale : " & Me.lblTotWg.Text & "</b></font>"

        sH = sH & "</body></html>"
        My.Computer.FileSystem.WriteAllText(repFile, sH, True)

        Me.WebBrowser1.Navigate(repFile)

        Me.lblWait.Visible = False

        Me.btnWeigment.Enabled = True


    End Sub

    Private Sub btnOpenWithExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenWithExcel.Click

        Dim f As String
        f = ""

        Dim f2 As String

        Dim fs As New frmStatus
        fs.Show("Opening Microsoft Excel, Please wait ...")

        Try

            f = Replace(nfile, ".html", "")
            f = f & ".xls"

            f2 = Dir(f)
            If f2 <> "" Then
                Kill(f)

            End If

            f = Replace(nfile, ".html", "")
            f = f & ".xls"


            FileCopy(nfile, f)   ' "c:\MyReport.xls")

            ' to check here
            'Shell(Sysvars.ExcelPath & " " & Chr(34) & f & Chr(34))  ' "c:\MyReport.xls")
            Process.Start(f)

        Catch ex As Exception
            MsgBox("Err: 2001" & ex.Message, MsgBoxStyle.Critical)  ' Emoticons.ErrorIcon)

        End Try

        Dim i As Int32
        For i = 1 To 100000
            System.Windows.Forms.Application.DoEvents()
        Next
        fs.Close()

    End Sub

    Private Sub frmWeighmentReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.cmbCustType.Items.Clear()
        cmbCustType.Items.Add("All")
        Dim ds As DataSet
        Dim w As String
        w = mslCons.WebAuthcode

        ds = msWebGetDS("Select * from tblCustTypes order by CustType", w)
        If ds.Tables.Count < 1 Then
            MsgBox("Can not retrieve CustTypes")
            Exit Sub
        End If

        Dim dr As DataRow
        Dim m As Integer

        For m = 0 To ds.Tables(0).Rows.Count - 1
            dr = ds.Tables(0).Rows(m)
            cmbCustType.Items.Add(dr("CustType") & "    " & dr("CustTypeDesc"))
        Next

        Me.cmbCustType.SelectedIndex = 0

    End Sub

End Class