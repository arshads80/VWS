﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mdiVWS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mdiVWS))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCustomers = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMaterials = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuVehicles = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOtherMasters = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransportersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DestinationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSite = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.SeurityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuChangePassword = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUserAdmin = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProcessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuWeighing = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReports = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTrnReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSummaryReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPrepaidCustReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuOnlineWeighment = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilitiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReprint1stTick = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReprintTick = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuEdit1stTicket = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditTicket = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuDel1stTick = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDeleteTicket = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuSystemSettings = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuGlobalSettings = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnVehicle = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnCust = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnMaterial = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnSource = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnLoc = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnSite = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnWeighing = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnTrnReports = New System.Windows.Forms.ToolStripButton()
        Me.btnSummaryReports = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblSite = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblUserName = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblSiteSelected = New System.Windows.Forms.ToolStripLabel()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ProcessToolStripMenuItem, Me.mnuReports, Me.UtilitiesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(5, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1284, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCustomers, Me.mnuMaterials, Me.mnuVehicles, Me.mnuOtherMasters, Me.ToolStripSeparator1, Me.SeurityToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'mnuCustomers
        '
        Me.mnuCustomers.Name = "mnuCustomers"
        Me.mnuCustomers.Size = New System.Drawing.Size(197, 22)
        Me.mnuCustomers.Text = "Customers"
        '
        'mnuMaterials
        '
        Me.mnuMaterials.Name = "mnuMaterials"
        Me.mnuMaterials.Size = New System.Drawing.Size(197, 22)
        Me.mnuMaterials.Text = "Materials"
        '
        'mnuVehicles
        '
        Me.mnuVehicles.Name = "mnuVehicles"
        Me.mnuVehicles.Size = New System.Drawing.Size(197, 22)
        Me.mnuVehicles.Text = "Vehicles"
        '
        'mnuOtherMasters
        '
        Me.mnuOtherMasters.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TransportersToolStripMenuItem, Me.DestinationToolStripMenuItem, Me.mnuSite})
        Me.mnuOtherMasters.Name = "mnuOtherMasters"
        Me.mnuOtherMasters.Size = New System.Drawing.Size(197, 22)
        Me.mnuOtherMasters.Text = "Supporting Masters"
        '
        'TransportersToolStripMenuItem
        '
        Me.TransportersToolStripMenuItem.Name = "TransportersToolStripMenuItem"
        Me.TransportersToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.TransportersToolStripMenuItem.Text = "Source / Transporters"
        '
        'DestinationToolStripMenuItem
        '
        Me.DestinationToolStripMenuItem.Name = "DestinationToolStripMenuItem"
        Me.DestinationToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.DestinationToolStripMenuItem.Text = "Locations / Destinations"
        '
        'mnuSite
        '
        Me.mnuSite.Name = "mnuSite"
        Me.mnuSite.Size = New System.Drawing.Size(226, 22)
        Me.mnuSite.Text = "Sites"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(194, 6)
        '
        'SeurityToolStripMenuItem
        '
        Me.SeurityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuChangePassword, Me.mnuUserAdmin})
        Me.SeurityToolStripMenuItem.Name = "SeurityToolStripMenuItem"
        Me.SeurityToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.SeurityToolStripMenuItem.Text = "Seurity"
        '
        'mnuChangePassword
        '
        Me.mnuChangePassword.Name = "mnuChangePassword"
        Me.mnuChangePassword.Size = New System.Drawing.Size(197, 22)
        Me.mnuChangePassword.Text = "Change Password"
        '
        'mnuUserAdmin
        '
        Me.mnuUserAdmin.Name = "mnuUserAdmin"
        Me.mnuUserAdmin.Size = New System.Drawing.Size(197, 22)
        Me.mnuUserAdmin.Text = "User Administration"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ProcessToolStripMenuItem
        '
        Me.ProcessToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuWeighing})
        Me.ProcessToolStripMenuItem.Name = "ProcessToolStripMenuItem"
        Me.ProcessToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.ProcessToolStripMenuItem.Text = "Process"
        '
        'mnuWeighing
        '
        Me.mnuWeighing.Name = "mnuWeighing"
        Me.mnuWeighing.Size = New System.Drawing.Size(132, 22)
        Me.mnuWeighing.Text = "Weighing"
        '
        'mnuReports
        '
        Me.mnuReports.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuTrnReport, Me.mnuSummaryReport, Me.mnuPrepaidCustReport, Me.ToolStripMenuItem1, Me.mnuOnlineWeighment})
        Me.mnuReports.Name = "mnuReports"
        Me.mnuReports.Size = New System.Drawing.Size(68, 20)
        Me.mnuReports.Text = "Reports"
        '
        'mnuTrnReport
        '
        Me.mnuTrnReport.Name = "mnuTrnReport"
        Me.mnuTrnReport.Size = New System.Drawing.Size(253, 22)
        Me.mnuTrnReport.Text = "Transaction Reports"
        '
        'mnuSummaryReport
        '
        Me.mnuSummaryReport.Name = "mnuSummaryReport"
        Me.mnuSummaryReport.Size = New System.Drawing.Size(253, 22)
        Me.mnuSummaryReport.Text = "Summary Reports"
        '
        'mnuPrepaidCustReport
        '
        Me.mnuPrepaidCustReport.Name = "mnuPrepaidCustReport"
        Me.mnuPrepaidCustReport.Size = New System.Drawing.Size(253, 22)
        Me.mnuPrepaidCustReport.Text = "Pre-paid Customer`s Report"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(250, 6)
        '
        'mnuOnlineWeighment
        '
        Me.mnuOnlineWeighment.Name = "mnuOnlineWeighment"
        Me.mnuOnlineWeighment.Size = New System.Drawing.Size(253, 22)
        Me.mnuOnlineWeighment.Text = "Online Weighment"
        '
        'UtilitiesToolStripMenuItem
        '
        Me.UtilitiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuReprint1stTick, Me.mnuReprintTick, Me.ToolStripSeparator12, Me.mnuEdit1stTicket, Me.mnuEditTicket, Me.ToolStripSeparator11, Me.mnuDel1stTick, Me.mnuDeleteTicket, Me.ToolStripSeparator10, Me.mnuSystemSettings, Me.mnuGlobalSettings})
        Me.UtilitiesToolStripMenuItem.Name = "UtilitiesToolStripMenuItem"
        Me.UtilitiesToolStripMenuItem.Size = New System.Drawing.Size(65, 20)
        Me.UtilitiesToolStripMenuItem.Text = "Utilities"
        '
        'mnuReprint1stTick
        '
        Me.mnuReprint1stTick.Name = "mnuReprint1stTick"
        Me.mnuReprint1stTick.Size = New System.Drawing.Size(183, 22)
        Me.mnuReprint1stTick.Text = "Reprint 1st Ticket"
        '
        'mnuReprintTick
        '
        Me.mnuReprintTick.Name = "mnuReprintTick"
        Me.mnuReprintTick.Size = New System.Drawing.Size(183, 22)
        Me.mnuReprintTick.Text = "Reprint Ticket"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(180, 6)
        '
        'mnuEdit1stTicket
        '
        Me.mnuEdit1stTicket.Name = "mnuEdit1stTicket"
        Me.mnuEdit1stTicket.Size = New System.Drawing.Size(183, 22)
        Me.mnuEdit1stTicket.Text = "Edit 1st Ticket"
        '
        'mnuEditTicket
        '
        Me.mnuEditTicket.Name = "mnuEditTicket"
        Me.mnuEditTicket.Size = New System.Drawing.Size(183, 22)
        Me.mnuEditTicket.Text = "Edit Ticket"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(180, 6)
        '
        'mnuDel1stTick
        '
        Me.mnuDel1stTick.Name = "mnuDel1stTick"
        Me.mnuDel1stTick.Size = New System.Drawing.Size(183, 22)
        Me.mnuDel1stTick.Text = "Delete 1st Ticket"
        '
        'mnuDeleteTicket
        '
        Me.mnuDeleteTicket.Name = "mnuDeleteTicket"
        Me.mnuDeleteTicket.Size = New System.Drawing.Size(183, 22)
        Me.mnuDeleteTicket.Text = "Delete Ticket"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(180, 6)
        '
        'mnuSystemSettings
        '
        Me.mnuSystemSettings.Name = "mnuSystemSettings"
        Me.mnuSystemSettings.Size = New System.Drawing.Size(183, 22)
        Me.mnuSystemSettings.Text = "System Settings"
        '
        'mnuGlobalSettings
        '
        Me.mnuGlobalSettings.Name = "mnuGlobalSettings"
        Me.mnuGlobalSettings.Size = New System.Drawing.Size(183, 22)
        Me.mnuGlobalSettings.Text = "Global Settings"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnVehicle, Me.ToolStripSeparator5, Me.btnCust, Me.ToolStripSeparator6, Me.btnMaterial, Me.ToolStripSeparator7, Me.btnSource, Me.ToolStripSeparator8, Me.btnLoc, Me.ToolStripSeparator9, Me.btnSite, Me.ToolStripSeparator2, Me.btnWeighing, Me.ToolStripSeparator3, Me.btnTrnReports, Me.btnSummaryReports, Me.ToolStripSeparator13, Me.lblSite, Me.ToolStripSeparator4, Me.lblUserName, Me.ToolStripSeparator14, Me.lblSiteSelected})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1284, 39)
        Me.ToolStrip1.TabIndex = 3
        '
        'btnVehicle
        '
        Me.btnVehicle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnVehicle.Image = Global.VWS.My.Resources.Resources.truckyellow
        Me.btnVehicle.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnVehicle.Name = "btnVehicle"
        Me.btnVehicle.Size = New System.Drawing.Size(36, 36)
        Me.btnVehicle.Text = "Vehicle"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 39)
        '
        'btnCust
        '
        Me.btnCust.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnCust.Image = Global.VWS.My.Resources.Resources.Youthedesigner_Digitally_Painted_Folder_user
        Me.btnCust.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnCust.Name = "btnCust"
        Me.btnCust.Size = New System.Drawing.Size(36, 36)
        Me.btnCust.Text = "Customer"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 39)
        '
        'btnMaterial
        '
        Me.btnMaterial.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnMaterial.Image = Global.VWS.My.Resources.Resources.Custom_Icon_Design_Flatastic_6_3d_material_drop_tool
        Me.btnMaterial.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnMaterial.Name = "btnMaterial"
        Me.btnMaterial.Size = New System.Drawing.Size(36, 36)
        Me.btnMaterial.Text = "Material"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 39)
        '
        'btnSource
        '
        Me.btnSource.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnSource.Image = Global.VWS.My.Resources.Resources.source
        Me.btnSource.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSource.Name = "btnSource"
        Me.btnSource.Size = New System.Drawing.Size(36, 36)
        Me.btnSource.Text = "Source / Transporter"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 39)
        '
        'btnLoc
        '
        Me.btnLoc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnLoc.Image = Global.VWS.My.Resources.Resources.Location
        Me.btnLoc.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnLoc.Name = "btnLoc"
        Me.btnLoc.Size = New System.Drawing.Size(36, 36)
        Me.btnLoc.Text = "Location / Destination"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 39)
        '
        'btnSite
        '
        Me.btnSite.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnSite.Image = Global.VWS.My.Resources.Resources.Seanau_3d_House_Factory
        Me.btnSite.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSite.Name = "btnSite"
        Me.btnSite.Size = New System.Drawing.Size(36, 36)
        Me.btnSite.Text = "Site"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 39)
        '
        'btnWeighing
        '
        Me.btnWeighing.Image = Global.VWS.My.Resources.Resources.Icons8_Windows_8_Transport_Weight_Station
        Me.btnWeighing.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnWeighing.Name = "btnWeighing"
        Me.btnWeighing.Size = New System.Drawing.Size(94, 36)
        Me.btnWeighing.Text = "Weighing"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 39)
        '
        'btnTrnReports
        '
        Me.btnTrnReports.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnTrnReports.Image = Global.VWS.My.Resources.Resources.file
        Me.btnTrnReports.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnTrnReports.Name = "btnTrnReports"
        Me.btnTrnReports.Size = New System.Drawing.Size(36, 36)
        Me.btnTrnReports.Text = "Reports"
        '
        'btnSummaryReports
        '
        Me.btnSummaryReports.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnSummaryReports.Image = Global.VWS.My.Resources.Resources._1422475289_order_history
        Me.btnSummaryReports.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSummaryReports.Name = "btnSummaryReports"
        Me.btnSummaryReports.Size = New System.Drawing.Size(36, 36)
        Me.btnSummaryReports.Text = "Summary Reports"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(6, 39)
        '
        'lblSite
        '
        Me.lblSite.Name = "lblSite"
        Me.lblSite.Size = New System.Drawing.Size(29, 36)
        Me.lblSite.Text = "Site:"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 39)
        '
        'lblUserName
        '
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(30, 36)
        Me.lblUserName.Text = "User"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 39)
        '
        'lblSiteSelected
        '
        Me.lblSiteSelected.Name = "lblSiteSelected"
        Me.lblSiteSelected.Size = New System.Drawing.Size(16, 36)
        Me.lblSiteSelected.Text = "   "
        '
        'mdiVWS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1284, 661)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "mdiVWS"
        Me.Text = "Vehicle Weighing System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuCustomers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMaterials As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOtherMasters As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransportersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DestinationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SeurityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuChangePassword As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUserAdmin As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProcessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuReports As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UtilitiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuWeighing As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSummaryReport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSystemSettings As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuGlobalSettings As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuVehicles As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents btnVehicle As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnCust As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnMaterial As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnSource As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnLoc As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnSite As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnWeighing As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnTrnReports As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents lblUserName As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuSite As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnSummaryReports As System.Windows.Forms.ToolStripButton
    Friend WithEvents mnuTrnReport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPrepaidCustReport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDel1stTick As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDeleteTicket As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuOnlineWeighment As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEdit1stTicket As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEditTicket As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuReprint1stTick As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuReprintTick As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents lblSite As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents lblSiteSelected As System.Windows.Forms.ToolStripLabel
End Class
