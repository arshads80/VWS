' **********************************************************
' Module name: MSDNLIB.VB
' Author of the Source Code : MUHAMMAD SIDDIQUE
' Modification Date : 2007-06-11
'       : 2007-06-17
'       : 2007-12-26   fill groupcombo added optional paramter ListMaxcount
'       : 2007-01-10   msfillgrouplist added and fillgroupcombo name changed to msfillgroupcombo
'       : 2007-01-14   msLoadAutoCompleteList
'       : 2007-01-14   msPopulateLastUse and filllastustlist
'       : 2007-01-18   preparetimed report - frmprogressbar added with more public variables

'       : 2009-04-02    msIsInternetOk    

'       : 2008-11-08    taken from msvblib mspropercase
'       : 2008-12-08    msGetFileNameOrPath extracts filename or path
'       : 2008-12-08    modified msstr for any char or string
'       : 2008-12-24    two more icons added in messagebox
'       : 2009-01-18    msGet1stSheetName added
'       : 2009-07-12    msReadReg and msWriteReg - reading and writing ms ini file
'       : 2009-10-28    msDaysinMonth - ret no of days in a month
'       : 2009-10-28    msSetConnectionStringValue
'       : 2010-06-01    msNumInWords modified cos 0.53 is returning .52 and 0.59 is returning 0.58 : problem in INT and Val functions
'       : 2010-08-27    msPrepareCrossTabReport
'       : 2010-09-03    Preparebasicreport is checking now datatype of the sum fields for displaying decimal points
' **********************************************************

Imports System.Data
Imports System.Data.OleDb
Imports System.Media

Module MSDNLIB

#Region "sys vars settings with db handling"


    Private FieldName(2, 1000) As String

    Public Sub msAddSysValue(ByVal sysName As String, ByVal sysVal As String)

        'msMessagebox(sysName & vbCrLf & sysVal)

        Dim i As Integer
        For i = 0 To 999
            If FieldName(0, i) = "" Then
                FieldName(0, i) = sysName
                FieldName(1, i) = sysVal
                Exit For
            End If
        Next

    End Sub

    Public Sub msSetSysValue(ByVal sysName As String, ByVal sysVal As String)

        Dim i As Integer
        For i = 0 To 999
            If FieldName(0, i) = "" Then
                'msMessagebox("Sys vars column: " & sysName & " notfound", Emoticons.ErrorIcon, "Warning")
                FieldName(0, i) = sysName
                FieldName(1, i) = sysVal
                Exit For
            ElseIf FieldName(0, i) = sysName Then
                FieldName(1, i) = sysVal
                Exit For
            End If
        Next

    End Sub

    Public Function msGetSysValue(ByVal sysName As String, Optional ByVal DefaultValue As String = "") As String

        Dim i As Integer

        msGetSysValue = DefaultValue

        For i = 0 To 999
            If FieldName(0, i) = sysName Then
                msGetSysValue = FieldName(1, i)
                Exit Function

            End If
        Next

        If i >= 999 Then ' sysname not exist in database

            Dim dbCn As New OleDbConnection
            If Not msOpenDbConnection(dbCn) Then Exit Function

            Dim d As Integer
            Dim s As String

            ResetUpdateArrays()
            d = 0
            ArUFields(d) = "KeyName"
            ArUValues(d) = sysName
            ArUType(d) = "S"

            d = d + 1
            ArUFields(d) = "KeyValue"
            ArUValues(d) = DefaultValue
            ArUType(d) = "S"

            s = msInsertRec(dbCn, "tblset")
            If Not IsNumeric(s) Then
                msMessagebox(s, Emoticons.ErrorIcon)
            End If
            dbCn.Close()

        End If

    End Function

    Public Sub msClearSysArray()
        Dim i As Int16
        Dim j As Int16
        For i = 0 To 1
            For j = 0 To 999
                FieldName(i, j) = ""
            Next
        Next
    End Sub

    Public Sub msReadSetTable()

        msClearSysArray()

        Dim dbCn5 As New OleDbConnection
        If Not msOpenDbConnection(dbCn5) Then
            msMessagebox("Database connection error", Emoticons.ErrorIcon)
            End
        End If

        Dim cm As OleDb.OleDbCommand
        Dim dr As OleDb.OleDbDataReader
        Dim sStr As String
        sStr = "Select * from tblSet order by KeyName"

        Try
            cm = New OleDbCommand(sStr, dbCn5)
            dr = cm.ExecuteReader()

            Do While dr.Read
                msAddSysValue(dr.Item("KeyName").ToString, dr.Item("KeyValue").ToString)
            Loop

            ' free memory 
            dr.Close()
            cm.Dispose()

        Catch ex As Exception

            msMessagebox(ex.ToString, Emoticons.ErrorIcon2, "Error")

        End Try
        dbCn5.Close()

    End Sub

    Public Sub msWriteSetTable(ByVal prmKeyName As String, ByVal prmkeyValue As String)

        Dim dbCn5 As New OleDbConnection
        If Not msOpenDbConnection(dbCn5) Then Exit Sub
        Dim cm As OleDb.OleDbCommand
        Dim sStr As String
        sStr = "Update tblSet set KeyValue = '" & prmkeyValue & "' where KeyName = '" & prmKeyName & "'"

        Try
            cm = New OleDbCommand(sStr, dbCn5)
            cm.ExecuteNonQuery()
            cm.Dispose()

        Catch ex As Exception
            'MsgBox(ex.ToString, MsgBoxStyle.Critical)

        End Try
        dbCn5.Close()

    End Sub


    
    Public Function msReadReg(ByVal RegField As String, Optional ByVal RegDefValue As String = "", Optional ByVal RegFile As String = "msRegSet.rs") As String

        ' 2009-07-12
        msReadReg = RegDefValue

        If My.Computer.FileSystem.FileExists(RegFile) Then
            ' ok check
        Else
            Exit Function
        End If

        Dim arf(1100) As String

        Dim srf As String
        srf = My.Computer.FileSystem.ReadAllText(RegFile)

        arf = Split(srf, vbCrLf, 1000, CompareMethod.Binary)  ' "^")

        Dim i As Integer
        RegField = Trim(RegField) & "==="

        Dim l As Integer
        l = Len(RegField)

        For i = 0 To 1000
            If Mid(arf(i), 1, l) = RegField Then
                msReadReg = Mid(arf(i), l + 1)
                Exit For
            End If
        Next


    End Function

    Public Sub msWriteReg(ByVal RegField As String, ByVal RegValue As String, Optional ByVal RegFile As String = "msRegSet.rs")

        Dim arf(1100) As String

        Dim srf As String

        If My.Computer.FileSystem.FileExists(RegFile) Then
            srf = My.Computer.FileSystem.ReadAllText(RegFile)
            arf = Split(srf, vbCrLf, 1000, CompareMethod.Binary)  ' "^")
        Else
            'Exit Sub
        End If

        Dim i As Integer
        RegField = Trim(RegField) & "==="
        Dim l As Integer
        l = Len(RegField)

        For i = 0 To 1000
            If Mid(arf(i), 1, l) = RegField Then
                arf(i) = RegField & RegValue
                Exit For
            ElseIf arf(i) = "" Then
                arf(i) = RegField & RegValue
                Exit For
            End If
        Next

        srf = ""

        For i = 0 To 1000
            srf = srf & arf(i) & vbCrLf
        Next

        Try
            My.Computer.FileSystem.WriteAllText(RegFile, srf, False)

        Catch ex As Exception

        End Try


    End Sub


#End Region

#Region "dbconnection"
    Public OleConStr As String
    Public adoConStr As String
    Public dbPath As String


    Public Function msOpenDbConnection(ByRef dbCn As OleDb.OleDbConnection) As Boolean

        If OleConStr = "" Then
            msSetConnectionStringValue()
        End If

        Try
            dbCn = New OleDb.OleDbConnection
            dbCn.ConnectionString = OleConStr
            'MsgBox(OleConStr)

            dbCn.Open()
            msOpenDbConnection = True

        Catch e As Exception

            'msMessagebox(e.Message, Emoticons.ErrorIcon2, "Database Connection Error")
            msOpenDbConnection = False

            If InStr("Err: 2010 " & e.Message, "Not a valid password") > 0 Then
                'End
                Exit Try
            End If


            Dim frmG As New frmStatus               ' ms0813
            frmG.Show("Err: 2000 " & "Database Connection Error")

            msOpenDbConnection = False

            Dim i As Long
            For i = 0 To 50000
                msDoEvents()
            Next
            frmG.Close()

            If msMessagebox("Data base connection Error" & vbCrLf & e.Message, Emoticons.ErrorIcon, "ERROR", "", "Close", "Ignore") = "Close" Then
                End
            End If

            'WriteEvent("dbError")

        End Try

    End Function

    Public Sub msSetConnectionStringValue()

        '2009-10-27

        '2009-10-27

        Dim dbPw As String
        dbPw = ""

        'Dim gPath As String

        'If dbPath = "" Then
        '    'dbPath = My.Computer.FileSystem.CurrentDirectory & "\dbSPS.mdb"
        '    gPath = GetSetting("CBPM" & RegSet, "dbPath", "dbPath", "")

        '    If Trim(gPath) = "" Then
        '        dbPath = sysvars.curPath & "\dbArabBank.accdb"

        '        SaveSetting("CBPM" & RegSet, "dbPath", "dbPath", dbPath)
        '    Else
        '        If sysvars.UseThisPathOnly = "0" Then
        '            If My.Computer.FileSystem.FileExists(gPath) Then
        '                dbPath = gPath
        '            Else
        '                dbPath = 
        '                SaveSetting("CBPM" & RegSet, "dbPath", "dbPath", dbPath)
        '            End If
        '        Else
        '            dbPath = gPath
        '        End If
        '    End If
        'End If

        If dbPath = "" Then

            If DbTyp = "2003" Then
                dbPath = sysvars.curPath & "\dbCBPM_" & Custcode & ".mdb"
            Else
                dbPath = sysvars.curPath & "\dbCBPM_" & Custcode & ".accdb"
            End If

        Else

        End If

        If dbPath.EndsWith(".mdb") Then
            OleConStr = "Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password=" & dbPw & ";Data Source=" & dbPath
        Else
            OleConStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & dbPath & ";Jet OLEDB:Database Password=" & dbPw & ";"
        End If

    End Sub

    'Public Function openAdoConnection(ByRef dbAdoCn As ADODB.Connection) As Boolean

    '    Try
    '        dbAdoCn = New ADODB.Connection
    '        dbAdoCn.ConnectionString = adoConStr
    '        dbAdoCn.Open()
    '        openAdoConnection = True

    '    Catch ex As Exception
    '        msMessagebox(ex.Message, Emoticons.ErrorIcon2, "Database Connection Error")
    '        openAdoConnection = False

    '    End Try

    'End Function

#End Region

#Region "msgeneral"

    Public Enum FormModes
        NormalMode = 0
        EditMode = 1
        AddMode = 2
        SearchMode = 3
    End Enum

    Public Enum Emoticons
        HappyIcon = 21
        HappyIcon2 = 22

        ErrorIcon = 31
        ErrorIcon2 = 32

        ExclamationIcon = 41
        ExclamationIcon2 = 42

        OkIcon = 51
        OkIcon2 = 52
        OkHand = 53

        QuestionIcon = 61

        SadIcon = 71

        StopIcon = 81

        TeleMessageIcon = 91

        WrongEntryIcon = 101
        AngryIcon = 102

        TeasingIcon = 111
        TeasingIcon2 = 112

    End Enum

    Public Function msMessagebox(ByVal cMsg As String, Optional ByVal iconCode As Emoticons = 21, Optional ByVal cTitle As String = "", Optional ByVal bt1 As String = "", Optional ByVal bt2 As String = "", Optional ByVal bt3 As String = "Ok") As String

        Dim frmM As New frmMsgBox
        Try
            If iconCode = Emoticons.ErrorIcon Then
                'SystemSounds.Hand.Play()

            End If
        Catch ex As Exception

        End Try
        
        msMessagebox = frmM.ShowDialog(cMsg, bt1, bt2, bt3, iconCode, cTitle)


    End Function

    Public Const msCancel As String = "~`uu~^#~"
    Public Const mmToTwips As Single = 56.667
    Public Const inchToMm As Single = 25.4
    Public Const Lfs As String = " | "   ' list field separator


    Public Function msInputBox(Optional ByVal cMsg As String = "Input", Optional ByVal cDefaultValue As String = "", Optional ByVal nInputLen As Integer = 0) As String
        Dim frmm As New frmInputBox
        msInputBox = frmm.ShowDialog(cMsg, cDefaultValue, nInputLen)

    End Function

    Public Function msStr(ByVal sNum As String, ByVal lLen As Integer, Optional ByVal PadChar As String = "0") As String


        'msStr = Right("000000000000000000000000000000" & sNum, lLen)
        msStr = Microsoft.VisualBasic.Right(StrDup(lLen, PadChar) & sNum, lLen)



    End Function

    Public Enum textAlign
        Left = 0
        Right = 1

        Center = 2
    End Enum

    

    Public Function msAlignText(ByVal cText As String, ByVal nLen As Int16, Optional ByVal TextAlignment As textAlign = 0) As String
        Dim i As Int16
        msAlignText = ""

        Select Case TextAlignment
            Case 0
                msAlignText = Left(cText & Space(nLen), nLen)
            Case 1
                msAlignText = Right(Space(nLen) & cText, nLen)
            Case 2
                If Len(cText) < nLen Then
                    i = (nLen - Len(cText)) / 2
                    msAlignText = Left(Space(i) & cText & Space(nLen), nLen)
                Else
                    msAlignText = cText
                End If

        End Select

    End Function


    ''''''' folg function is directly taken from msvblib
    Public Function msNumInWords(ByVal prmnNum As String, Optional ByVal BigUnit As String = " ", Optional ByVal SmlUnit As String = " ") As String

        ' last modification 2010-02-26
        ' last modification 2010-06-01

        Dim nNum As Double

        prmnNum = Replace(prmnNum, ",", "")
        prmnNum = Replace(prmnNum, " ", "")
        prmnNum = Replace(prmnNum, "-", "")

        If IsNumeric(prmnNum) Then
            nNum = prmnNum
        Else
            msNumInWords = ""
            Exit Function
        End If


        Dim BeforeDec, AfterDec As String
        Dim tDig, tW As String

        'Dim i As Integer

        Dim W As String

        'Dim sg As Single
        'sg = 0

        'Dim mg As Single

        Dim dotpos As Integer
        dotpos = InStr(prmnNum, ".")

        If nNum < 0 Then nNum = nNum * -1

        If dotpos > 0 Then
            BeforeDec = Mid(prmnNum, 1, dotpos - 1)
            AfterDec = Mid(prmnNum, dotpos + 1)
        Else
            BeforeDec = prmnNum
            AfterDec = "0"
        End If

        'BeforeDec = CInt(Int(nNum))
        'sg = nNum - CLng(BeforeDec)
        

        'sg = nNum - Val(BeforeDec)
        ''mg = (sg + 0.001) * 100
        'If sg = 0.53 Then  
        '    mg = 53  ' is acutally returning 52
        'ElseIf sg = 0.59 Then
        '    mg = 59   ' isactually returning 58
        'Else
        '    mg = sg * 100
        'End If

        'AfterDec = CInt(Int(mg))

        If Val(BeforeDec) = 0 Then
            W = "Zero "
            GoTo getFills
        End If

        tDig = Right(BeforeDec, 3)
        tW = threeDig(msStr(tDig, 3))
        W = tW

        If Len(BeforeDec) <= 3 Then
            GoTo getFills
        ElseIf Len(BeforeDec) > 3 And Len(BeforeDec) < 7 Then
            tDig = Left(BeforeDec, Len(BeforeDec) - 3)
        Else
            tDig = Mid(BeforeDec, Len(BeforeDec) - 6 + 1, 3)
        End If
        tW = threeDig(msStr(tDig, 3))

        ''''''''''''''''''''''''''''''''''''
        '        If tW = "One " Then
        W = tW & "Thousand " & W
        'Else
        'W = tW & "Thousands " & W
        'End If
        ''''''''''''''''''''''''''''''''''''

        If Len(BeforeDec) <= 6 Then
            GoTo getFills
        ElseIf Len(BeforeDec) > 6 And Len(BeforeDec) < 9 Then
            tDig = Left(BeforeDec, Len(BeforeDec) - 6)
        Else
            tDig = Mid(BeforeDec, Len(BeforeDec) - 9 + 1, 3)
        End If
        tW = threeDig(msStr(tDig, 3))
        W = tW & "Million " & W
        W = Replace(W, "Million Thousand", "Million")


getFills:
        W = BigUnit & " " & W & "and " & SmlUnit & " "

        If Val(AfterDec) = 0 Then
            tW = "Zero "
        Else
            tW = threeDig(msStr(AfterDec, 3))
        End If

        'W = W & tW & SmlUnit & " " & "Only"
        W = W & tW & "Only"

        msNumInWords = W


    End Function

    ' this function is being called by msnuminwords
    Private Function threeDig(ByVal ctDig As String) As String
        Dim im As Integer
        Dim W As String
        W = ""
        im = Mid(ctDig, 3, 1)
        Select Case im
            Case 1
                W = "One "
            Case 2
                W = "Two "
            Case 3
                W = "Three "
            Case 4
                W = "Four "
            Case 5
                W = "Five "
            Case 6
                W = "Six "
            Case 7
                W = "Seven "
            Case 8
                W = "Eight "
            Case 9
                W = "Nine "
        End Select

        im = Mid(ctDig, 2, 1)
        Select Case im
            Case 1
                im = Mid(ctDig, 2, 2)
                Select Case im
                    Case 10
                        W = "Ten "
                    Case 11
                        W = "Eleven "
                    Case 12
                        W = "Twelve "
                    Case 13
                        W = "Thirteen "
                    Case 14
                        W = "Fourteen "
                    Case 15
                        W = "Fifteen "
                    Case 16
                        W = "Sixteen "
                    Case 17
                        W = "Seventeen "
                    Case 18
                        W = "Eighteen "
                    Case 19
                        W = "Ninteen "
                End Select
            Case 2
                W = "Twenty " + W
            Case 3
                W = "Thirty " + W
            Case 4
                W = "Forty " + W
            Case 5
                W = "Fifty " + W
            Case 6
                W = "Sixty " + W
            Case 7
                W = "Seventy " + W
            Case 8
                W = "Eighty " + W
            Case 9
                W = "Ninety " + W
        End Select

        im = Mid(ctDig, 1, 1)
        Select Case im
            Case 1
                W = "One Hundred " + W
            Case 2
                W = "Two Hundred " + W
            Case 3
                W = "Three Hundred " + W
            Case 4
                W = "Four Hundred " + W
            Case 5
                W = "Five Hundred " + W
            Case 6
                W = "Six Hundred " + W
            Case 7
                W = "Seven Hundred " + W
            Case 8
                W = "Eight Hundred " + W
            Case 9
                W = "Nine Hundred " + W
        End Select

        threeDig = W

    End Function

    Public Function msdate(ByVal dt As Date) As String

        msdate = Format(dt, "yyyy-MM-dd")

    End Function

    Public Function msdateToDate(ByVal myDt As String) As String

        msdateToDate = ""
        If Len(myDt) = 10 Then
            msdateToDate = Mid(myDt, 9, 2) & "-" & Mid(myDt, 6, 2) & "-" & Mid(myDt, 1, 4)
        End If

    End Function

    Public Function msDateTime(ByVal dtTm As Date) As String
        msDateTime = Format(dtTm, "yyyyMMddHHmm")

    End Function

    Public Function msDaysinMonth(ByVal dt As Date) As Integer

        ' 2009-10-28
        Dim x As Integer
        x = dt.Month
        If x = 4 Or x = 6 Or x = 9 Or x = 11 Then
            msDaysinMonth = 30
        ElseIf x = 2 Then
            If dt.Year Mod 4 = 0 Then
                msDaysinMonth = 29
            Else
                msDaysinMonth = 28
            End If
        Else
            msDaysinMonth = 31
        End If

    End Function


    Public Sub msDoEvents()
        System.Windows.Forms.Application.DoEvents()

    End Sub

    Public Function msGetStringbreak(ByVal cText As String, ByVal AvgLen As Integer) As Integer

        If Len(cText) < 25 Then
            msGetStringbreak = Len(cText)
            Exit Function
        End If

        If AvgLen < 15 Then
            msGetStringbreak = Len(cText)
            Exit Function
        End If

        Dim s As String
        
        Dim i As Integer
        s = cText

        If Len(s) > AvgLen Then
            For i = AvgLen - 10 To Len(s)
                If Mid(s, i, 1) = " " Then
                    msGetStringbreak = i
                    Exit For
                End If
            Next
        End If

    End Function

    '  autocompletelist handling
    Public lastUseList(500) As String
    Public LastInx As Integer

    Public Sub msPopulateLastUse(ByVal ctxt As String)

        lastUseList(LastInx) = ctxt
        LastInx = LastInx + 1
        If LastInx >= UBound(lastUseList) Then LastInx = 1

    End Sub

    Public Sub msFillLastUSe(ByVal ctBox As TextBox)

        Dim i As Integer
        For i = 1 To UBound(lastUseList)
            If lastUseList(i) = "" Then Exit For
            ctBox.AutoCompleteCustomSource.Add(lastUseList(i))
        Next

    End Sub

    Public Function msGetTimeDuration(ByVal t1 As String, ByVal t2 As String) As String

        ' takes 2 times in HH:mm format and  returns t2-t1 
        msGetTimeDuration = "00:00"
        Dim h As Integer
        Dim m As Integer
        m = Val(Mid(t2, 4, 2)) - Val(Mid(t1, 4, 2))
        h = Val(Mid(t2, 1, 2)) - Val(Mid(t1, 1, 2))
        m = m + h * 60

        msGetTimeDuration = msStr(Int(m / 60), 2) & ":" & msStr(m Mod 60, 2)


    End Function




    Public Function msProperCase(ByVal cText As String) As String

        ' taken from msvblib 2008-11-08

        Dim cnt, i As Integer
        Dim rText As String
        Dim makeup As Boolean
        Dim oneChar As String

        cnt = Len(cText)
        rText = ""

        If cnt = 0 Then
            msProperCase = ""
            Exit Function
        End If

        For i = 1 To cnt
            If i = 1 Then
                makeup = True
            End If

            oneChar = Mid(cText, i, 1)

            If makeup Then
                rText = rText & UCase(oneChar)
            Else
                rText = rText & LCase(oneChar)
            End If

            If oneChar = " " Or oneChar = "." Or oneChar = "," Or oneChar = "/" Or oneChar = "(" Or oneChar = ")" Or oneChar = "[" Or oneChar = "]" Or oneChar = "{" Or oneChar = "}" Or oneChar = "-" Or oneChar = "=" Or oneChar = "&" Or oneChar = "*" Or oneChar = "%" Then
                makeup = True
            Else
                makeup = False
            End If

        Next

        rText = Replace(rText, " Of ", " of ")
        rText = Replace(rText, " Llc", " LLC")
        rText = Replace(rText, " Fzco", " FZCO")

        msProperCase = rText

    End Function

    Public Function msGetFileNameOrPath(ByVal fFullName As String, ByVal F_or_P As String) As String

        ' extracts file name or path from full filename string
        ' 2008-12-08

        Dim fp As String
        fp = LCase(F_or_P)

        msGetFileNameOrPath = ""

        If fFullName = "" Then Exit Function
        If InStr(fFullName, "\") = 0 Then
            If fp = "f" Then
                msGetFileNameOrPath = fFullName


            End If
            Exit Function

        End If

        Dim i As Integer
        For i = Len(fFullName) To 1 Step -1
            If Mid(fFullName, i, 1) = "\" Then Exit For
        Next

        If fp = "f" Then
            msGetFileNameOrPath = Mid(fFullName, i + 1)
        Else
            msGetFileNameOrPath = Mid(fFullName, 1, i - 1)

        End If


    End Function

#End Region

#Region "List_combos"

    Public Sub SelectComboTextItem(ByVal cmbCombo As ComboBox, ByVal txtItem As String)

        If cmbCombo.Items.Count < 1 Then Exit Sub

        Dim i As Integer
        For i = 0 To cmbCombo.Items.Count - 1
            If cmbCombo.Items(i).ToString = txtItem Then
                cmbCombo.SelectedIndex = i
                Exit For
            End If
        Next

    End Sub

#End Region

#Region "msgeneral_db_related"

    Public ArUFields(20) As String
    'Public ArUHeader(20) As String
    Public ArUType(20) As String
    'Public ArUSize(20) As Integer
    Public ArUValues(20) As String   ' used for insert and update

    'Public All_Tot_recs_U As Long

    Public Const ArBoundU = 19

    
    Public Sub ResetUpdateArrays(Optional ByVal ForceReset As Boolean = False)

        Dim i As Integer

        If Not ForceReset Then
            Do While True
                If ArUFields(0) = "" Then
                    Exit Do
                Else
                    Console.Write("Update mode")

                End If
                msDoEvents()
            Loop

        End If

        For i = 0 To ArBoundU

            ArUFields(i) = ""
            ArUType(i) = ""  ' N and S(non N)  only   not used like reports  c n f d s ts
            'ArUSize(i) = 0
            ArUValues(i) = ""

        Next

        'All_Tot_recs = 0
        'Finish_Reporting = False
        'Curr_rec = 0


    End Sub

    Public Function msGetGroupName(ByRef prmDbCnG As OleDbConnection, ByVal prmStrSql As String) As String

        msGetGroupName = ""
        'Dim dbCnG As New oledbConnection
        'If Not OpenDbConnection(dbCnG) Then Exit Function

        'Dim sStr As String
        Dim cm As OleDb.OleDbCommand
        Dim dr As OleDb.OleDbDataReader

        Try

            cm = New OleDb.OleDbCommand(prmStrSql, prmDbCnG)
            dr = cm.ExecuteReader()
            If dr.Read Then
                msGetGroupName = dr.Item(1).ToString()
            End If
            dr.Close()

        Catch ex As Exception
            msMessagebox("Err: 2034 " & ex.Message, MSDNLIB.Emoticons.ErrorIcon2)

        End Try

    End Function

    Public Function msGetFieldValue(ByRef PrmDbCn As OleDbConnection, ByVal prmStrSql As String, Optional ByVal FieldName As String = "") As String

        msGetFieldValue = ""
        'Dim dbCnG As New oledbConnection
        'If Not OpenDbConnection(dbCnG) Then Exit Function
        Dim cm As OleDb.OleDbCommand
        Dim dr As OleDb.OleDbDataReader

        Try

            cm = New OleDb.OleDbCommand(prmStrSql, PrmDbCn)
            dr = cm.ExecuteReader()
            If dr.Read Then

                If FieldName = "" Then
                    msGetFieldValue = dr.Item(0).ToString()
                Else
                    msGetFieldValue = dr.Item(FieldName).ToString()
                End If

            End If
            dr.Close()

        Catch ex As Exception
            msMessagebox("Err: 2035 " & ex.Message, MSDNLIB.Emoticons.ErrorIcon2)

        End Try

    End Function

    Public Function msGetFieldValue_2018(ByVal prmStrSql As String, Optional ByVal PrmDbCn110407 As OleDbConnection = Nothing, Optional ByVal FieldName As String = "") As String

        Dim mustclosedbcon As Boolean
        mustclosedbcon = False

        msGetFieldValue_2018 = ""
        If PrmDbCn110407 Is Nothing Then
            If Not msOpenDbConnection(PrmDbCn110407) Then Exit Function
            mustclosedbcon = True
        End If

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader

        Try

            cm = New OleDbCommand(prmStrSql, PrmDbCn110407)
            dr = cm.ExecuteReader()
            If dr.Read Then

                If FieldName = "" Then
                    msGetFieldValue_2018 = dr.Item(0).ToString()
                Else
                    msGetFieldValue_2018 = dr.Item(FieldName).ToString()
                End If

            End If
            dr.Close()

        Catch ex As Exception
            MessageBox.Show("Err: 110407 " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

        If mustclosedbcon Then
            PrmDbCn110407.Close()
        End If

    End Function

    Public Sub msFillGroupCombo(ByVal prmStrSql As String, ByVal LB As ComboBox, Optional ByVal ListMaxCount As Integer = 0)

        Dim lstItem As New msListItem

        LB.Items.Clear()
        'Me.ListBox1.Items.Clear()

        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout
        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
        Dim x As Integer
        Dim cnt As Integer

        Try

            cm = New OleDbCommand(prmStrSql, dbCn)
            dr = cm.ExecuteReader

            Do While dr.Read

                lstItem = New msListItem(dr.Item(1).ToString, dr.Item(0).ToString)
                x = LB.Items.Add(lstItem)

                'If dr.Item("GroupID") = FindCode Then
                'Me.ListBox1.SelectedIndex = x
                'End If

                cnt = cnt + 1
                If ListMaxCount > 0 Then
                    If cnt >= ListMaxCount Then Exit Do
                End If

            Loop

            dr.Close()
            cm.Dispose()

        Catch ex As Exception
            msMessagebox("Err: 2036 " & ex.Message, Emoticons.ErrorIcon)

        End Try

        dbCn.Close()

gout:

    End Sub

    Public Sub msFillGroupList(ByVal prmStrSql As String, ByVal LB As ListBox, Optional ByVal ListMaxCount As Integer = 0, Optional ByVal SelectedID As String = "")

        Dim lstItem As New msListItem

        LB.Items.Clear()
        'Me.ListBox1.Items.Clear()

        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout
        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
        Dim x As Integer
        Dim cnt As Integer

        Try

            cm = New OleDbCommand(prmStrSql, dbCn)
            dr = cm.ExecuteReader

            Do While dr.Read

                lstItem = New msListItem(dr.Item(1).ToString, dr.Item(0).ToString)
                x = LB.Items.Add(lstItem)

                If SelectedID <> "" Then
                    If dr.Item(0).ToString.Trim = SelectedID Then
                        LB.SelectedIndex = x
                    End If
                End If

                cnt = cnt + 1
                If ListMaxCount > 0 Then
                    If cnt >= ListMaxCount Then Exit Do
                End If

            Loop

            dr.Close()
            cm.Dispose()

        Catch ex As Exception
            msMessagebox("Err: 2037 " & ex.Message, Emoticons.ErrorIcon)

        End Try

        dbCn.Close()

gout:

    End Sub


    Public Function msInsertRec(ByRef prmDbCng As OleDbConnection, ByVal prmTableName As String) As String

        Dim i As Integer
        Dim s As String

        s = "Insert Into " & prmTableName & "( "
        s = s & "[" & ArUFields(0) & "]"

        For i = 1 To ArBoundU
            If ArUFields(i) <> "" Then
                s = s & ", [" & ArUFields(i) & "]"
            End If
        Next

        s = s & " ) Values ( "
        If ArUType(0) = "N" Then
            s = s & ArUValues(0)
        Else
            s = s & "'" & Replace(ArUValues(0), "'", "") & "'"
        End If

        For i = 1 To ArBoundU

            If ArUFields(i) <> "" Then
                If ArUType(i) = "N" Then
                    s = s & ", " & ArUValues(i)
                Else
                    s = s & ", '" & Replace(ArUValues(i), "'", "") & "'"
                End If
            End If

        Next

        s = s & " ) "

        Dim cm As OleDbCommand
        Try
            cm = New OleDbCommand(s, prmDbCng)
            i = cm.ExecuteNonQuery
            msInsertRec = i
        Catch ex As Exception
            msInsertRec = ex.Message
            'MsgBox(ex.ToString)   ' to put this

        End Try

        ResetUpdateArrays(True)


    End Function

    Public Function msUpdateRec(ByRef prmDbCng As OleDbConnection, ByVal prmTableName As String, ByVal prmWhereExp As String) As String

        Dim i As Integer
        Dim s As String

        s = "Update " & prmTableName & " Set "
        s = s & "[" & ArUFields(0) & "] = "
        If ArUType(0) = "N" Then
            s = s & ArUValues(0)
        Else
            s = s & "'" & Replace(ArUValues(0), "'", " ") & "'"
        End If

        For i = 1 To ArBoundU
            If ArUFields(i) <> "" Then
                s = s & ", [" & ArUFields(i) & "] = "
                If ArUType(i) = "N" Then
                    s = s & " " & ArUValues(i)
                Else   ' S
                    s = s & " '" & Replace(ArUValues(i), "'", " ") & "'"
                End If
            End If

        Next

        If prmWhereExp <> "" Then
            s = s & " where " & prmWhereExp
        End If


        'Dim dbCnI As New oledbConnection
        'If Not OpenDbConnection(dbCnI) Then
        'msInsertRec = "DB Connection Error"
        'Exit Function
        'End If

        Dim cm As OleDbCommand
        Try
            cm = New OleDbCommand(s, prmDbCng)
            i = cm.ExecuteNonQuery
            msUpdateRec = i
        Catch ex As Exception
            msUpdateRec = ex.Message
            'MsgBox(ex.ToString)

        End Try
        ResetUpdateArrays(True)

    End Function

    Public Sub msLoadAutoCompleteList(ByRef dbCn As OleDbConnection, ByRef txtBox As TextBox, ByVal SQLStr As String, Optional ByVal list_count As Integer = 0)
        Dim i As Integer
        i = 0
        Try
            Dim cm As OleDbCommand
            Dim dr As OleDbDataReader
            cm = New OleDbCommand(SQLStr, dbCn)
            dr = cm.ExecuteReader
            Do While dr.Read
                txtBox.AutoCompleteCustomSource.Add(dr.Item(0).ToString)
                i = i + 1
                If list_count = 0 Then
                    msDoEvents()
                Else
                    If i > list_count Then
                        Exit Do
                    End If
                End If

            Loop
            dr.Close()
            cm.Dispose()
        Catch ex As Exception
            msMessagebox("Err: 2039 " & ex.Message)

        End Try

    End Sub

#End Region

#Region "MS Office"
    Public Function msGet1stSheetName(ByRef prmDbCnExc As OleDbConnection) As String

        msGet1stSheetName = ""
        'Dim cnExc As New oledbConnection
        'Dim conStr As String
        Dim dt As New DataTable
        Dim ExcSheetName As String
        Dim row As DataRow


        Try
            'conStr = "Provider=Microsoft.Jet.oledb.4.0;" & "Data Source=" & prmExcelFile & ";Extended Properties=Excel 8.0;"
            'cnExc.ConnectionString = conStr
            'cnExc.Open()
            dt = prmDbCnExc.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
            row = dt.Rows(0)
            ExcSheetName = row("TABLE_NAME").ToString
            msGet1stSheetName = ExcSheetName

            'cnExc.Close()

        Catch ex As Exception
            msMessagebox(ex.Message, Emoticons.ErrorIcon, "Error 4101")

        End Try


    End Function
#End Region


#Region "API calls"
    Private Declare Function GetVolumeInformation Lib "kernel32" Alias "GetVolumeInformationA" (ByVal lpRootPathName As String, ByVal lpVolumeNameBuffer As String, ByVal nVolumeNameSize As Integer, ByRef lpVolumeSerialNumber As Integer, ByRef lpMaximumComponentLength As Integer, ByRef lpFileSystemFlags As Integer, ByVal lpFileSystemNameBuffer As String, ByVal nFileSystemNameSize As Integer) As Integer

    Public Function msGetHDserial(ByVal rDr As String) As String

        Dim root As String
        Dim volume_name As String
        Dim serial_number As Integer
        Dim max_component_length As Integer
        Dim file_system_flags As Integer
        Dim file_system_name As String
        Dim pos As Integer

        root = rDr
        volume_name = Space(1024)
        file_system_name = Space(1024)

        If GetVolumeInformation(root, volume_name, Len(volume_name), serial_number, max_component_length, file_system_flags, file_system_name, Len(file_system_name)) = 0 Then
            MessageBox.Show("Error getting volume information.", "Error Getting Information", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            msGetHDserial = ""
            Exit Function
        End If

        pos = volume_name.IndexOf(Chr(0))
        volume_name = volume_name.Substring(0, pos)
        'lblVolumeName.Text = volume_name
        msGetHDserial = serial_number.ToString
        'lblMaxComponentLength.Text = max_component_length.ToString

        'pos = file_system_name.IndexOf(Chr(0))
        'file_system_name = file_system_name.Substring(0, pos)
        'lblFileSystem.Text = file_system_name

        'lblFlags.Text = "&&H" & Hex$(file_system_flags)

    End Function

    

#End Region

#Region "security codes"
    Public Function msEncryptData(ByVal Ctext As String) As String


        Dim a(256) As String
        a(0) = "D1"
        a(1) = "4H"
        a(2) = "D2"
        a(3) = "2J"
        a(4) = "D0"
        a(5) = "8K"
        a(6) = "5H"
        a(7) = "0A"
        a(8) = "L0"
        a(9) = "7I"
        a(10) = "I6"
        a(11) = "8T"
        a(12) = "T7"
        a(13) = "0N"
        a(14) = "M9"
        a(15) = "8M"
        a(16) = "T6"
        a(17) = "A1"
        a(18) = "4Q"
        a(19) = "U0"
        a(20) = "3J"
        a(21) = "45"
        a(22) = "36"
        a(23) = "6S"
        a(24) = "H3"
        a(25) = "8F"
        a(26) = "27"
        a(27) = "Q2"
        a(28) = "9F"
        a(29) = "Q3"
        a(30) = "G0"
        a(31) = "88"
        a(32) = "R5"
        a(33) = "C9"
        a(34) = "6M"
        a(35) = "M7"
        a(36) = "1L"
        a(37) = "D4"
        a(38) = "3D"
        a(39) = "F7"
        a(40) = "K7"
        a(41) = "9K"
        a(42) = "H6"
        a(43) = "J1"
        a(44) = "5F"
        a(45) = "I8"
        a(46) = "I5"
        a(47) = "9T"
        a(48) = "U1"
        a(49) = "N1"
        a(50) = "U2"
        a(51) = "5T"
        a(52) = "U3"
        a(53) = "A2"
        a(54) = "0E"
        a(55) = "E1"
        a(56) = "J4"
        a(57) = "43"
        a(58) = "E2"
        a(59) = "S7"
        a(60) = "H2"
        a(61) = "D9"
        a(62) = "5S"
        a(63) = "Q1"
        a(64) = "R6"
        a(65) = "0P"
        a(66) = "G1"
        a(67) = "99"
        a(68) = "3E"
        a(69) = "C8"
        a(70) = "M5"
        a(71) = "7D"
        a(72) = "L2"
        a(73) = "A7"
        a(74) = "5D"
        a(75) = "F6"
        a(76) = "K6"
        a(77) = "D6"
        a(78) = "7H"
        a(79) = "J0"
        a(80) = "F3"
        a(81) = "4A"
        a(82) = "4I"
        a(83) = "W8"
        a(84) = "X9"
        a(85) = "N2"
        a(86) = "6V"
        a(87) = "V7"
        a(88) = "4U"
        a(89) = "A3"
        a(90) = "Q5"
        a(91) = "53"
        a(92) = "J5"
        a(93) = "7Z"
        a(94) = "S8"
        a(95) = "H0"
        a(96) = "1H"
        a(97) = "Z6"
        a(98) = "9G"
        a(99) = "Z5"
        a(100) = "R7"
        a(101) = "P1"
        a(102) = "G2"
        a(103) = "0Q"
        a(104) = "E4"
        a(105) = "7C"
        a(106) = "R4"
        a(107) = "T4"
        a(108) = "3L"
        a(109) = "A6"
        a(110) = "M4"
        a(111) = "5K"
        a(112) = "E5"
        a(113) = "S4"
        a(114) = "H8"
        a(115) = "9I"
        a(116) = "F2"
        a(117) = "A5"
        a(118) = "I3"
        a(119) = "7W"
        a(120) = "0X"
        a(121) = "N3"
        a(122) = "5V"
        a(123) = "8V"
        a(124) = "U5"
        a(125) = "X8"
        a(126) = "Q6"
        a(127) = "82"
        a(128) = "6J"
        a(129) = "4C"
        a(130) = "S9"
        a(131) = "Z4"
        a(132) = "W0"
        a(133) = "9V"
        a(134) = "G8"
        a(135) = "R8"
        a(136) = "5C"
        a(137) = "P2"
        a(138) = "G3"
        a(139) = "0T"
        a(140) = "P9"
        a(141) = "Z3"
        a(142) = "3R"
        a(143) = "L5"
        a(144) = "L4"
        a(145) = "6C"
        a(146) = "M3"
        a(147) = "4K"
        a(148) = "E6"
        a(149) = "S3"
        a(150) = "H9"
        a(151) = "T3"
        a(152) = "4F"
        a(153) = "F1"
        a(154) = "2I"
        a(155) = "W6"
        a(156) = "X1"
        a(157) = "4N"
        a(158) = "V4"
        a(159) = "X7"
        a(160) = "U6"
        a(161) = "2Z"
        a(162) = "7Q"
        a(163) = "11"
        a(164) = "J7"
        a(165) = "W1"
        a(166) = "C3"
        a(167) = "T1"
        a(168) = "C2"
        a(169) = "C1"
        a(170) = "G7"
        a(171) = "R9"
        a(172) = "P3"
        a(173) = "G6"
        a(174) = "G4"
        a(175) = "5G"
        a(176) = "P8"
        a(177) = "0B"
        a(178) = "A9"
        a(179) = "L6"
        a(180) = "2R"
        a(181) = "A8"
        a(182) = "M2"
        a(183) = "3K"
        a(184) = "E7"
        a(185) = "S2"
        a(186) = "I0"
        a(187) = "8E"
        a(188) = "I1"
        a(189) = "F0"
        a(190) = "9E"
        a(191) = "5W"
        a(192) = "X2"
        a(193) = "N5"
        a(194) = "V3"
        a(195) = "Z1"
        a(196) = "U7"
        a(197) = "Y6"
        a(198) = "B9"
        a(199) = "O0"
        a(200) = "8J"
        a(201) = "B8"
        a(202) = "2W"
        a(203) = "Q8"
        a(204) = "7Y"
        a(205) = "C0"
        a(206) = "8Y"
        a(207) = "Y5"
        a(208) = "4P"
        a(209) = "Y4"
        a(210) = "P7"
        a(211) = "Z0"
        a(212) = "R1"
        a(213) = "B1"
        a(214) = "3Y"
        a(215) = "7L"
        a(216) = "L8"
        a(217) = "1S"
        a(218) = "M1"
        a(219) = "K2"
        a(220) = "L9"
        a(221) = "5X"
        a(222) = "Y9"
        a(223) = "X3"
        a(224) = "2Y"
        a(225) = "X4"
        a(226) = "T2"
        a(227) = "W4"
        a(228) = "9W"
        a(229) = "N6"
        a(230) = "V2"
        a(231) = "Y1"
        a(232) = "8U"
        a(233) = "W3"
        a(234) = "N9"
        a(235) = "8N"
        a(236) = "J9"
        a(237) = "B7"
        a(238) = "K0"
        a(239) = "Q9"
        a(240) = "N7"
        a(241) = "Y0"
        a(242) = "B6"
        a(243) = "6X"
        a(244) = "P5"
        a(245) = "B5"
        a(246) = "P6"
        a(247) = "V1"
        a(248) = "R0"
        a(249) = "2B"
        a(250) = "B3"
        a(251) = "B4"
        a(252) = "V0"
        a(253) = "0S"
        a(254) = "M0"
        a(255) = "K1"

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As Integer
        sR = ""
        If Ctext = "" Then
            msEncryptData = ""
            Exit Function
        End If

        nl = Len(Ctext)
        Dim p As String

        For i = 1 To nl
            p = Mid(Ctext, i, 1)
            aski = Asc(p)
            l = l + aski
            sR = sR & a(aski)
        Next

        Dim m201 As Integer
        m201 = l Mod 201

        sR = a(m201) & sR

        msEncryptData = sR


    End Function

    Public Function msDecryptData(ByVal Ctext As String) As String
        ' this function returns text encrypted by encrypt data function
        ' but it gives first character 0 or 1
        ' 0 - checksum not ok - data is temperred
        ' 1 - checksum ok - returns original data encrypted by encryptdata function


        Dim a(256) As String
        a(0) = "D1"
        a(1) = "4H"
        a(2) = "D2"
        a(3) = "2J"
        a(4) = "D0"
        a(5) = "8K"
        a(6) = "5H"
        a(7) = "0A"
        a(8) = "L0"
        a(9) = "7I"
        a(10) = "I6"
        a(11) = "8T"
        a(12) = "T7"
        a(13) = "0N"
        a(14) = "M9"
        a(15) = "8M"
        a(16) = "T6"
        a(17) = "A1"
        a(18) = "4Q"
        a(19) = "U0"
        a(20) = "3J"
        a(21) = "45"
        a(22) = "36"
        a(23) = "6S"
        a(24) = "H3"
        a(25) = "8F"
        a(26) = "27"
        a(27) = "Q2"
        a(28) = "9F"
        a(29) = "Q3"
        a(30) = "G0"
        a(31) = "88"
        a(32) = "R5"
        a(33) = "C9"
        a(34) = "6M"
        a(35) = "M7"
        a(36) = "1L"
        a(37) = "D4"
        a(38) = "3D"
        a(39) = "F7"
        a(40) = "K7"
        a(41) = "9K"
        a(42) = "H6"
        a(43) = "J1"
        a(44) = "5F"
        a(45) = "I8"
        a(46) = "I5"
        a(47) = "9T"
        a(48) = "U1"
        a(49) = "N1"
        a(50) = "U2"
        a(51) = "5T"
        a(52) = "U3"
        a(53) = "A2"
        a(54) = "0E"
        a(55) = "E1"
        a(56) = "J4"
        a(57) = "43"
        a(58) = "E2"
        a(59) = "S7"
        a(60) = "H2"
        a(61) = "D9"
        a(62) = "5S"
        a(63) = "Q1"
        a(64) = "R6"
        a(65) = "0P"
        a(66) = "G1"
        a(67) = "99"
        a(68) = "3E"
        a(69) = "C8"
        a(70) = "M5"
        a(71) = "7D"
        a(72) = "L2"
        a(73) = "A7"
        a(74) = "5D"
        a(75) = "F6"
        a(76) = "K6"
        a(77) = "D6"
        a(78) = "7H"
        a(79) = "J0"
        a(80) = "F3"
        a(81) = "4A"
        a(82) = "4I"
        a(83) = "W8"
        a(84) = "X9"
        a(85) = "N2"
        a(86) = "6V"
        a(87) = "V7"
        a(88) = "4U"
        a(89) = "A3"
        a(90) = "Q5"
        a(91) = "53"
        a(92) = "J5"
        a(93) = "7Z"
        a(94) = "S8"
        a(95) = "H0"
        a(96) = "1H"
        a(97) = "Z6"
        a(98) = "9G"
        a(99) = "Z5"
        a(100) = "R7"
        a(101) = "P1"
        a(102) = "G2"
        a(103) = "0Q"
        a(104) = "E4"
        a(105) = "7C"
        a(106) = "R4"
        a(107) = "T4"
        a(108) = "3L"
        a(109) = "A6"
        a(110) = "M4"
        a(111) = "5K"
        a(112) = "E5"
        a(113) = "S4"
        a(114) = "H8"
        a(115) = "9I"
        a(116) = "F2"
        a(117) = "A5"
        a(118) = "I3"
        a(119) = "7W"
        a(120) = "0X"
        a(121) = "N3"
        a(122) = "5V"
        a(123) = "8V"
        a(124) = "U5"
        a(125) = "X8"
        a(126) = "Q6"
        a(127) = "82"
        a(128) = "6J"
        a(129) = "4C"
        a(130) = "S9"
        a(131) = "Z4"
        a(132) = "W0"
        a(133) = "9V"
        a(134) = "G8"
        a(135) = "R8"
        a(136) = "5C"
        a(137) = "P2"
        a(138) = "G3"
        a(139) = "0T"
        a(140) = "P9"
        a(141) = "Z3"
        a(142) = "3R"
        a(143) = "L5"
        a(144) = "L4"
        a(145) = "6C"
        a(146) = "M3"
        a(147) = "4K"
        a(148) = "E6"
        a(149) = "S3"
        a(150) = "H9"
        a(151) = "T3"
        a(152) = "4F"
        a(153) = "F1"
        a(154) = "2I"
        a(155) = "W6"
        a(156) = "X1"
        a(157) = "4N"
        a(158) = "V4"
        a(159) = "X7"
        a(160) = "U6"
        a(161) = "2Z"
        a(162) = "7Q"
        a(163) = "11"
        a(164) = "J7"
        a(165) = "W1"
        a(166) = "C3"
        a(167) = "T1"
        a(168) = "C2"
        a(169) = "C1"
        a(170) = "G7"
        a(171) = "R9"
        a(172) = "P3"
        a(173) = "G6"
        a(174) = "G4"
        a(175) = "5G"
        a(176) = "P8"
        a(177) = "0B"
        a(178) = "A9"
        a(179) = "L6"
        a(180) = "2R"
        a(181) = "A8"
        a(182) = "M2"
        a(183) = "3K"
        a(184) = "E7"
        a(185) = "S2"
        a(186) = "I0"
        a(187) = "8E"
        a(188) = "I1"
        a(189) = "F0"
        a(190) = "9E"
        a(191) = "5W"
        a(192) = "X2"
        a(193) = "N5"
        a(194) = "V3"
        a(195) = "Z1"
        a(196) = "U7"
        a(197) = "Y6"
        a(198) = "B9"
        a(199) = "O0"
        a(200) = "8J"
        a(201) = "B8"
        a(202) = "2W"
        a(203) = "Q8"
        a(204) = "7Y"
        a(205) = "C0"
        a(206) = "8Y"
        a(207) = "Y5"
        a(208) = "4P"
        a(209) = "Y4"
        a(210) = "P7"
        a(211) = "Z0"
        a(212) = "R1"
        a(213) = "B1"
        a(214) = "3Y"
        a(215) = "7L"
        a(216) = "L8"
        a(217) = "1S"
        a(218) = "M1"
        a(219) = "K2"
        a(220) = "L9"
        a(221) = "5X"
        a(222) = "Y9"
        a(223) = "X3"
        a(224) = "2Y"
        a(225) = "X4"
        a(226) = "T2"
        a(227) = "W4"
        a(228) = "9W"
        a(229) = "N6"
        a(230) = "V2"
        a(231) = "Y1"
        a(232) = "8U"
        a(233) = "W3"
        a(234) = "N9"
        a(235) = "8N"
        a(236) = "J9"
        a(237) = "B7"
        a(238) = "K0"
        a(239) = "Q9"
        a(240) = "N7"
        a(241) = "Y0"
        a(242) = "B6"
        a(243) = "6X"
        a(244) = "P5"
        a(245) = "B5"
        a(246) = "P6"
        a(247) = "V1"
        a(248) = "R0"
        a(249) = "2B"
        a(250) = "B3"
        a(251) = "B4"
        a(252) = "V0"
        a(253) = "0S"
        a(254) = "M0"
        a(255) = "K1"

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As String
        Dim m201 As Integer
        Dim mChar As String

        If Ctext = "" Then
            msDecryptData = ""
            Exit Function
        End If

        mChar = Mid(Ctext, 1, 2)
        For i = 0 To 255
            If a(i) = mChar Then
                m201 = i
                Exit For
            End If
        Next


        nl = Len(Ctext)

        Dim j As Integer
        sR = ""
        For i = 3 To nl Step 2
            aski = Mid(Ctext, i, 2)
            For j = 0 To 255
                If a(j) = aski Then
                    l = l + j
                    sR = sR & Chr(j)
                    Exit For
                End If
            Next
        Next

        If m201 = l Mod 201 Then
            sR = "1" & sR
        Else
            sR = "0" & sR
        End If

        msDecryptData = sR

    End Function

    
    Public Function msEncryptNum(ByVal sNum As String) As String

        Dim ar(1010) As String

        ar(0) = "D5"
        ar(1) = "JF"
        ar(2) = "DH"
        ar(3) = "AW"
        ar(4) = "TE"
        ar(5) = "NN"
        ar(6) = "EE"
        ar(7) = "VG"
        ar(8) = "5T"
        ar(9) = "SV"
        ar(10) = "M4"
        ar(11) = "DG"
        ar(12) = "JZ"
        ar(13) = "QA"
        ar(14) = "LK"
        ar(15) = "MB"
        ar(16) = "5C"
        ar(17) = "U5"
        ar(18) = "UQ"
        ar(19) = "7U"
        ar(20) = "PJ"
        ar(21) = "4G"
        ar(22) = "PH"
        ar(23) = "78"
        ar(24) = "O9"
        ar(25) = "ZR"
        ar(26) = "H9"
        ar(27) = "TF"
        ar(28) = "ME"
        ar(29) = "GP"
        ar(30) = "XP"
        ar(31) = "9R"
        ar(32) = "AY"
        ar(33) = "88"
        ar(34) = "UR"
        ar(35) = "K9"
        ar(36) = "HW"
        ar(37) = "5M"
        ar(38) = "RO"
        ar(39) = "XE"
        ar(40) = "H2"
        ar(41) = "KT"
        ar(42) = "4N"
        ar(43) = "9N"
        ar(44) = "QF"
        ar(45) = "LB"
        ar(46) = "VU"
        ar(47) = "M5"
        ar(48) = "U9"
        ar(49) = "3V"
        ar(50) = "5Y"
        ar(51) = "EI"
        ar(52) = "SL"
        ar(53) = "H6"
        ar(54) = "QJ"
        ar(55) = "ID"
        ar(56) = "MU"
        ar(57) = "L3"
        ar(58) = "9Z"
        ar(59) = "GK"
        ar(60) = "MF"
        ar(61) = "ST"
        ar(62) = "L9"
        ar(63) = "KN"
        ar(64) = "IA"
        ar(65) = "UL"
        ar(66) = "7W"
        ar(67) = "8P"
        ar(68) = "3X"
        ar(69) = "MG"
        ar(70) = "T8"
        ar(71) = "RS"
        ar(72) = "IN"
        ar(73) = "KI"
        ar(74) = "F3"
        ar(75) = "VT"
        ar(76) = "QU"
        ar(77) = "PN"
        ar(78) = "U8"
        ar(79) = "NH"
        ar(80) = "GL"
        ar(81) = "M3"
        ar(82) = "VO"
        ar(83) = "CP"
        ar(84) = "RT"
        ar(85) = "2G"
        ar(86) = "AP"
        ar(87) = "8K"
        ar(88) = "YF"
        ar(89) = "VQ"
        ar(90) = "P5"
        ar(91) = "QI"
        ar(92) = "KH"
        ar(93) = "J9"
        ar(94) = "IB"
        ar(95) = "IG"
        ar(96) = "YR"
        ar(97) = "B7"
        ar(98) = "PY"
        ar(99) = "G2"
        ar(100) = "BH"
        ar(101) = "LT"
        ar(102) = "XJ"
        ar(103) = "6U"
        ar(104) = "MR"
        ar(105) = "BR"
        ar(106) = "7R"
        ar(107) = "6X"
        ar(108) = "GZ"
        ar(109) = "OT"
        ar(110) = "C2"
        ar(111) = "XW"
        ar(112) = "G4"
        ar(113) = "F5"
        ar(114) = "KD"
        ar(115) = "FZ"
        ar(116) = "2Y"
        ar(117) = "VF"
        ar(118) = "QZ"
        ar(119) = "SH"
        ar(120) = "Z2"
        ar(121) = "NG"
        ar(122) = "LP"
        ar(123) = "VJ"
        ar(124) = "VS"
        ar(125) = "2R"
        ar(126) = "EM"
        ar(127) = "EN"
        ar(128) = "2M"
        ar(129) = "HD"
        ar(130) = "84"
        ar(131) = "AX"
        ar(132) = "68"
        ar(133) = "JX"
        ar(134) = "HZ"
        ar(135) = "KE"
        ar(136) = "D3"
        ar(137) = "QT"
        ar(138) = "AZ"
        ar(139) = "K2"
        ar(140) = "W4"
        ar(141) = "OR"
        ar(142) = "3F"
        ar(143) = "98"
        ar(144) = "NB"
        ar(145) = "BE"
        ar(146) = "2L"
        ar(147) = "XT"
        ar(148) = "4R"
        ar(149) = "WX"
        ar(150) = "7T"
        ar(151) = "WN"
        ar(152) = "A3"
        ar(153) = "4I"
        ar(154) = "9X"
        ar(155) = "NC"
        ar(156) = "HQ"
        ar(157) = "B5"
        ar(158) = "YU"
        ar(159) = "X9"
        ar(160) = "JD"
        ar(161) = "II"
        ar(162) = "UE"
        ar(163) = "IM"
        ar(164) = "G7"
        ar(165) = "8N"
        ar(166) = "A4"
        ar(167) = "RJ"
        ar(168) = "YS"
        ar(169) = "EO"
        ar(170) = "EK"
        ar(171) = "XB"
        ar(172) = "L5"
        ar(173) = "ZT"
        ar(174) = "BF"
        ar(175) = "S8"
        ar(176) = "ZL"
        ar(177) = "PU"
        ar(178) = "OB"
        ar(179) = "TZ"
        ar(180) = "DL"
        ar(181) = "IC"
        ar(182) = "28"
        ar(183) = "6H"
        ar(184) = "IK"
        ar(185) = "44"
        ar(186) = "MP"
        ar(187) = "CG"
        ar(188) = "LF"
        ar(189) = "MN"
        ar(190) = "6B"
        ar(191) = "XL"
        ar(192) = "CM"
        ar(193) = "GF"
        ar(194) = "4U"
        ar(195) = "P7"
        ar(196) = "J3"
        ar(197) = "VH"
        ar(198) = "UV"
        ar(199) = "R2"
        ar(200) = "DR"
        ar(201) = "OZ"
        ar(202) = "WT"
        ar(203) = "BK"
        ar(204) = "6M"
        ar(205) = "KV"
        ar(206) = "25"
        ar(207) = "GH"
        ar(208) = "7O"
        ar(209) = "B6"
        ar(210) = "AO"
        ar(211) = "GQ"
        ar(212) = "HH"
        ar(213) = "2D"
        ar(214) = "IP"
        ar(215) = "O3"
        ar(216) = "IT"
        ar(217) = "RM"
        ar(218) = "TG"
        ar(219) = "HX"
        ar(220) = "EB"
        ar(221) = "9I"
        ar(222) = "XD"
        ar(223) = "6D"
        ar(224) = "VY"
        ar(225) = "K5"
        ar(226) = "DW"
        ar(227) = "E6"
        ar(228) = "O7"
        ar(229) = "UH"
        ar(230) = "MK"
        ar(231) = "RZ"
        ar(232) = "26"
        ar(233) = "VD"
        ar(234) = "XS"
        ar(235) = "TD"
        ar(236) = "QO"
        ar(237) = "H8"
        ar(238) = "EF"
        ar(239) = "OS"
        ar(240) = "CR"
        ar(241) = "3G"
        ar(242) = "TC"
        ar(243) = "FI"
        ar(244) = "MW"
        ar(245) = "GM"
        ar(246) = "RC"
        ar(247) = "BI"
        ar(248) = "9A"
        ar(249) = "4W"
        ar(250) = "US"
        ar(251) = "ZO"
        ar(252) = "BZ"
        ar(253) = "SO"
        ar(254) = "ZN"
        ar(255) = "8B"
        ar(256) = "IE"
        ar(257) = "AQ"
        ar(258) = "BW"
        ar(259) = "Y6"
        ar(260) = "KG"
        ar(261) = "XF"
        ar(262) = "23"
        ar(263) = "O8"
        ar(264) = "SF"
        ar(265) = "ZM"
        ar(266) = "XI"
        ar(267) = "XA"
        ar(268) = "8G"
        ar(269) = "YQ"
        ar(270) = "5I"
        ar(271) = "H4"
        ar(272) = "H5"
        ar(273) = "RX"
        ar(274) = "NS"
        ar(275) = "2E"
        ar(276) = "FX"
        ar(277) = "MD"
        ar(278) = "SX"
        ar(279) = "M8"
        ar(280) = "BJ"
        ar(281) = "RB"
        ar(282) = "CT"
        ar(283) = "ZS"
        ar(284) = "QS"
        ar(285) = "BM"
        ar(286) = "FW"
        ar(287) = "TP"
        ar(288) = "DP"
        ar(289) = "NO"
        ar(290) = "HR"
        ar(291) = "QK"
        ar(292) = "6R"
        ar(293) = "3C"
        ar(294) = "2V"
        ar(295) = "QN"
        ar(296) = "OW"
        ar(297) = "YA"
        ar(298) = "N8"
        ar(299) = "58"
        ar(300) = "R3"
        ar(301) = "EG"
        ar(302) = "E9"
        ar(303) = "D2"
        ar(304) = "7F"
        ar(305) = "7A"
        ar(306) = "2O"
        ar(307) = "77"
        ar(308) = "3B"
        ar(309) = "6L"
        ar(310) = "Y7"
        ar(311) = "AA"
        ar(312) = "9L"
        ar(313) = "NY"
        ar(314) = "N4"
        ar(315) = "HL"
        ar(316) = "8X"
        ar(317) = "ZI"
        ar(318) = "4E"
        ar(319) = "F4"
        ar(320) = "WQ"
        ar(321) = "NI"
        ar(322) = "2H"
        ar(323) = "9J"
        ar(324) = "KU"
        ar(325) = "TO"
        ar(326) = "4L"
        ar(327) = "5R"
        ar(328) = "3M"
        ar(329) = "NR"
        ar(330) = "4K"
        ar(331) = "OI"
        ar(332) = "SJ"
        ar(333) = "XH"
        ar(334) = "E3"
        ar(335) = "XY"
        ar(336) = "WJ"
        ar(337) = "GJ"
        ar(338) = "RQ"
        ar(339) = "HI"
        ar(340) = "HY"
        ar(341) = "Y8"
        ar(342) = "5S"
        ar(343) = "E2"
        ar(344) = "5J"
        ar(345) = "37"
        ar(346) = "OE"
        ar(347) = "IH"
        ar(348) = "JJ"
        ar(349) = "XG"
        ar(350) = "GN"
        ar(351) = "4V"
        ar(352) = "AN"
        ar(353) = "EQ"
        ar(354) = "YD"
        ar(355) = "69"
        ar(356) = "OV"
        ar(357) = "P4"
        ar(358) = "4D"
        ar(359) = "C5"
        ar(360) = "3Z"
        ar(361) = "8W"
        ar(362) = "R8"
        ar(363) = "EL"
        ar(364) = "KJ"
        ar(365) = "6Y"
        ar(366) = "DD"
        ar(367) = "NP"
        ar(368) = "8A"
        ar(369) = "Y5"
        ar(370) = "TI"
        ar(371) = "5X"
        ar(372) = "QM"
        ar(373) = "JG"
        ar(374) = "BT"
        ar(375) = "Q7"
        ar(376) = "9Q"
        ar(377) = "4M"
        ar(378) = "32"
        ar(379) = "VM"
        ar(380) = "PZ"
        ar(381) = "UJ"
        ar(382) = "4Y"
        ar(383) = "RH"
        ar(384) = "9Y"
        ar(385) = "6J"
        ar(386) = "85"
        ar(387) = "XC"
        ar(388) = "AR"
        ar(389) = "IS"
        ar(390) = "94"
        ar(391) = "LV"
        ar(392) = "8R"
        ar(393) = "FQ"
        ar(394) = "BV"
        ar(395) = "OC"
        ar(396) = "XU"
        ar(397) = "X7"
        ar(398) = "KL"
        ar(399) = "FM"
        ar(400) = "TS"
        ar(401) = "T3"
        ar(402) = "KK"
        ar(403) = "39"
        ar(404) = "8F"
        ar(405) = "UA"
        ar(406) = "4A"
        ar(407) = "AT"
        ar(408) = "QP"
        ar(409) = "W6"
        ar(410) = "54"
        ar(411) = "92"
        ar(412) = "G9"
        ar(413) = "Y4"
        ar(414) = "Q3"
        ar(415) = "AJ"
        ar(416) = "7K"
        ar(417) = "42"
        ar(418) = "V4"
        ar(419) = "ZP"
        ar(420) = "IY"
        ar(421) = "JS"
        ar(422) = "VV"
        ar(423) = "34"
        ar(424) = "E8"
        ar(425) = "TH"
        ar(426) = "YG"
        ar(427) = "JQ"
        ar(428) = "FC"
        ar(429) = "N2"
        ar(430) = "S2"
        ar(431) = "A9"
        ar(432) = "ND"
        ar(433) = "46"
        ar(434) = "FT"
        ar(435) = "KZ"
        ar(436) = "ZV"
        ar(437) = "TY"
        ar(438) = "W2"
        ar(439) = "HS"
        ar(440) = "AH"
        ar(441) = "8D"
        ar(442) = "CX"
        ar(443) = "LS"
        ar(444) = "2K"
        ar(445) = "RY"
        ar(446) = "YE"
        ar(447) = "33"
        ar(448) = "I8"
        ar(449) = "FY"
        ar(450) = "MS"
        ar(451) = "K6"
        ar(452) = "KY"
        ar(453) = "SU"
        ar(454) = "ZG"
        ar(455) = "L2"
        ar(456) = "BS"
        ar(457) = "SR"
        ar(458) = "6Q"
        ar(459) = "GR"
        ar(460) = "JP"
        ar(461) = "8T"
        ar(462) = "HF"
        ar(463) = "KB"
        ar(464) = "RU"
        ar(465) = "M6"
        ar(466) = "T7"
        ar(467) = "DF"
        ar(468) = "SM"
        ar(469) = "5Z"
        ar(470) = "CU"
        ar(471) = "D7"
        ar(472) = "WK"
        ar(473) = "8J"
        ar(474) = "R7"
        ar(475) = "Z4"
        ar(476) = "RP"
        ar(477) = "Q2"
        ar(478) = "GS"
        ar(479) = "TL"
        ar(480) = "3Y"
        ar(481) = "6W"
        ar(482) = "MH"
        ar(483) = "48"
        ar(484) = "RR"
        ar(485) = "FB"
        ar(486) = "LM"
        ar(487) = "38"
        ar(488) = "CF"
        ar(489) = "OG"
        ar(490) = "EH"
        ar(491) = "VE"
        ar(492) = "TJ"
        ar(493) = "ZY"
        ar(494) = "ZE"
        ar(495) = "8I"
        ar(496) = "57"
        ar(497) = "2U"
        ar(498) = "62"
        ar(499) = "Z9"
        ar(500) = "J5"
        ar(501) = "WW"
        ar(502) = "Z7"
        ar(503) = "QD"
        ar(504) = "3E"
        ar(505) = "UO"
        ar(506) = "S5"
        ar(507) = "4C"
        ar(508) = "PX"
        ar(509) = "8C"
        ar(510) = "W3"
        ar(511) = "9W"
        ar(512) = "VR"
        ar(513) = "8M"
        ar(514) = "ZK"
        ar(515) = "5K"
        ar(516) = "F9"
        ar(517) = "5G"
        ar(518) = "64"
        ar(519) = "DX"
        ar(520) = "LH"
        ar(521) = "P8"
        ar(522) = "NL"
        ar(523) = "PW"
        ar(524) = "9S"
        ar(525) = "M7"
        ar(526) = "E5"
        ar(527) = "JC"
        ar(528) = "DC"
        ar(529) = "5H"
        ar(530) = "QY"
        ar(531) = "CI"
        ar(532) = "WI"
        ar(533) = "9T"
        ar(534) = "UD"
        ar(535) = "V5"
        ar(536) = "TU"
        ar(537) = "NZ"
        ar(538) = "HN"
        ar(539) = "UN"
        ar(540) = "ER"
        ar(541) = "LO"
        ar(542) = "QL"
        ar(543) = "VC"
        ar(544) = "Q8"
        ar(545) = "8S"
        ar(546) = "U3"
        ar(547) = "TN"
        ar(548) = "G8"
        ar(549) = "OO"
        ar(550) = "PR"
        ar(551) = "PG"
        ar(552) = "Y3"
        ar(553) = "ZX"
        ar(554) = "T5"
        ar(555) = "IW"
        ar(556) = "O5"
        ar(557) = "XX"
        ar(558) = "IX"
        ar(559) = "ZC"
        ar(560) = "9C"
        ar(561) = "8Y"
        ar(562) = "N6"
        ar(563) = "WF"
        ar(564) = "HG"
        ar(565) = "AM"
        ar(566) = "FO"
        ar(567) = "NA"
        ar(568) = "HE"
        ar(569) = "R5"
        ar(570) = "S9"
        ar(571) = "N7"
        ar(572) = "CN"
        ar(573) = "SD"
        ar(574) = "6G"
        ar(575) = "3W"
        ar(576) = "8V"
        ar(577) = "6K"
        ar(578) = "DQ"
        ar(579) = "2X"
        ar(580) = "XR"
        ar(581) = "G6"
        ar(582) = "JA"
        ar(583) = "79"
        ar(584) = "I5"
        ar(585) = "LE"
        ar(586) = "JR"
        ar(587) = "66"
        ar(588) = "9E"
        ar(589) = "CO"
        ar(590) = "7C"
        ar(591) = "EV"
        ar(592) = "LA"
        ar(593) = "JK"
        ar(594) = "L7"
        ar(595) = "H3"
        ar(596) = "3S"
        ar(597) = "FN"
        ar(598) = "MY"
        ar(599) = "3R"
        ar(600) = "NK"
        ar(601) = "J8"
        ar(602) = "YJ"
        ar(603) = "6Z"
        ar(604) = "QB"
        ar(605) = "BP"
        ar(606) = "TW"
        ar(607) = "FR"
        ar(608) = "9O"
        ar(609) = "95"
        ar(610) = "3K"
        ar(611) = "2F"
        ar(612) = "BL"
        ar(613) = "OA"
        ar(614) = "IU"
        ar(615) = "M2"
        ar(616) = "RW"
        ar(617) = "BA"
        ar(618) = "AB"
        ar(619) = "A8"
        ar(620) = "6A"
        ar(621) = "NF"
        ar(622) = "VI"
        ar(623) = "CJ"
        ar(624) = "2C"
        ar(625) = "TV"
        ar(626) = "X2"
        ar(627) = "BN"
        ar(628) = "3U"
        ar(629) = "DO"
        ar(630) = "7G"
        ar(631) = "7B"
        ar(632) = "PS"
        ar(633) = "WR"
        ar(634) = "36"
        ar(635) = "CL"
        ar(636) = "VP"
        ar(637) = "UC"
        ar(638) = "9P"
        ar(639) = "WG"
        ar(640) = "YL"
        ar(641) = "EU"
        ar(642) = "HK"
        ar(643) = "8H"
        ar(644) = "C8"
        ar(645) = "NU"
        ar(646) = "K7"
        ar(647) = "VX"
        ar(648) = "ZU"
        ar(649) = "NX"
        ar(650) = "6T"
        ar(651) = "SG"
        ar(652) = "WO"
        ar(653) = "JY"
        ar(654) = "P9"
        ar(655) = "OM"
        ar(656) = "67"
        ar(657) = "GD"
        ar(658) = "8O"
        ar(659) = "3H"
        ar(660) = "IF"
        ar(661) = "CA"
        ar(662) = "X8"
        ar(663) = "BG"
        ar(664) = "VK"
        ar(665) = "D4"
        ar(666) = "HM"
        ar(667) = "JI"
        ar(668) = "Y2"
        ar(669) = "N3"
        ar(670) = "WD"
        ar(671) = "UW"
        ar(672) = "XZ"
        ar(673) = "XM"
        ar(674) = "YB"
        ar(675) = "EX"
        ar(676) = "CY"
        ar(677) = "CV"
        ar(678) = "3L"
        ar(679) = "87"
        ar(680) = "FH"
        ar(681) = "X6"
        ar(682) = "NT"
        ar(683) = "A6"
        ar(684) = "MA"
        ar(685) = "RF"
        ar(686) = "TB"
        ar(687) = "UU"
        ar(688) = "3A"
        ar(689) = "WU"
        ar(690) = "QQ"
        ar(691) = "5W"
        ar(692) = "52"
        ar(693) = "8E"
        ar(694) = "TK"
        ar(695) = "FD"
        ar(696) = "I9"
        ar(697) = "HJ"
        ar(698) = "X4"
        ar(699) = "3I"
        ar(700) = "IR"
        ar(701) = "CZ"
        ar(702) = "OH"
        ar(703) = "9D"
        ar(704) = "T2"
        ar(705) = "SQ"
        ar(706) = "LC"
        ar(707) = "W5"
        ar(708) = "HP"
        ar(709) = "QG"
        ar(710) = "HA"
        ar(711) = "6E"
        ar(712) = "PD"
        ar(713) = "QV"
        ar(714) = "HC"
        ar(715) = "GY"
        ar(716) = "S3"
        ar(717) = "27"
        ar(718) = "ZA"
        ar(719) = "7V"
        ar(720) = "LD"
        ar(721) = "6P"
        ar(722) = "T4"
        ar(723) = "5N"
        ar(724) = "NE"
        ar(725) = "6S"
        ar(726) = "5O"
        ar(727) = "HU"
        ar(728) = "GX"
        ar(729) = "6F"
        ar(730) = "7L"
        ar(731) = "TX"
        ar(732) = "HT"
        ar(733) = "MJ"
        ar(734) = "2N"
        ar(735) = "4J"
        ar(736) = "63"
        ar(737) = "PI"
        ar(738) = "53"
        ar(739) = "W8"
        ar(740) = "YX"
        ar(741) = "SZ"
        ar(742) = "E4"
        ar(743) = "Z8"
        ar(744) = "BB"
        ar(745) = "5P"
        ar(746) = "GG"
        ar(747) = "5E"
        ar(748) = "A2"
        ar(749) = "7P"
        ar(750) = "PF"
        ar(751) = "3O"
        ar(752) = "2A"
        ar(753) = "4F"
        ar(754) = "P3"
        ar(755) = "LJ"
        ar(756) = "56"
        ar(757) = "4O"
        ar(758) = "9K"
        ar(759) = "MX"
        ar(760) = "DB"
        ar(761) = "7J"
        ar(762) = "ML"
        ar(763) = "LL"
        ar(764) = "3T"
        ar(765) = "JB"
        ar(766) = "7X"
        ar(767) = "SB"
        ar(768) = "DI"
        ar(769) = "FJ"
        ar(770) = "SA"
        ar(771) = "YM"
        ar(772) = "MZ"
        ar(773) = "KS"
        ar(774) = "KX"
        ar(775) = "5D"
        ar(776) = "J4"
        ar(777) = "PC"
        ar(778) = "6V"
        ar(779) = "97"
        ar(780) = "KW"
        ar(781) = "UY"
        ar(782) = "Q5"
        ar(783) = "OL"
        ar(784) = "J2"
        ar(785) = "C9"
        ar(786) = "ZZ"
        ar(787) = "IQ"
        ar(788) = "YO"
        ar(789) = "4P"
        ar(790) = "CB"
        ar(791) = "JN"
        ar(792) = "UX"
        ar(793) = "AF"
        ar(794) = "K8"
        ar(795) = "K4"
        ar(796) = "MI"
        ar(797) = "3D"
        ar(798) = "7Q"
        ar(799) = "QE"
        ar(800) = "2S"
        ar(801) = "GW"
        ar(802) = "P6"
        ar(803) = "7D"
        ar(804) = "82"
        ar(805) = "RE"
        ar(806) = "WB"
        ar(807) = "CQ"
        ar(808) = "RN"
        ar(809) = "KO"
        ar(810) = "LG"
        ar(811) = "R9"
        ar(812) = "24"
        ar(813) = "V6"
        ar(814) = "DU"
        ar(815) = "F7"
        ar(816) = "C4"
        ar(817) = "JW"
        ar(818) = "GU"
        ar(819) = "UF"
        ar(820) = "RI"
        ar(821) = "2P"
        ar(822) = "LX"
        ar(823) = "CE"
        ar(824) = "SP"
        ar(825) = "F2"
        ar(826) = "TQ"
        ar(827) = "FP"
        ar(828) = "BD"
        ar(829) = "AK"
        ar(830) = "ZB"
        ar(831) = "J6"
        ar(832) = "2B"
        ar(833) = "BO"
        ar(834) = "4B"
        ar(835) = "5F"
        ar(836) = "72"
        ar(837) = "NV"
        ar(838) = "GV"
        ar(839) = "W9"
        ar(840) = "JV"
        ar(841) = "35"
        ar(842) = "FS"
        ar(843) = "KP"
        ar(844) = "S7"
        ar(845) = "KF"
        ar(846) = "H7"
        ar(847) = "JO"
        ar(848) = "XQ"
        ar(849) = "JM"
        ar(850) = "GE"
        ar(851) = "WE"
        ar(852) = "E7"
        ar(853) = "WY"
        ar(854) = "CH"
        ar(855) = "N5"
        ar(856) = "U2"
        ar(857) = "OP"
        ar(858) = "D9"
        ar(859) = "76"
        ar(860) = "5A"
        ar(861) = "CK"
        ar(862) = "LQ"
        ar(863) = "4S"
        ar(864) = "LY"
        ar(865) = "K3"
        ar(866) = "7I"
        ar(867) = "XO"
        ar(868) = "9G"
        ar(869) = "YC"
        ar(870) = "XK"
        ar(871) = "V3"
        ar(872) = "A5"
        ar(873) = "ZQ"
        ar(874) = "ES"
        ar(875) = "L4"
        ar(876) = "JU"
        ar(877) = "YY"
        ar(878) = "65"
        ar(879) = "O2"
        ar(880) = "Q9"
        ar(881) = "YW"
        ar(882) = "R6"
        ar(883) = "RL"
        ar(884) = "AU"
        ar(885) = "AS"
        ar(886) = "VA"
        ar(887) = "73"
        ar(888) = "AI"
        ar(889) = "MC"
        ar(890) = "WP"
        ar(891) = "MQ"
        ar(892) = "7H"
        ar(893) = "DJ"
        ar(894) = "RV"
        ar(895) = "PM"
        ar(896) = "RG"
        ar(897) = "UG"
        ar(898) = "SE"
        ar(899) = "HO"
        ar(900) = "LZ"
        ar(901) = "G5"
        ar(902) = "VB"
        ar(903) = "GB"
        ar(904) = "4Q"
        ar(905) = "47"
        ar(906) = "RK"
        ar(907) = "9V"
        ar(908) = "OX"
        ar(909) = "EW"
        ar(910) = "PT"
        ar(911) = "3J"
        ar(912) = "5L"
        ar(913) = "I3"
        ar(914) = "XV"
        ar(915) = "FL"
        ar(916) = "LR"
        ar(917) = "BQ"
        ar(918) = "EC"
        ar(919) = "WL"
        ar(920) = "B4"
        ar(921) = "DE"
        ar(922) = "QX"
        ar(923) = "L6"
        ar(924) = "BU"
        ar(925) = "DM"
        ar(926) = "43"
        ar(927) = "S6"
        ar(928) = "ZD"
        ar(929) = "VL"
        ar(930) = "2I"
        ar(931) = "9B"
        ar(932) = "FU"
        ar(933) = "CW"
        ar(934) = "96"
        ar(935) = "SK"
        ar(936) = "QC"
        ar(937) = "3Q"
        ar(938) = "GT"
        ar(939) = "2Q"
        ar(940) = "QW"
        ar(941) = "CD"
        ar(942) = "L8"
        ar(943) = "22"
        ar(944) = "YP"
        ar(945) = "PO"
        ar(946) = "PQ"
        ar(947) = "7Y"
        ar(948) = "KM"
        ar(949) = "ZW"
        ar(950) = "FG"
        ar(951) = "75"
        ar(952) = "GC"
        ar(953) = "V7"
        ar(954) = "83"
        ar(955) = "WZ"
        ar(956) = "8Z"
        ar(957) = "I7"
        ar(958) = "D6"
        ar(959) = "ZF"
        ar(960) = "7E"
        ar(961) = "B9"
        ar(962) = "YH"
        ar(963) = "ON"
        ar(964) = "QH"
        ar(965) = "8L"
        ar(966) = "SY"
        ar(967) = "FE"
        ar(968) = "ED"
        ar(969) = "MM"
        ar(970) = "YK"
        ar(971) = "9H"
        ar(972) = "WH"
        ar(973) = "DN"
        ar(974) = "ET"
        ar(975) = "9F"
        ar(976) = "EA"
        ar(977) = "QR"
        ar(978) = "OQ"
        ar(979) = "IL"
        ar(980) = "YI"
        ar(981) = "OK"
        ar(982) = "PV"
        ar(983) = "SI"
        ar(984) = "NM"
        ar(985) = "M9"
        ar(986) = "Z3"
        ar(987) = "4T"
        ar(988) = "V8"
        ar(989) = "Q4"
        ar(990) = "AV"
        ar(991) = "DK"
        ar(992) = "PE"
        ar(993) = "R4"
        ar(994) = "WC"
        ar(995) = "FA"
        ar(996) = "GA"
        ar(997) = "6I"
        ar(998) = "J7"
        ar(999) = "93"
        ar(1000) = "8Q"

        msEncryptNum = ""

        If Not IsNumeric(sNum) Then Exit Function

        Dim rSeed As Integer
        Randomize()

        'rSeed = Int(Rnd * 88) + 11
        rSeed = Int(Rnd * 500)

        Dim l As Long
        l = Len(sNum)
        If l > 9 Then Exit Function

        If l Mod 2 = 1 Then
            sNum = "0" & sNum
            l = l + 1
        End If

        Dim sNummod As Integer

        'Dim newSnum As Long
        '
        'For l = 1 To Len(sNum)
        '    newSnum = newSnum + Asc(Mid(sNum, 1, 1))
        'Next
        '
        'sNummod = (newSnum Mod 71) + 12   ' to do something here

        sNummod = (sNum Mod 71) + 12

        sNum = sNum & sNummod

        On Error GoTo erh

        Dim i As Integer
        Dim sRet As String
        sRet = ""

        Dim iNum As Integer
        iNum = 0

        Dim pNum As Integer
        pNum = 0

        For i = 1 To Len(sNum) Step 2
            iNum = Mid(sNum, i, 2) + rSeed + i + pNum
            If iNum > 700 Then
                Stop
            End If
            sRet = sRet & ar(iNum)
            pNum = Asc(Mid(sRet, Len(sRet), 1)) - 41
        Next

        sRet = ar(rSeed) & sRet

        Dim secNum As Long

        For i = 1 To Len(sRet)
            secNum = secNum + Asc(Mid(sRet, 1, 1)) - 39
        Next

        secNum = secNum Mod 489

        sRet = ar(secNum) & sRet

        msEncryptNum = sRet

        Exit Function

erh:
        MsgBox(Err.Description, vbExclamation, "encrypt error")


    End Function

    Public Function msDecryptNum(ByVal sCode As String) As String

        Dim ar(1010) As String

        ar(0) = "D5"
        ar(1) = "JF"
        ar(2) = "DH"
        ar(3) = "AW"
        ar(4) = "TE"
        ar(5) = "NN"
        ar(6) = "EE"
        ar(7) = "VG"
        ar(8) = "5T"
        ar(9) = "SV"
        ar(10) = "M4"
        ar(11) = "DG"
        ar(12) = "JZ"
        ar(13) = "QA"
        ar(14) = "LK"
        ar(15) = "MB"
        ar(16) = "5C"
        ar(17) = "U5"
        ar(18) = "UQ"
        ar(19) = "7U"
        ar(20) = "PJ"
        ar(21) = "4G"
        ar(22) = "PH"
        ar(23) = "78"
        ar(24) = "O9"
        ar(25) = "ZR"
        ar(26) = "H9"
        ar(27) = "TF"
        ar(28) = "ME"
        ar(29) = "GP"
        ar(30) = "XP"
        ar(31) = "9R"
        ar(32) = "AY"
        ar(33) = "88"
        ar(34) = "UR"
        ar(35) = "K9"
        ar(36) = "HW"
        ar(37) = "5M"
        ar(38) = "RO"
        ar(39) = "XE"
        ar(40) = "H2"
        ar(41) = "KT"
        ar(42) = "4N"
        ar(43) = "9N"
        ar(44) = "QF"
        ar(45) = "LB"
        ar(46) = "VU"
        ar(47) = "M5"
        ar(48) = "U9"
        ar(49) = "3V"
        ar(50) = "5Y"
        ar(51) = "EI"
        ar(52) = "SL"
        ar(53) = "H6"
        ar(54) = "QJ"
        ar(55) = "ID"
        ar(56) = "MU"
        ar(57) = "L3"
        ar(58) = "9Z"
        ar(59) = "GK"
        ar(60) = "MF"
        ar(61) = "ST"
        ar(62) = "L9"
        ar(63) = "KN"
        ar(64) = "IA"
        ar(65) = "UL"
        ar(66) = "7W"
        ar(67) = "8P"
        ar(68) = "3X"
        ar(69) = "MG"
        ar(70) = "T8"
        ar(71) = "RS"
        ar(72) = "IN"
        ar(73) = "KI"
        ar(74) = "F3"
        ar(75) = "VT"
        ar(76) = "QU"
        ar(77) = "PN"
        ar(78) = "U8"
        ar(79) = "NH"
        ar(80) = "GL"
        ar(81) = "M3"
        ar(82) = "VO"
        ar(83) = "CP"
        ar(84) = "RT"
        ar(85) = "2G"
        ar(86) = "AP"
        ar(87) = "8K"
        ar(88) = "YF"
        ar(89) = "VQ"
        ar(90) = "P5"
        ar(91) = "QI"
        ar(92) = "KH"
        ar(93) = "J9"
        ar(94) = "IB"
        ar(95) = "IG"
        ar(96) = "YR"
        ar(97) = "B7"
        ar(98) = "PY"
        ar(99) = "G2"
        ar(100) = "BH"
        ar(101) = "LT"
        ar(102) = "XJ"
        ar(103) = "6U"
        ar(104) = "MR"
        ar(105) = "BR"
        ar(106) = "7R"
        ar(107) = "6X"
        ar(108) = "GZ"
        ar(109) = "OT"
        ar(110) = "C2"
        ar(111) = "XW"
        ar(112) = "G4"
        ar(113) = "F5"
        ar(114) = "KD"
        ar(115) = "FZ"
        ar(116) = "2Y"
        ar(117) = "VF"
        ar(118) = "QZ"
        ar(119) = "SH"
        ar(120) = "Z2"
        ar(121) = "NG"
        ar(122) = "LP"
        ar(123) = "VJ"
        ar(124) = "VS"
        ar(125) = "2R"
        ar(126) = "EM"
        ar(127) = "EN"
        ar(128) = "2M"
        ar(129) = "HD"
        ar(130) = "84"
        ar(131) = "AX"
        ar(132) = "68"
        ar(133) = "JX"
        ar(134) = "HZ"
        ar(135) = "KE"
        ar(136) = "D3"
        ar(137) = "QT"
        ar(138) = "AZ"
        ar(139) = "K2"
        ar(140) = "W4"
        ar(141) = "OR"
        ar(142) = "3F"
        ar(143) = "98"
        ar(144) = "NB"
        ar(145) = "BE"
        ar(146) = "2L"
        ar(147) = "XT"
        ar(148) = "4R"
        ar(149) = "WX"
        ar(150) = "7T"
        ar(151) = "WN"
        ar(152) = "A3"
        ar(153) = "4I"
        ar(154) = "9X"
        ar(155) = "NC"
        ar(156) = "HQ"
        ar(157) = "B5"
        ar(158) = "YU"
        ar(159) = "X9"
        ar(160) = "JD"
        ar(161) = "II"
        ar(162) = "UE"
        ar(163) = "IM"
        ar(164) = "G7"
        ar(165) = "8N"
        ar(166) = "A4"
        ar(167) = "RJ"
        ar(168) = "YS"
        ar(169) = "EO"
        ar(170) = "EK"
        ar(171) = "XB"
        ar(172) = "L5"
        ar(173) = "ZT"
        ar(174) = "BF"
        ar(175) = "S8"
        ar(176) = "ZL"
        ar(177) = "PU"
        ar(178) = "OB"
        ar(179) = "TZ"
        ar(180) = "DL"
        ar(181) = "IC"
        ar(182) = "28"
        ar(183) = "6H"
        ar(184) = "IK"
        ar(185) = "44"
        ar(186) = "MP"
        ar(187) = "CG"
        ar(188) = "LF"
        ar(189) = "MN"
        ar(190) = "6B"
        ar(191) = "XL"
        ar(192) = "CM"
        ar(193) = "GF"
        ar(194) = "4U"
        ar(195) = "P7"
        ar(196) = "J3"
        ar(197) = "VH"
        ar(198) = "UV"
        ar(199) = "R2"
        ar(200) = "DR"
        ar(201) = "OZ"
        ar(202) = "WT"
        ar(203) = "BK"
        ar(204) = "6M"
        ar(205) = "KV"
        ar(206) = "25"
        ar(207) = "GH"
        ar(208) = "7O"
        ar(209) = "B6"
        ar(210) = "AO"
        ar(211) = "GQ"
        ar(212) = "HH"
        ar(213) = "2D"
        ar(214) = "IP"
        ar(215) = "O3"
        ar(216) = "IT"
        ar(217) = "RM"
        ar(218) = "TG"
        ar(219) = "HX"
        ar(220) = "EB"
        ar(221) = "9I"
        ar(222) = "XD"
        ar(223) = "6D"
        ar(224) = "VY"
        ar(225) = "K5"
        ar(226) = "DW"
        ar(227) = "E6"
        ar(228) = "O7"
        ar(229) = "UH"
        ar(230) = "MK"
        ar(231) = "RZ"
        ar(232) = "26"
        ar(233) = "VD"
        ar(234) = "XS"
        ar(235) = "TD"
        ar(236) = "QO"
        ar(237) = "H8"
        ar(238) = "EF"
        ar(239) = "OS"
        ar(240) = "CR"
        ar(241) = "3G"
        ar(242) = "TC"
        ar(243) = "FI"
        ar(244) = "MW"
        ar(245) = "GM"
        ar(246) = "RC"
        ar(247) = "BI"
        ar(248) = "9A"
        ar(249) = "4W"
        ar(250) = "US"
        ar(251) = "ZO"
        ar(252) = "BZ"
        ar(253) = "SO"
        ar(254) = "ZN"
        ar(255) = "8B"
        ar(256) = "IE"
        ar(257) = "AQ"
        ar(258) = "BW"
        ar(259) = "Y6"
        ar(260) = "KG"
        ar(261) = "XF"
        ar(262) = "23"
        ar(263) = "O8"
        ar(264) = "SF"
        ar(265) = "ZM"
        ar(266) = "XI"
        ar(267) = "XA"
        ar(268) = "8G"
        ar(269) = "YQ"
        ar(270) = "5I"
        ar(271) = "H4"
        ar(272) = "H5"
        ar(273) = "RX"
        ar(274) = "NS"
        ar(275) = "2E"
        ar(276) = "FX"
        ar(277) = "MD"
        ar(278) = "SX"
        ar(279) = "M8"
        ar(280) = "BJ"
        ar(281) = "RB"
        ar(282) = "CT"
        ar(283) = "ZS"
        ar(284) = "QS"
        ar(285) = "BM"
        ar(286) = "FW"
        ar(287) = "TP"
        ar(288) = "DP"
        ar(289) = "NO"
        ar(290) = "HR"
        ar(291) = "QK"
        ar(292) = "6R"
        ar(293) = "3C"
        ar(294) = "2V"
        ar(295) = "QN"
        ar(296) = "OW"
        ar(297) = "YA"
        ar(298) = "N8"
        ar(299) = "58"
        ar(300) = "R3"
        ar(301) = "EG"
        ar(302) = "E9"
        ar(303) = "D2"
        ar(304) = "7F"
        ar(305) = "7A"
        ar(306) = "2O"
        ar(307) = "77"
        ar(308) = "3B"
        ar(309) = "6L"
        ar(310) = "Y7"
        ar(311) = "AA"
        ar(312) = "9L"
        ar(313) = "NY"
        ar(314) = "N4"
        ar(315) = "HL"
        ar(316) = "8X"
        ar(317) = "ZI"
        ar(318) = "4E"
        ar(319) = "F4"
        ar(320) = "WQ"
        ar(321) = "NI"
        ar(322) = "2H"
        ar(323) = "9J"
        ar(324) = "KU"
        ar(325) = "TO"
        ar(326) = "4L"
        ar(327) = "5R"
        ar(328) = "3M"
        ar(329) = "NR"
        ar(330) = "4K"
        ar(331) = "OI"
        ar(332) = "SJ"
        ar(333) = "XH"
        ar(334) = "E3"
        ar(335) = "XY"
        ar(336) = "WJ"
        ar(337) = "GJ"
        ar(338) = "RQ"
        ar(339) = "HI"
        ar(340) = "HY"
        ar(341) = "Y8"
        ar(342) = "5S"
        ar(343) = "E2"
        ar(344) = "5J"
        ar(345) = "37"
        ar(346) = "OE"
        ar(347) = "IH"
        ar(348) = "JJ"
        ar(349) = "XG"
        ar(350) = "GN"
        ar(351) = "4V"
        ar(352) = "AN"
        ar(353) = "EQ"
        ar(354) = "YD"
        ar(355) = "69"
        ar(356) = "OV"
        ar(357) = "P4"
        ar(358) = "4D"
        ar(359) = "C5"
        ar(360) = "3Z"
        ar(361) = "8W"
        ar(362) = "R8"
        ar(363) = "EL"
        ar(364) = "KJ"
        ar(365) = "6Y"
        ar(366) = "DD"
        ar(367) = "NP"
        ar(368) = "8A"
        ar(369) = "Y5"
        ar(370) = "TI"
        ar(371) = "5X"
        ar(372) = "QM"
        ar(373) = "JG"
        ar(374) = "BT"
        ar(375) = "Q7"
        ar(376) = "9Q"
        ar(377) = "4M"
        ar(378) = "32"
        ar(379) = "VM"
        ar(380) = "PZ"
        ar(381) = "UJ"
        ar(382) = "4Y"
        ar(383) = "RH"
        ar(384) = "9Y"
        ar(385) = "6J"
        ar(386) = "85"
        ar(387) = "XC"
        ar(388) = "AR"
        ar(389) = "IS"
        ar(390) = "94"
        ar(391) = "LV"
        ar(392) = "8R"
        ar(393) = "FQ"
        ar(394) = "BV"
        ar(395) = "OC"
        ar(396) = "XU"
        ar(397) = "X7"
        ar(398) = "KL"
        ar(399) = "FM"
        ar(400) = "TS"
        ar(401) = "T3"
        ar(402) = "KK"
        ar(403) = "39"
        ar(404) = "8F"
        ar(405) = "UA"
        ar(406) = "4A"
        ar(407) = "AT"
        ar(408) = "QP"
        ar(409) = "W6"
        ar(410) = "54"
        ar(411) = "92"
        ar(412) = "G9"
        ar(413) = "Y4"
        ar(414) = "Q3"
        ar(415) = "AJ"
        ar(416) = "7K"
        ar(417) = "42"
        ar(418) = "V4"
        ar(419) = "ZP"
        ar(420) = "IY"
        ar(421) = "JS"
        ar(422) = "VV"
        ar(423) = "34"
        ar(424) = "E8"
        ar(425) = "TH"
        ar(426) = "YG"
        ar(427) = "JQ"
        ar(428) = "FC"
        ar(429) = "N2"
        ar(430) = "S2"
        ar(431) = "A9"
        ar(432) = "ND"
        ar(433) = "46"
        ar(434) = "FT"
        ar(435) = "KZ"
        ar(436) = "ZV"
        ar(437) = "TY"
        ar(438) = "W2"
        ar(439) = "HS"
        ar(440) = "AH"
        ar(441) = "8D"
        ar(442) = "CX"
        ar(443) = "LS"
        ar(444) = "2K"
        ar(445) = "RY"
        ar(446) = "YE"
        ar(447) = "33"
        ar(448) = "I8"
        ar(449) = "FY"
        ar(450) = "MS"
        ar(451) = "K6"
        ar(452) = "KY"
        ar(453) = "SU"
        ar(454) = "ZG"
        ar(455) = "L2"
        ar(456) = "BS"
        ar(457) = "SR"
        ar(458) = "6Q"
        ar(459) = "GR"
        ar(460) = "JP"
        ar(461) = "8T"
        ar(462) = "HF"
        ar(463) = "KB"
        ar(464) = "RU"
        ar(465) = "M6"
        ar(466) = "T7"
        ar(467) = "DF"
        ar(468) = "SM"
        ar(469) = "5Z"
        ar(470) = "CU"
        ar(471) = "D7"
        ar(472) = "WK"
        ar(473) = "8J"
        ar(474) = "R7"
        ar(475) = "Z4"
        ar(476) = "RP"
        ar(477) = "Q2"
        ar(478) = "GS"
        ar(479) = "TL"
        ar(480) = "3Y"
        ar(481) = "6W"
        ar(482) = "MH"
        ar(483) = "48"
        ar(484) = "RR"
        ar(485) = "FB"
        ar(486) = "LM"
        ar(487) = "38"
        ar(488) = "CF"
        ar(489) = "OG"
        ar(490) = "EH"
        ar(491) = "VE"
        ar(492) = "TJ"
        ar(493) = "ZY"
        ar(494) = "ZE"
        ar(495) = "8I"
        ar(496) = "57"
        ar(497) = "2U"
        ar(498) = "62"
        ar(499) = "Z9"
        ar(500) = "J5"
        ar(501) = "WW"
        ar(502) = "Z7"
        ar(503) = "QD"
        ar(504) = "3E"
        ar(505) = "UO"
        ar(506) = "S5"
        ar(507) = "4C"
        ar(508) = "PX"
        ar(509) = "8C"
        ar(510) = "W3"
        ar(511) = "9W"
        ar(512) = "VR"
        ar(513) = "8M"
        ar(514) = "ZK"
        ar(515) = "5K"
        ar(516) = "F9"
        ar(517) = "5G"
        ar(518) = "64"
        ar(519) = "DX"
        ar(520) = "LH"
        ar(521) = "P8"
        ar(522) = "NL"
        ar(523) = "PW"
        ar(524) = "9S"
        ar(525) = "M7"
        ar(526) = "E5"
        ar(527) = "JC"
        ar(528) = "DC"
        ar(529) = "5H"
        ar(530) = "QY"
        ar(531) = "CI"
        ar(532) = "WI"
        ar(533) = "9T"
        ar(534) = "UD"
        ar(535) = "V5"
        ar(536) = "TU"
        ar(537) = "NZ"
        ar(538) = "HN"
        ar(539) = "UN"
        ar(540) = "ER"
        ar(541) = "LO"
        ar(542) = "QL"
        ar(543) = "VC"
        ar(544) = "Q8"
        ar(545) = "8S"
        ar(546) = "U3"
        ar(547) = "TN"
        ar(548) = "G8"
        ar(549) = "OO"
        ar(550) = "PR"
        ar(551) = "PG"
        ar(552) = "Y3"
        ar(553) = "ZX"
        ar(554) = "T5"
        ar(555) = "IW"
        ar(556) = "O5"
        ar(557) = "XX"
        ar(558) = "IX"
        ar(559) = "ZC"
        ar(560) = "9C"
        ar(561) = "8Y"
        ar(562) = "N6"
        ar(563) = "WF"
        ar(564) = "HG"
        ar(565) = "AM"
        ar(566) = "FO"
        ar(567) = "NA"
        ar(568) = "HE"
        ar(569) = "R5"
        ar(570) = "S9"
        ar(571) = "N7"
        ar(572) = "CN"
        ar(573) = "SD"
        ar(574) = "6G"
        ar(575) = "3W"
        ar(576) = "8V"
        ar(577) = "6K"
        ar(578) = "DQ"
        ar(579) = "2X"
        ar(580) = "XR"
        ar(581) = "G6"
        ar(582) = "JA"
        ar(583) = "79"
        ar(584) = "I5"
        ar(585) = "LE"
        ar(586) = "JR"
        ar(587) = "66"
        ar(588) = "9E"
        ar(589) = "CO"
        ar(590) = "7C"
        ar(591) = "EV"
        ar(592) = "LA"
        ar(593) = "JK"
        ar(594) = "L7"
        ar(595) = "H3"
        ar(596) = "3S"
        ar(597) = "FN"
        ar(598) = "MY"
        ar(599) = "3R"
        ar(600) = "NK"
        ar(601) = "J8"
        ar(602) = "YJ"
        ar(603) = "6Z"
        ar(604) = "QB"
        ar(605) = "BP"
        ar(606) = "TW"
        ar(607) = "FR"
        ar(608) = "9O"
        ar(609) = "95"
        ar(610) = "3K"
        ar(611) = "2F"
        ar(612) = "BL"
        ar(613) = "OA"
        ar(614) = "IU"
        ar(615) = "M2"
        ar(616) = "RW"
        ar(617) = "BA"
        ar(618) = "AB"
        ar(619) = "A8"
        ar(620) = "6A"
        ar(621) = "NF"
        ar(622) = "VI"
        ar(623) = "CJ"
        ar(624) = "2C"
        ar(625) = "TV"
        ar(626) = "X2"
        ar(627) = "BN"
        ar(628) = "3U"
        ar(629) = "DO"
        ar(630) = "7G"
        ar(631) = "7B"
        ar(632) = "PS"
        ar(633) = "WR"
        ar(634) = "36"
        ar(635) = "CL"
        ar(636) = "VP"
        ar(637) = "UC"
        ar(638) = "9P"
        ar(639) = "WG"
        ar(640) = "YL"
        ar(641) = "EU"
        ar(642) = "HK"
        ar(643) = "8H"
        ar(644) = "C8"
        ar(645) = "NU"
        ar(646) = "K7"
        ar(647) = "VX"
        ar(648) = "ZU"
        ar(649) = "NX"
        ar(650) = "6T"
        ar(651) = "SG"
        ar(652) = "WO"
        ar(653) = "JY"
        ar(654) = "P9"
        ar(655) = "OM"
        ar(656) = "67"
        ar(657) = "GD"
        ar(658) = "8O"
        ar(659) = "3H"
        ar(660) = "IF"
        ar(661) = "CA"
        ar(662) = "X8"
        ar(663) = "BG"
        ar(664) = "VK"
        ar(665) = "D4"
        ar(666) = "HM"
        ar(667) = "JI"
        ar(668) = "Y2"
        ar(669) = "N3"
        ar(670) = "WD"
        ar(671) = "UW"
        ar(672) = "XZ"
        ar(673) = "XM"
        ar(674) = "YB"
        ar(675) = "EX"
        ar(676) = "CY"
        ar(677) = "CV"
        ar(678) = "3L"
        ar(679) = "87"
        ar(680) = "FH"
        ar(681) = "X6"
        ar(682) = "NT"
        ar(683) = "A6"
        ar(684) = "MA"
        ar(685) = "RF"
        ar(686) = "TB"
        ar(687) = "UU"
        ar(688) = "3A"
        ar(689) = "WU"
        ar(690) = "QQ"
        ar(691) = "5W"
        ar(692) = "52"
        ar(693) = "8E"
        ar(694) = "TK"
        ar(695) = "FD"
        ar(696) = "I9"
        ar(697) = "HJ"
        ar(698) = "X4"
        ar(699) = "3I"
        ar(700) = "IR"
        ar(701) = "CZ"
        ar(702) = "OH"
        ar(703) = "9D"
        ar(704) = "T2"
        ar(705) = "SQ"
        ar(706) = "LC"
        ar(707) = "W5"
        ar(708) = "HP"
        ar(709) = "QG"
        ar(710) = "HA"
        ar(711) = "6E"
        ar(712) = "PD"
        ar(713) = "QV"
        ar(714) = "HC"
        ar(715) = "GY"
        ar(716) = "S3"
        ar(717) = "27"
        ar(718) = "ZA"
        ar(719) = "7V"
        ar(720) = "LD"
        ar(721) = "6P"
        ar(722) = "T4"
        ar(723) = "5N"
        ar(724) = "NE"
        ar(725) = "6S"
        ar(726) = "5O"
        ar(727) = "HU"
        ar(728) = "GX"
        ar(729) = "6F"
        ar(730) = "7L"
        ar(731) = "TX"
        ar(732) = "HT"
        ar(733) = "MJ"
        ar(734) = "2N"
        ar(735) = "4J"
        ar(736) = "63"
        ar(737) = "PI"
        ar(738) = "53"
        ar(739) = "W8"
        ar(740) = "YX"
        ar(741) = "SZ"
        ar(742) = "E4"
        ar(743) = "Z8"
        ar(744) = "BB"
        ar(745) = "5P"
        ar(746) = "GG"
        ar(747) = "5E"
        ar(748) = "A2"
        ar(749) = "7P"
        ar(750) = "PF"
        ar(751) = "3O"
        ar(752) = "2A"
        ar(753) = "4F"
        ar(754) = "P3"
        ar(755) = "LJ"
        ar(756) = "56"
        ar(757) = "4O"
        ar(758) = "9K"
        ar(759) = "MX"
        ar(760) = "DB"
        ar(761) = "7J"
        ar(762) = "ML"
        ar(763) = "LL"
        ar(764) = "3T"
        ar(765) = "JB"
        ar(766) = "7X"
        ar(767) = "SB"
        ar(768) = "DI"
        ar(769) = "FJ"
        ar(770) = "SA"
        ar(771) = "YM"
        ar(772) = "MZ"
        ar(773) = "KS"
        ar(774) = "KX"
        ar(775) = "5D"
        ar(776) = "J4"
        ar(777) = "PC"
        ar(778) = "6V"
        ar(779) = "97"
        ar(780) = "KW"
        ar(781) = "UY"
        ar(782) = "Q5"
        ar(783) = "OL"
        ar(784) = "J2"
        ar(785) = "C9"
        ar(786) = "ZZ"
        ar(787) = "IQ"
        ar(788) = "YO"
        ar(789) = "4P"
        ar(790) = "CB"
        ar(791) = "JN"
        ar(792) = "UX"
        ar(793) = "AF"
        ar(794) = "K8"
        ar(795) = "K4"
        ar(796) = "MI"
        ar(797) = "3D"
        ar(798) = "7Q"
        ar(799) = "QE"
        ar(800) = "2S"
        ar(801) = "GW"
        ar(802) = "P6"
        ar(803) = "7D"
        ar(804) = "82"
        ar(805) = "RE"
        ar(806) = "WB"
        ar(807) = "CQ"
        ar(808) = "RN"
        ar(809) = "KO"
        ar(810) = "LG"
        ar(811) = "R9"
        ar(812) = "24"
        ar(813) = "V6"
        ar(814) = "DU"
        ar(815) = "F7"
        ar(816) = "C4"
        ar(817) = "JW"
        ar(818) = "GU"
        ar(819) = "UF"
        ar(820) = "RI"
        ar(821) = "2P"
        ar(822) = "LX"
        ar(823) = "CE"
        ar(824) = "SP"
        ar(825) = "F2"
        ar(826) = "TQ"
        ar(827) = "FP"
        ar(828) = "BD"
        ar(829) = "AK"
        ar(830) = "ZB"
        ar(831) = "J6"
        ar(832) = "2B"
        ar(833) = "BO"
        ar(834) = "4B"
        ar(835) = "5F"
        ar(836) = "72"
        ar(837) = "NV"
        ar(838) = "GV"
        ar(839) = "W9"
        ar(840) = "JV"
        ar(841) = "35"
        ar(842) = "FS"
        ar(843) = "KP"
        ar(844) = "S7"
        ar(845) = "KF"
        ar(846) = "H7"
        ar(847) = "JO"
        ar(848) = "XQ"
        ar(849) = "JM"
        ar(850) = "GE"
        ar(851) = "WE"
        ar(852) = "E7"
        ar(853) = "WY"
        ar(854) = "CH"
        ar(855) = "N5"
        ar(856) = "U2"
        ar(857) = "OP"
        ar(858) = "D9"
        ar(859) = "76"
        ar(860) = "5A"
        ar(861) = "CK"
        ar(862) = "LQ"
        ar(863) = "4S"
        ar(864) = "LY"
        ar(865) = "K3"
        ar(866) = "7I"
        ar(867) = "XO"
        ar(868) = "9G"
        ar(869) = "YC"
        ar(870) = "XK"
        ar(871) = "V3"
        ar(872) = "A5"
        ar(873) = "ZQ"
        ar(874) = "ES"
        ar(875) = "L4"
        ar(876) = "JU"
        ar(877) = "YY"
        ar(878) = "65"
        ar(879) = "O2"
        ar(880) = "Q9"
        ar(881) = "YW"
        ar(882) = "R6"
        ar(883) = "RL"
        ar(884) = "AU"
        ar(885) = "AS"
        ar(886) = "VA"
        ar(887) = "73"
        ar(888) = "AI"
        ar(889) = "MC"
        ar(890) = "WP"
        ar(891) = "MQ"
        ar(892) = "7H"
        ar(893) = "DJ"
        ar(894) = "RV"
        ar(895) = "PM"
        ar(896) = "RG"
        ar(897) = "UG"
        ar(898) = "SE"
        ar(899) = "HO"
        ar(900) = "LZ"
        ar(901) = "G5"
        ar(902) = "VB"
        ar(903) = "GB"
        ar(904) = "4Q"
        ar(905) = "47"
        ar(906) = "RK"
        ar(907) = "9V"
        ar(908) = "OX"
        ar(909) = "EW"
        ar(910) = "PT"
        ar(911) = "3J"
        ar(912) = "5L"
        ar(913) = "I3"
        ar(914) = "XV"
        ar(915) = "FL"
        ar(916) = "LR"
        ar(917) = "BQ"
        ar(918) = "EC"
        ar(919) = "WL"
        ar(920) = "B4"
        ar(921) = "DE"
        ar(922) = "QX"
        ar(923) = "L6"
        ar(924) = "BU"
        ar(925) = "DM"
        ar(926) = "43"
        ar(927) = "S6"
        ar(928) = "ZD"
        ar(929) = "VL"
        ar(930) = "2I"
        ar(931) = "9B"
        ar(932) = "FU"
        ar(933) = "CW"
        ar(934) = "96"
        ar(935) = "SK"
        ar(936) = "QC"
        ar(937) = "3Q"
        ar(938) = "GT"
        ar(939) = "2Q"
        ar(940) = "QW"
        ar(941) = "CD"
        ar(942) = "L8"
        ar(943) = "22"
        ar(944) = "YP"
        ar(945) = "PO"
        ar(946) = "PQ"
        ar(947) = "7Y"
        ar(948) = "KM"
        ar(949) = "ZW"
        ar(950) = "FG"
        ar(951) = "75"
        ar(952) = "GC"
        ar(953) = "V7"
        ar(954) = "83"
        ar(955) = "WZ"
        ar(956) = "8Z"
        ar(957) = "I7"
        ar(958) = "D6"
        ar(959) = "ZF"
        ar(960) = "7E"
        ar(961) = "B9"
        ar(962) = "YH"
        ar(963) = "ON"
        ar(964) = "QH"
        ar(965) = "8L"
        ar(966) = "SY"
        ar(967) = "FE"
        ar(968) = "ED"
        ar(969) = "MM"
        ar(970) = "YK"
        ar(971) = "9H"
        ar(972) = "WH"
        ar(973) = "DN"
        ar(974) = "ET"
        ar(975) = "9F"
        ar(976) = "EA"
        ar(977) = "QR"
        ar(978) = "OQ"
        ar(979) = "IL"
        ar(980) = "YI"
        ar(981) = "OK"
        ar(982) = "PV"
        ar(983) = "SI"
        ar(984) = "NM"
        ar(985) = "M9"
        ar(986) = "Z3"
        ar(987) = "4T"
        ar(988) = "V8"
        ar(989) = "Q4"
        ar(990) = "AV"
        ar(991) = "DK"
        ar(992) = "PE"
        ar(993) = "R4"
        ar(994) = "WC"
        ar(995) = "FA"
        ar(996) = "GA"
        ar(997) = "6I"
        ar(998) = "J7"
        ar(999) = "93"
        ar(1000) = "8Q"

        msDecryptNum = ""

        Dim firstChk As String
        firstChk = Mid(sCode, 1, 2)

        sCode = Mid(sCode, 3)

        Dim m As Integer

        Dim secNum As Long

        For m = 1 To Len(sCode)
            secNum = secNum + Asc(Mid(sCode, 1, 1)) - 39
        Next

        secNum = secNum Mod 489

        If ar(secNum) <> firstChk Then
            Exit Function
        End If

        On Error GoTo erh

        Dim rSeed As Integer
        Dim i As Integer
        rSeed = 0

        Dim sTemp As String
        sTemp = Mid(sCode, 1, 2)

        For i = 1 To 1000
            If ar(i) = sTemp Then
                rSeed = i
                Exit For
            End If
        Next

        'If rSeed < 11 Then GoTo erh

        If rSeed >= 500 Then GoTo erh

        Dim sNum As String
        sNum = ""

        Dim j As Integer
        sCode = Mid(sCode, 3)
        Dim pNum As Integer
        pNum = 0

        For i = 1 To Len(sCode) Step 2
            sTemp = Mid(sCode, i, 2)
            For j = 1 To 1000
                If ar(j) = sTemp Then
                    sNum = sNum & Right("00" & (j - rSeed - i - pNum), 2)
                    Exit For
                End If
            Next
            pNum = Asc(Mid(sTemp, 2, 1)) - 41
        Next

        Dim sNummod As String
        sNummod = Mid(sNum, Len(sNum) - 1)

        'Dim nNumMod As Integer
        'If Len(sNummod) > 2 Then
        '    nNumMod = Mid(sNummod, Len(sNummod) - 2)
        'End If

        Dim sRet As String
        sRet = Mid(sNum, 1, Len(sNum) - 2)

        Dim newSnum As Long
        Dim l As Long

        For l = 1 To Len(sRet)
            newSnum = newSnum + Asc(Mid(sNum, 1, 1))
        Next

        'sNummod = (newSnum Mod 71) + 12

        'If (newSnum Mod 71) + 12 = sNummod Then
        If (sRet Mod 71) + 12 = sNummod Then
            msDecryptNum = sRet
        End If


        Exit Function

erh:
        MsgBox(Err.Description, vbCritical, "Decrypt error")

    End Function


#End Region

#Region "HTML Reports"

    Public ArFields(30) As String
    Public ArHeader(30) As String
    Public ArType(30) As String
    Public ArSize(30) As Integer
    Public ArValues(30) As String   ' used for insert and update

    Public All_Tot_recs As Long

    Public Const ArBound = 29

    Public Finish_Reporting As Boolean
    Public Curr_rec As Long

        Public Sub ResetReportArrays()

            Dim i As Integer
            For i = 0 To ArBound
                ArFields(i) = ""
                ArHeader(i) = ""
                ArType(i) = ""  ' c n f d s ts
                ArSize(i) = 0
                ArValues(i) = ""

            Next
            All_Tot_recs = 0
            Finish_Reporting = False
            Curr_rec = 0


        End Sub


    Public Sub PrepareBasicReport(ByVal strSql As String, Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal CountCaption As String = "", Optional ByVal SumCaption As String = "", Optional ByVal SumField As String = "", Optional ByVal SumCaption2 As String = "", Optional ByVal SumField2 As String = "", Optional ByVal SumCaption3 As String = "", Optional ByVal SumField3 As String = "", Optional ByVal ShowSrNo As Boolean = True)

        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout

        Dim frmS As New frmStatus
        frmS.Show("Generating Report, Please wait ...")

        '---------------------------------
        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "mmss")
        Dim fn As String
        'fn = "c:\Report.html"
        fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
        '-----------------------------------

        Dim cnt As Long
        Dim sumAmt As Double
        cnt = 0
        sumAmt = 0

        Dim SumAmt2 As Double
        SumAmt2 = 0

        Dim SumAmt3 As Double
        SumAmt3 = 0

        Dim sumDataType As String
        Dim sumDataType2 As String
        Dim sumDataType3 As String

        sumDataType = ""
        sumDataType2 = ""
        sumDataType3 = ""

        Dim s As String

        ' -----------------------------------------
        s = "<html>"

        s = s & "<head>"
        s = s & "<meta http-equiv='Content-Language' content='en-us'>"
        s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>SPS Report</title>"
        s = s & "</head>"

        s = s & "<body style='font-family: Verdana; font-size: 10px'>"

        My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

        's = "<p><i><b><font face='Verdana' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
        s = "<p><i><b><font face='Tahoma' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"

        s = s & "<p><font color='#800000' size='2'>" & RepHead & "</font></p>"

        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

        s = "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'>"
        s = s & "<thead><tr>"

        If ShowSrNo Then
            s = s & "<td bgcolor='#99CCFF' align='center'><b><font size='2'>Sr No</font></b></td>"
            
        End If

        Dim i As Integer
        Dim d As String

        Dim sNo As Integer
        sNo = 1

        For i = 0 To ArBound
            
            If ArFields(i) = "" Then Exit For
            s = s & "<td "
            If ArSize(i) > 0 Then
                s = s & "width = '" & ArSize(i) & "%' "
            End If
            s = s & " bgcolor='#99CCFF' "
            If ArType(i) = "C" Then  ' char center align then
                s = s & " align='center' "
            ElseIf ArType(i) = "N" Then  ' nuber
                s = s & " align='right' "
            ElseIf ArType(i) = "F" Then  ' floating
                s = s & " align='right' "
            ElseIf ArType(i) = "D" Then   ' date
                ' no need
            Else   ' string 
                ' no need
            End If
            s = s & "><b><font size='2'>" & ArHeader(i) & "</font></b></td>"
        Next
        s = s & "</tr></thead>"

        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table header

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
        Try
            cm = New OleDbCommand(strSql, dbCn)
            dr = cm.ExecuteReader
            Do While dr.Read
                msDoEvents()
                s = "<tr>"
                For i = 0 To ArBound
                    If i = 0 Then
                        If ShowSrNo Then
                            s = s & "<td align='center'><font size='2'>" & sNo & "</font></td>"
                            'i = i + 1
                            sNo = sNo + 1
                        End If
                    End If
                    If ArFields(i) = "" Then Exit For
                    s = s & "<td "
                    If ArType(i) = "C" Then  ' char ot center align then
                        s = s & " align='center' "
                    ElseIf ArType(i) = "N" Then  ' nuber
                        s = s & " align='right' "
                    ElseIf ArType(i) = "F" Then  ' floating
                        s = s & " align='right' "
                    ElseIf ArType(i) = "D" Then   ' date
                        ' no need
                    Else   ' string 
                        ' no need
                    End If
                    s = s & " >"
                    s = s & "<font size='2'>"

                    If ArType(i) = "C" Then  ' char ot center align then
                        d = dr.Item(ArFields(i)).ToString
                        If d = "" Then d = "&nbsp;"
                        s = s & d
                    ElseIf ArType(i) = "N" Then  ' number
                        s = s & dr.Item(ArFields(i))
                    ElseIf ArType(i) = "F" Then  ' floating
                        s = s & Format(dr.Item(ArFields(i)), "N")
                    ElseIf ArType(i) = "D" Then   ' date
                        d = dr.Item(ArFields(i)).ToString
                        If d = "" Then
                            s = s & "&nbsp;"
                        Else
                            's = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4)
                            s = s & Format(DateSerial(Mid(d, 1, 4), Mid(d, 6, 2), Mid(d, 9, 2)), "Short Date")
                        End If
                    Else   ' string 
                        d = dr.Item(ArFields(i)).ToString & "&nbsp;"
                        If d = "" Then d = "&nbsp;"
                        s = s & d
                    End If
                    s = s & "</font>"
                    s = s & "</td>"
                    If SumField <> "" Then
                        If ArFields(i) = SumField Then
                            sumAmt = sumAmt + dr.Item(ArFields(i))
                            sumDataType = ArType(i)
                        End If
                    End If
                    If SumField2 <> "" Then
                        If ArFields(i) = SumField2 Then
                            SumAmt2 = SumAmt2 + dr.Item(ArFields(i))
                            sumDataType2 = ArType(i)
                        End If
                    End If
                    If SumField3 <> "" Then
                        If ArFields(i) = SumField3 Then
                            SumAmt3 = SumAmt3 + dr.Item(ArFields(i))
                            sumDataType3 = ArType(i)
                        End If
                    End If
                Next

                s = s & " </tr>"
                My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table row
                cnt = cnt + 1
            Loop

            dr.Close()
            cm.Dispose()
        Catch ex As Exception
            msMessagebox("Err: 2040 " & ex.Message, Emoticons.ErrorIcon)
            'MsgBox(ex.ToString)

        End Try

        dbCn.Close()

        s = "</thead></table>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' close table

        ' ----- summary
        If CountCaption > "" Or SumCaption > "" Then
            s = "<br>"
            s = s & "<table border='1' width='50%' id='table2'  cellpadding='0' cellspacing='0'>"
            If CountCaption > "" Then
                s = s & "<tr>"
                s = s & "<td><b><font size='2' color='#0000FF'>" & CountCaption & "</font></b></td>"
                s = s & "<td>"
                s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & cnt & "</font></b></td>"
                s = s & "</tr>"

            End If
            If SumCaption > "" Then
                s = s & "<tr>"
                s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption & "</font></b></td>"
                s = s & "<td>"
                If sumDataType = "F" Then
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(sumAmt, "N") & "</font></b></td>"
                Else
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & sumAmt & "</font></b></td>"
                End If

                s = s & "</tr>"
            End If
            If SumCaption2 > "" Then
                s = s & "<tr>"
                s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption2 & "</font></b></td>"
                s = s & "<td>"
                If sumDataType2 = "F" Then
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt2, "N") & "</font></b></td>"
                Else
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & SumAmt2 & "</font></b></td>"
                End If

                s = s & "</tr>"
            End If
            If SumCaption3 > "" Then
                s = s & "<tr>"
                s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption3 & "</font></b></td>"
                s = s & "<td>"
                If sumDataType3 = "F" Then
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt3, "N") & "</font></b></td>"
                Else
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & SumAmt3 & "</font></b></td>"
                End If

                s = s & "</tr>"
            End If
            s = s & "</table>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' summary
        End If


        ' -------------

        ' write footer
        s = "<p><font color='#800000' size='2'><b>" & RepFoot & "</b></font></p>"
        s = s & "<p>&nbsp;</p>"
        s = s & "</body>"
        s = s & "</html>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' footer
        ' -----------------------------------------

        frmS.Close()


        Dim frmRep As New frmReports
        frmRep.ShowDialog(fn)
        'frmRep.Show(fn)


gout:

    End Sub

    'Private Sub MakeSummary(ByVal prmRepName As String, ByVal DispRep As Boolean)

    '    Dim frmW As New frmStatus
    '    frmW.Show("Please wait generating report ...")

    '    Dim dbCnW As New OleDbConnection
    '    If Not OpenDbConnection(dbCnW) Then
    '        frmW.Close()
    '        Exit Sub
    '    End If

    '    Dim repFile As String
    '    repFile = prmRepName

    '    'repFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\CBPM" & Format(Date.Now, "yyMMddHHmmss") & ".html"
    '    'nFile = repFile


    '    Dim sH As String

    '    If My.Computer.FileSystem.FileExists(repFile) Then
    '        ' do nothing
    '    Else

    '        sH = "<html>"
    '        sH = sH & "<head>"
    '        sH = sH & "<meta http-equiv='Content-Language' content='en-us'>"
    '        sH = sH & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
    '        sH = sH & "<title>Cheque Books Production Summary</title>"
    '        sH = sH & "<STYLE>"
    '        sH = sH & "BR.page { page-break-after: always }"
    '        sH = sH & "</STYLE>"

    '        sH = sH & "</head>"
    '        sH = sH & "<body>"
    '        My.Computer.FileSystem.WriteAllText(repFile, sH, False)
    '        sH = ""

    '    End If

    '    Dim i As Integer
    '    Dim hdg As String

    '    If Me.rbPrinted.Checked Then
    '        'hdg = "<b>Dates From : " & Format(Me.dtpFrm.Value, "d") & "  To : " & Format(Me.dtpTo.Value, "d") & "</B><br>"
    '        hdg = "<b>����� ��       : " & Format(Me.dtpFrm.Value, "d") & "  ��� : " & Format(Me.dtpTo.Value, "d") & "</B><br>"

    '    Else
    '        'hdg = "<b>Pending Summary</b><br>"
    '        hdg = "<b>���� ��������</b><br>"
    '    End If

    '    Dim bks(100) As String
    '    Dim bkstot(100) As Integer
    '    Dim DailyTot As Integer
    '    Dim Fulltot As Integer

    '    Dim totBks As Integer


    '    Dim cmBk As OleDbCommand
    '    Dim drBk As OleDbDataReader
    '    Try
    '        cmBk = New OleDbCommand("Select * from tblbookTypes order by BookType ", dbCnW)
    '        drBk = cmBk.ExecuteReader

    '        Do While drBk.Read
    '            bks(i) = drBk.Item("BkDescription").ToString
    '            i = i + 1
    '        Loop
    '        drBk.Close()
    '        cmBk.Dispose()

    '        totBks = i

    '    Catch ex As Exception
    '        msMessagebox(ex.Message, Emoticons.ErrorIcon, "Error : 2210")
    '        frmW.Close()
    '        Exit Sub
    '    End Try

    '    Dim cmR As OleDbCommand
    '    Dim drR As OleDbDataReader
    '    Dim sW As String
    '    Dim lstItem As New msListItem


    '    'sW = "TRANSFORM Count(tblCBRS.RequestNo) AS CountOfRequestID"
    '    'sW = sW & " SELECT tblCBRS.PrintDate"
    '    'sW = sW & " FROM tblCBRS INNER JOIN tblBookTypes ON tblCBRS.BookType = tblBookTypes.BookType"
    '    'sW = sW & " where tblCBRS.PrsFlag = 2 "
    '    'sW = sW & " and tblCBRS.Bankcode = '" & sysvars.SelectedBankCode & "'"
    '    'sW = sW & " and PrintDate >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd") & "'"
    '    'sW = sW & " and PrintDate <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd") & "'"


    '    sW = "Select Count(tblCBRS.RequestNo) AS CountOfRequestID, "
    '    If Me.rbPrinted.Checked Then
    '        sW = sW & "Printdate, "
    '    Else
    '        sW = sW & "Requestdate, "
    '    End If

    '    sW = sW & " BookType, BkDescription From tblCBRS "
    '    sW = sW & " where "
    '    If Me.rbPendings.Checked Then
    '        sW = sW & " PrsFlag < 2 "
    '        'hdg = hdg & "Cheque Books Pendings Report" & "<Br>"
    '        hdg = hdg & "���� ������ ��������" & "<Br>"
    '    Else
    '        sW = sW & " PrsFlag = 2 "
    '    End If
    '    sW = sW & "  and CancelDate = '' "
    '    If Me.rbPrinted.Checked Then
    '        sW = sW & " and PrintDate >= '" & Format(Me.dtpFrm.Value, "yyyy-MM-dd") & "'"
    '        sW = sW & " and PrintDate <= '" & Format(Me.dtpTo.Value, "yyyy-MM-dd") & "'"

    '    End If
    '    If Val(Me.txtBatchNo.Text) > 0 Then
    '        sW = sW & " and BatchNo = " & Val(Me.txtBatchNo.Text)
    '        'hdg = hdg & "Batch No : " & Me.txtBatchNo.Text & "<Br>"
    '        hdg = hdg & "��� ����� : " & Me.txtBatchNo.Text & "<Br>"
    '    End If

    '    If Me.lstBranch.SelectedIndex > 0 Then
    '        lstItem = CType(Me.lstBranch.SelectedItem, msListItem)
    '        sW = sW & " and BranchCode = '" & lstItem.ID & "'"
    '        hdg = hdg & "��� : " & lstItem.Value & "<Br>"
    '    End If

    '    If Me.txtAccNo.Text <> "" Then
    '        sW = sW & " and AccountNo = '" & Me.txtAccNo.Text & "'"
    '        hdg = hdg & "��� ������ : " & Me.txtAccNo.Text & " - " & Me.lblAccName.Text & "<Br>"
    '    End If
    '    If Me.rbPrinted.Checked Then
    '        sW = sW & " Group By Printdate, BookType, BkDescription"

    '    Else
    '        sW = sW & " Group By Requestdate, BookType, BkDescription"

    '    End If



    '    sH = "<p  Align = 'Center'><B><font = 'Arial' size = '6' >" & mdiCBPM.lblSelectedBank.Text & "</font></B></p>"
    '    If Me.rbPrinted.Checked Then
    '        sH = sH & "<p  Align = 'Center'><B><font = 'Arial' size = '4' Align = 'Center' ><I>Cheque Books Production Summary</I></font></B></p>"

    '    Else
    '        sH = sH & "<p  Align = 'Center'><B><font = 'Arial' size = '4' Align = 'Center' ><I>Cheque Books Pending Summary</I></font></B></p>"

    '    End If

    '    'sH = "<p><i><b><h3>&nbsp;&nbsp;&nbsp;Cheque books Production Summary</h3></b></i><br>"
    '    sH = sH & "<b>" & hdg & " </b><br>"

    '    sH = sH & "</p>"

    '    My.Computer.FileSystem.WriteAllText(repFile, sH, True)
    '    sH = ""

    '    ' table header

    '    'sH = "</p>"
    '    sH = sH & "<table border='1' width='100%' id='table1'  cellspacing='0' cellpadding='0' bordercolor='#C0C0C0'>"

    '    sH = sH & "<tr bgcolor='#FFFF00'>"
    '    sH = sH & "<td><b>Date</b></td>"
    '    For i = 0 To 99
    '        If bks(i) = "" Then Exit For
    '        sH = sH & "<td><b>" & bks(i) & "</b></td>"
    '    Next
    '    sH = sH & "<td><b>Total</b></td>"
    '    sH = sH & "</tr>"
    '    My.Computer.FileSystem.WriteAllText(repFile, sH, True)
    '    sH = ""

    '    Dim Pdt As String
    '    Dim oldPdt As String
    '    Dim Bkt As String

    '    oldPdt = ""
    '    i = 0
    '    Dim b As Integer

    '    Try

    '        cmR = New OleDbCommand(sW, dbCnW)
    '        drR = cmR.ExecuteReader

    '        sW = ""
    '        DailyTot = 0

    '        Do While drR.Read

    '            If Me.rbPrinted.Checked Then
    '                Pdt = drR.Item("PrintDate").ToString

    '            Else
    '                Pdt = drR.Item("RequestDate").ToString

    '            End If
    '            sW = ""

    '            ' close and goto next row

    '            If Pdt <> oldPdt Then

    '                ' if not first row
    '                If oldPdt <> "" Then
    '                    ' add daly tot
    '                    Do While i < totBks
    '                        sW = sW & "<td>&nbsp;0</td>"
    '                        i = i + 1
    '                    Loop
    '                    sW = sW & "<td>" & DailyTot & "</td>"
    '                    sW = sW & "</tr>"
    '                End If


    '                oldPdt = Pdt
    '                sW = sW & "<tr>"
    '                sW = sW & "<td>" & Format(DateSerial(Mid(Pdt, 1, 4), Mid(Pdt, 6, 2), Mid(Pdt, 9, 2)), "d") & "</td>"
    '                i = 0
    '                DailyTot = 0

    '            End If

    '            Bkt = drR.Item("BkDescription").ToString

    '            For b = i To totBks
    '                If bks(b) = "" Then Exit For
    '                If Bkt = bks(b) Then
    '                    sW = sW & "<td>" & drR.Item("CountOfRequestID") & "</td>"
    '                    bkstot(b) = bkstot(b) + drR.Item("CountOfRequestID")
    '                    DailyTot = DailyTot + drR.Item("CountOfRequestID")
    '                    Fulltot = Fulltot + drR.Item("CountOfRequestID")
    '                    i = i + 1
    '                    Exit For
    '                Else
    '                    sW = sW & "<td>&nbsp;0</td>"
    '                    i = i + 1
    '                End If
    '            Next

    '            My.Computer.FileSystem.WriteAllText(repFile, sW, True)
    '            sW = ""

    '        Loop

    '    Catch ex As Exception

    '        msMessagebox(ex.Message, Emoticons.ErrorIcon2, "Error : 1031")

    '    End Try

    '    ' close if incomplete row

    '    ' if not first row
    '    If oldPdt <> "" Then
    '        ' add daly tot
    '        Do While i < totBks
    '            sW = sW & "<td>&nbsp;0</td>"
    '            i = i + 1
    '        Loop
    '        sW = sW & "<td>" & DailyTot & "</td>"
    '        sW = sW & "</tr>"
    '    End If


    '    'oldPdt = Pdt
    '    'sW = sW & "<tr>"
    '    'sW = sW & "<td>" & Pdt & "</td>"
    '    'i = 0
    '    'DailyTot = 0

    '    sW = sW & "<tr  bgcolor='#FFFF00'>"
    '    'sW = sW & "<td><b>Grand Total</b></td>"
    '    sW = sW & "<td><b>��������</b></td>"
    '    For i = 0 To 99
    '        If bks(i) = "" Then Exit For
    '        sW = sW & "<td><b>" & bkstot(i) & "</b></td>"
    '    Next
    '    sW = sW & "<td><b>" & Fulltot & "</b></td>"
    '    sW = sW & "</tr>"

    '    My.Computer.FileSystem.WriteAllText(repFile, sW, True)
    '    sW = ""

    '    sH = "</table>"
    '    My.Computer.FileSystem.WriteAllText(repFile, sH, True)

    '    sH = ""
    '    frmW.Close()

    '    If DispRep Then

    '        sH = sH & "</body>"

    '        sH = sH & "</html>"
    '        My.Computer.FileSystem.WriteAllText(repFile, sH, True)

    '        Dim frmRep As New frmReports
    '        frmRep.ShowDialog(repFile)

    '    Else
    '        sH = "<BR CLASS=page>"
    '        My.Computer.FileSystem.WriteAllText(repFile, sH, True)

    '    End If


    'End Sub

    Public Sub msPrepareCrossTabSummary(ByVal sSqlHead As String, ByVal sSqlDetails As String, ByVal MatchField As String, ByVal LeftTitle As String, ByVal LeftTitleField As String, ByVal SumField As String, Optional ByVal SumDataType As String = "N", Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal DispRep As Boolean = True, Optional ByVal RepFile As String = "")

        ' 2010-08-27 

        ' sql rules
        ' ssqlhead should be sorted by matchfield (only one field neded)
        ' ssqldetails should be sorted by leftsidefield, matchfield (3 fields need including sumfield )
        'If sSqlHead and sqldetail should have same where cluase

        Dim dbCnCT As New OleDbConnection
        If Not msOpenDbConnection(dbCnCT) Then GoTo gout

        Dim frmS As New frmStatus
        frmS.Show("Generating Report, Please wait ...")

        '---------------------------------
        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "mmss")
        Dim fn As String
        'fn = "c:\Report.html"
        If RepFile = "" Then
            fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
        Else
            fn = RepFile
        End If

        '-----------------------------------

        Dim s As String

        ' -----------------------------------------

        If My.Computer.FileSystem.FileExists(fn) Then
            ' do nothing
        Else
            s = "<html>"

            s = s & "<head>"
            s = s & "<meta http-equiv='Content-Language' content='en-us'>"
            s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
            s = s & "<title>SS Report</title>"
            s = s & "<STYLE>"
            s = s & "BR.page { page-break-after: always }"
            s = s & "</STYLE>"
            s = s & "</head>"

            s = s & "<body style='font-family: Verdana; font-size: 10px'>"

            My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header
        End If

        s = "<p><i><b><font face='Tahoma' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
        s = s & "<p><font color='#800000' size='2'><b>" & RepHead & "</b></font></p>"

        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header
        s = ""

        Dim i As Integer

        Dim heads(100) As String
        Dim ColTotal(100) As Double
        Dim TotHeads As Integer

        Dim cmHead As OleDbCommand
        Dim drHead As OleDbDataReader

        Try

            i = 0
            cmHead = New OleDbCommand(sSqlHead, dbCnCT)
            drHead = cmHead.ExecuteReader
            Do While drHead.Read
                heads(i) = drHead.Item(MatchField).ToString
                i = i + 1
            Loop
            drHead.Close()
            cmHead.Dispose()
            TotHeads = i

        Catch ex As Exception
            msMessagebox("Error : 3219" & vbCrLf & ex.Message, Emoticons.ErrorIcon, "Attention")
            Exit Sub
        End Try


        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

        s = "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'>"


        s = s & "<thead><tr bgcolor='#99FFCC'>"
        s = s & "<td><b><font size='2'>" & LeftTitle & "</font></b></td>"

        For i = 0 To 99
            If heads(i) = "" Then Exit For
            s = s & "<td><b><font size='2'>" & heads(i) & "</font></b></td>"
        Next

        s = s & "<td><b>Totals</b></td>"
        s = s & "</tr>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)
        s = ""

        Dim SideHead As String
        Dim OldSideHead As String
        Dim colHead As String

        OldSideHead = ""
        i = 0
        Dim c As Integer

        Dim cmDet As OleDbCommand
        Dim drDet As OleDbDataReader

        Dim RowTotal As Double
        Dim FullTotal As Double

        Try
            cmDet = New OleDbCommand(sSqlDetails, dbCnCT)
            drDet = cmDet.ExecuteReader
            s = 0
            RowTotal = 0

            Do While drDet.Read
                SideHead = drDet.Item(LeftTitleField).ToString
                s = ""
                ' close and got next row 
                If SideHead <> OldSideHead Then
                    ' if not firt row
                    If OldSideHead <> "" Then
                        Do While i < TotHeads
                            's = s & "<td>&nbsp;0</td>"
                            s = s & "<td align='right'><font size='2'>0</font></td>"
                            i = i + 1
                        Loop
                        If SumDataType = "F" Then
                            s = s & "<td align='right'><font size='2'>" & Format(RowTotal, "N") & "</font></td>"
                        Else
                            s = s & "<td align='right'><font size='2'>" & RowTotal & "</font></td>"
                        End If

                        s = s & "</tr>"
                    End If

                    OldSideHead = SideHead
                    s = s & "<tr>"
                    If IsDate(SideHead) Then
                        s = s & "<td>" & Format(CDate(SideHead), "Short Date") & "</td>"  ' hear option should be there to convert msdate to normal date if side head is date
                    Else
                        s = s & "<td><font size='2'>" & SideHead & "</font></td>"
                    End If
                    i = 0
                    RowTotal = 0
                End If

                colHead = drDet.Item(MatchField).ToString
                For c = i To TotHeads
                    If heads(c) = "" Then Exit For
                    If heads(c) = colHead Then
                        s = s & "<td "
                        s = s & " align='right' "
                        If SumDataType = "F" Then
                            s = s & " ><font size='2'>" & Format(drDet.Item(SumField), "N") & "</font></td>"

                        Else ' N
                            s = s & " ><font size='2'>" & drDet.Item(SumField) & "</font></td>"

                        End If

                        ColTotal(c) = ColTotal(c) + drDet.Item(SumField)
                        RowTotal = RowTotal + drDet.Item(SumField)
                        FullTotal = FullTotal + drDet.Item(SumField)
                        i = i + 1
                        Exit For
                    Else
                        's = s & "<td>&nbsp;0</td>"
                        s = s & "<td align='right'><font size='2'>0</font></td>"
                        i = i + 1
                    End If


                Next
                My.Computer.FileSystem.WriteAllText(fn, s, True)
                s = ""

            Loop

        Catch ex As Exception
            msMessagebox(ex.Message, Emoticons.ErrorIcon2, "Error : 1031")

        End Try

        ' close if in complete row

        ' if not first row
        If OldSideHead <> "" Then
            ' add row total
            Do While i < TotHeads
                s = s & "<td align='right'><font size='2'>0</font></td>"
                i = i + 1
            Loop
            If SumDataType = "F" Then
                s = s & "<td align='right'><font size='2'>" & Format(RowTotal, "N") & "</font></td>"
            Else
                s = s & "<td align='right'><font size='2'>" & RowTotal & "</font></td>"
            End If

            s = s & "</tr>"
        End If

        s = s & "<tr  bgcolor='#99FFCC'>"
        s = s & "<td><b>Totals</b></td>"
        's = s & "<td><b>��������</b></td>"
        For i = 0 To 99
            If heads(i) = "" Then Exit For
            If SumDataType = "F" Then
                s = s & "<td align='right'><b><font size='2'>" & Format(ColTotal(i), "N") & "<font size='2'></b></td>"
            Else
                s = s & "<td align='right'><b><font size='2'>" & ColTotal(i) & "<font size='2'></b></td>"
            End If

        Next
        If SumDataType = "F" Then
            s = s & "<td align='right'><b><font size='2'>" & Format(FullTotal, "N") & "<font size='2'></b></td>"
        Else
            s = s & "<td align='right'><b><font size='2'>" & FullTotal & "<font size='2'></b></td>"
        End If

        s = s & "</tr>"

        s = s & "</thead></table>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)

        s = ""

        frmS.Close()


        If DispRep Then

            s = s & "</body>"

            s = s & "</html>"
            My.Computer.FileSystem.WriteAllText(fn, s, True)

            Dim frmRep As New frmReports
            frmRep.ShowDialog(fn)

        Else
            s = "<BR CLASS=page>"
            My.Computer.FileSystem.WriteAllText(fn, s, True)

        End If

gout:

    End Sub

    Public Sub msPrepareCrossTabSummarySpecialHead(ByVal sSqlHead As String, ByVal sSqlDetails As String, ByVal MatchField As String, ByVal LeftTitle As String, ByVal LeftTitleField As String, ByVal SumField As String, Optional ByVal SumDataType As String = "N", Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "")

        ' 2010-09-25
        ' this is specially made for one report in SPS application

        ' sql rules
        ' ssqlhead should be sorted by matchfield (only one field neded)
        ' ssqldetails should be sorted by leftsidefield, matchfield (3 fields need including sumfield )
        'If sSqlHead and sqldetail should have same where cluase

        Dim dbCnCT As New OleDbConnection
        If Not msOpenDbConnection(dbCnCT) Then GoTo gout

        Dim frmS As New frmStatus
        frmS.Show("Generating Report, Please wait ...")

        '---------------------------------
        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "mmss")
        Dim fn As String
        'fn = "c:\Report.html"
        fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
        '-----------------------------------

        Dim s As String

        ' -----------------------------------------
        s = "<html>"

        s = s & "<head>"
        s = s & "<meta http-equiv='Content-Language' content='en-us'>"
        s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>SS Report</title>"
        s = s & "<STYLE>"
        s = s & "BR.page { page-break-after: always }"
        s = s & "</STYLE>"
        s = s & "</head>"

        s = s & "<body style='font-family: Verdana; font-size: 10px'>"

        My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

        s = "<p><i><b><font face='Tahoma' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
        s = s & "<p><font color='#800000' size='2'><b>" & RepHead & "</b></font></p>"

        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header
        s = ""

        Dim i As Integer

        Dim heads(100) As String
        Dim ColTotal(100) As Double
        Dim TotHeads As Integer

        Dim cmHead As OleDbCommand
        Dim drHead As OleDbDataReader

        Try

            i = 0
            cmHead = New OleDbCommand(sSqlHead, dbCnCT)
            drHead = cmHead.ExecuteReader
            Do While drHead.Read
                heads(i) = drHead.Item(MatchField).ToString
                i = i + 1
            Loop
            drHead.Close()
            cmHead.Dispose()
            TotHeads = i

        Catch ex As Exception
            msMessagebox("Error : 3219" & vbCrLf & ex.Message, Emoticons.ErrorIcon, "Attention")
            Exit Sub
        End Try


        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

        s = "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'>"


        s = s & "<thead><tr bgcolor='#99FFCC'>"
        s = s & "<td><b><font size='2'>" & LeftTitle & "</font></b></td>"

        Dim spclHead As String   ' for SPS added
        For i = 0 To 99
            If heads(i) = "" Then Exit For
            spclHead = Format(DateSerial(Mid(heads(i), 3, 4), Mid(heads(i), 1, 2), 1), "MMM yyyy")
            's = s & "<td><b><font size='2'>" & heads(i) & "</font></b></td>"
            s = s & "<td><b><font size='2'>" & spclHead & "</font></b></td>"
        Next

        s = s & "<td><b>Totals</b></td>"
        s = s & "</tr>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)
        s = ""

        Dim SideHead As String
        Dim OldSideHead As String
        Dim colHead As String

        OldSideHead = ""
        i = 0
        Dim c As Integer

        Dim cmDet As OleDbCommand
        Dim drDet As OleDbDataReader

        Dim RowTotal As Double
        Dim FullTotal As Double

        Try
            cmDet = New OleDbCommand(sSqlDetails, dbCnCT)
            drDet = cmDet.ExecuteReader
            s = 0
            RowTotal = 0

            Do While drDet.Read
                SideHead = drDet.Item(LeftTitleField).ToString
                s = ""
                ' close and got next row 
                If SideHead <> OldSideHead Then
                    ' if not firt row
                    If OldSideHead <> "" Then
                        Do While i < TotHeads
                            's = s & "<td>&nbsp;0</td>"
                            s = s & "<td align='right'><font size='2'>0</font></td>"
                            i = i + 1
                        Loop
                        If SumDataType = "F" Then
                            s = s & "<td align='right'><font size='2'>" & Format(RowTotal, "N") & "</font></td>"
                        Else
                            s = s & "<td align='right'><font size='2'>" & RowTotal & "</font></td>"
                        End If

                        s = s & "</tr>"
                    End If

                    OldSideHead = SideHead
                    s = s & "<tr>"
                    If IsDate(SideHead) Then
                        s = s & "<td>" & Format(CDate(SideHead), "Short Date") & "</td>"  ' hear option should be there to convert msdate to normal date if side head is date
                    Else
                        s = s & "<td><font size='2'>" & SideHead & "</font></td>"
                    End If
                    i = 0
                    RowTotal = 0
                End If

                colHead = drDet.Item(MatchField).ToString
                For c = i To TotHeads
                    If heads(c) = "" Then Exit For
                    If heads(c) = colHead Then
                        s = s & "<td "
                        s = s & " align='right' "
                        If SumDataType = "F" Then
                            s = s & " ><font size='2'>" & Format(drDet.Item(SumField), "N") & "</font></td>"

                        Else ' N
                            s = s & " ><font size='2'>" & drDet.Item(SumField) & "</font></td>"

                        End If

                        ColTotal(c) = ColTotal(c) + drDet.Item(SumField)
                        RowTotal = RowTotal + drDet.Item(SumField)
                        FullTotal = FullTotal + drDet.Item(SumField)
                        i = i + 1
                        Exit For
                    Else
                        's = s & "<td>&nbsp;0</td>"
                        s = s & "<td align='right'><font size='2'>0</font></td>"
                        i = i + 1
                    End If


                Next
                My.Computer.FileSystem.WriteAllText(fn, s, True)
                s = ""

            Loop

        Catch ex As Exception
            msMessagebox(ex.Message, Emoticons.ErrorIcon2, "Error : 1031")

        End Try

        ' close if in complete row

        ' if not first row
        If OldSideHead <> "" Then
            ' add row total
            Do While i < TotHeads
                s = s & "<td align='right'><font size='2'>0</font></td>"
                i = i + 1
            Loop
            If SumDataType = "F" Then
                s = s & "<td align='right'><font size='2'>" & Format(RowTotal, "N") & "</font></td>"
            Else
                s = s & "<td align='right'><font size='2'>" & RowTotal & "</font></td>"
            End If

            s = s & "</tr>"
        End If

        s = s & "<tr  bgcolor='#99FFCC'>"
        s = s & "<td><b>Totals</b></td>"
        's = s & "<td><b>��������</b></td>"
        For i = 0 To 99
            If heads(i) = "" Then Exit For
            If SumDataType = "F" Then
                s = s & "<td align='right'><b><font size='2'>" & Format(ColTotal(i), "N") & "<font size='2'></b></td>"
            Else
                s = s & "<td align='right'><b><font size='2'>" & ColTotal(i) & "<font size='2'></b></td>"
            End If

        Next
        If SumDataType = "F" Then
            s = s & "<td align='right'><b><font size='2'>" & Format(FullTotal, "N") & "<font size='2'></b></td>"
        Else
            s = s & "<td align='right'><b><font size='2'>" & FullTotal & "<font size='2'></b></td>"
        End If

        s = s & "</tr>"

        s = s & "</thead></table>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)

        s = ""

        frmS.Close()


        s = s & "</body>"

        s = s & "</html>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)

        Dim frmRep As New frmReports
        frmRep.ShowDialog(fn)


gout:

    End Sub

        Public Sub PrepareBasicConditionalReport(ByVal strSql As String, Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal CountCaption As String = "", Optional ByVal SumCaption As String = "", Optional ByVal SumField As String = "", Optional ByVal SumCaption2 As String = "", Optional ByVal SumField2 As String = "")

            Dim ncol As Boolean ' to check if debit and credit both 0 then change color
        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout

            Dim frmS As New frmStatus
            frmS.Show("Generating Report, Please wait ...")

            '---------------------------------
            '---------------------------------
            MakeReportDir()
            Dim subFn As String
            subFn = Format(Now(), "mmss")
            Dim fn As String
            'fn = "c:\Report.html"
            fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
            '-----------------------------------

            Dim cnt As Long

        Dim sumAmt As Double
            cnt = 0
            sumAmt = 0

            Dim SumAmt2 As Double
            sumAmt = 0

            Dim s As String

            ' -----------------------------------------
            s = "<html>"

            s = s & "<head>"
            s = s & "<meta http-equiv='Content-Language' content='en-us'>"
            s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>SS Report</title>"
            s = s & "</head>"

            s = s & "<body style='font-family: Verdana; font-size: 10px'>"

            My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

            s = "<p><i><b><font face='Verdana' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
            s = s & "<p><font color='#800000' size='2'><b>" & RepHead & "</b></font></p>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

            s = "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'>"
        s = s & "<thead><tr>"
            Dim i As Integer
            Dim d As String

            For i = 0 To 19
                If ArFields(i) = "" Then Exit For
                s = s & "<td "
                If ArSize(i) > 0 Then
                    s = s & "width = '" & ArSize(i) & "%' "
                End If
                s = s & " bgcolor='#99CCFF' "
                If ArType(i) = "C" Then  ' char ot center align then
                    s = s & " align='center' "
                ElseIf ArType(i) = "N" Then  ' nuber
                    s = s & " align='right' "
                ElseIf ArType(i) = "F" Then  ' floating
                    s = s & " align='right' "
                ElseIf ArType(i) = "D" Then   ' date
                    ' no need
                Else   ' string 
                    ' no need
                End If
                s = s & "><b><font size='2'>" & ArHeader(i) & "</font></b></td>"
            Next
        s = s & "</tr></thead>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table header

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
            Try
            cm = New OleDbCommand(strSql, dbCn)
                dr = cm.ExecuteReader


                Do While dr.Read
                    msDoEvents()
                    If dr.Item("Debit") = 0 And dr.Item("Credit") = 0 Then
                        ncol = True
                    Else
                        ncol = False
                    End If

                    s = "<tr>"
                    For i = 0 To 19
                        If ArFields(i) = "" Then Exit For
                        s = s & "<td "
                        If ArType(i) = "C" Then  ' char ot center align then
                            s = s & " align='center' "
                        ElseIf ArType(i) = "N" Then  ' nuber
                            s = s & " align='right' "
                        ElseIf ArType(i) = "F" Then  ' floating
                            s = s & " align='right' "
                        ElseIf ArType(i) = "D" Then   ' date
                            ' no need
                        Else   ' string 
                            ' no need
                        End If
                        s = s & " >"

                        If ncol Then
                            s = s & "<font color='#FF0000' size='2'>"
                        Else
                            s = s & "<font size='2'>"
                        End If

                        If ArType(i) = "C" Then  ' char ot center align then
                            d = dr.Item(ArFields(i)).ToString
                            If d = "" Then d = "&nbsp;"
                            s = s & d
                        ElseIf ArType(i) = "N" Then  ' number
                            s = s & dr.Item(ArFields(i))
                        ElseIf ArType(i) = "F" Then  ' floating
                            s = s & Format(dr.Item(ArFields(i)), "N")
                        ElseIf ArType(i) = "D" Then   ' date
                            d = dr.Item(ArFields(i)).ToString
                            If d = "" Then
                                s = s & "&nbsp;"
                            Else
                                s = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4)
                            End If
                        Else   ' string 
                            d = dr.Item(ArFields(i)).ToString
                            If d = "" Then d = "&nbsp;"
                            s = s & d
                        End If
                        s = s & "</font>"
                        s = s & "</td>"
                        If SumField <> "" Then
                            If ArFields(i) = SumField Then
                                sumAmt = sumAmt + dr.Item(ArFields(i))
                            End If
                        End If
                        If SumField2 <> "" Then
                            If ArFields(i) = SumField2 Then
                                SumAmt2 = SumAmt2 + dr.Item(ArFields(i))
                            End If
                        End If
                    Next
                    s = s & " </tr>"
                    My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table row
                    cnt = cnt + 1
                Loop

                dr.Close()
                cm.Dispose()
            Catch ex As Exception
            msMessagebox("Err: 2044 " & ex.Message, Emoticons.ErrorIcon)
            'MsgBox(ex.ToString)

            End Try

            dbCn.Close()

            s = "</table>"
            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' close table

            ' ----- summary
            If CountCaption > "" Or SumCaption > "" Then
                s = "<br>"
                s = s & "<table border='1' width='50%' id='table2'  cellpadding='0' cellspacing='0'>"
                If CountCaption > "" Then
                    s = s & "<tr>"
                    s = s & "<td><b><font size='2' color='#0000FF'>" & CountCaption & "</font></b></td>"
                    s = s & "<td>"
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & cnt & "</font></b></td>"
                    s = s & "</tr>"

                End If
                If SumCaption > "" Then
                    s = s & "<tr>"
                    s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption & "</font></b></td>"
                    s = s & "<td>"
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(sumAmt, "N") & "</font></b></td>"
                    s = s & "</tr>"
                End If
                If SumCaption2 > "" Then
                    s = s & "<tr>"
                    s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption2 & "</font></b></td>"
                    s = s & "<td>"
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt2, "N") & "</font></b></td>"
                    s = s & "</tr>"
                End If
                s = s & "</table>"

                My.Computer.FileSystem.WriteAllText(fn, s, True)   ' summary
            End If


            ' -------------

            ' write footer
            s = "<p><font color='#800000' size='2'><b>" & RepFoot & "</b></font></p>"
            s = s & "<p>&nbsp;</p>"
            s = s & "</body>"
            s = s & "</html>"
            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' footer
            ' -----------------------------------------

            frmS.Close()


            Dim frmRep As New frmReports
            frmRep.ShowDialog(fn)
            'frmRep.Show(fn)

gout:

        End Sub

        Public Sub PrepareBasicConditionalReport2(ByVal strSql As String, Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "")

            Dim nCol As Boolean
            nCol = False

        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout

            Dim frmS As New frmStatus
            frmS.Show("Generating Report, Please wait ...")

            '---------------------------------
            MakeReportDir()
            Dim subFn As String
            subFn = Format(Now(), "mmss")
            Dim fn As String
            'fn = "c:\Report.html"
            fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
            '-----------------------------------

            'Dim cnt As Long

            Dim s As String

            ' -----------------------------------------
            s = "<html>"

            s = s & "<head>"
            s = s & "<meta http-equiv='Content-Language' content='en-us'>"
            s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>SPS Report</title>"
            s = s & "</head>"

            s = s & "<body>"

            My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

            s = "<p><i><b><font face='Verdana' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
            s = s & "<p><font color='#800000' size='2'><b>" & RepHead & "</b></font></p>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

            s = "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'>"
        s = s & "<thead><tr>"
            Dim i As Integer
            Dim d As String

            For i = 0 To 19
                If ArFields(i) = "" Then Exit For
                s = s & "<td "
                If ArSize(i) > 0 Then
                    s = s & "width = '" & ArSize(i) & "%' "
                End If
                s = s & " bgcolor='#99CCFF' "
                If ArType(i) = "C" Then  ' char ot center align then
                    s = s & " align='center' "
                ElseIf ArType(i) = "N" Then  ' nuber
                    s = s & " align='right' "
                ElseIf ArType(i) = "F" Then  ' floating
                    s = s & " align='right' "
                ElseIf ArType(i) = "D" Then   ' date
                    ' no need
                Else   ' string 
                    ' no need
                End If
                s = s & "><b>" & ArHeader(i) & "</b></td>"
            Next
        s = s & "</tr></thead>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table header

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
            Try
            cm = New OleDbCommand(strSql, dbCn)
                dr = cm.ExecuteReader
                Do While dr.Read
                    If dr.Item("Debit") = 0 And dr.Item("Credit") = 0 Then
                        nCol = True
                    Else
                        nCol = False
                    End If

                    s = "<tr>"
                    For i = 0 To 19
                        If ArFields(i) = "" Then Exit For
                        s = s & "<td "
                        If ArType(i) = "C" Then  ' char ot center align then
                            s = s & " align='center' "
                        ElseIf ArType(i) = "N" Then  ' nuber
                            s = s & " align='right' "
                        ElseIf ArType(i) = "F" Then  ' floating
                            s = s & " align='right' "
                        ElseIf ArType(i) = "D" Then   ' date
                            ' no need
                        Else   ' string 
                            ' no need
                        End If
                        s = s & " >"
                        If nCol Then
                            s = s & "<font color='#FF0000' size='2'>"
                        Else
                            s = s & "<font size='2'>"
                        End If


                        If ArType(i) = "C" Then  ' char ot center align then
                            d = dr.Item(ArFields(i)).ToString
                            If d = "" Then d = "&nbsp;"
                            s = s & d
                        ElseIf ArType(i) = "N" Then  ' number
                            s = s & dr.Item(ArFields(i))
                        ElseIf ArType(i) = "F" Then  ' floating
                            s = s & Format(dr.Item(ArFields(i)), "N")
                        ElseIf ArType(i) = "D" Then   ' date
                            d = dr.Item(ArFields(i)).ToString
                            If d = "" Then
                                s = s & "&nbsp;"
                            Else
                                s = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4)
                            End If
                        Else   ' string 
                            d = dr.Item(ArFields(i)).ToString
                            If d = "" Then d = "&nbsp;"
                            s = s & d
                        End If

                        If nCol Then
                            s = s & "</font>"
                        End If
                        s = s & "</td>"
                    Next
                    s = s & "</font>"
                    s = s & " </tr>"
                    My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table row
                Loop

                dr.Close()
                cm.Dispose()
            Catch ex As Exception
            msMessagebox("Err: 2041 " & ex.Message, Emoticons.ErrorIcon)
            'MsgBox(ex.ToString)

            End Try

            dbCn.Close()

            s = "</table>"
            s = s & "<p><font color='#800000' size='2'><b>" & RepFoot & "</b></font></p>"
            s = s & "<p>&nbsp;</p>"
            s = s & "</body>"
            s = s & "</html>"
            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' footer
            ' -----------------------------------------

            frmS.Close()

            Dim frmRep As New frmReports
            frmRep.ShowDialog(fn)
        'frmRep.Show(fn)

gout:

        End Sub

        Private Sub MakeReportDir()

            If Not My.Computer.FileSystem.DirectoryExists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports") Then
                My.Computer.FileSystem.CreateDirectory(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports")
            End If

        End Sub

        Public Sub PrepareTimedReport(ByVal strSql As String, Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal CountCaption As String = "", Optional ByVal SumCaption As String = "", Optional ByVal SumField As String = "", Optional ByVal SumCaption2 As String = "", Optional ByVal SumField2 As String = "", Optional ByVal SumCaption3 As String = "", Optional ByVal SumField3 As String = "")

            ' this can replace to preparebasicreport with ardisp facility and saperate time calC
            'On Error Resume Next

        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout

            '        Dim frmS As New frmStatus
            '       frmS.Show("Generating Report, Please wait ...")

            Dim frmPrBar As New frmRepProgress
            frmPrBar.Show()

            '---------------------------------
            MakeReportDir()
            Dim subFn As String
            subFn = Format(Now(), "mmss")
            Dim fn As String
            'fn = "c:\Report.html"
            fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
            '-----------------------------------

            Dim cnt As Long
            Dim sumAmt As Double
            cnt = 0
            sumAmt = 0

            Dim SumAmt2 As Double
            SumAmt2 = 0

            Dim SumAmt3 As Double
            SumAmt3 = 0

            Dim SumSecs As Long
            SumSecs = 0

            Dim s As String

            ' -----------------------------------------
            s = "<html>"

            s = s & "<head>"
            s = s & "<meta http-equiv='Content-Language' content='en-us'>"
            s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>Blue Cheque Report</title>"
            s = s & "</head>"

            s = s & "<body style='font-family: Verdana; font-size: 10px'>"

            My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

            s = "<p><i><b><font face='Verdana' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
            s = s & "<p><font color='#800000' size='2'><b>" & RepHead & "</b></font></p>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

            s = "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'>"
        s = s & "<thead><tr>"
            Dim i As Integer
            Dim d As String

            For i = 0 To 19
                If ArFields(i) = "" Then Exit For
                If ArHeader(i) <> "" Then
                    s = s & "<td "
                    If ArSize(i) > 0 Then
                        s = s & "width = '" & ArSize(i) & "%' "
                    End If
                    s = s & " bgcolor='#99CCFF' "
                    If ArType(i) = "C" Then  ' char ot center align then
                        s = s & " align='center' "
                    ElseIf ArType(i) = "N" Then  ' nuber
                        s = s & " align='right' "
                    ElseIf ArType(i) = "F" Then  ' floating
                        s = s & " align='right' "
                    ElseIf ArType(i) = "D" Then   ' date
                        ' no need
                    Else   ' string 
                        ' no need
                    End If
                    s = s & "><b><font size='2'>" & ArHeader(i) & "</font></b></td>"
                End If
            Next
        s = s & "</tr></thead>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table header

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
            Try

            ' get count -------------------------------------
            Dim s1 As String
            s1 = "Select Count(*) from (" & strSql & ")"
            cm = New OleDbCommand(s1, dbCn)
                All_Tot_recs = cm.ExecuteScalar
                'MsgBox(All_Tot_recs)

                ' ------------------------------------------------

            cm = New OleDbCommand(strSql, dbCn)
                dr = cm.ExecuteReader
                Do While dr.Read

                    If Finish_Reporting Then
                        Exit Do
                    End If
                    Curr_rec += 1



                    msDoEvents()
                    s = "<tr>"
                    For i = 0 To 19
                        If ArFields(i) = "" Then Exit For
                        If ArHeader(i) <> "" Then


                            s = s & "<td "
                            If ArType(i) = "C" Then  ' char ot center align then
                                s = s & " align='center' "
                            ElseIf ArType(i) = "N" Then  ' nuber
                                s = s & " align='right' "
                            ElseIf ArType(i) = "F" Then  ' floating
                                s = s & " align='right' "
                            ElseIf ArType(i) = "D" Then   ' date
                                ' no need
                            Else   ' string 
                                ' no need
                            End If
                            s = s & " >"
                            s = s & "<font size='2'>"

                            If ArType(i) = "C" Then  ' char ot center align then
                                d = dr.Item(ArFields(i)).ToString
                                If d = "" Then d = "&nbsp;"
                                s = s & d
                            ElseIf ArType(i) = "N" Then  ' number
                                s = s & dr.Item(ArFields(i))
                            ElseIf ArType(i) = "F" Then  ' floating
                                s = s & Format(dr.Item(ArFields(i)), "N")
                            ElseIf ArType(i) = "D" Then   ' date
                                d = dr.Item(ArFields(i)).ToString
                                If d = "" Then
                                    s = s & "&nbsp;"
                                Else
                                    s = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4)
                                End If
                            Else   ' string 
                                d = dr.Item(ArFields(i)).ToString
                                If d = "" Then d = "&nbsp;"
                                s = s & d
                            End If
                            s = s & "</font>"
                            s = s & "</td>"
                        End If


                        If SumField <> "" Then
                            If ArFields(i) = SumField Then
                                sumAmt = sumAmt + dr.Item(ArFields(i))
                                If ArType(i) = "TS" Then   ' time in secs
                                    SumSecs = SumSecs + dr.Item(ArFields(i))
                                End If
                            End If
                        End If
                        If SumField2 <> "" Then
                            If ArFields(i) = SumField2 Then
                                SumAmt2 = SumAmt2 + dr.Item(ArFields(i))
                            End If
                        End If
                        If SumField3 <> "" Then
                            If ArFields(i) = SumField3 Then
                                SumAmt3 = SumAmt3 + dr.Item(ArFields(i))
                            End If
                        End If
                    Next

                    s = s & " </tr>"
                    My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table row
                    cnt = cnt + 1
                Loop
                Finish_Reporting = True

                dr.Close()
                cm.Dispose()

            Catch ex As Exception

                Finish_Reporting = True
                frmPrBar.Hide()

            msMessagebox("Err: 2042 " & ex.Message, Emoticons.ErrorIcon)
                'MsgBox(ex.ToString)

            End Try

            dbCn.Close()

            Try
                s = "</table>"
                My.Computer.FileSystem.WriteAllText(fn, s, True)   ' close table

                ' --- showcopyr adjustment
                If cnt > 1000 Then
                    SaveSetting("CAA", "ShowCopyR", "RVal", "-1")
                End If

                ' ----- summary
                If CountCaption > "" Or SumCaption > "" Then
                    s = "<br>"
                    s = s & "<table border='1' width='50%' id='table2'  cellpadding='0' cellspacing='0'>"
                    If CountCaption > "" Then
                        s = s & "<tr>"
                        s = s & "<td><b><font size='2' color='#0000FF'>" & CountCaption & "</font></b></td>"
                        s = s & "<td>"
                        s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & cnt & "</font></b></td>"
                        s = s & "</tr>"

                    End If
                    If SumCaption > "" Then
                        s = s & "<tr>"
                        s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption & "</font></b></td>"
                        s = s & "<td>"
                        If SumSecs > 0 Then
                            s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & msSecsToTime(SumSecs) & "</font></b></td>"
                        Else
                            s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(sumAmt, "N") & "</font></b></td>"
                        End If

                        s = s & "</tr>"
                    End If
                    If SumCaption2 > "" Then
                        s = s & "<tr>"
                        s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption2 & "</font></b></td>"
                        s = s & "<td>"
                        s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt2, "N") & "</font></b></td>"
                        s = s & "</tr>"
                    End If
                    If SumCaption3 > "" Then
                        s = s & "<tr>"
                        s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption3 & "</font></b></td>"
                        s = s & "<td>"
                        s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt3, "N") & "</font></b></td>"
                        s = s & "</tr>"
                    End If
                    s = s & "</table>"

                    My.Computer.FileSystem.WriteAllText(fn, s, True)   ' summary
                End If


                ' -------------

                ' write footer
                s = "<p><font color='#800000' size='2'><b>" & RepFoot & "</b></font></p>"
                s = s & "<p>&nbsp;</p>"
                s = s & "</body>"
                s = s & "</html>"
                My.Computer.FileSystem.WriteAllText(fn, s, True)   ' footer
                ' -----------------------------------------

                frmPrBar.Close()
                'frmS.Close()

                Finish_Reporting = True

            Catch ex As Exception

            End Try

            Try
                Dim frmRep As New frmReports
                frmRep.ShowDialog(fn)
                'frmRep.Show(fn)

            Catch ex As Exception

            End Try


gout:

        End Sub


        Public Sub PrepareTimedGroupedReport(ByVal strSql As String, Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal CountCaption As String = "", Optional ByVal SumCaption As String = "", Optional ByVal SumField As String = "", Optional ByVal SumCaption2 As String = "", Optional ByVal SumField2 As String = "", Optional ByVal SumCaption3 As String = "", Optional ByVal SumField3 As String = "", Optional ByVal prmNewFile As Boolean = True, Optional ByVal prmOpenReport As Boolean = True)

            ' this can replace to preparebasicreport with ardisp facility and saperate time calC

        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout

            Dim frmS As New frmStatus
            frmS.Show("Generating Report, Please wait ...")

            '---------------------------------
            '---------------------------------
            MakeReportDir()

            Dim subFn As String
            subFn = Format(Date.Today, "dd")
            Dim fn As String
            'fn = "c:\Report.html"
            fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
            '-----------------------------------

            Dim cnt As Long
            Dim sumAmt As Double
            cnt = 0
            sumAmt = 0

            Dim SumAmt2 As Double
            SumAmt2 = 0

            Dim SumAmt3 As Double
            SumAmt3 = 0

            Dim SumSecs As Long
            SumSecs = 0

            Dim s As String

            ' -----------------------------------------

            If prmNewFile Then
                s = "<html>"

                s = s & "<head>"
                s = s & "<meta http-equiv='Content-Language' content='en-us'>"
                s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
            s = s & "<title>SPS Report</title>"
                s = s & "</head>"

                s = s & "<STYLE>"   ' page break setting
                s = s & "BR.page { page-break-after: always }"
                s = s & "</STYLE>"

                s = s & "<body style='font-family: Verdana; font-size: 10px'>"

                My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

            End If

            s = "<p><i><b><font face='Verdana' size='5' color='#0000FF'>" & RepTitle & "</font></b></i></p>"
            s = s & "<p><font color='#800000' size='2'><b>" & RepHead & "</b></font></p>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

            s = "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'>"
        s = s & "<thead><tr>"
            Dim i As Integer
            Dim d As String

            For i = 0 To 19
                If ArFields(i) = "" Then Exit For
                If ArHeader(i) <> "" Then
                    s = s & "<td "
                    If ArSize(i) > 0 Then
                        s = s & "width = '" & ArSize(i) & "%' "
                    End If
                    s = s & " bgcolor='#99CCFF' "
                    If ArType(i) = "C" Then  ' char ot center align then
                        s = s & " align='center' "
                    ElseIf ArType(i) = "N" Then  ' nuber
                        s = s & " align='right' "
                    ElseIf ArType(i) = "F" Then  ' floating
                        s = s & " align='right' "
                    ElseIf ArType(i) = "D" Then   ' date
                        ' no need
                    Else   ' string 
                        ' no need
                    End If
                    s = s & "><b><font size='2'>" & ArHeader(i) & "</font></b></td>"
                End If
            Next
        s = s & "</tr></thead>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table header

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
            Try
            cm = New OleDbCommand(strSql, dbCn)
                dr = cm.ExecuteReader
                Do While dr.Read
                    msDoEvents()
                    s = "<tr>"
                    For i = 0 To 19
                        If ArFields(i) = "" Then Exit For
                        If ArHeader(i) <> "" Then


                            s = s & "<td "
                            If ArType(i) = "C" Then  ' char ot center align then
                                s = s & " align='center' "
                            ElseIf ArType(i) = "N" Then  ' nuber
                                s = s & " align='right' "
                            ElseIf ArType(i) = "F" Then  ' floating
                                s = s & " align='right' "
                            ElseIf ArType(i) = "D" Then   ' date
                                ' no need
                            Else   ' string 
                                ' no need
                            End If
                            s = s & " >"
                            s = s & "<font size='2'>"

                            If ArType(i) = "C" Then  ' char ot center align then
                                d = dr.Item(ArFields(i)).ToString
                                If d = "" Then d = "&nbsp;"
                                s = s & d
                            ElseIf ArType(i) = "N" Then  ' number
                                s = s & dr.Item(ArFields(i))
                            ElseIf ArType(i) = "F" Then  ' floating
                                s = s & Format(dr.Item(ArFields(i)), "N")
                            ElseIf ArType(i) = "D" Then   ' date
                                d = dr.Item(ArFields(i)).ToString
                                If d = "" Then
                                    s = s & "&nbsp;"
                                Else
                                    s = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4)
                                End If
                            Else   ' string 
                                d = dr.Item(ArFields(i)).ToString
                                If d = "" Then d = "&nbsp;"
                                s = s & d
                            End If
                            s = s & "</font>"
                            s = s & "</td>"
                        End If


                        If SumField <> "" Then
                            If ArFields(i) = SumField Then
                                sumAmt = sumAmt + dr.Item(ArFields(i))
                                If ArType(i) = "TS" Then   ' time in secs
                                    SumSecs = SumSecs + dr.Item(ArFields(i))
                                End If
                            End If
                        End If
                        If SumField2 <> "" Then
                            If ArFields(i) = SumField2 Then
                                SumAmt2 = SumAmt2 + dr.Item(ArFields(i))
                            End If
                        End If
                        If SumField3 <> "" Then
                            If ArFields(i) = SumField3 Then
                                SumAmt3 = SumAmt3 + dr.Item(ArFields(i))
                            End If
                        End If
                    Next

                    s = s & " </tr>"
                    My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table row
                    cnt = cnt + 1
                Loop

                dr.Close()
                cm.Dispose()
            Catch ex As Exception
            msMessagebox("Err: 2043 " & ex.Message, Emoticons.ErrorIcon)
            'MsgBox(ex.ToString)

            End Try

            dbCn.Close()

            s = "</table>"
            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' close table

            ' --- showcopyr adjustment
            If cnt > 1000 Then
                SaveSetting("CAA", "ShowCopyR", "RVal", "-1")
            End If

            ' ----- summary
            If CountCaption > "" Or SumCaption > "" Then
                s = "<br>"
                s = s & "<table border='1' width='50%' id='table2'  cellpadding='0' cellspacing='0'>"
                If CountCaption > "" Then
                    s = s & "<tr>"
                    s = s & "<td><b><font size='2' color='#0000FF'>" & CountCaption & "</font></b></td>"
                    s = s & "<td>"
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & cnt & "</font></b></td>"
                    s = s & "</tr>"

                End If
                If SumCaption > "" Then
                    s = s & "<tr>"
                    s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption & "</font></b></td>"
                    s = s & "<td>"
                    If SumSecs > 0 Then
                        s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & msSecsToTime(SumSecs) & "</font></b></td>"
                    Else
                        s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(sumAmt, "N") & "</font></b></td>"
                    End If

                    s = s & "</tr>"
                End If
                If SumCaption2 > "" Then
                    s = s & "<tr>"
                    s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption2 & "</font></b></td>"
                    s = s & "<td>"
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt2, "N") & "</font></b></td>"
                    s = s & "</tr>"
                End If
                If SumCaption3 > "" Then
                    s = s & "<tr>"
                    s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption3 & "</font></b></td>"
                    s = s & "<td>"
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt3, "N") & "</font></b></td>"
                    s = s & "</tr>"
                End If
                s = s & "</table>"

                My.Computer.FileSystem.WriteAllText(fn, s, True)   ' summary
            End If


            ' -------------

            ' write group footer
            s = "<p><font color='#800000' size='2'><b>" & RepFoot & "</b></font></p>"
            s = s & "<p>&nbsp;</p>"

            My.Computer.FileSystem.WriteAllText(fn, s, True)   ' footer
            ' -----------------------------------------

            frmS.Close()

            If prmOpenReport Then
                ' report footer
                s = "</body>"
                s = s & "</html>"
                My.Computer.FileSystem.WriteAllText(fn, s, True)   ' footer

                Dim frmRep As New frmReports  ' show report
                frmRep.ShowDialog(fn)
                'frmRep.Show(fn)


            Else   ' add pagebreak
                s = "<BR CLASS=page>"
                My.Computer.FileSystem.WriteAllText(fn, s, True)   ' footer

            End If

gout:

        End Sub

        Public Function msSecsToTime(ByVal TotSecs As Long) As String

            msSecsToTime = ""
            Dim h As Long
            Dim m As Long

            h = Int(TotSecs / 3600)
            TotSecs = TotSecs Mod 3600
            m = Int(TotSecs / 60)
            TotSecs = TotSecs Mod 60
            msSecsToTime = h & ":" & m & ":" & TotSecs

        End Function

    Public Sub msPrepareBasicReport(ByVal strSql As String, Optional ByVal RepTitle As String = "", Optional ByVal RepHead As String = "", Optional ByVal RepFoot As String = "", Optional ByVal CountCaption As String = "", Optional ByVal SumCaption As String = "", Optional ByVal SumField As String = "", Optional ByVal SumCaption2 As String = "", Optional ByVal SumField2 As String = "", Optional ByVal SumCaption3 As String = "", Optional ByVal SumField3 As String = "", Optional ByVal ShowSrNo As Boolean = True, Optional ByVal RepFileName As String = "", Optional ByVal ComNam As String = "", Optional ByVal colCode As String = "#0000FF", Optional ByVal OpenAsModal As Boolean = True, Optional ByVal MDI_Parent_Form As Form = Nothing)

        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout

        Dim frmS As New frmStatus
        frmS.Show("Generating Report, Please wait ...")

        '---------------------------------
        MakeReportDir()
        Dim subFn As String
        subFn = Format(Now(), "mmss")
        Dim fn As String
        'fn = "c:\Report.html"
        If RepFileName = "" Then
            fn = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MSReports\MSReports" & subFn & ".html"
        Else
            fn = RepFileName
        End If

        '-----------------------------------

        Dim cnt As Long
        Dim sumAmt As Double
        cnt = 0
        sumAmt = 0

        Dim SumAmt2 As Double
        SumAmt2 = 0

        Dim SumAmt3 As Double
        SumAmt3 = 0

        Dim sumDataType As String
        Dim sumDataType2 As String
        Dim sumDataType3 As String

        sumDataType = ""
        sumDataType2 = ""
        sumDataType3 = ""

        Dim s As String

        ' -----------------------------------------
        s = "<html>"

        s = s & "<head>"
        s = s & "<meta http-equiv='Content-Language' content='en-us'>"
        s = s & "<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>"
        s = s & "<title>&nbsp;</title>"
        s = s & "</head>"

        s = s & "<body style='font-family: Verdana; font-size: 10px'>"

        My.Computer.FileSystem.WriteAllText(fn, s, False)   ' html header

        If ComNam = "" Then
            s = ""
        Else
            If ComNam.StartsWith("<") Then  ' html code
                s = ComNam
            Else   ' prepare html
                s = "<p align='center'><b><font face='Verdana' size='4' color='" & colCode & "' >" & ComNam & "</font></b></p>"

            End If

        End If

        s = s & "<p><i><b><font face='Verdana' size='3' color='#0000FF'>" & RepTitle & "</font></b></i></p>"

        s = s & "<p><font color='#800000' size='2'>" & RepHead & "</font></p>"

        ' no need to write again and again in file
        'My.Computer.FileSystem.WriteAllText(fn, s, True)   ' report header

        s = s & "<table border='1' width='100%' id='table1' cellpadding='0' cellspacing='0'"
        s = s & " bordercolorlight='#99FF66' bordercolordark='#99FF66' bordercolor='#99FF66' style='border-collapse: collapse'>"
        s = s & "<thead><tr>"

        If ShowSrNo Then
            s = s & "<td bgcolor='#99CCFF' bordercolorlight='#99FF66' bordercolordark='#99FF66' align='center'><b><font size='2'>Sr No</font></b></td>"

        End If

        Dim i As Integer
        Dim d As String

        Dim sNo As Integer
        sNo = 1

        For i = 0 To ArBound

            If ArFields(i) = "" Then Exit For
            s = s & "<td "
            If ArSize(i) > 0 Then
                s = s & "width = '" & ArSize(i) & "%' "
            End If
            s = s & " bgcolor='#99CCFF' bordercolorlight='#99FF66' bordercolordark='#99FF66'"
            If ArType(i) = "C" Then  ' char center align then
                s = s & " align='center' "
            ElseIf ArType(i) = "N" Then  ' nuber
                s = s & " align='right' "
            ElseIf ArType(i) = "F" Then  ' floating
                s = s & " align='right' "
            ElseIf ArType(i) = "D" Then   ' date
                ' no need
            ElseIf ArType(i) = "DT" Then  ' date time
                ' no need

            Else   ' string 
                ' no need
            End If
            s = s & "><b><font size='2'>" & ArHeader(i) & "</font></b></td>"
        Next
        s = s & "</tr></thead>"

        'My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table header

        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
        Try
            cm = New OleDbCommand(strSql, dbCn)
            dr = cm.ExecuteReader
            Do While dr.Read
                msDoEvents()
                s = s & "<tr>"
                For i = 0 To ArBound
                    If i = 0 Then
                        If ShowSrNo Then
                            s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66' align='center'><font size='2'>" & sNo & "</font></td>"
                            'i = i + 1
                            sNo = sNo + 1
                        End If
                    End If
                    If ArFields(i) = "" Then Exit For
                    s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66' "
                    If ArType(i) = "C" Then  ' char ot center align then
                        s = s & " align='center' "
                    ElseIf ArType(i) = "N" Then  ' nuber
                        s = s & " align='right' "
                    ElseIf ArType(i) = "F" Then  ' floating
                        s = s & " align='right' "
                    ElseIf ArType(i) = "B" Then   ' barcode
                        s = s & " align='center' "
                    ElseIf ArType(i) = "D" Then   ' date
                        ' no need
                    ElseIf ArType(i) = "DT" Then   ' date time
                        ' no need
                    ElseIf ArType(i) = "SI" Then    ' signature image
                        ' no need
                    Else   ' string 
                        ' no need
                    End If
                    s = s & " >"
                    If ArType(i) = "B" Then   'barcode
                        s = s & "<font face='SKANDATArC39' size='8'>"

                    Else
                        s = s & "<font face='Verdana' size='2'>"

                    End If

                    If ArType(i) = "C" Then  ' char ot center align then
                        d = dr.Item(ArFields(i)).ToString
                        If d = "" Then d = "&nbsp;"
                        s = s & d
                    ElseIf ArType(i) = "N" Then  ' number
                        s = s & dr.Item(ArFields(i))
                    ElseIf ArType(i) = "F" Then  ' floating
                        s = s & Format(dr.Item(ArFields(i)), "N")
                    ElseIf ArType(i) = "D" Then   ' date
                        d = Trim(dr.Item(ArFields(i)).ToString)
                        If d = "" Then
                            s = s & "&nbsp;"
                        Else
                            's = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4)
                            s = s & Format(DateSerial(Mid(d, 1, 4), Mid(d, 6, 2), Mid(d, 9, 2)), "Short Date")
                        End If
                    ElseIf ArType(i) = "W" Then    ' waqt
                        d = Trim(dr.Item(ArFields(i)).ToString)
                        If d = "" Then
                            s = s & "&nbsp;"
                            'ElseIf d.StartsWith("20") Then  ' 4 digit yr 
                            ' 10 digits yyMMddHHmm
                            ' 12 dig    yyyyMMddHHmm   or yyMMddHHmmss
                            ' 14 dig    yyyyMMddHHmmss
                        Else    ' 4 digits year
                            s = s & Mid(d, 7, 2) & "/" & Mid(d, 5, 2) & "/" & Mid(d, 1, 4) & " " & Mid(d, 9, 2) & ":" & Mid(d, 11, 2)
                            's = s & Format(DateSerial(Mid(d, 1, 4), Mid(d, 6, 2), Mid(d, 9, 2)), "Short Date")
                            If d.Length = 14 Then   ' secs
                                s = s & ":" & Mid(d, 13, 2)
                            End If
                        End If

                    ElseIf ArType(i) = "DT" Then    ' date time yyyy-mm-dd hh:mm:ss format
                        d = Trim(dr.Item(ArFields(i)).ToString)
                        If d = "" Then
                            s = s & "&nbsp;"
                            'ElseIf d.StartsWith("20") Then  ' 4 digit yr 
                            ' 10 digits yyMMddHHmm
                            ' 12 dig    yyyyMMddHHmm   or yyMMddHHmmss
                            ' 14 dig    yyyyMMddHHmmss
                        Else    ' 4 digits year
                            s = s & Mid(d, 9, 2) & "/" & Mid(d, 6, 2) & "/" & Mid(d, 1, 4) & " " & Mid(d, 12, 5) ' w/o seconds & ":" & Mid(d, 11, 2)
                            's = s & Format(DateSerial(Mid(d, 1, 4), Mid(d, 6, 2), Mid(d, 9, 2)), "Short Date")
                            'If d.Length = 14 Then   ' secs
                            '    s = s & ":" & Mid(d, 13, 2)
                            'End If
                        End If
                    ElseIf ArType(i) = "SI" Then   ' sign image
                        s = s & "<img border='0' src=" & Trim(dr.Item(ArFields(i)).ToString) & "></td>"
                    ElseIf ArType(i).StartsWith("SIC") Then   ' custom size
                        If Len(ArType(i)) = 9 Then
                            s = s & "<img border='0' src=" & Trim(dr.Item(ArFields(i)).ToString) & " width='" & Mid(ArType(i), 4, 3) & "' height='" & Mid(ArType(i), 7, 3) & "'></td>"
                        End If
                    ElseIf ArType(i) = "B" Then
                        d = dr.Item(ArFields(i)).ToString & " "   ' & "<Br>"
                        If d = "" Then d = "&nbsp;"
                        s = s & d
                    ElseIf ArType(i) = "BL" Then
                        s = s & "&nbsp;&nbsp;&nbsp;<br>"
                    Else   ' string 
                        d = dr.Item(ArFields(i)).ToString & "&nbsp;"
                        If d = "" Then d = "&nbsp;"
                        s = s & d
                    End If
                    s = s & "</font>"
                    s = s & "</td>"
                    If SumField <> "" Then
                        If ArFields(i) = SumField Then
                            sumAmt = sumAmt + dr.Item(ArFields(i))
                            sumDataType = ArType(i)
                        End If
                    End If
                    If SumField2 <> "" Then
                        If ArFields(i) = SumField2 Then
                            SumAmt2 = SumAmt2 + dr.Item(ArFields(i))
                            sumDataType2 = ArType(i)
                        End If
                    End If
                    If SumField3 <> "" Then
                        If ArFields(i) = SumField3 Then
                            SumAmt3 = SumAmt3 + dr.Item(ArFields(i))
                            sumDataType3 = ArType(i)
                        End If
                    End If
                Next

                s = s & " </tr>"
                If Len(s) > 5000 Then
                    My.Computer.FileSystem.WriteAllText(fn, s, True)   ' table row
                    s = ""
                End If

                cnt = cnt + 1
            Loop

            dr.Close()
            cm.Dispose()
        Catch ex As Exception
            msMessagebox("Err: 2040 " & ex.Message, Emoticons.ErrorIcon)
            'MsgBox(ex.ToString)

        End Try

        dbCn.Close()

        s = s & "</thead></table>"
        'My.Computer.FileSystem.WriteAllText(fn, s, True)   ' close table

        ' ----- summary
        If CountCaption > "" Or SumCaption > "" Then
            s = s & "<br>"
            s = s & "<table border='1' width='50%' id='table2'  cellpadding='0' cellspacing='0'"    '>"
            s = s & " bordercolorlight='#99FF66' bordercolordark='#99FF66' bordercolor='#99FF66' style='border-collapse: collapse'>"

            If CountCaption > "" Then
                s = s & "<tr>"
                s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66'><b><font size='2' color='#0000FF'>" & CountCaption & "</font></b></td>"
                s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66'>"
                s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & cnt & "</font></b></td>"
                s = s & "</tr>"

            End If
            If SumCaption > "" Then
                s = s & "<tr>"
                s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66'><b><font size='2' color='#0000FF'>" & SumCaption & "</font></b></td>"
                s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66'>"
                If sumDataType = "F" Then
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(sumAmt, "N") & "</font></b></td>"
                Else
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & sumAmt & "</font></b></td>"
                End If

                s = s & "</tr>"
            End If
            If SumCaption2 > "" Then
                s = s & "<tr>"
                s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66'><b><font size='2' color='#0000FF'>" & SumCaption2 & "</font></b></td>"
                s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66'>"
                If sumDataType2 = "F" Then
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt2, "N") & "</font></b></td>"
                Else
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & SumAmt2 & "</font></b></td>"
                End If

                s = s & "</tr>"
            End If
            If SumCaption3 > "" Then
                s = s & "<tr bordercolorlight='#99FF66' bordercolordark='#99FF66'>"
                s = s & "<td><b><font size='2' color='#0000FF'>" & SumCaption3 & "</font></b></td>"
                s = s & "<td bordercolorlight='#99FF66' bordercolordark='#99FF66'>"
                If sumDataType3 = "F" Then
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & Format(SumAmt3, "N") & "</font></b></td>"
                Else
                    s = s & "<p align='right'><b><font size='2' color='#0000FF'>" & SumAmt3 & "</font></b></td>"
                End If

                s = s & "</tr>"
            End If
            s = s & "</table>"

            'My.Computer.FileSystem.WriteAllText(fn, s, True)   ' summary
        End If


        ' -------------

        ' write footer
        If RepFoot <> "" Then
            s = s & "<p><font color='#800000' size='2'><b>" & RepFoot & "</b></font></p>"
        End If

        s = s & "<p>&nbsp;</p>"
        s = s & "</body>"
        s = s & "</html>"
        My.Computer.FileSystem.WriteAllText(fn, s, True)   ' final entry in the file
        ' -----------------------------------------

        frmS.Close()

        If RepFileName = "" Then
            Dim frmRep As New frmReports
            If OpenAsModal Then
                frmRep.ShowDialog(fn)
            Else
                If IsNothing(MDI_Parent_Form) Then
                    ' do nothing
                Else
                    frmRep.MdiParent = MDI_Parent_Form
                End If
                frmRep.Show(fn)
            End If

        Else ' made for emailing
            ' do nothing - just prepare report file
        End If

gout:

    End Sub

#End Region

#Region "Random Encrypt"

    ' trial enc decode
    Public Function msTrialEnc(ByVal ctext As String) As String

        Dim ar(300) As String

        ar(0) = "R6"
        ar(1) = "YG"
        ar(2) = "37"
        ar(3) = "FU"
        ar(4) = "UF"
        ar(5) = "WT"
        ar(6) = "KZ"
        ar(7) = "2V"
        ar(8) = "SC"
        ar(9) = "T2"
        ar(10) = "KB"
        ar(11) = "VZ"
        ar(12) = "UK"
        ar(13) = "F7"
        ar(14) = "V6"
        ar(15) = "FV"
        ar(16) = "VD"
        ar(17) = "UR"
        ar(18) = "S8"
        ar(19) = "3U"
        ar(20) = "JN"
        ar(21) = "56"
        ar(22) = "YC"
        ar(23) = "WU"
        ar(24) = "SW"
        ar(25) = "YQ"
        ar(26) = "3P"
        ar(27) = "3B"
        ar(28) = "CG"
        ar(29) = "52"
        ar(30) = "2Y"
        ar(31) = "UY"
        ar(32) = "RY"
        ar(33) = "LG"
        ar(34) = "PR"
        ar(35) = "BS"
        ar(36) = "4Y"
        ar(37) = "CC"
        ar(38) = "QF"
        ar(39) = "AA"
        ar(40) = "CW"
        ar(41) = "C6"
        ar(42) = "N9"
        ar(43) = "4J"
        ar(44) = "VF"
        ar(45) = "72"
        ar(46) = "KC"
        ar(47) = "D2"
        ar(48) = "Q6"
        ar(49) = "ES"
        ar(50) = "PA"
        ar(51) = "4P"
        ar(52) = "XD"
        ar(53) = "L8"
        ar(54) = "K7"
        ar(55) = "TT"
        ar(56) = "2D"
        ar(57) = "8W"
        ar(58) = "H2"
        ar(59) = "6S"
        ar(60) = "VS"
        ar(61) = "A6"
        ar(62) = "P8"
        ar(63) = "C2"
        ar(64) = "VR"
        ar(65) = "TJ"
        ar(66) = "9T"
        ar(67) = "4W"
        ar(68) = "54"
        ar(69) = "33"
        ar(70) = "WZ"
        ar(71) = "TP"
        ar(72) = "S5"
        ar(73) = "9D"
        ar(74) = "79"
        ar(75) = "7A"
        ar(76) = "7W"
        ar(77) = "HP"
        ar(78) = "RS"
        ar(79) = "AY"
        ar(80) = "BG"
        ar(81) = "H5"
        ar(82) = "63"
        ar(83) = "UV"
        ar(84) = "KM"
        ar(85) = "7B"
        ar(86) = "59"
        ar(87) = "AU"
        ar(88) = "77"
        ar(89) = "7T"
        ar(90) = "JA"
        ar(91) = "8K"
        ar(92) = "XR"
        ar(93) = "8S"
        ar(94) = "JQ"
        ar(95) = "G4"
        ar(96) = "FS"
        ar(97) = "7F"
        ar(98) = "MG"
        ar(99) = "S2"
        ar(100) = "RK"
        ar(101) = "P2"
        ar(102) = "3A"
        ar(103) = "HE"
        ar(104) = "PD"
        ar(105) = "NR"
        ar(106) = "DE"
        ar(107) = "4X"
        ar(108) = "PV"
        ar(109) = "KQ"
        ar(110) = "7U"
        ar(111) = "ZW"
        ar(112) = "4A"
        ar(113) = "M3"
        ar(114) = "EP"
        ar(115) = "MX"
        ar(116) = "LV"
        ar(117) = "VX"
        ar(118) = "YA"
        ar(119) = "HF"
        ar(120) = "DK"
        ar(121) = "L3"
        ar(122) = "MW"
        ar(123) = "6Z"
        ar(124) = "WR"
        ar(125) = "AN"
        ar(126) = "PK"
        ar(127) = "KL"
        ar(128) = "E7"
        ar(129) = "TX"
        ar(130) = "6F"
        ar(131) = "A4"
        ar(132) = "PQ"
        ar(133) = "E9"
        ar(134) = "7G"
        ar(135) = "7Y"
        ar(136) = "34"
        ar(137) = "PE"
        ar(138) = "NN"
        ar(139) = "5P"
        ar(140) = "BC"
        ar(141) = "UL"
        ar(142) = "HA"
        ar(143) = "XU"
        ar(144) = "AQ"
        ar(145) = "ML"
        ar(146) = "AT"
        ar(147) = "VU"
        ar(148) = "3W"
        ar(149) = "KA"
        ar(150) = "G9"
        ar(151) = "SG"
        ar(152) = "58"
        ar(153) = "NC"
        ar(154) = "3X"
        ar(155) = "9M"
        ar(156) = "WG"
        ar(157) = "AG"
        ar(158) = "EM"
        ar(159) = "JE"
        ar(160) = "BU"
        ar(161) = "BM"
        ar(162) = "XM"
        ar(163) = "N2"
        ar(164) = "J2"
        ar(165) = "MB"
        ar(166) = "3L"
        ar(167) = "VY"
        ar(168) = "QA"
        ar(169) = "ZY"
        ar(170) = "76"
        ar(171) = "UM"
        ar(172) = "4B"
        ar(173) = "H7"
        ar(174) = "9B"
        ar(175) = "BH"
        ar(176) = "A3"
        ar(177) = "FH"
        ar(178) = "5N"
        ar(179) = "YD"
        ar(180) = "8V"
        ar(181) = "JY"
        ar(182) = "YZ"
        ar(183) = "FF"
        ar(184) = "DD"
        ar(185) = "B7"
        ar(186) = "JP"
        ar(187) = "WW"
        ar(188) = "C5"
        ar(189) = "M2"
        ar(190) = "GR"
        ar(191) = "MN"
        ar(192) = "7P"
        ar(193) = "CU"
        ar(194) = "7Q"
        ar(195) = "5J"
        ar(196) = "C4"
        ar(197) = "FC"
        ar(198) = "VK"
        ar(199) = "UJ"
        ar(200) = "MF"
        ar(201) = "YK"
        ar(202) = "9Y"
        ar(203) = "66"
        ar(204) = "5D"
        ar(205) = "TA"
        ar(206) = "H8"
        ar(207) = "XQ"
        ar(208) = "3M"
        ar(209) = "FM"
        ar(210) = "WC"
        ar(211) = "2L"
        ar(212) = "Y6"
        ar(213) = "6C"
        ar(214) = "LP"
        ar(215) = "DG"
        ar(216) = "M5"
        ar(217) = "CD"
        ar(218) = "PL"
        ar(219) = "3R"
        ar(220) = "GH"
        ar(221) = "TG"
        ar(222) = "4T"
        ar(223) = "ZS"
        ar(224) = "LW"
        ar(225) = "X8"
        ar(226) = "BZ"
        ar(227) = "AK"
        ar(228) = "P7"
        ar(229) = "PB"
        ar(230) = "EQ"
        ar(231) = "FB"
        ar(232) = "B4"
        ar(233) = "AV"
        ar(234) = "ZU"
        ar(235) = "UX"
        ar(236) = "SN"
        ar(237) = "ST"
        ar(238) = "PZ"
        ar(239) = "LK"
        ar(240) = "K3"
        ar(241) = "7Z"
        ar(242) = "ZM"
        ar(243) = "P9"
        ar(244) = "D4"
        ar(245) = "W5"
        ar(246) = "XG"
        ar(247) = "JH"
        ar(248) = "F6"
        ar(249) = "DR"
        ar(250) = "PJ"
        ar(251) = "YW"
        ar(252) = "GT"
        ar(253) = "3G"
        ar(254) = "F3"
        ar(255) = "FD"
        ar(256) = "SQ"
        ar(257) = "FY"
        ar(258) = "RX"
        ar(259) = "ZX"
        ar(260) = "B8"
        ar(261) = "V5"
        ar(262) = "ZK"
        ar(263) = "BA"
        ar(264) = "XP"
        ar(265) = "H9"
        ar(266) = "U8"
        ar(267) = "8H"
        ar(268) = "N5"
        ar(269) = "2C"
        ar(270) = "LA"
        ar(271) = "DU"
        ar(272) = "UH"
        ar(273) = "2M"
        ar(274) = "VH"
        ar(275) = "VE"
        ar(276) = "74"
        ar(277) = "5T"
        ar(278) = "LU"
        ar(279) = "Q3"
        ar(280) = "6Y"
        ar(281) = "96"
        ar(282) = "2J"
        ar(283) = "47"
        ar(284) = "YB"
        ar(285) = "GU"
        ar(286) = "86"
        ar(287) = "JU"
        ar(288) = "YR"
        ar(289) = "QU"
        ar(290) = "GZ"
        ar(291) = "TH"
        ar(292) = "22"
        ar(293) = "YL"
        ar(294) = "TS"
        ar(295) = "RQ"
        ar(296) = "YN"
        ar(297) = "AW"
        ar(298) = "JL"
        ar(299) = "9H"

        Dim r As Integer

        Randomize()
        r = Int(Rnd() * 10)

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As Integer
        sR = ""
        If ctext = "" Then
            msTrialEnc = ""
            Exit Function
        End If

        If Not IsNumeric(ctext) Then
            msTrialEnc = ""
            Exit Function
        End If

        nl = Len(ctext)
        Dim p As String
        Dim k As Integer
        k = 0

        l = Asc(r)

        For i = 1 To nl
            k = k + 1
            If k > 13 Then k = 0
            p = Mid(ctext, i, 1)
            aski = Asc(p) + k + r
            l = l + aski
            sR = sR & ar(aski)
        Next

        Dim m201 As Integer
        m201 = l Mod 209

        sR = ar(m201) & ar(r) & sR

        Dim mod253 As Integer
        mod253 = Val(ctext) Mod 253

        sR = sR & ar(mod253)

        msTrialEnc = sR


    End Function


    Public Function msTrialDec(ByVal ctext As String) As String

        Dim ar(300) As String

        ar(0) = "R6"
        ar(1) = "YG"
        ar(2) = "37"
        ar(3) = "FU"
        ar(4) = "UF"
        ar(5) = "WT"
        ar(6) = "KZ"
        ar(7) = "2V"
        ar(8) = "SC"
        ar(9) = "T2"
        ar(10) = "KB"
        ar(11) = "VZ"
        ar(12) = "UK"
        ar(13) = "F7"
        ar(14) = "V6"
        ar(15) = "FV"
        ar(16) = "VD"
        ar(17) = "UR"
        ar(18) = "S8"
        ar(19) = "3U"
        ar(20) = "JN"
        ar(21) = "56"
        ar(22) = "YC"
        ar(23) = "WU"
        ar(24) = "SW"
        ar(25) = "YQ"
        ar(26) = "3P"
        ar(27) = "3B"
        ar(28) = "CG"
        ar(29) = "52"
        ar(30) = "2Y"
        ar(31) = "UY"
        ar(32) = "RY"
        ar(33) = "LG"
        ar(34) = "PR"
        ar(35) = "BS"
        ar(36) = "4Y"
        ar(37) = "CC"
        ar(38) = "QF"
        ar(39) = "AA"
        ar(40) = "CW"
        ar(41) = "C6"
        ar(42) = "N9"
        ar(43) = "4J"
        ar(44) = "VF"
        ar(45) = "72"
        ar(46) = "KC"
        ar(47) = "D2"
        ar(48) = "Q6"
        ar(49) = "ES"
        ar(50) = "PA"
        ar(51) = "4P"
        ar(52) = "XD"
        ar(53) = "L8"
        ar(54) = "K7"
        ar(55) = "TT"
        ar(56) = "2D"
        ar(57) = "8W"
        ar(58) = "H2"
        ar(59) = "6S"
        ar(60) = "VS"
        ar(61) = "A6"
        ar(62) = "P8"
        ar(63) = "C2"
        ar(64) = "VR"
        ar(65) = "TJ"
        ar(66) = "9T"
        ar(67) = "4W"
        ar(68) = "54"
        ar(69) = "33"
        ar(70) = "WZ"
        ar(71) = "TP"
        ar(72) = "S5"
        ar(73) = "9D"
        ar(74) = "79"
        ar(75) = "7A"
        ar(76) = "7W"
        ar(77) = "HP"
        ar(78) = "RS"
        ar(79) = "AY"
        ar(80) = "BG"
        ar(81) = "H5"
        ar(82) = "63"
        ar(83) = "UV"
        ar(84) = "KM"
        ar(85) = "7B"
        ar(86) = "59"
        ar(87) = "AU"
        ar(88) = "77"
        ar(89) = "7T"
        ar(90) = "JA"
        ar(91) = "8K"
        ar(92) = "XR"
        ar(93) = "8S"
        ar(94) = "JQ"
        ar(95) = "G4"
        ar(96) = "FS"
        ar(97) = "7F"
        ar(98) = "MG"
        ar(99) = "S2"
        ar(100) = "RK"
        ar(101) = "P2"
        ar(102) = "3A"
        ar(103) = "HE"
        ar(104) = "PD"
        ar(105) = "NR"
        ar(106) = "DE"
        ar(107) = "4X"
        ar(108) = "PV"
        ar(109) = "KQ"
        ar(110) = "7U"
        ar(111) = "ZW"
        ar(112) = "4A"
        ar(113) = "M3"
        ar(114) = "EP"
        ar(115) = "MX"
        ar(116) = "LV"
        ar(117) = "VX"
        ar(118) = "YA"
        ar(119) = "HF"
        ar(120) = "DK"
        ar(121) = "L3"
        ar(122) = "MW"
        ar(123) = "6Z"
        ar(124) = "WR"
        ar(125) = "AN"
        ar(126) = "PK"
        ar(127) = "KL"
        ar(128) = "E7"
        ar(129) = "TX"
        ar(130) = "6F"
        ar(131) = "A4"
        ar(132) = "PQ"
        ar(133) = "E9"
        ar(134) = "7G"
        ar(135) = "7Y"
        ar(136) = "34"
        ar(137) = "PE"
        ar(138) = "NN"
        ar(139) = "5P"
        ar(140) = "BC"
        ar(141) = "UL"
        ar(142) = "HA"
        ar(143) = "XU"
        ar(144) = "AQ"
        ar(145) = "ML"
        ar(146) = "AT"
        ar(147) = "VU"
        ar(148) = "3W"
        ar(149) = "KA"
        ar(150) = "G9"
        ar(151) = "SG"
        ar(152) = "58"
        ar(153) = "NC"
        ar(154) = "3X"
        ar(155) = "9M"
        ar(156) = "WG"
        ar(157) = "AG"
        ar(158) = "EM"
        ar(159) = "JE"
        ar(160) = "BU"
        ar(161) = "BM"
        ar(162) = "XM"
        ar(163) = "N2"
        ar(164) = "J2"
        ar(165) = "MB"
        ar(166) = "3L"
        ar(167) = "VY"
        ar(168) = "QA"
        ar(169) = "ZY"
        ar(170) = "76"
        ar(171) = "UM"
        ar(172) = "4B"
        ar(173) = "H7"
        ar(174) = "9B"
        ar(175) = "BH"
        ar(176) = "A3"
        ar(177) = "FH"
        ar(178) = "5N"
        ar(179) = "YD"
        ar(180) = "8V"
        ar(181) = "JY"
        ar(182) = "YZ"
        ar(183) = "FF"
        ar(184) = "DD"
        ar(185) = "B7"
        ar(186) = "JP"
        ar(187) = "WW"
        ar(188) = "C5"
        ar(189) = "M2"
        ar(190) = "GR"
        ar(191) = "MN"
        ar(192) = "7P"
        ar(193) = "CU"
        ar(194) = "7Q"
        ar(195) = "5J"
        ar(196) = "C4"
        ar(197) = "FC"
        ar(198) = "VK"
        ar(199) = "UJ"
        ar(200) = "MF"
        ar(201) = "YK"
        ar(202) = "9Y"
        ar(203) = "66"
        ar(204) = "5D"
        ar(205) = "TA"
        ar(206) = "H8"
        ar(207) = "XQ"
        ar(208) = "3M"
        ar(209) = "FM"
        ar(210) = "WC"
        ar(211) = "2L"
        ar(212) = "Y6"
        ar(213) = "6C"
        ar(214) = "LP"
        ar(215) = "DG"
        ar(216) = "M5"
        ar(217) = "CD"
        ar(218) = "PL"
        ar(219) = "3R"
        ar(220) = "GH"
        ar(221) = "TG"
        ar(222) = "4T"
        ar(223) = "ZS"
        ar(224) = "LW"
        ar(225) = "X8"
        ar(226) = "BZ"
        ar(227) = "AK"
        ar(228) = "P7"
        ar(229) = "PB"
        ar(230) = "EQ"
        ar(231) = "FB"
        ar(232) = "B4"
        ar(233) = "AV"
        ar(234) = "ZU"
        ar(235) = "UX"
        ar(236) = "SN"
        ar(237) = "ST"
        ar(238) = "PZ"
        ar(239) = "LK"
        ar(240) = "K3"
        ar(241) = "7Z"
        ar(242) = "ZM"
        ar(243) = "P9"
        ar(244) = "D4"
        ar(245) = "W5"
        ar(246) = "XG"
        ar(247) = "JH"
        ar(248) = "F6"
        ar(249) = "DR"
        ar(250) = "PJ"
        ar(251) = "YW"
        ar(252) = "GT"
        ar(253) = "3G"
        ar(254) = "F3"
        ar(255) = "FD"
        ar(256) = "SQ"
        ar(257) = "FY"
        ar(258) = "RX"
        ar(259) = "ZX"
        ar(260) = "B8"
        ar(261) = "V5"
        ar(262) = "ZK"
        ar(263) = "BA"
        ar(264) = "XP"
        ar(265) = "H9"
        ar(266) = "U8"
        ar(267) = "8H"
        ar(268) = "N5"
        ar(269) = "2C"
        ar(270) = "LA"
        ar(271) = "DU"
        ar(272) = "UH"
        ar(273) = "2M"
        ar(274) = "VH"
        ar(275) = "VE"
        ar(276) = "74"
        ar(277) = "5T"
        ar(278) = "LU"
        ar(279) = "Q3"
        ar(280) = "6Y"
        ar(281) = "96"
        ar(282) = "2J"
        ar(283) = "47"
        ar(284) = "YB"
        ar(285) = "GU"
        ar(286) = "86"
        ar(287) = "JU"
        ar(288) = "YR"
        ar(289) = "QU"
        ar(290) = "GZ"
        ar(291) = "TH"
        ar(292) = "22"
        ar(293) = "YL"
        ar(294) = "TS"
        ar(295) = "RQ"
        ar(296) = "YN"
        ar(297) = "AW"
        ar(298) = "JL"
        ar(299) = "9H"
        '        ar(300) = "FW"

        Dim r As Integer
        Dim rChar As String

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As String
        Dim m201 As Integer
        Dim mChar As String

        If ctext = "" Then
            msTrialDec = ""
            Exit Function
        End If

        If Len(ctext) < 4 Then
            msTrialDec = ""
            Exit Function
        End If

        Dim mod253 As Integer
        'mod253 = Val(ctext) Mod 253
        mChar = Mid(ctext, Len(ctext) - 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                mod253 = i
                Exit For
            End If
        Next

        ctext = Mid(ctext, 1, Len(ctext) - 2)


        mChar = Mid(ctext, 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                m201 = i
                Exit For
            End If
        Next

        rChar = Mid(ctext, 3, 2)
        For i = 0 To 255
            If ar(i) = rChar Then
                r = i
                Exit For
            End If
        Next

        l = Asc(r)
        nl = Len(ctext)

        Dim j As Integer
        Dim k As Integer
        k = 0
        sR = ""

        For i = 5 To nl Step 2
            k = k + 1
            If k > 13 Then k = 0
            aski = Mid(ctext, i, 2)
            For j = 0 To 255
                If ar(j) = aski Then
                    l = l + j
                    On Error Resume Next
                    sR = sR & Chr(j - k - r)

                    Exit For
                End If
            Next
        Next

        If IsNumeric(sR) Then

            If m201 = l Mod 209 Then
                'sR = sR
                If sR Mod 253 = mod253 Then
                    ' output sr
                Else
                    sR = ""
                End If
            Else
                sR = ""  '  "0" & sR
            End If

        Else
            sR = ""
        End If


        msTrialDec = sR

    End Function

    ' basic enc decode

    Public Function msBasicDec(ByVal ctext As String) As String

        Dim ar(300) As String

        ar(0) = "8B"
        ar(1) = "LH"
        ar(2) = "DJ"
        ar(3) = "2W"
        ar(4) = "GH"
        ar(5) = "62"
        ar(6) = "4B"
        ar(7) = "AJ"
        ar(8) = "DN"
        ar(9) = "QB"
        ar(10) = "DV"
        ar(11) = "6J"
        ar(12) = "M4"
        ar(13) = "A6"
        ar(14) = "AT"
        ar(15) = "EH"
        ar(16) = "BJ"
        ar(17) = "LL"
        ar(18) = "QZ"
        ar(19) = "TA"
        ar(20) = "FU"
        ar(21) = "TQ"
        ar(22) = "QD"
        ar(23) = "38"
        ar(24) = "7F"
        ar(25) = "AL"
        ar(26) = "KH"
        ar(27) = "5F"
        ar(28) = "WM"
        ar(29) = "V8"
        ar(30) = "3K"
        ar(31) = "BG"
        ar(32) = "MV"
        ar(33) = "VU"
        ar(34) = "35"
        ar(35) = "6P"
        ar(36) = "Z7"
        ar(37) = "CG"
        ar(38) = "57"
        ar(39) = "PN"
        ar(40) = "8D"
        ar(41) = "82"
        ar(42) = "2N"
        ar(43) = "2H"
        ar(44) = "56"
        ar(45) = "R2"
        ar(46) = "KG"
        ar(47) = "58"
        ar(48) = "KK"
        ar(49) = "6W"
        ar(50) = "LD"
        ar(51) = "HP"
        ar(52) = "NM"
        ar(53) = "CN"
        ar(54) = "5M"
        ar(55) = "RH"
        ar(56) = "MZ"
        ar(57) = "72"
        ar(58) = "PR"
        ar(59) = "PC"
        ar(60) = "YA"
        ar(61) = "QM"
        ar(62) = "YR"
        ar(63) = "L7"
        ar(64) = "SE"
        ar(65) = "QU"
        ar(66) = "B4"
        ar(67) = "T5"
        ar(68) = "SR"
        ar(69) = "NH"
        ar(70) = "XG"
        ar(71) = "NB"
        ar(72) = "HQ"
        ar(73) = "LN"
        ar(74) = "FW"
        ar(75) = "PA"
        ar(76) = "B3"
        ar(77) = "TC"
        ar(78) = "L5"
        ar(79) = "GM"
        ar(80) = "UL"
        ar(81) = "5E"
        ar(82) = "VK"
        ar(83) = "KF"
        ar(84) = "6M"
        ar(85) = "76"
        ar(86) = "SG"
        ar(87) = "KV"
        ar(88) = "ZN"
        ar(89) = "9N"
        ar(90) = "P2"
        ar(91) = "BP"
        ar(92) = "QJ"
        ar(93) = "49"
        ar(94) = "X6"
        ar(95) = "VR"
        ar(96) = "Q7"
        ar(97) = "ZA"
        ar(98) = "E6"
        ar(99) = "Q4"
        ar(100) = "LF"
        ar(101) = "KC"
        ar(102) = "5H"
        ar(103) = "XC"
        ar(104) = "BA"
        ar(105) = "ZP"
        ar(106) = "CH"
        ar(107) = "AN"
        ar(108) = "DF"
        ar(109) = "FZ"
        ar(110) = "PQ"
        ar(111) = "3A"
        ar(112) = "KT"
        ar(113) = "WL"
        ar(114) = "QX"
        ar(115) = "PY"
        ar(116) = "59"
        ar(117) = "DX"
        ar(118) = "85"
        ar(119) = "X7"
        ar(120) = "BY"
        ar(121) = "TL"
        ar(122) = "GC"
        ar(123) = "QW"
        ar(124) = "BF"
        ar(125) = "GW"
        ar(126) = "LV"
        ar(127) = "WE"
        ar(128) = "DL"
        ar(129) = "J4"
        ar(130) = "2K"
        ar(131) = "XP"
        ar(132) = "99"
        ar(133) = "GV"
        ar(134) = "7J"
        ar(135) = "ML"
        ar(136) = "VW"
        ar(137) = "SV"
        ar(138) = "7Z"
        ar(139) = "3N"
        ar(140) = "XB"
        ar(141) = "VZ"
        ar(142) = "JV"
        ar(143) = "EW"
        ar(144) = "L3"
        ar(145) = "32"
        ar(146) = "Y8"
        ar(147) = "JJ"
        ar(148) = "YM"
        ar(149) = "QG"
        ar(150) = "H4"
        ar(151) = "FJ"
        ar(152) = "V3"
        ar(153) = "3M"
        ar(154) = "DS"
        ar(155) = "9A"
        ar(156) = "D9"
        ar(157) = "98"
        ar(158) = "8H"
        ar(159) = "TD"
        ar(160) = "MP"
        ar(161) = "CQ"
        ar(162) = "XW"
        ar(163) = "D6"
        ar(164) = "4E"
        ar(165) = "LY"
        ar(166) = "L2"
        ar(167) = "NV"
        ar(168) = "HG"
        ar(169) = "XU"
        ar(170) = "NX"
        ar(171) = "4W"
        ar(172) = "2Z"
        ar(173) = "SF"
        ar(174) = "EP"
        ar(175) = "M7"
        ar(176) = "3C"
        ar(177) = "K7"
        ar(178) = "ZJ"
        ar(179) = "SQ"
        ar(180) = "MX"
        ar(181) = "96"
        ar(182) = "WT"
        ar(183) = "P9"
        ar(184) = "C2"
        ar(185) = "WH"
        ar(186) = "RR"
        ar(187) = "UN"
        ar(188) = "UD"
        ar(189) = "BV"
        ar(190) = "H8"
        ar(191) = "P5"
        ar(192) = "29"
        ar(193) = "Z9"
        ar(194) = "4A"
        ar(195) = "UQ"
        ar(196) = "R8"
        ar(197) = "47"
        ar(198) = "2G"
        ar(199) = "M3"
        ar(200) = "SL"
        ar(201) = "E7"
        ar(202) = "ZS"
        ar(203) = "7E"
        ar(204) = "2X"
        ar(205) = "2Y"
        ar(206) = "TF"
        ar(207) = "PM"
        ar(208) = "M2"
        ar(209) = "EY"
        ar(210) = "3J"
        ar(211) = "WS"
        ar(212) = "54"
        ar(213) = "9E"
        ar(214) = "8J"
        ar(215) = "TS"
        ar(216) = "N8"
        ar(217) = "BQ"
        ar(218) = "YF"
        ar(219) = "5N"
        ar(220) = "H3"
        ar(221) = "2T"
        ar(222) = "2B"
        ar(223) = "AV"
        ar(224) = "Y2"
        ar(225) = "YZ"
        ar(226) = "SA"
        ar(227) = "4Q"
        ar(228) = "89"
        ar(229) = "7N"
        ar(230) = "FA"
        ar(231) = "A8"
        ar(232) = "XJ"
        ar(233) = "2M"
        ar(234) = "63"
        ar(235) = "AP"
        ar(236) = "5Z"
        ar(237) = "LC"
        ar(238) = "NW"
        ar(239) = "3P"
        ar(240) = "BD"
        ar(241) = "BN"
        ar(242) = "K5"
        ar(243) = "Q9"
        ar(244) = "TK"
        ar(245) = "3U"
        ar(246) = "VL"
        ar(247) = "JZ"
        ar(248) = "DA"
        ar(249) = "DC"
        ar(250) = "53"
        ar(251) = "4Y"
        ar(252) = "NU"
        ar(253) = "J6"
        ar(254) = "ZL"
        ar(255) = "RQ"
        ar(256) = "5L"
        ar(257) = "P4"
        ar(258) = "FR"
        ar(259) = "PP"
        ar(260) = "XS"
        ar(261) = "Z5"
        ar(262) = "9J"
        ar(263) = "JU"
        ar(264) = "KE"
        ar(265) = "U6"
        ar(266) = "R4"
        ar(267) = "ZZ"
        ar(268) = "SJ"
        ar(269) = "6Y"
        ar(270) = "79"
        ar(271) = "RC"
        ar(272) = "UF"
        ar(273) = "YL"
        ar(274) = "DB"
        ar(275) = "VC"
        ar(276) = "TG"
        ar(277) = "QQ"
        ar(278) = "7U"
        ar(279) = "NK"
        ar(280) = "6A"
        ar(281) = "JB"
        ar(282) = "LA"
        ar(283) = "46"
        ar(284) = "6Z"
        ar(285) = "CB"
        ar(286) = "KZ"
        ar(287) = "5K"
        ar(288) = "6Q"
        ar(289) = "RB"
        ar(290) = "88"
        ar(291) = "7S"
        ar(292) = "ZQ"
        ar(293) = "VY"
        ar(294) = "7Y"
        ar(295) = "5C"
        ar(296) = "JY"
        ar(297) = "4P"
        ar(298) = "2Q"
        ar(299) = "9G"

        Dim r As Integer
        Dim rChar As String

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As String
        Dim m201 As Integer
        Dim mChar As String

        If ctext = "" Then
            msBasicDec = ""
            Exit Function
        End If

        If Len(ctext) < 4 Then
            msBasicDec = ""
            Exit Function
        End If

        Dim mod253 As Integer
        'mod253 = Val(ctext) Mod 253
        mChar = Mid(ctext, Len(ctext) - 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                mod253 = i
                Exit For
            End If
        Next

        ctext = Mid(ctext, 1, Len(ctext) - 2)


        mChar = Mid(ctext, 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                m201 = i
                Exit For
            End If
        Next

        rChar = Mid(ctext, 3, 2)
        For i = 0 To 255
            If ar(i) = rChar Then
                r = i
                Exit For
            End If
        Next

        l = Asc(r)
        nl = Len(ctext)

        Dim j As Integer
        Dim k As Integer
        k = 0
        sR = ""

        For i = 5 To nl Step 2
            k = k + 1
            If k > 13 Then k = 0
            aski = Mid(ctext, i, 2)
            For j = 0 To 255
                If ar(j) = aski Then
                    l = l + j
                    On Error Resume Next
                    sR = sR & Chr(j - k - r)

                    Exit For
                End If
            Next
        Next

        If IsNumeric(sR) Then

            If m201 = l Mod 209 Then
                'sR = sR
                If sR Mod 253 = mod253 Then
                    ' output sr
                Else
                    sR = ""
                End If
            Else
                sR = ""  '  "0" & sR
            End If

        Else
            sR = ""
        End If


        msBasicDec = sR



    End Function



    Public Function msBasicEnc(ByVal ctext As String) As String

        Dim ar(300) As String

        ar(0) = "8B"
        ar(1) = "LH"
        ar(2) = "DJ"
        ar(3) = "2W"
        ar(4) = "GH"
        ar(5) = "62"
        ar(6) = "4B"
        ar(7) = "AJ"
        ar(8) = "DN"
        ar(9) = "QB"
        ar(10) = "DV"
        ar(11) = "6J"
        ar(12) = "M4"
        ar(13) = "A6"
        ar(14) = "AT"
        ar(15) = "EH"
        ar(16) = "BJ"
        ar(17) = "LL"
        ar(18) = "QZ"
        ar(19) = "TA"
        ar(20) = "FU"
        ar(21) = "TQ"
        ar(22) = "QD"
        ar(23) = "38"
        ar(24) = "7F"
        ar(25) = "AL"
        ar(26) = "KH"
        ar(27) = "5F"
        ar(28) = "WM"
        ar(29) = "V8"
        ar(30) = "3K"
        ar(31) = "BG"
        ar(32) = "MV"
        ar(33) = "VU"
        ar(34) = "35"
        ar(35) = "6P"
        ar(36) = "Z7"
        ar(37) = "CG"
        ar(38) = "57"
        ar(39) = "PN"
        ar(40) = "8D"
        ar(41) = "82"
        ar(42) = "2N"
        ar(43) = "2H"
        ar(44) = "56"
        ar(45) = "R2"
        ar(46) = "KG"
        ar(47) = "58"
        ar(48) = "KK"
        ar(49) = "6W"
        ar(50) = "LD"
        ar(51) = "HP"
        ar(52) = "NM"
        ar(53) = "CN"
        ar(54) = "5M"
        ar(55) = "RH"
        ar(56) = "MZ"
        ar(57) = "72"
        ar(58) = "PR"
        ar(59) = "PC"
        ar(60) = "YA"
        ar(61) = "QM"
        ar(62) = "YR"
        ar(63) = "L7"
        ar(64) = "SE"
        ar(65) = "QU"
        ar(66) = "B4"
        ar(67) = "T5"
        ar(68) = "SR"
        ar(69) = "NH"
        ar(70) = "XG"
        ar(71) = "NB"
        ar(72) = "HQ"
        ar(73) = "LN"
        ar(74) = "FW"
        ar(75) = "PA"
        ar(76) = "B3"
        ar(77) = "TC"
        ar(78) = "L5"
        ar(79) = "GM"
        ar(80) = "UL"
        ar(81) = "5E"
        ar(82) = "VK"
        ar(83) = "KF"
        ar(84) = "6M"
        ar(85) = "76"
        ar(86) = "SG"
        ar(87) = "KV"
        ar(88) = "ZN"
        ar(89) = "9N"
        ar(90) = "P2"
        ar(91) = "BP"
        ar(92) = "QJ"
        ar(93) = "49"
        ar(94) = "X6"
        ar(95) = "VR"
        ar(96) = "Q7"
        ar(97) = "ZA"
        ar(98) = "E6"
        ar(99) = "Q4"
        ar(100) = "LF"
        ar(101) = "KC"
        ar(102) = "5H"
        ar(103) = "XC"
        ar(104) = "BA"
        ar(105) = "ZP"
        ar(106) = "CH"
        ar(107) = "AN"
        ar(108) = "DF"
        ar(109) = "FZ"
        ar(110) = "PQ"
        ar(111) = "3A"
        ar(112) = "KT"
        ar(113) = "WL"
        ar(114) = "QX"
        ar(115) = "PY"
        ar(116) = "59"
        ar(117) = "DX"
        ar(118) = "85"
        ar(119) = "X7"
        ar(120) = "BY"
        ar(121) = "TL"
        ar(122) = "GC"
        ar(123) = "QW"
        ar(124) = "BF"
        ar(125) = "GW"
        ar(126) = "LV"
        ar(127) = "WE"
        ar(128) = "DL"
        ar(129) = "J4"
        ar(130) = "2K"
        ar(131) = "XP"
        ar(132) = "99"
        ar(133) = "GV"
        ar(134) = "7J"
        ar(135) = "ML"
        ar(136) = "VW"
        ar(137) = "SV"
        ar(138) = "7Z"
        ar(139) = "3N"
        ar(140) = "XB"
        ar(141) = "VZ"
        ar(142) = "JV"
        ar(143) = "EW"
        ar(144) = "L3"
        ar(145) = "32"
        ar(146) = "Y8"
        ar(147) = "JJ"
        ar(148) = "YM"
        ar(149) = "QG"
        ar(150) = "H4"
        ar(151) = "FJ"
        ar(152) = "V3"
        ar(153) = "3M"
        ar(154) = "DS"
        ar(155) = "9A"
        ar(156) = "D9"
        ar(157) = "98"
        ar(158) = "8H"
        ar(159) = "TD"
        ar(160) = "MP"
        ar(161) = "CQ"
        ar(162) = "XW"
        ar(163) = "D6"
        ar(164) = "4E"
        ar(165) = "LY"
        ar(166) = "L2"
        ar(167) = "NV"
        ar(168) = "HG"
        ar(169) = "XU"
        ar(170) = "NX"
        ar(171) = "4W"
        ar(172) = "2Z"
        ar(173) = "SF"
        ar(174) = "EP"
        ar(175) = "M7"
        ar(176) = "3C"
        ar(177) = "K7"
        ar(178) = "ZJ"
        ar(179) = "SQ"
        ar(180) = "MX"
        ar(181) = "96"
        ar(182) = "WT"
        ar(183) = "P9"
        ar(184) = "C2"
        ar(185) = "WH"
        ar(186) = "RR"
        ar(187) = "UN"
        ar(188) = "UD"
        ar(189) = "BV"
        ar(190) = "H8"
        ar(191) = "P5"
        ar(192) = "29"
        ar(193) = "Z9"
        ar(194) = "4A"
        ar(195) = "UQ"
        ar(196) = "R8"
        ar(197) = "47"
        ar(198) = "2G"
        ar(199) = "M3"
        ar(200) = "SL"
        ar(201) = "E7"
        ar(202) = "ZS"
        ar(203) = "7E"
        ar(204) = "2X"
        ar(205) = "2Y"
        ar(206) = "TF"
        ar(207) = "PM"
        ar(208) = "M2"
        ar(209) = "EY"
        ar(210) = "3J"
        ar(211) = "WS"
        ar(212) = "54"
        ar(213) = "9E"
        ar(214) = "8J"
        ar(215) = "TS"
        ar(216) = "N8"
        ar(217) = "BQ"
        ar(218) = "YF"
        ar(219) = "5N"
        ar(220) = "H3"
        ar(221) = "2T"
        ar(222) = "2B"
        ar(223) = "AV"
        ar(224) = "Y2"
        ar(225) = "YZ"
        ar(226) = "SA"
        ar(227) = "4Q"
        ar(228) = "89"
        ar(229) = "7N"
        ar(230) = "FA"
        ar(231) = "A8"
        ar(232) = "XJ"
        ar(233) = "2M"
        ar(234) = "63"
        ar(235) = "AP"
        ar(236) = "5Z"
        ar(237) = "LC"
        ar(238) = "NW"
        ar(239) = "3P"
        ar(240) = "BD"
        ar(241) = "BN"
        ar(242) = "K5"
        ar(243) = "Q9"
        ar(244) = "TK"
        ar(245) = "3U"
        ar(246) = "VL"
        ar(247) = "JZ"
        ar(248) = "DA"
        ar(249) = "DC"
        ar(250) = "53"
        ar(251) = "4Y"
        ar(252) = "NU"
        ar(253) = "J6"
        ar(254) = "ZL"
        ar(255) = "RQ"
        ar(256) = "5L"
        ar(257) = "P4"
        ar(258) = "FR"
        ar(259) = "PP"
        ar(260) = "XS"
        ar(261) = "Z5"
        ar(262) = "9J"
        ar(263) = "JU"
        ar(264) = "KE"
        ar(265) = "U6"
        ar(266) = "R4"
        ar(267) = "ZZ"
        ar(268) = "SJ"
        ar(269) = "6Y"
        ar(270) = "79"
        ar(271) = "RC"
        ar(272) = "UF"
        ar(273) = "YL"
        ar(274) = "DB"
        ar(275) = "VC"
        ar(276) = "TG"
        ar(277) = "QQ"
        ar(278) = "7U"
        ar(279) = "NK"
        ar(280) = "6A"
        ar(281) = "JB"
        ar(282) = "LA"
        ar(283) = "46"
        ar(284) = "6Z"
        ar(285) = "CB"
        ar(286) = "KZ"
        ar(287) = "5K"
        ar(288) = "6Q"
        ar(289) = "RB"
        ar(290) = "88"
        ar(291) = "7S"
        ar(292) = "ZQ"
        ar(293) = "VY"
        ar(294) = "7Y"
        ar(295) = "5C"
        ar(296) = "JY"
        ar(297) = "4P"
        ar(298) = "2Q"
        ar(299) = "9G"
        'ar(300) = "D5"

        Dim r As Integer

        Randomize()
        r = Int(Rnd * 10)

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As Integer
        sR = ""
        If ctext = "" Then
            msBasicEnc = ""
            Exit Function
        End If

        If Not IsNumeric(ctext) Then
            msBasicEnc = ""
            Exit Function
        End If

        nl = Len(ctext)
        Dim p As String
        Dim k As Integer
        k = 0

        l = Asc(r)

        For i = 1 To nl
            k = k + 1
            If k > 13 Then k = 0
            p = Mid(ctext, i, 1)
            aski = Asc(p) + k + r
            l = l + aski
            sR = sR & ar(aski)
        Next

        Dim m201 As Integer
        m201 = l Mod 209

        sR = ar(m201) & ar(r) & sR

        Dim mod253 As Integer
        mod253 = Val(ctext) Mod 253

        sR = sR & ar(mod253)

        msBasicEnc = sR


    End Function



    ' -------- adv enc
    Public Function msAdvDec(ByVal ctext As String) As String

        Dim ar(300) As String

        ar(0) = "G5"
        ar(1) = "U3"
        ar(2) = "ZA"
        ar(3) = "ZV"
        ar(4) = "KK"
        ar(5) = "Z3"
        ar(6) = "RH"
        ar(7) = "GH"
        ar(8) = "JD"
        ar(9) = "W9"
        ar(10) = "9S"
        ar(11) = "PX"
        ar(12) = "UR"
        ar(13) = "EG"
        ar(14) = "RJ"
        ar(15) = "SG"
        ar(16) = "NL"
        ar(17) = "9Q"
        ar(18) = "TC"
        ar(19) = "R2"
        ar(20) = "SP"
        ar(21) = "H3"
        ar(22) = "YD"
        ar(23) = "V9"
        ar(24) = "7T"
        ar(25) = "NU"
        ar(26) = "EP"
        ar(27) = "9M"
        ar(28) = "VR"
        ar(29) = "ZQ"
        ar(30) = "NW"
        ar(31) = "VZ"
        ar(32) = "BT"
        ar(33) = "V4"
        ar(34) = "XT"
        ar(35) = "MA"
        ar(36) = "6N"
        ar(37) = "JJ"
        ar(38) = "M4"
        ar(39) = "KR"
        ar(40) = "7S"
        ar(41) = "W8"
        ar(42) = "62"
        ar(43) = "KJ"
        ar(44) = "6Y"
        ar(45) = "ZW"
        ar(46) = "AA"
        ar(47) = "TX"
        ar(48) = "XW"
        ar(49) = "KX"
        ar(50) = "BD"
        ar(51) = "A3"
        ar(52) = "QF"
        ar(53) = "VD"
        ar(54) = "2F"
        ar(55) = "DZ"
        ar(56) = "JV"
        ar(57) = "4R"
        ar(58) = "RN"
        ar(59) = "NX"
        ar(60) = "GM"
        ar(61) = "W4"
        ar(62) = "3H"
        ar(63) = "55"
        ar(64) = "FD"
        ar(65) = "ME"
        ar(66) = "WU"
        ar(67) = "6Q"
        ar(68) = "G6"
        ar(69) = "2X"
        ar(70) = "2E"
        ar(71) = "SD"
        ar(72) = "VG"
        ar(73) = "P7"
        ar(74) = "RM"
        ar(75) = "JL"
        ar(76) = "6L"
        ar(77) = "E6"
        ar(78) = "G7"
        ar(79) = "ZJ"
        ar(80) = "YM"
        ar(81) = "BS"
        ar(82) = "97"
        ar(83) = "38"
        ar(84) = "N2"
        ar(85) = "XR"
        ar(86) = "EJ"
        ar(87) = "W3"
        ar(88) = "5P"
        ar(89) = "8A"
        ar(90) = "Q9"
        ar(91) = "DD"
        ar(92) = "PW"
        ar(93) = "3J"
        ar(94) = "TF"
        ar(95) = "V2"
        ar(96) = "6T"
        ar(97) = "XL"
        ar(98) = "QV"
        ar(99) = "CA"
        ar(100) = "FX"
        ar(101) = "SR"
        ar(102) = "YC"
        ar(103) = "P4"
        ar(104) = "V7"
        ar(105) = "VF"
        ar(106) = "K2"
        ar(107) = "EZ"
        ar(108) = "5F"
        ar(109) = "KW"
        ar(110) = "J5"
        ar(111) = "DT"
        ar(112) = "YA"
        ar(113) = "FB"
        ar(114) = "4K"
        ar(115) = "L3"
        ar(116) = "P6"
        ar(117) = "5G"
        ar(118) = "6W"
        ar(119) = "9P"
        ar(120) = "U7"
        ar(121) = "HA"
        ar(122) = "HG"
        ar(123) = "B4"
        ar(124) = "D8"
        ar(125) = "NA"
        ar(126) = "ZG"
        ar(127) = "SY"
        ar(128) = "XF"
        ar(129) = "8F"
        ar(130) = "KB"
        ar(131) = "PZ"
        ar(132) = "L6"
        ar(133) = "JM"
        ar(134) = "N4"
        ar(135) = "WG"
        ar(136) = "XC"
        ar(137) = "8Y"
        ar(138) = "JK"
        ar(139) = "7P"
        ar(140) = "AU"
        ar(141) = "BN"
        ar(142) = "PB"
        ar(143) = "4X"
        ar(144) = "WD"
        ar(145) = "WJ"
        ar(146) = "AP"
        ar(147) = "5J"
        ar(148) = "ZX"
        ar(149) = "TA"
        ar(150) = "RL"
        ar(151) = "Y9"
        ar(152) = "4S"
        ar(153) = "YS"
        ar(154) = "UD"
        ar(155) = "LX"
        ar(156) = "3U"
        ar(157) = "XK"
        ar(158) = "6E"
        ar(159) = "KV"
        ar(160) = "2H"
        ar(161) = "BP"
        ar(162) = "QH"
        ar(163) = "M7"
        ar(164) = "X5"
        ar(165) = "D5"
        ar(166) = "JG"
        ar(167) = "VP"
        ar(168) = "EE"
        ar(169) = "6S"
        ar(170) = "KL"
        ar(171) = "69"
        ar(172) = "MM"
        ar(173) = "A4"
        ar(174) = "7V"
        ar(175) = "SM"
        ar(176) = "FQ"
        ar(177) = "J9"
        ar(178) = "DN"
        ar(179) = "FZ"
        ar(180) = "FE"
        ar(181) = "S6"
        ar(182) = "5N"
        ar(183) = "N6"
        ar(184) = "3A"
        ar(185) = "SW"
        ar(186) = "BR"
        ar(187) = "DV"
        ar(188) = "Z7"
        ar(189) = "LE"
        ar(190) = "LH"
        ar(191) = "WP"
        ar(192) = "JB"
        ar(193) = "VT"
        ar(194) = "WV"
        ar(195) = "LA"
        ar(196) = "2V"
        ar(197) = "9Z"
        ar(198) = "MR"
        ar(199) = "X2"
        ar(200) = "9L"
        ar(201) = "WY"
        ar(202) = "JU"
        ar(203) = "2J"
        ar(204) = "X6"
        ar(205) = "NS"
        ar(206) = "MU"
        ar(207) = "QL"
        ar(208) = "MJ"
        ar(209) = "S7"
        ar(210) = "UL"
        ar(211) = "GN"
        ar(212) = "GL"
        ar(213) = "87"
        ar(214) = "WX"
        ar(215) = "67"
        ar(216) = "UX"
        ar(217) = "YH"
        ar(218) = "UY"
        ar(219) = "B5"
        ar(220) = "9N"
        ar(221) = "PA"
        ar(222) = "ZC"
        ar(223) = "NM"
        ar(224) = "Q8"
        ar(225) = "JP"
        ar(226) = "P9"
        ar(227) = "56"
        ar(228) = "E9"
        ar(229) = "3D"
        ar(230) = "T2"
        ar(231) = "U6"
        ar(232) = "8M"
        ar(233) = "SH"
        ar(234) = "BY"
        ar(235) = "B6"
        ar(236) = "N3"
        ar(237) = "GC"
        ar(238) = "NG"
        ar(239) = "85"
        ar(240) = "ZH"
        ar(241) = "6K"
        ar(242) = "VW"
        ar(243) = "BG"
        ar(244) = "72"
        ar(245) = "58"
        ar(246) = "KA"
        ar(247) = "VS"
        ar(248) = "PC"
        ar(249) = "6H"
        ar(250) = "AB"
        ar(251) = "SC"
        ar(252) = "QE"
        ar(253) = "GJ"
        ar(254) = "4N"
        ar(255) = "E7"
        ar(256) = "7C"
        ar(257) = "K9"
        ar(258) = "7U"
        ar(259) = "5B"
        ar(260) = "QS"
        ar(261) = "AJ"
        ar(262) = "4P"
        ar(263) = "HH"
        ar(264) = "SQ"
        ar(265) = "HF"
        ar(266) = "3C"
        ar(267) = "DQ"
        ar(268) = "Y3"
        ar(269) = "46"
        ar(270) = "26"
        ar(271) = "VM"
        ar(272) = "EL"
        ar(273) = "M9"
        ar(274) = "95"
        ar(275) = "2Y"
        ar(276) = "Z2"
        ar(277) = "8P"
        ar(278) = "2T"
        ar(279) = "QQ"
        ar(280) = "MH"
        ar(281) = "U8"
        ar(282) = "RZ"
        ar(283) = "WM"
        ar(284) = "YX"
        ar(285) = "KC"
        ar(286) = "HV"
        ar(287) = "5C"
        ar(288) = "GA"
        ar(289) = "4B"
        ar(290) = "3B"
        ar(291) = "TJ"
        ar(292) = "UE"
        ar(293) = "X9"
        ar(294) = "LJ"
        ar(295) = "FH"
        ar(296) = "G8"
        ar(297) = "UG"
        ar(298) = "YK"
        ar(299) = "RX"
        'ar(300) = "UJ"


        Dim r As Integer
        Dim rChar As String

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As String
        Dim m201 As Integer
        Dim mChar As String

        If ctext = "" Then
            msAdvDec = ""
            Exit Function
        End If

        If Len(ctext) < 4 Then
            msAdvDec = ""
            Exit Function
        End If

        Dim mod253 As Integer
        'mod253 = Val(ctext) Mod 253
        mChar = Mid(ctext, Len(ctext) - 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                mod253 = i
                Exit For
            End If
        Next

        ctext = Mid(ctext, 1, Len(ctext) - 2)


        mChar = Mid(ctext, 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                m201 = i
                Exit For
            End If
        Next

        rChar = Mid(ctext, 3, 2)
        For i = 0 To 255
            If ar(i) = rChar Then
                r = i
                Exit For
            End If
        Next

        l = Asc(r)
        nl = Len(ctext)

        Dim j As Integer
        Dim k As Integer
        k = 0
        sR = ""

        For i = 5 To nl Step 2
            k = k + 1
            If k > 13 Then k = 0
            aski = Mid(ctext, i, 2)
            For j = 0 To 255
                If ar(j) = aski Then
                    l = l + j
                    On Error Resume Next
                    sR = sR & Chr(j - k - r)

                    Exit For
                End If
            Next
        Next

        If IsNumeric(sR) Then

            If m201 = l Mod 209 Then
                'sR = sR
                If sR Mod 253 = mod253 Then
                    ' output sr
                Else
                    sR = ""
                End If
            Else
                sR = ""  '  "0" & sR
            End If

        Else
            sR = ""
        End If


        msAdvDec = sR



    End Function



    Public Function msAdvEnc(ByVal ctext As String) As String

        Dim ar(300) As String

        ar(0) = "G5"
        ar(1) = "U3"
        ar(2) = "ZA"
        ar(3) = "ZV"
        ar(4) = "KK"
        ar(5) = "Z3"
        ar(6) = "RH"
        ar(7) = "GH"
        ar(8) = "JD"
        ar(9) = "W9"
        ar(10) = "9S"
        ar(11) = "PX"
        ar(12) = "UR"
        ar(13) = "EG"
        ar(14) = "RJ"
        ar(15) = "SG"
        ar(16) = "NL"
        ar(17) = "9Q"
        ar(18) = "TC"
        ar(19) = "R2"
        ar(20) = "SP"
        ar(21) = "H3"
        ar(22) = "YD"
        ar(23) = "V9"
        ar(24) = "7T"
        ar(25) = "NU"
        ar(26) = "EP"
        ar(27) = "9M"
        ar(28) = "VR"
        ar(29) = "ZQ"
        ar(30) = "NW"
        ar(31) = "VZ"
        ar(32) = "BT"
        ar(33) = "V4"
        ar(34) = "XT"
        ar(35) = "MA"
        ar(36) = "6N"
        ar(37) = "JJ"
        ar(38) = "M4"
        ar(39) = "KR"
        ar(40) = "7S"
        ar(41) = "W8"
        ar(42) = "62"
        ar(43) = "KJ"
        ar(44) = "6Y"
        ar(45) = "ZW"
        ar(46) = "AA"
        ar(47) = "TX"
        ar(48) = "XW"
        ar(49) = "KX"
        ar(50) = "BD"
        ar(51) = "A3"
        ar(52) = "QF"
        ar(53) = "VD"
        ar(54) = "2F"
        ar(55) = "DZ"
        ar(56) = "JV"
        ar(57) = "4R"
        ar(58) = "RN"
        ar(59) = "NX"
        ar(60) = "GM"
        ar(61) = "W4"
        ar(62) = "3H"
        ar(63) = "55"
        ar(64) = "FD"
        ar(65) = "ME"
        ar(66) = "WU"
        ar(67) = "6Q"
        ar(68) = "G6"
        ar(69) = "2X"
        ar(70) = "2E"
        ar(71) = "SD"
        ar(72) = "VG"
        ar(73) = "P7"
        ar(74) = "RM"
        ar(75) = "JL"
        ar(76) = "6L"
        ar(77) = "E6"
        ar(78) = "G7"
        ar(79) = "ZJ"
        ar(80) = "YM"
        ar(81) = "BS"
        ar(82) = "97"
        ar(83) = "38"
        ar(84) = "N2"
        ar(85) = "XR"
        ar(86) = "EJ"
        ar(87) = "W3"
        ar(88) = "5P"
        ar(89) = "8A"
        ar(90) = "Q9"
        ar(91) = "DD"
        ar(92) = "PW"
        ar(93) = "3J"
        ar(94) = "TF"
        ar(95) = "V2"
        ar(96) = "6T"
        ar(97) = "XL"
        ar(98) = "QV"
        ar(99) = "CA"
        ar(100) = "FX"
        ar(101) = "SR"
        ar(102) = "YC"
        ar(103) = "P4"
        ar(104) = "V7"
        ar(105) = "VF"
        ar(106) = "K2"
        ar(107) = "EZ"
        ar(108) = "5F"
        ar(109) = "KW"
        ar(110) = "J5"
        ar(111) = "DT"
        ar(112) = "YA"
        ar(113) = "FB"
        ar(114) = "4K"
        ar(115) = "L3"
        ar(116) = "P6"
        ar(117) = "5G"
        ar(118) = "6W"
        ar(119) = "9P"
        ar(120) = "U7"
        ar(121) = "HA"
        ar(122) = "HG"
        ar(123) = "B4"
        ar(124) = "D8"
        ar(125) = "NA"
        ar(126) = "ZG"
        ar(127) = "SY"
        ar(128) = "XF"
        ar(129) = "8F"
        ar(130) = "KB"
        ar(131) = "PZ"
        ar(132) = "L6"
        ar(133) = "JM"
        ar(134) = "N4"
        ar(135) = "WG"
        ar(136) = "XC"
        ar(137) = "8Y"
        ar(138) = "JK"
        ar(139) = "7P"
        ar(140) = "AU"
        ar(141) = "BN"
        ar(142) = "PB"
        ar(143) = "4X"
        ar(144) = "WD"
        ar(145) = "WJ"
        ar(146) = "AP"
        ar(147) = "5J"
        ar(148) = "ZX"
        ar(149) = "TA"
        ar(150) = "RL"
        ar(151) = "Y9"
        ar(152) = "4S"
        ar(153) = "YS"
        ar(154) = "UD"
        ar(155) = "LX"
        ar(156) = "3U"
        ar(157) = "XK"
        ar(158) = "6E"
        ar(159) = "KV"
        ar(160) = "2H"
        ar(161) = "BP"
        ar(162) = "QH"
        ar(163) = "M7"
        ar(164) = "X5"
        ar(165) = "D5"
        ar(166) = "JG"
        ar(167) = "VP"
        ar(168) = "EE"
        ar(169) = "6S"
        ar(170) = "KL"
        ar(171) = "69"
        ar(172) = "MM"
        ar(173) = "A4"
        ar(174) = "7V"
        ar(175) = "SM"
        ar(176) = "FQ"
        ar(177) = "J9"
        ar(178) = "DN"
        ar(179) = "FZ"
        ar(180) = "FE"
        ar(181) = "S6"
        ar(182) = "5N"
        ar(183) = "N6"
        ar(184) = "3A"
        ar(185) = "SW"
        ar(186) = "BR"
        ar(187) = "DV"
        ar(188) = "Z7"
        ar(189) = "LE"
        ar(190) = "LH"
        ar(191) = "WP"
        ar(192) = "JB"
        ar(193) = "VT"
        ar(194) = "WV"
        ar(195) = "LA"
        ar(196) = "2V"
        ar(197) = "9Z"
        ar(198) = "MR"
        ar(199) = "X2"
        ar(200) = "9L"
        ar(201) = "WY"
        ar(202) = "JU"
        ar(203) = "2J"
        ar(204) = "X6"
        ar(205) = "NS"
        ar(206) = "MU"
        ar(207) = "QL"
        ar(208) = "MJ"
        ar(209) = "S7"
        ar(210) = "UL"
        ar(211) = "GN"
        ar(212) = "GL"
        ar(213) = "87"
        ar(214) = "WX"
        ar(215) = "67"
        ar(216) = "UX"
        ar(217) = "YH"
        ar(218) = "UY"
        ar(219) = "B5"
        ar(220) = "9N"
        ar(221) = "PA"
        ar(222) = "ZC"
        ar(223) = "NM"
        ar(224) = "Q8"
        ar(225) = "JP"
        ar(226) = "P9"
        ar(227) = "56"
        ar(228) = "E9"
        ar(229) = "3D"
        ar(230) = "T2"
        ar(231) = "U6"
        ar(232) = "8M"
        ar(233) = "SH"
        ar(234) = "BY"
        ar(235) = "B6"
        ar(236) = "N3"
        ar(237) = "GC"
        ar(238) = "NG"
        ar(239) = "85"
        ar(240) = "ZH"
        ar(241) = "6K"
        ar(242) = "VW"
        ar(243) = "BG"
        ar(244) = "72"
        ar(245) = "58"
        ar(246) = "KA"
        ar(247) = "VS"
        ar(248) = "PC"
        ar(249) = "6H"
        ar(250) = "AB"
        ar(251) = "SC"
        ar(252) = "QE"
        ar(253) = "GJ"
        ar(254) = "4N"
        ar(255) = "E7"
        ar(256) = "7C"
        ar(257) = "K9"
        ar(258) = "7U"
        ar(259) = "5B"
        ar(260) = "QS"
        ar(261) = "AJ"
        ar(262) = "4P"
        ar(263) = "HH"
        ar(264) = "SQ"
        ar(265) = "HF"
        ar(266) = "3C"
        ar(267) = "DQ"
        ar(268) = "Y3"
        ar(269) = "46"
        ar(270) = "26"
        ar(271) = "VM"
        ar(272) = "EL"
        ar(273) = "M9"
        ar(274) = "95"
        ar(275) = "2Y"
        ar(276) = "Z2"
        ar(277) = "8P"
        ar(278) = "2T"
        ar(279) = "QQ"
        ar(280) = "MH"
        ar(281) = "U8"
        ar(282) = "RZ"
        ar(283) = "WM"
        ar(284) = "YX"
        ar(285) = "KC"
        ar(286) = "HV"
        ar(287) = "5C"
        ar(288) = "GA"
        ar(289) = "4B"
        ar(290) = "3B"
        ar(291) = "TJ"
        ar(292) = "UE"
        ar(293) = "X9"
        ar(294) = "LJ"
        ar(295) = "FH"
        ar(296) = "G8"
        ar(297) = "UG"
        ar(298) = "YK"
        ar(299) = "RX"
        'ar(300) = "UJ"
        'ar(300) = "D5"

        Dim r As Integer

        Randomize()
        r = Int(Rnd * 10)

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As Integer
        sR = ""
        If ctext = "" Then
            msAdvEnc = ""
            Exit Function
        End If

        If Not IsNumeric(ctext) Then
            msAdvEnc = ""
            Exit Function
        End If

        nl = Len(ctext)
        Dim p As String
        Dim k As Integer
        k = 0

        l = Asc(r)

        For i = 1 To nl
            k = k + 1
            If k > 13 Then k = 0
            p = Mid(ctext, i, 1)
            aski = Asc(p) + k + r
            l = l + aski
            sR = sR & ar(aski)
        Next

        Dim m201 As Integer
        m201 = l Mod 209

        sR = ar(m201) & ar(r) & sR

        Dim mod253 As Integer
        mod253 = Val(ctext) Mod 253

        sR = sR & ar(mod253)

        msAdvEnc = sR


    End Function




    Public Function msEncryptRandom(ByVal cText As String) As String


        Dim ar(500) As String

        ar(0) = "CE"
        ar(1) = "2P"
        ar(2) = "RW"
        ar(3) = "2B"
        ar(4) = "F9"
        ar(5) = "97"
        ar(6) = "01"
        ar(7) = "JN"
        ar(8) = "QP"
        ar(9) = "LB"
        ar(10) = "H6"
        ar(11) = "2H"
        ar(12) = "BM"
        ar(13) = "41"
        ar(14) = "BQ"
        ar(15) = "MU"
        ar(16) = "CG"
        ar(17) = "PQ"
        ar(18) = "0G"
        ar(19) = "FI"
        ar(20) = "MB"
        ar(21) = "0E"
        ar(22) = "U9"
        ar(23) = "AI"
        ar(24) = "XV"
        ar(25) = "B0"
        ar(26) = "AF"
        ar(27) = "TH"
        ar(28) = "UE"
        ar(29) = "D0"
        ar(30) = "26"
        ar(31) = "59"
        ar(32) = "J8"
        ar(33) = "5P"
        ar(34) = "4C"
        ar(35) = "9B"
        ar(36) = "GZ"
        ar(37) = "RB"
        ar(38) = "VE"
        ar(39) = "4A"
        ar(40) = "MX"
        ar(41) = "NE"
        ar(42) = "BT"
        ar(43) = "ZG"
        ar(44) = "0A"
        ar(45) = "56"
        ar(46) = "WZ"
        ar(47) = "WD"
        ar(48) = "OJ"
        ar(49) = "3Z"
        ar(50) = "GL"
        ar(51) = "6E"
        ar(52) = "5X"
        ar(53) = "1K"
        ar(54) = "QQ"
        ar(55) = "4U"
        ar(56) = "8R"
        ar(57) = "GU"
        ar(58) = "E7"
        ar(59) = "VK"
        ar(60) = "A6"
        ar(61) = "FV"
        ar(62) = "V6"
        ar(63) = "2A"
        ar(64) = "WL"
        ar(65) = "4N"
        ar(66) = "KF"
        ar(67) = "FW"
        ar(68) = "QI"
        ar(69) = "Z4"
        ar(70) = "SO"
        ar(71) = "DI"
        ar(72) = "TT"
        ar(73) = "OA"
        ar(74) = "0U"
        ar(75) = "DX"
        ar(76) = "5T"
        ar(77) = "2O"
        ar(78) = "R2"
        ar(79) = "O5"
        ar(80) = "6F"
        ar(81) = "YN"
        ar(82) = "FH"
        ar(83) = "D5"
        ar(84) = "EY"
        ar(85) = "ML"
        ar(86) = "8A"
        ar(87) = "CX"
        ar(88) = "XH"
        ar(89) = "UN"
        ar(90) = "CC"
        ar(91) = "3O"
        ar(92) = "OW"
        ar(93) = "GF"
        ar(94) = "EW"
        ar(95) = "A1"
        ar(96) = "TK"
        ar(97) = "U7"
        ar(98) = "N0"
        ar(99) = "PC"
        ar(100) = "B2"
        ar(101) = "AK"
        ar(102) = "5G"
        ar(103) = "X6"
        ar(104) = "BD"
        ar(105) = "OK"
        ar(106) = "XZ"
        ar(107) = "GD"
        ar(108) = "IT"
        ar(109) = "H3"
        ar(110) = "MV"
        ar(111) = "OI"
        ar(112) = "TW"
        ar(113) = "Y8"
        ar(114) = "US"
        ar(115) = "0P"
        ar(116) = "9K"
        ar(117) = "VL"
        ar(118) = "HF"
        ar(119) = "2T"
        ar(120) = "EB"
        ar(121) = "OX"
        ar(122) = "ZO"
        ar(123) = "SB"
        ar(124) = "A9"
        ar(125) = "Y3"
        ar(126) = "HR"
        ar(127) = "FN"
        ar(128) = "LR"
        ar(129) = "ZE"
        ar(130) = "LV"
        ar(131) = "WT"
        ar(132) = "SL"
        ar(133) = "CQ"
        ar(134) = "GB"
        ar(135) = "AZ"
        ar(136) = "CT"
        ar(137) = "04"
        ar(138) = "AS"
        ar(139) = "K3"
        ar(140) = "P9"
        ar(141) = "4D"
        ar(142) = "8B"
        ar(143) = "J7"
        ar(144) = "B3"
        ar(145) = "HW"
        ar(146) = "07"
        ar(147) = "46"
        ar(148) = "DE"
        ar(149) = "KG"
        ar(150) = "V9"
        ar(151) = "F0"
        ar(152) = "7Y"
        ar(153) = "O4"
        ar(154) = "E1"
        ar(155) = "55"
        ar(156) = "AH"
        ar(157) = "L7"
        ar(158) = "MQ"
        ar(159) = "7K"
        ar(160) = "XJ"
        ar(161) = "SY"
        ar(162) = "5H"
        ar(163) = "2L"
        ar(164) = "T4"
        ar(165) = "23"
        ar(166) = "LJ"
        ar(167) = "1C"
        ar(168) = "5M"
        ar(169) = "ZX"
        ar(170) = "NT"
        ar(171) = "W0"
        ar(172) = "G8"
        ar(173) = "51"
        ar(174) = "AQ"
        ar(175) = "LA"
        ar(176) = "SE"
        ar(177) = "L1"
        ar(178) = "8H"
        ar(179) = "5Q"
        ar(180) = "I5"
        ar(181) = "IY"
        ar(182) = "22"
        ar(183) = "HP"
        ar(184) = "FE"
        ar(185) = "K2"
        ar(186) = "A8"
        ar(187) = "0V"
        ar(188) = "P6"
        ar(189) = "IR"
        ar(190) = "PO"
        ar(191) = "79"
        ar(192) = "QC"
        ar(193) = "YZ"
        ar(194) = "9M"
        ar(195) = "OY"
        ar(196) = "LS"
        ar(197) = "9T"
        ar(198) = "UZ"
        ar(199) = "S6"
        ar(200) = "VG"
        ar(201) = "2U"
        ar(202) = "DP"
        ar(203) = "9S"
        ar(204) = "2R"
        ar(205) = "VN"
        ar(206) = "IZ"
        ar(207) = "XY"
        ar(208) = "77"
        ar(209) = "7O"
        ar(210) = "VO"
        ar(211) = "IQ"
        ar(212) = "5O"
        ar(213) = "69"
        ar(214) = "OU"
        ar(215) = "JI"
        ar(216) = "WQ"
        ar(217) = "FQ"
        ar(218) = "20"
        ar(219) = "28"
        ar(220) = "6O"
        ar(221) = "SN"
        ar(222) = "S9"
        ar(223) = "LD"
        ar(224) = "WN"
        ar(225) = "D2"
        ar(226) = "NP"
        ar(227) = "YO"
        ar(228) = "C0"
        ar(229) = "CA"
        ar(230) = "1S"
        ar(231) = "5Y"
        ar(232) = "NU"
        ar(233) = "C5"
        ar(234) = "T2"
        ar(235) = "82"
        ar(236) = "EP"
        ar(237) = "1U"
        ar(238) = "Y6"
        ar(239) = "SA"
        ar(240) = "4X"
        ar(241) = "W7"
        ar(242) = "ZB"
        ar(243) = "IK"
        ar(244) = "DB"
        ar(245) = "RX"
        ar(246) = "U8"
        ar(247) = "ZJ"
        ar(248) = "TF"
        ar(249) = "VS"
        ar(250) = "TQ"
        ar(251) = "V7"
        ar(252) = "VW"
        ar(253) = "5C"
        ar(254) = "OD"
        ar(255) = "I8"
        ar(256) = "IB"
        ar(257) = "DK"
        ar(258) = "KE"
        ar(259) = "PG"
        ar(260) = "BU"
        ar(261) = "MO"
        ar(262) = "5W"
        ar(263) = "HE"
        ar(264) = "P4"
        ar(265) = "7V"
        ar(266) = "1Y"
        ar(267) = "XQ"
        ar(268) = "N1"
        ar(269) = "HC"
        ar(270) = "P8"
        ar(271) = "7L"
        ar(272) = "H0"
        ar(273) = "XU"
        ar(274) = "CZ"
        ar(275) = "OM"
        ar(276) = "3U"
        ar(277) = "6Z"
        ar(278) = "DJ"
        ar(279) = "NW"
        ar(280) = "BH"
        ar(281) = "AJ"
        ar(282) = "K7"
        ar(283) = "XO"
        ar(284) = "2G"
        ar(285) = "BC"
        ar(286) = "9U"
        ar(287) = "I3"
        ar(288) = "K0"
        ar(289) = "B8"
        ar(290) = "T5"
        ar(291) = "NO"
        ar(292) = "UK"
        ar(293) = "80"
        ar(294) = "JM"
        ar(295) = "FF"
        ar(296) = "0N"
        ar(297) = "HA"
        ar(298) = "X2"
        ar(299) = "AW"
        ar(300) = "U3"
        ar(301) = "E9"
        ar(302) = "BN"
        ar(303) = "9D"
        ar(304) = "TO"
        ar(305) = "00"
        ar(306) = "Q7"
        ar(307) = "NN"
        ar(308) = "ON"
        ar(309) = "X5"
        ar(310) = "6H"
        ar(311) = "BV"
        ar(312) = "OR"
        ar(313) = "1V"
        ar(314) = "89"
        ar(315) = "GT"
        ar(316) = "IO"
        ar(317) = "VZ"
        ar(318) = "6X"
        ar(319) = "4Q"
        ar(320) = "52"
        ar(321) = "TN"
        ar(322) = "1W"
        ar(323) = "MN"
        ar(324) = "5S"
        ar(325) = "QT"
        ar(326) = "GY"
        ar(327) = "TX"
        ar(328) = "96"
        ar(329) = "3M"
        ar(330) = "R1"
        ar(331) = "GA"
        ar(332) = "C9"
        ar(333) = "ZN"
        ar(334) = "7D"
        ar(335) = "FZ"
        ar(336) = "MM"
        ar(337) = "D8"
        ar(338) = "0Z"
        ar(339) = "ED"
        ar(340) = "IW"
        ar(341) = "AO"
        ar(342) = "SF"
        ar(343) = "9Y"
        ar(344) = "YK"
        ar(345) = "I4"
        ar(346) = "2S"
        ar(347) = "CL"
        ar(348) = "HQ"
        ar(349) = "M1"
        ar(350) = "13"
        ar(351) = "YV"
        ar(352) = "EV"
        ar(353) = "OO"
        ar(354) = "LP"
        ar(355) = "ZK"
        ar(356) = "M5"
        ar(357) = "33"
        ar(358) = "39"
        ar(359) = "WJ"
        ar(360) = "PX"
        ar(361) = "8V"
        ar(362) = "60"
        ar(363) = "5L"
        ar(364) = "VI"
        ar(365) = "S2"
        ar(366) = "OF"
        ar(367) = "IV"
        ar(368) = "Q4"
        ar(369) = "OE"
        ar(370) = "WI"
        ar(371) = "LZ"
        ar(372) = "D9"
        ar(373) = "ZT"
        ar(374) = "4E"
        ar(375) = "VF"
        ar(376) = "AG"
        ar(377) = "I7"
        ar(378) = "IG"
        ar(379) = "12"
        ar(380) = "MC"
        ar(381) = "O1"
        ar(382) = "UB"
        ar(383) = "PM"
        ar(384) = "2F"
        ar(385) = "3J"
        ar(386) = "DH"
        ar(387) = "KS"
        ar(388) = "7N"
        ar(389) = "MP"
        ar(390) = "CN"
        ar(391) = "DW"
        ar(392) = "TS"
        ar(393) = "HJ"
        ar(394) = "RA"
        ar(395) = "PT"
        ar(396) = "YH"
        ar(397) = "UH"
        ar(398) = "4G"
        ar(399) = "9Q"
        ar(400) = "U6"
        ar(401) = "68"
        ar(402) = "Q5"
        ar(403) = "7H"
        ar(404) = "YG"
        ar(405) = "PY"
        ar(406) = "RM"
        ar(407) = "AA"
        ar(408) = "JG"
        ar(409) = "3W"
        ar(410) = "CR"
        ar(411) = "LG"
        ar(412) = "I9"
        ar(413) = "OC"
        ar(414) = "N3"
        ar(415) = "PE"
        ar(416) = "36"
        ar(417) = "IM"
        ar(418) = "J0"
        ar(419) = "UW"
        ar(420) = "J4"
        ar(421) = "JV"
        ar(422) = "ZZ"
        ar(423) = "CP"
        ar(424) = "5D"
        ar(425) = "IN"
        ar(426) = "DQ"
        ar(427) = "LE"
        ar(428) = "KO"
        ar(429) = "J1"
        ar(430) = "PN"
        ar(431) = "JR"
        ar(432) = "16"
        ar(433) = "WM"
        ar(434) = "PA"
        ar(435) = "OQ"
        ar(436) = "XD"
        ar(437) = "WE"
        ar(438) = "4M"
        ar(439) = "C7"
        ar(440) = "AD"
        ar(441) = "0C"
        ar(442) = "RZ"
        ar(443) = "7Q"
        ar(444) = "9F"
        ar(445) = "2E"
        ar(446) = "XF"
        ar(447) = "5B"
        ar(448) = "4W"
        ar(449) = "XG"
        ar(450) = "KC"
        ar(451) = "QE"
        ar(452) = "02"
        ar(453) = "38"
        ar(454) = "1P"
        ar(455) = "AT"
        ar(456) = "WW"
        ar(457) = "RH"
        ar(458) = "FU"
        ar(459) = "KN"
        ar(460) = "Z3"
        ar(461) = "N2"
        ar(462) = "Q9"
        ar(463) = "FY"
        ar(464) = "8O"
        ar(465) = "DC"
        ar(466) = "TG"
        ar(467) = "YA"
        ar(468) = "H2"
        ar(469) = "O2"
        ar(470) = "6G"
        ar(471) = "KU"
        ar(472) = "7S"
        ar(473) = "25"
        ar(474) = "0M"
        ar(475) = "9O"
        ar(476) = "8M"
        ar(477) = "SC"
        ar(478) = "IU"
        ar(479) = "BW"
        ar(480) = "YP"
        ar(481) = "VU"
        ar(482) = "QG"
        ar(483) = "HL"
        ar(484) = "RO"
        ar(485) = "RK"
        ar(486) = "RI"
        ar(487) = "TI"
        ar(488) = "PL"
        ar(489) = "F1"
        ar(490) = "XN"
        ar(491) = "EU"
        ar(492) = "HX"
        ar(493) = "HH"
        ar(494) = "E6"
        ar(495) = "UQ"
        ar(496) = "FP"
        ar(497) = "3F"
        ar(498) = "AC"
        ar(499) = "34"


        Dim r As Integer

        Randomize()
        r = Int(Rnd() * 10)

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As Integer
        sR = ""
        If cText = "" Then
            msEncryptRandom = ""
            Exit Function
        End If

        nl = Len(cText)
        Dim p As String
        Dim k As Integer
        k = 0

        l = Asc(r)

        For i = 1 To nl
            k = k + 1
            If k > 13 Then k = 0
            p = Mid(cText, i, 1)
            aski = Asc(p) + k + r
            l = l + aski
            sR = sR & ar(aski)
        Next

        Dim m201 As Integer
        m201 = l Mod 201

        sR = ar(m201) & ar(r) & sR

        msEncryptRandom = sR


    End Function

    Public Function msDecryptRandom(ByVal cText As String) As String

        Dim ar(500) As String

        ar(0) = "CE"
        ar(1) = "2P"
        ar(2) = "RW"
        ar(3) = "2B"
        ar(4) = "F9"
        ar(5) = "97"
        ar(6) = "01"
        ar(7) = "JN"
        ar(8) = "QP"
        ar(9) = "LB"
        ar(10) = "H6"
        ar(11) = "2H"
        ar(12) = "BM"
        ar(13) = "41"
        ar(14) = "BQ"
        ar(15) = "MU"
        ar(16) = "CG"
        ar(17) = "PQ"
        ar(18) = "0G"
        ar(19) = "FI"
        ar(20) = "MB"
        ar(21) = "0E"
        ar(22) = "U9"
        ar(23) = "AI"
        ar(24) = "XV"
        ar(25) = "B0"
        ar(26) = "AF"
        ar(27) = "TH"
        ar(28) = "UE"
        ar(29) = "D0"
        ar(30) = "26"
        ar(31) = "59"
        ar(32) = "J8"
        ar(33) = "5P"
        ar(34) = "4C"
        ar(35) = "9B"
        ar(36) = "GZ"
        ar(37) = "RB"
        ar(38) = "VE"
        ar(39) = "4A"
        ar(40) = "MX"
        ar(41) = "NE"
        ar(42) = "BT"
        ar(43) = "ZG"
        ar(44) = "0A"
        ar(45) = "56"
        ar(46) = "WZ"
        ar(47) = "WD"
        ar(48) = "OJ"
        ar(49) = "3Z"
        ar(50) = "GL"
        ar(51) = "6E"
        ar(52) = "5X"
        ar(53) = "1K"
        ar(54) = "QQ"
        ar(55) = "4U"
        ar(56) = "8R"
        ar(57) = "GU"
        ar(58) = "E7"
        ar(59) = "VK"
        ar(60) = "A6"
        ar(61) = "FV"
        ar(62) = "V6"
        ar(63) = "2A"
        ar(64) = "WL"
        ar(65) = "4N"
        ar(66) = "KF"
        ar(67) = "FW"
        ar(68) = "QI"
        ar(69) = "Z4"
        ar(70) = "SO"
        ar(71) = "DI"
        ar(72) = "TT"
        ar(73) = "OA"
        ar(74) = "0U"
        ar(75) = "DX"
        ar(76) = "5T"
        ar(77) = "2O"
        ar(78) = "R2"
        ar(79) = "O5"
        ar(80) = "6F"
        ar(81) = "YN"
        ar(82) = "FH"
        ar(83) = "D5"
        ar(84) = "EY"
        ar(85) = "ML"
        ar(86) = "8A"
        ar(87) = "CX"
        ar(88) = "XH"
        ar(89) = "UN"
        ar(90) = "CC"
        ar(91) = "3O"
        ar(92) = "OW"
        ar(93) = "GF"
        ar(94) = "EW"
        ar(95) = "A1"
        ar(96) = "TK"
        ar(97) = "U7"
        ar(98) = "N0"
        ar(99) = "PC"
        ar(100) = "B2"
        ar(101) = "AK"
        ar(102) = "5G"
        ar(103) = "X6"
        ar(104) = "BD"
        ar(105) = "OK"
        ar(106) = "XZ"
        ar(107) = "GD"
        ar(108) = "IT"
        ar(109) = "H3"
        ar(110) = "MV"
        ar(111) = "OI"
        ar(112) = "TW"
        ar(113) = "Y8"
        ar(114) = "US"
        ar(115) = "0P"
        ar(116) = "9K"
        ar(117) = "VL"
        ar(118) = "HF"
        ar(119) = "2T"
        ar(120) = "EB"
        ar(121) = "OX"
        ar(122) = "ZO"
        ar(123) = "SB"
        ar(124) = "A9"
        ar(125) = "Y3"
        ar(126) = "HR"
        ar(127) = "FN"
        ar(128) = "LR"
        ar(129) = "ZE"
        ar(130) = "LV"
        ar(131) = "WT"
        ar(132) = "SL"
        ar(133) = "CQ"
        ar(134) = "GB"
        ar(135) = "AZ"
        ar(136) = "CT"
        ar(137) = "04"
        ar(138) = "AS"
        ar(139) = "K3"
        ar(140) = "P9"
        ar(141) = "4D"
        ar(142) = "8B"
        ar(143) = "J7"
        ar(144) = "B3"
        ar(145) = "HW"
        ar(146) = "07"
        ar(147) = "46"
        ar(148) = "DE"
        ar(149) = "KG"
        ar(150) = "V9"
        ar(151) = "F0"
        ar(152) = "7Y"
        ar(153) = "O4"
        ar(154) = "E1"
        ar(155) = "55"
        ar(156) = "AH"
        ar(157) = "L7"
        ar(158) = "MQ"
        ar(159) = "7K"
        ar(160) = "XJ"
        ar(161) = "SY"
        ar(162) = "5H"
        ar(163) = "2L"
        ar(164) = "T4"
        ar(165) = "23"
        ar(166) = "LJ"
        ar(167) = "1C"
        ar(168) = "5M"
        ar(169) = "ZX"
        ar(170) = "NT"
        ar(171) = "W0"
        ar(172) = "G8"
        ar(173) = "51"
        ar(174) = "AQ"
        ar(175) = "LA"
        ar(176) = "SE"
        ar(177) = "L1"
        ar(178) = "8H"
        ar(179) = "5Q"
        ar(180) = "I5"
        ar(181) = "IY"
        ar(182) = "22"
        ar(183) = "HP"
        ar(184) = "FE"
        ar(185) = "K2"
        ar(186) = "A8"
        ar(187) = "0V"
        ar(188) = "P6"
        ar(189) = "IR"
        ar(190) = "PO"
        ar(191) = "79"
        ar(192) = "QC"
        ar(193) = "YZ"
        ar(194) = "9M"
        ar(195) = "OY"
        ar(196) = "LS"
        ar(197) = "9T"
        ar(198) = "UZ"
        ar(199) = "S6"
        ar(200) = "VG"
        ar(201) = "2U"
        ar(202) = "DP"
        ar(203) = "9S"
        ar(204) = "2R"
        ar(205) = "VN"
        ar(206) = "IZ"
        ar(207) = "XY"
        ar(208) = "77"
        ar(209) = "7O"
        ar(210) = "VO"
        ar(211) = "IQ"
        ar(212) = "5O"
        ar(213) = "69"
        ar(214) = "OU"
        ar(215) = "JI"
        ar(216) = "WQ"
        ar(217) = "FQ"
        ar(218) = "20"
        ar(219) = "28"
        ar(220) = "6O"
        ar(221) = "SN"
        ar(222) = "S9"
        ar(223) = "LD"
        ar(224) = "WN"
        ar(225) = "D2"
        ar(226) = "NP"
        ar(227) = "YO"
        ar(228) = "C0"
        ar(229) = "CA"
        ar(230) = "1S"
        ar(231) = "5Y"
        ar(232) = "NU"
        ar(233) = "C5"
        ar(234) = "T2"
        ar(235) = "82"
        ar(236) = "EP"
        ar(237) = "1U"
        ar(238) = "Y6"
        ar(239) = "SA"
        ar(240) = "4X"
        ar(241) = "W7"
        ar(242) = "ZB"
        ar(243) = "IK"
        ar(244) = "DB"
        ar(245) = "RX"
        ar(246) = "U8"
        ar(247) = "ZJ"
        ar(248) = "TF"
        ar(249) = "VS"
        ar(250) = "TQ"
        ar(251) = "V7"
        ar(252) = "VW"
        ar(253) = "5C"
        ar(254) = "OD"
        ar(255) = "I8"
        ar(256) = "IB"
        ar(257) = "DK"
        ar(258) = "KE"
        ar(259) = "PG"
        ar(260) = "BU"
        ar(261) = "MO"
        ar(262) = "5W"
        ar(263) = "HE"
        ar(264) = "P4"
        ar(265) = "7V"
        ar(266) = "1Y"
        ar(267) = "XQ"
        ar(268) = "N1"
        ar(269) = "HC"
        ar(270) = "P8"
        ar(271) = "7L"
        ar(272) = "H0"
        ar(273) = "XU"
        ar(274) = "CZ"
        ar(275) = "OM"
        ar(276) = "3U"
        ar(277) = "6Z"
        ar(278) = "DJ"
        ar(279) = "NW"
        ar(280) = "BH"
        ar(281) = "AJ"
        ar(282) = "K7"
        ar(283) = "XO"
        ar(284) = "2G"
        ar(285) = "BC"
        ar(286) = "9U"
        ar(287) = "I3"
        ar(288) = "K0"
        ar(289) = "B8"
        ar(290) = "T5"
        ar(291) = "NO"
        ar(292) = "UK"
        ar(293) = "80"
        ar(294) = "JM"
        ar(295) = "FF"
        ar(296) = "0N"
        ar(297) = "HA"
        ar(298) = "X2"
        ar(299) = "AW"
        ar(300) = "U3"
        ar(301) = "E9"
        ar(302) = "BN"
        ar(303) = "9D"
        ar(304) = "TO"
        ar(305) = "00"
        ar(306) = "Q7"
        ar(307) = "NN"
        ar(308) = "ON"
        ar(309) = "X5"
        ar(310) = "6H"
        ar(311) = "BV"
        ar(312) = "OR"
        ar(313) = "1V"
        ar(314) = "89"
        ar(315) = "GT"
        ar(316) = "IO"
        ar(317) = "VZ"
        ar(318) = "6X"
        ar(319) = "4Q"
        ar(320) = "52"
        ar(321) = "TN"
        ar(322) = "1W"
        ar(323) = "MN"
        ar(324) = "5S"
        ar(325) = "QT"
        ar(326) = "GY"
        ar(327) = "TX"
        ar(328) = "96"
        ar(329) = "3M"
        ar(330) = "R1"
        ar(331) = "GA"
        ar(332) = "C9"
        ar(333) = "ZN"
        ar(334) = "7D"
        ar(335) = "FZ"
        ar(336) = "MM"
        ar(337) = "D8"
        ar(338) = "0Z"
        ar(339) = "ED"
        ar(340) = "IW"
        ar(341) = "AO"
        ar(342) = "SF"
        ar(343) = "9Y"
        ar(344) = "YK"
        ar(345) = "I4"
        ar(346) = "2S"
        ar(347) = "CL"
        ar(348) = "HQ"
        ar(349) = "M1"
        ar(350) = "13"
        ar(351) = "YV"
        ar(352) = "EV"
        ar(353) = "OO"
        ar(354) = "LP"
        ar(355) = "ZK"
        ar(356) = "M5"
        ar(357) = "33"
        ar(358) = "39"
        ar(359) = "WJ"
        ar(360) = "PX"
        ar(361) = "8V"
        ar(362) = "60"
        ar(363) = "5L"
        ar(364) = "VI"
        ar(365) = "S2"
        ar(366) = "OF"
        ar(367) = "IV"
        ar(368) = "Q4"
        ar(369) = "OE"
        ar(370) = "WI"
        ar(371) = "LZ"
        ar(372) = "D9"
        ar(373) = "ZT"
        ar(374) = "4E"
        ar(375) = "VF"
        ar(376) = "AG"
        ar(377) = "I7"
        ar(378) = "IG"
        ar(379) = "12"
        ar(380) = "MC"
        ar(381) = "O1"
        ar(382) = "UB"
        ar(383) = "PM"
        ar(384) = "2F"
        ar(385) = "3J"
        ar(386) = "DH"
        ar(387) = "KS"
        ar(388) = "7N"
        ar(389) = "MP"
        ar(390) = "CN"
        ar(391) = "DW"
        ar(392) = "TS"
        ar(393) = "HJ"
        ar(394) = "RA"
        ar(395) = "PT"
        ar(396) = "YH"
        ar(397) = "UH"
        ar(398) = "4G"
        ar(399) = "9Q"
        ar(400) = "U6"
        ar(401) = "68"
        ar(402) = "Q5"
        ar(403) = "7H"
        ar(404) = "YG"
        ar(405) = "PY"
        ar(406) = "RM"
        ar(407) = "AA"
        ar(408) = "JG"
        ar(409) = "3W"
        ar(410) = "CR"
        ar(411) = "LG"
        ar(412) = "I9"
        ar(413) = "OC"
        ar(414) = "N3"
        ar(415) = "PE"
        ar(416) = "36"
        ar(417) = "IM"
        ar(418) = "J0"
        ar(419) = "UW"
        ar(420) = "J4"
        ar(421) = "JV"
        ar(422) = "ZZ"
        ar(423) = "CP"
        ar(424) = "5D"
        ar(425) = "IN"
        ar(426) = "DQ"
        ar(427) = "LE"
        ar(428) = "KO"
        ar(429) = "J1"
        ar(430) = "PN"
        ar(431) = "JR"
        ar(432) = "16"
        ar(433) = "WM"
        ar(434) = "PA"
        ar(435) = "OQ"
        ar(436) = "XD"
        ar(437) = "WE"
        ar(438) = "4M"
        ar(439) = "C7"
        ar(440) = "AD"
        ar(441) = "0C"
        ar(442) = "RZ"
        ar(443) = "7Q"
        ar(444) = "9F"
        ar(445) = "2E"
        ar(446) = "XF"
        ar(447) = "5B"
        ar(448) = "4W"
        ar(449) = "XG"
        ar(450) = "KC"
        ar(451) = "QE"
        ar(452) = "02"
        ar(453) = "38"
        ar(454) = "1P"
        ar(455) = "AT"
        ar(456) = "WW"
        ar(457) = "RH"
        ar(458) = "FU"
        ar(459) = "KN"
        ar(460) = "Z3"
        ar(461) = "N2"
        ar(462) = "Q9"
        ar(463) = "FY"
        ar(464) = "8O"
        ar(465) = "DC"
        ar(466) = "TG"
        ar(467) = "YA"
        ar(468) = "H2"
        ar(469) = "O2"
        ar(470) = "6G"
        ar(471) = "KU"
        ar(472) = "7S"
        ar(473) = "25"
        ar(474) = "0M"
        ar(475) = "9O"
        ar(476) = "8M"
        ar(477) = "SC"
        ar(478) = "IU"
        ar(479) = "BW"
        ar(480) = "YP"
        ar(481) = "VU"
        ar(482) = "QG"
        ar(483) = "HL"
        ar(484) = "RO"
        ar(485) = "RK"
        ar(486) = "RI"
        ar(487) = "TI"
        ar(488) = "PL"
        ar(489) = "F1"
        ar(490) = "XN"
        ar(491) = "EU"
        ar(492) = "HX"
        ar(493) = "HH"
        ar(494) = "E6"
        ar(495) = "UQ"
        ar(496) = "FP"
        ar(497) = "3F"
        ar(498) = "AC"
        ar(499) = "34"


        Dim r As Integer
        Dim rChar As String

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As String
        Dim m201 As Integer
        Dim mChar As String

        If cText = "" Then
            msDecryptRandom = ""
            Exit Function
        End If


        mChar = Mid(cText, 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                m201 = i
                Exit For
            End If
        Next

        rChar = Mid(cText, 3, 2)
        For i = 0 To 255
            If ar(i) = rChar Then
                r = i
                Exit For
            End If
        Next

        l = Asc(r)
        nl = Len(cText)

        Dim j As Integer
        Dim k As Integer
        k = 0
        sR = ""
        For i = 5 To nl Step 2
            k = k + 1
            If k > 13 Then k = 0
            aski = Mid(cText, i, 2)
            For j = 0 To 255
                If ar(j) = aski Then
                    l = l + j
                    sR = sR & Chr(j - k - r)
                    Exit For
                End If
            Next
        Next

        If m201 = l Mod 201 Then
            sR = "1" & sR
        Else
            sR = "0" & sR
        End If

        msDecryptRandom = sR


    End Function


    Public Function msEncryptRandom2(ByVal cText As String) As String

        Dim ar(500) As String
        ar(0) = "KK"
        ar(1) = "3P"
        ar(2) = "8K"
        ar(3) = "RD"
        ar(4) = "KF"
        ar(5) = "NA"
        ar(6) = "T4"
        ar(7) = "6X"
        ar(8) = "MY"
        ar(9) = "KQ"
        ar(10) = "EC"
        ar(11) = "PA"
        ar(12) = "B5"
        ar(13) = "OP"
        ar(14) = "Y6"
        ar(15) = "CE"
        ar(16) = "IM"
        ar(17) = "FI"
        ar(18) = "GO"
        ar(19) = "OB"
        ar(20) = "JI"
        ar(21) = "KB"
        ar(22) = "L1"
        ar(23) = "XT"
        ar(24) = "R8"
        ar(25) = "EY"
        ar(26) = "CR"
        ar(27) = "25"
        ar(28) = "VB"
        ar(29) = "WU"
        ar(30) = "5S"
        ar(31) = "ZB"
        ar(32) = "ZN"
        ar(33) = "3E"
        ar(34) = "NC"
        ar(35) = "U0"
        ar(36) = "G6"
        ar(37) = "TE"
        ar(38) = "49"
        ar(39) = "51"
        ar(40) = "6E"
        ar(41) = "JO"
        ar(42) = "35"
        ar(43) = "O0"
        ar(44) = "7W"
        ar(45) = "LF"
        ar(46) = "AX"
        ar(47) = "HE"
        ar(48) = "T1"
        ar(49) = "L8"
        ar(50) = "II"
        ar(51) = "VX"
        ar(52) = "Q9"
        ar(53) = "C4"
        ar(54) = "TO"
        ar(55) = "7A"
        ar(56) = "M1"
        ar(57) = "E3"
        ar(58) = "AO"
        ar(59) = "6J"
        ar(60) = "YT"
        ar(61) = "LO"
        ar(62) = "BM"
        ar(63) = "6K"
        ar(64) = "HR"
        ar(65) = "M8"
        ar(66) = "RN"
        ar(67) = "GK"
        ar(68) = "OW"
        ar(69) = "G4"
        ar(70) = "X3"
        ar(71) = "5K"
        ar(72) = "9I"
        ar(73) = "OQ"
        ar(74) = "V3"
        ar(75) = "XN"
        ar(76) = "FA"
        ar(77) = "PL"
        ar(78) = "BJ"
        ar(79) = "G5"
        ar(80) = "MW"
        ar(81) = "YI"
        ar(82) = "XP"
        ar(83) = "23"
        ar(84) = "9Y"
        ar(85) = "M4"
        ar(86) = "9X"
        ar(87) = "O3"
        ar(88) = "AD"
        ar(89) = "IR"
        ar(90) = "D0"
        ar(91) = "TU"
        ar(92) = "I3"
        ar(93) = "P3"
        ar(94) = "UW"
        ar(95) = "SR"
        ar(96) = "G8"
        ar(97) = "MO"
        ar(98) = "R2"
        ar(99) = "3T"
        ar(100) = "AM"
        ar(101) = "RK"
        ar(102) = "Y9"
        ar(103) = "JB"
        ar(104) = "D7"
        ar(105) = "MS"
        ar(106) = "56"
        ar(107) = "5N"
        ar(108) = "Y2"
        ar(109) = "J6"
        ar(110) = "5W"
        ar(111) = "OL"
        ar(112) = "UI"
        ar(113) = "SK"
        ar(114) = "OU"
        ar(115) = "UJ"
        ar(116) = "EB"
        ar(117) = "WF"
        ar(118) = "QP"
        ar(119) = "BE"
        ar(120) = "J0"
        ar(121) = "S0"
        ar(122) = "SI"
        ar(123) = "8B"
        ar(124) = "XZ"
        ar(125) = "ES"
        ar(126) = "77"
        ar(127) = "3V"
        ar(128) = "VY"
        ar(129) = "UQ"
        ar(130) = "9C"
        ar(131) = "NL"
        ar(132) = "BG"
        ar(133) = "JP"
        ar(134) = "ZU"
        ar(135) = "9T"
        ar(136) = "VL"
        ar(137) = "K3"
        ar(138) = "LX"
        ar(139) = "W0"
        ar(140) = "NK"
        ar(141) = "3K"
        ar(142) = "79"
        ar(143) = "LP"
        ar(144) = "RH"
        ar(145) = "33"
        ar(146) = "V7"
        ar(147) = "YW"
        ar(148) = "C3"
        ar(149) = "SQ"
        ar(150) = "MD"
        ar(151) = "O9"
        ar(152) = "W6"
        ar(153) = "7H"
        ar(154) = "KG"
        ar(155) = "IV"
        ar(156) = "M0"
        ar(157) = "IU"
        ar(158) = "EO"
        ar(159) = "F3"
        ar(160) = "6N"
        ar(161) = "2M"
        ar(162) = "K9"
        ar(163) = "2A"
        ar(164) = "4K"
        ar(165) = "4H"
        ar(166) = "B6"
        ar(167) = "61"
        ar(168) = "93"
        ar(169) = "X1"
        ar(170) = "TX"
        ar(171) = "GP"
        ar(172) = "NF"
        ar(173) = "OO"
        ar(174) = "7C"
        ar(175) = "QL"
        ar(176) = "K6"
        ar(177) = "ER"
        ar(178) = "YG"
        ar(179) = "7T"
        ar(180) = "ME"
        ar(181) = "C7"
        ar(182) = "Y8"
        ar(183) = "P1"
        ar(184) = "FN"
        ar(185) = "B0"
        ar(186) = "TH"
        ar(187) = "W1"
        ar(188) = "2S"
        ar(189) = "W9"
        ar(190) = "WS"
        ar(191) = "ZI"
        ar(192) = "U1"
        ar(193) = "KP"
        ar(194) = "LN"
        ar(195) = "KC"
        ar(196) = "G0"
        ar(197) = "B4"
        ar(198) = "22"
        ar(199) = "IH"
        ar(200) = "NG"
        ar(201) = "XH"
        ar(202) = "GW"
        ar(203) = "LR"
        ar(204) = "JJ"
        ar(205) = "QM"
        ar(206) = "3U"
        ar(207) = "54"
        ar(208) = "ZP"
        ar(209) = "RO"
        ar(210) = "MM"
        ar(211) = "SD"
        ar(212) = "5C"
        ar(213) = "Z3"
        ar(214) = "EJ"
        ar(215) = "ZX"
        ar(216) = "CX"
        ar(217) = "JY"
        ar(218) = "CZ"
        ar(219) = "NI"
        ar(220) = "4I"
        ar(221) = "S9"
        ar(222) = "FX"
        ar(223) = "UC"
        ar(224) = "DB"
        ar(225) = "F9"
        ar(226) = "E9"
        ar(227) = "2D"
        ar(228) = "7V"
        ar(229) = "V1"
        ar(230) = "TT"
        ar(231) = "I5"
        ar(232) = "7B"
        ar(233) = "X4"
        ar(234) = "8U"
        ar(235) = "Z6"
        ar(236) = "CP"
        ar(237) = "DM"
        ar(238) = "V0"
        ar(239) = "2O"
        ar(240) = "AR"
        ar(241) = "L6"
        ar(242) = "83"
        ar(243) = "60"
        ar(244) = "DE"
        ar(245) = "T2"
        ar(246) = "ZO"
        ar(247) = "VH"
        ar(248) = "V6"
        ar(249) = "CN"
        ar(250) = "6Q"
        ar(251) = "JZ"
        ar(252) = "AQ"
        ar(253) = "Z4"
        ar(254) = "A2"
        ar(255) = "EA"
        ar(256) = "IT"
        ar(257) = "AI"
        ar(258) = "2I"
        ar(259) = "7K"
        ar(260) = "K0"
        ar(261) = "W3"
        ar(262) = "WI"
        ar(263) = "4U"
        ar(264) = "7Z"
        ar(265) = "BH"
        ar(266) = "V8"
        ar(267) = "WA"
        ar(268) = "4Y"
        ar(269) = "BT"
        ar(270) = "X8"
        ar(271) = "CH"
        ar(272) = "JX"
        ar(273) = "6F"
        ar(274) = "ST"
        ar(275) = "TB"
        ar(276) = "L3"
        ar(277) = "CW"
        ar(278) = "HK"
        ar(279) = "U6"
        ar(280) = "VF"
        ar(281) = "8S"
        ar(282) = "JH"
        ar(283) = "DQ"
        ar(284) = "7D"
        ar(285) = "ZH"
        ar(286) = "GG"
        ar(287) = "DL"
        ar(288) = "MZ"
        ar(289) = "RA"
        ar(290) = "EG"
        ar(291) = "99"
        ar(292) = "KT"
        ar(293) = "OK"
        ar(294) = "G1"
        ar(295) = "D1"
        ar(296) = "PB"
        ar(297) = "QB"
        ar(298) = "QN"
        ar(299) = "RQ"
        ar(300) = "PS"
        ar(301) = "M6"
        ar(302) = "8L"
        ar(303) = "9H"
        ar(304) = "LJ"
        ar(305) = "46"
        ar(306) = "UA"
        ar(307) = "A1"
        ar(308) = "ZK"
        ar(309) = "NW"
        ar(310) = "YO"
        ar(311) = "4Z"
        ar(312) = "JD"
        ar(313) = "N0"
        ar(314) = "BA"
        ar(315) = "4R"
        ar(316) = "UT"
        ar(317) = "ZE"
        ar(318) = "SL"
        ar(319) = "LB"
        ar(320) = "SJ"
        ar(321) = "5T"
        ar(322) = "7S"
        ar(323) = "5B"
        ar(324) = "DZ"
        ar(325) = "NO"
        ar(326) = "PZ"
        ar(327) = "U7"
        ar(328) = "WG"
        ar(329) = "BC"
        ar(330) = "DT"
        ar(331) = "PI"
        ar(332) = "O6"
        ar(333) = "3X"
        ar(334) = "HS"
        ar(335) = "CT"
        ar(336) = "SH"
        ar(337) = "SO"
        ar(338) = "Q4"
        ar(339) = "K1"
        ar(340) = "81"
        ar(341) = "J8"
        ar(342) = "TQ"
        ar(343) = "UM"
        ar(344) = "XS"
        ar(345) = "P8"
        ar(346) = "U9"
        ar(347) = "YS"
        ar(348) = "9Q"
        ar(349) = "PQ"
        ar(350) = "9M"
        ar(351) = "CU"
        ar(352) = "EF"
        ar(353) = "QJ"
        ar(354) = "FD"
        ar(355) = "H4"
        ar(356) = "G3"
        ar(357) = "QD"
        ar(358) = "4C"
        ar(359) = "7J"
        ar(360) = "U8"
        ar(361) = "CJ"
        ar(362) = "GR"
        ar(363) = "43"
        ar(364) = "HX"
        ar(365) = "IP"
        ar(366) = "8M"
        ar(367) = "5Y"
        ar(368) = "SW"
        ar(369) = "S3"
        ar(370) = "PT"
        ar(371) = "WW"
        ar(372) = "X9"
        ar(373) = "K7"
        ar(374) = "VD"
        ar(375) = "WO"
        ar(376) = "TK"
        ar(377) = "RC"
        ar(378) = "DC"
        ar(379) = "6T"
        ar(380) = "P4"
        ar(381) = "OY"
        ar(382) = "GB"
        ar(383) = "PW"
        ar(384) = "HT"
        ar(385) = "T3"
        ar(386) = "9K"
        ar(387) = "T5"
        ar(388) = "MA"
        ar(389) = "6A"
        ar(390) = "8J"
        ar(391) = "9J"
        ar(392) = "U5"
        ar(393) = "WL"
        ar(394) = "H1"
        ar(395) = "PO"
        ar(396) = "N5"
        ar(397) = "YQ"
        ar(398) = "GU"
        ar(399) = "P5"
        ar(400) = "8A"
        ar(401) = "YR"
        ar(402) = "EM"
        ar(403) = "CG"
        ar(404) = "AA"
        ar(405) = "V5"
        ar(406) = "C0"
        ar(407) = "EP"
        ar(408) = "FT"
        ar(409) = "IG"
        ar(410) = "KN"
        ar(411) = "6V"
        ar(412) = "3G"
        ar(413) = "HH"
        ar(414) = "6U"
        ar(415) = "2B"
        ar(416) = "K8"
        ar(417) = "3O"
        ar(418) = "AG"
        ar(419) = "AS"
        ar(420) = "O1"
        ar(421) = "T8"
        ar(422) = "5G"
        ar(423) = "DS"
        ar(424) = "AL"
        ar(425) = "8Q"
        ar(426) = "9G"
        ar(427) = "VS"
        ar(428) = "EZ"
        ar(429) = "34"
        ar(430) = "IW"
        ar(431) = "W2"
        ar(432) = "5H"
        ar(433) = "JS"
        ar(434) = "JR"
        ar(435) = "R7"
        ar(436) = "AH"
        ar(437) = "PH"
        ar(438) = "YD"
        ar(439) = "CQ"
        ar(440) = "36"
        ar(441) = "BQ"
        ar(442) = "40"
        ar(443) = "QU"
        ar(444) = "2W"
        ar(445) = "89"
        ar(446) = "SB"
        ar(447) = "JK"
        ar(448) = "E4"
        ar(449) = "OR"
        ar(450) = "QC"
        ar(451) = "XJ"
        ar(452) = "N4"
        ar(453) = "EI"
        ar(454) = "ID"
        ar(455) = "N8"
        ar(456) = "N2"
        ar(457) = "PY"
        ar(458) = "70"
        ar(459) = "5V"
        ar(460) = "WY"
        ar(461) = "JA"
        ar(462) = "3S"
        ar(463) = "N3"
        ar(464) = "OS"
        ar(465) = "3A"
        ar(466) = "67"
        ar(467) = "4Q"
        ar(468) = "ZV"
        ar(469) = "TM"
        ar(470) = "D4"
        ar(471) = "MR"
        ar(472) = "JF"
        ar(473) = "3I"
        ar(474) = "SN"
        ar(475) = "98"
        ar(476) = "N7"
        ar(477) = "C6"
        ar(478) = "IF"
        ar(479) = "I6"
        ar(480) = "IX"
        ar(481) = "Q8"
        ar(482) = "R9"
        ar(483) = "4T"
        ar(484) = "KU"
        ar(485) = "2Y"
        ar(486) = "L2"
        ar(487) = "DJ"
        ar(488) = "L7"
        ar(489) = "RE"
        ar(490) = "TI"
        ar(491) = "2G"
        ar(492) = "50"
        ar(493) = "YA"
        ar(494) = "I2"
        ar(495) = "YF"
        ar(496) = "JE"
        ar(497) = "XK"
        ar(498) = "6B"
        ar(499) = "DU"

        Dim r As Integer

        Randomize()
        r = Int(Rnd() * 10)

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As Integer
        sR = ""
        If cText = "" Then
            msEncryptRandom2 = ""
            Exit Function
        End If

        nl = Len(cText)
        Dim p As String
        Dim k As Integer
        k = 0

        l = Asc(r)

        For i = 1 To nl
            k = k + 1
            If k > 13 Then k = 0
            p = Mid(cText, i, 1)
            aski = Asc(p) + k + r
            l = l + aski
            sR = sR & ar(aski)
        Next

        Dim m190 As Integer
        m190 = l Mod 190

        sR = ar(m190) & ar(r) & sR

        msEncryptRandom2 = sR


    End Function


    Public Function msDecryptRandom2(ByVal cText As String) As String

        Dim ar(500) As String
        ar(0) = "KK"
        ar(1) = "3P"
        ar(2) = "8K"
        ar(3) = "RD"
        ar(4) = "KF"
        ar(5) = "NA"
        ar(6) = "T4"
        ar(7) = "6X"
        ar(8) = "MY"
        ar(9) = "KQ"
        ar(10) = "EC"
        ar(11) = "PA"
        ar(12) = "B5"
        ar(13) = "OP"
        ar(14) = "Y6"
        ar(15) = "CE"
        ar(16) = "IM"
        ar(17) = "FI"
        ar(18) = "GO"
        ar(19) = "OB"
        ar(20) = "JI"
        ar(21) = "KB"
        ar(22) = "L1"
        ar(23) = "XT"
        ar(24) = "R8"
        ar(25) = "EY"
        ar(26) = "CR"
        ar(27) = "25"
        ar(28) = "VB"
        ar(29) = "WU"
        ar(30) = "5S"
        ar(31) = "ZB"
        ar(32) = "ZN"
        ar(33) = "3E"
        ar(34) = "NC"
        ar(35) = "U0"
        ar(36) = "G6"
        ar(37) = "TE"
        ar(38) = "49"
        ar(39) = "51"
        ar(40) = "6E"
        ar(41) = "JO"
        ar(42) = "35"
        ar(43) = "O0"
        ar(44) = "7W"
        ar(45) = "LF"
        ar(46) = "AX"
        ar(47) = "HE"
        ar(48) = "T1"
        ar(49) = "L8"
        ar(50) = "II"
        ar(51) = "VX"
        ar(52) = "Q9"
        ar(53) = "C4"
        ar(54) = "TO"
        ar(55) = "7A"
        ar(56) = "M1"
        ar(57) = "E3"
        ar(58) = "AO"
        ar(59) = "6J"
        ar(60) = "YT"
        ar(61) = "LO"
        ar(62) = "BM"
        ar(63) = "6K"
        ar(64) = "HR"
        ar(65) = "M8"
        ar(66) = "RN"
        ar(67) = "GK"
        ar(68) = "OW"
        ar(69) = "G4"
        ar(70) = "X3"
        ar(71) = "5K"
        ar(72) = "9I"
        ar(73) = "OQ"
        ar(74) = "V3"
        ar(75) = "XN"
        ar(76) = "FA"
        ar(77) = "PL"
        ar(78) = "BJ"
        ar(79) = "G5"
        ar(80) = "MW"
        ar(81) = "YI"
        ar(82) = "XP"
        ar(83) = "23"
        ar(84) = "9Y"
        ar(85) = "M4"
        ar(86) = "9X"
        ar(87) = "O3"
        ar(88) = "AD"
        ar(89) = "IR"
        ar(90) = "D0"
        ar(91) = "TU"
        ar(92) = "I3"
        ar(93) = "P3"
        ar(94) = "UW"
        ar(95) = "SR"
        ar(96) = "G8"
        ar(97) = "MO"
        ar(98) = "R2"
        ar(99) = "3T"
        ar(100) = "AM"
        ar(101) = "RK"
        ar(102) = "Y9"
        ar(103) = "JB"
        ar(104) = "D7"
        ar(105) = "MS"
        ar(106) = "56"
        ar(107) = "5N"
        ar(108) = "Y2"
        ar(109) = "J6"
        ar(110) = "5W"
        ar(111) = "OL"
        ar(112) = "UI"
        ar(113) = "SK"
        ar(114) = "OU"
        ar(115) = "UJ"
        ar(116) = "EB"
        ar(117) = "WF"
        ar(118) = "QP"
        ar(119) = "BE"
        ar(120) = "J0"
        ar(121) = "S0"
        ar(122) = "SI"
        ar(123) = "8B"
        ar(124) = "XZ"
        ar(125) = "ES"
        ar(126) = "77"
        ar(127) = "3V"
        ar(128) = "VY"
        ar(129) = "UQ"
        ar(130) = "9C"
        ar(131) = "NL"
        ar(132) = "BG"
        ar(133) = "JP"
        ar(134) = "ZU"
        ar(135) = "9T"
        ar(136) = "VL"
        ar(137) = "K3"
        ar(138) = "LX"
        ar(139) = "W0"
        ar(140) = "NK"
        ar(141) = "3K"
        ar(142) = "79"
        ar(143) = "LP"
        ar(144) = "RH"
        ar(145) = "33"
        ar(146) = "V7"
        ar(147) = "YW"
        ar(148) = "C3"
        ar(149) = "SQ"
        ar(150) = "MD"
        ar(151) = "O9"
        ar(152) = "W6"
        ar(153) = "7H"
        ar(154) = "KG"
        ar(155) = "IV"
        ar(156) = "M0"
        ar(157) = "IU"
        ar(158) = "EO"
        ar(159) = "F3"
        ar(160) = "6N"
        ar(161) = "2M"
        ar(162) = "K9"
        ar(163) = "2A"
        ar(164) = "4K"
        ar(165) = "4H"
        ar(166) = "B6"
        ar(167) = "61"
        ar(168) = "93"
        ar(169) = "X1"
        ar(170) = "TX"
        ar(171) = "GP"
        ar(172) = "NF"
        ar(173) = "OO"
        ar(174) = "7C"
        ar(175) = "QL"
        ar(176) = "K6"
        ar(177) = "ER"
        ar(178) = "YG"
        ar(179) = "7T"
        ar(180) = "ME"
        ar(181) = "C7"
        ar(182) = "Y8"
        ar(183) = "P1"
        ar(184) = "FN"
        ar(185) = "B0"
        ar(186) = "TH"
        ar(187) = "W1"
        ar(188) = "2S"
        ar(189) = "W9"
        ar(190) = "WS"
        ar(191) = "ZI"
        ar(192) = "U1"
        ar(193) = "KP"
        ar(194) = "LN"
        ar(195) = "KC"
        ar(196) = "G0"
        ar(197) = "B4"
        ar(198) = "22"
        ar(199) = "IH"
        ar(200) = "NG"
        ar(201) = "XH"
        ar(202) = "GW"
        ar(203) = "LR"
        ar(204) = "JJ"
        ar(205) = "QM"
        ar(206) = "3U"
        ar(207) = "54"
        ar(208) = "ZP"
        ar(209) = "RO"
        ar(210) = "MM"
        ar(211) = "SD"
        ar(212) = "5C"
        ar(213) = "Z3"
        ar(214) = "EJ"
        ar(215) = "ZX"
        ar(216) = "CX"
        ar(217) = "JY"
        ar(218) = "CZ"
        ar(219) = "NI"
        ar(220) = "4I"
        ar(221) = "S9"
        ar(222) = "FX"
        ar(223) = "UC"
        ar(224) = "DB"
        ar(225) = "F9"
        ar(226) = "E9"
        ar(227) = "2D"
        ar(228) = "7V"
        ar(229) = "V1"
        ar(230) = "TT"
        ar(231) = "I5"
        ar(232) = "7B"
        ar(233) = "X4"
        ar(234) = "8U"
        ar(235) = "Z6"
        ar(236) = "CP"
        ar(237) = "DM"
        ar(238) = "V0"
        ar(239) = "2O"
        ar(240) = "AR"
        ar(241) = "L6"
        ar(242) = "83"
        ar(243) = "60"
        ar(244) = "DE"
        ar(245) = "T2"
        ar(246) = "ZO"
        ar(247) = "VH"
        ar(248) = "V6"
        ar(249) = "CN"
        ar(250) = "6Q"
        ar(251) = "JZ"
        ar(252) = "AQ"
        ar(253) = "Z4"
        ar(254) = "A2"
        ar(255) = "EA"
        ar(256) = "IT"
        ar(257) = "AI"
        ar(258) = "2I"
        ar(259) = "7K"
        ar(260) = "K0"
        ar(261) = "W3"
        ar(262) = "WI"
        ar(263) = "4U"
        ar(264) = "7Z"
        ar(265) = "BH"
        ar(266) = "V8"
        ar(267) = "WA"
        ar(268) = "4Y"
        ar(269) = "BT"
        ar(270) = "X8"
        ar(271) = "CH"
        ar(272) = "JX"
        ar(273) = "6F"
        ar(274) = "ST"
        ar(275) = "TB"
        ar(276) = "L3"
        ar(277) = "CW"
        ar(278) = "HK"
        ar(279) = "U6"
        ar(280) = "VF"
        ar(281) = "8S"
        ar(282) = "JH"
        ar(283) = "DQ"
        ar(284) = "7D"
        ar(285) = "ZH"
        ar(286) = "GG"
        ar(287) = "DL"
        ar(288) = "MZ"
        ar(289) = "RA"
        ar(290) = "EG"
        ar(291) = "99"
        ar(292) = "KT"
        ar(293) = "OK"
        ar(294) = "G1"
        ar(295) = "D1"
        ar(296) = "PB"
        ar(297) = "QB"
        ar(298) = "QN"
        ar(299) = "RQ"
        ar(300) = "PS"
        ar(301) = "M6"
        ar(302) = "8L"
        ar(303) = "9H"
        ar(304) = "LJ"
        ar(305) = "46"
        ar(306) = "UA"
        ar(307) = "A1"
        ar(308) = "ZK"
        ar(309) = "NW"
        ar(310) = "YO"
        ar(311) = "4Z"
        ar(312) = "JD"
        ar(313) = "N0"
        ar(314) = "BA"
        ar(315) = "4R"
        ar(316) = "UT"
        ar(317) = "ZE"
        ar(318) = "SL"
        ar(319) = "LB"
        ar(320) = "SJ"
        ar(321) = "5T"
        ar(322) = "7S"
        ar(323) = "5B"
        ar(324) = "DZ"
        ar(325) = "NO"
        ar(326) = "PZ"
        ar(327) = "U7"
        ar(328) = "WG"
        ar(329) = "BC"
        ar(330) = "DT"
        ar(331) = "PI"
        ar(332) = "O6"
        ar(333) = "3X"
        ar(334) = "HS"
        ar(335) = "CT"
        ar(336) = "SH"
        ar(337) = "SO"
        ar(338) = "Q4"
        ar(339) = "K1"
        ar(340) = "81"
        ar(341) = "J8"
        ar(342) = "TQ"
        ar(343) = "UM"
        ar(344) = "XS"
        ar(345) = "P8"
        ar(346) = "U9"
        ar(347) = "YS"
        ar(348) = "9Q"
        ar(349) = "PQ"
        ar(350) = "9M"
        ar(351) = "CU"
        ar(352) = "EF"
        ar(353) = "QJ"
        ar(354) = "FD"
        ar(355) = "H4"
        ar(356) = "G3"
        ar(357) = "QD"
        ar(358) = "4C"
        ar(359) = "7J"
        ar(360) = "U8"
        ar(361) = "CJ"
        ar(362) = "GR"
        ar(363) = "43"
        ar(364) = "HX"
        ar(365) = "IP"
        ar(366) = "8M"
        ar(367) = "5Y"
        ar(368) = "SW"
        ar(369) = "S3"
        ar(370) = "PT"
        ar(371) = "WW"
        ar(372) = "X9"
        ar(373) = "K7"
        ar(374) = "VD"
        ar(375) = "WO"
        ar(376) = "TK"
        ar(377) = "RC"
        ar(378) = "DC"
        ar(379) = "6T"
        ar(380) = "P4"
        ar(381) = "OY"
        ar(382) = "GB"
        ar(383) = "PW"
        ar(384) = "HT"
        ar(385) = "T3"
        ar(386) = "9K"
        ar(387) = "T5"
        ar(388) = "MA"
        ar(389) = "6A"
        ar(390) = "8J"
        ar(391) = "9J"
        ar(392) = "U5"
        ar(393) = "WL"
        ar(394) = "H1"
        ar(395) = "PO"
        ar(396) = "N5"
        ar(397) = "YQ"
        ar(398) = "GU"
        ar(399) = "P5"
        ar(400) = "8A"
        ar(401) = "YR"
        ar(402) = "EM"
        ar(403) = "CG"
        ar(404) = "AA"
        ar(405) = "V5"
        ar(406) = "C0"
        ar(407) = "EP"
        ar(408) = "FT"
        ar(409) = "IG"
        ar(410) = "KN"
        ar(411) = "6V"
        ar(412) = "3G"
        ar(413) = "HH"
        ar(414) = "6U"
        ar(415) = "2B"
        ar(416) = "K8"
        ar(417) = "3O"
        ar(418) = "AG"
        ar(419) = "AS"
        ar(420) = "O1"
        ar(421) = "T8"
        ar(422) = "5G"
        ar(423) = "DS"
        ar(424) = "AL"
        ar(425) = "8Q"
        ar(426) = "9G"
        ar(427) = "VS"
        ar(428) = "EZ"
        ar(429) = "34"
        ar(430) = "IW"
        ar(431) = "W2"
        ar(432) = "5H"
        ar(433) = "JS"
        ar(434) = "JR"
        ar(435) = "R7"
        ar(436) = "AH"
        ar(437) = "PH"
        ar(438) = "YD"
        ar(439) = "CQ"
        ar(440) = "36"
        ar(441) = "BQ"
        ar(442) = "40"
        ar(443) = "QU"
        ar(444) = "2W"
        ar(445) = "89"
        ar(446) = "SB"
        ar(447) = "JK"
        ar(448) = "E4"
        ar(449) = "OR"
        ar(450) = "QC"
        ar(451) = "XJ"
        ar(452) = "N4"
        ar(453) = "EI"
        ar(454) = "ID"
        ar(455) = "N8"
        ar(456) = "N2"
        ar(457) = "PY"
        ar(458) = "70"
        ar(459) = "5V"
        ar(460) = "WY"
        ar(461) = "JA"
        ar(462) = "3S"
        ar(463) = "N3"
        ar(464) = "OS"
        ar(465) = "3A"
        ar(466) = "67"
        ar(467) = "4Q"
        ar(468) = "ZV"
        ar(469) = "TM"
        ar(470) = "D4"
        ar(471) = "MR"
        ar(472) = "JF"
        ar(473) = "3I"
        ar(474) = "SN"
        ar(475) = "98"
        ar(476) = "N7"
        ar(477) = "C6"
        ar(478) = "IF"
        ar(479) = "I6"
        ar(480) = "IX"
        ar(481) = "Q8"
        ar(482) = "R9"
        ar(483) = "4T"
        ar(484) = "KU"
        ar(485) = "2Y"
        ar(486) = "L2"
        ar(487) = "DJ"
        ar(488) = "L7"
        ar(489) = "RE"
        ar(490) = "TI"
        ar(491) = "2G"
        ar(492) = "50"
        ar(493) = "YA"
        ar(494) = "I2"
        ar(495) = "YF"
        ar(496) = "JE"
        ar(497) = "XK"
        ar(498) = "6B"
        ar(499) = "DU"

        Dim r As Integer
        Dim rChar As String

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As String
        Dim m190 As Integer
        Dim mChar As String

        If cText = "" Then
            msDecryptRandom2 = ""
            Exit Function
        End If


        mChar = Mid(cText, 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                m190 = i
                Exit For
            End If
        Next

        rChar = Mid(cText, 3, 2)
        For i = 0 To 255
            If ar(i) = rChar Then
                r = i
                Exit For
            End If
        Next

        l = Asc(r)
        nl = Len(cText)

        Dim j As Integer
        Dim k As Integer
        k = 0
        sR = ""
        For i = 5 To nl Step 2
            k = k + 1
            If k > 13 Then k = 0
            aski = Mid(cText, i, 2)
            For j = 0 To 255
                If ar(j) = aski Then
                    l = l + j
                    On Error Resume Next
                    sR = sR & Chr(j - k - r)
                    Exit For
                End If
            Next
        Next

        If m190 = l Mod 190 Then
            sR = "1" & sR
        Else
            sR = "0" & sR
        End If

        msDecryptRandom2 = sR



    End Function

    Public Function msEncryptRandom3(ByVal cText As String) As String


        Dim ar(500) As String
        ar(0) = "35"
        ar(1) = "VI"
        ar(2) = "GJ"
        ar(3) = "2L"
        ar(4) = "KM"
        ar(5) = "MZ"
        ar(6) = "PC"
        ar(7) = "GO"
        ar(8) = "GE"
        ar(9) = "53"
        ar(10) = "TF"
        ar(11) = "EV"
        ar(12) = "68"
        ar(13) = "4D"
        ar(14) = "CX"
        ar(15) = "81"
        ar(16) = "7L"
        ar(17) = "ZK"
        ar(18) = "SM"
        ar(19) = "RO"
        ar(20) = "S2"
        ar(21) = "VN"
        ar(22) = "6V"
        ar(23) = "SY"
        ar(24) = "LK"
        ar(25) = "Y4"
        ar(26) = "HV"
        ar(27) = "VK"
        ar(28) = "98"
        ar(29) = "AN"
        ar(30) = "LG"
        ar(31) = "XS"
        ar(32) = "UX"
        ar(33) = "TR"
        ar(34) = "G3"
        ar(35) = "VO"
        ar(36) = "OA"
        ar(37) = "2A"
        ar(38) = "YD"
        ar(39) = "78"
        ar(40) = "E3"
        ar(41) = "QL"
        ar(42) = "XM"
        ar(43) = "79"
        ar(44) = "PX"
        ar(45) = "RB"
        ar(46) = "DK"
        ar(47) = "U7"
        ar(48) = "DM"
        ar(49) = "OR"
        ar(50) = "HE"
        ar(51) = "Q3"
        ar(52) = "72"
        ar(53) = "NF"
        ar(54) = "3C"
        ar(55) = "P9"
        ar(56) = "PS"
        ar(57) = "8A"
        ar(58) = "TV"
        ar(59) = "7V"
        ar(60) = "XW"
        ar(61) = "4R"
        ar(62) = "NQ"
        ar(63) = "E6"
        ar(64) = "M0"
        ar(65) = "AR"
        ar(66) = "ZO"
        ar(67) = "6X"
        ar(68) = "YM"
        ar(69) = "6M"
        ar(70) = "XH"
        ar(71) = "L0"
        ar(72) = "5D"
        ar(73) = "D1"
        ar(74) = "KY"
        ar(75) = "OM"
        ar(76) = "VJ"
        ar(77) = "V2"
        ar(78) = "UD"
        ar(79) = "6F"
        ar(80) = "TP"
        ar(81) = "9Y"
        ar(82) = "FY"
        ar(83) = "X8"
        ar(84) = "45"
        ar(85) = "2F"
        ar(86) = "TJ"
        ar(87) = "ED"
        ar(88) = "T8"
        ar(89) = "VR"
        ar(90) = "OI"
        ar(91) = "P6"
        ar(92) = "V4"
        ar(93) = "YZ"
        ar(94) = "O1"
        ar(95) = "T9"
        ar(96) = "D7"
        ar(97) = "EJ"
        ar(98) = "WH"
        ar(99) = "BM"
        ar(100) = "9P"
        ar(101) = "EW"
        ar(102) = "80"
        ar(103) = "7D"
        ar(104) = "2V"
        ar(105) = "7H"
        ar(106) = "83"
        ar(107) = "2T"
        ar(108) = "TE"
        ar(109) = "9Z"
        ar(110) = "BD"
        ar(111) = "T3"
        ar(112) = "T4"
        ar(113) = "4Y"
        ar(114) = "VT"
        ar(115) = "WU"
        ar(116) = "4B"
        ar(117) = "IN"
        ar(118) = "AU"
        ar(119) = "7U"
        ar(120) = "B5"
        ar(121) = "JH"
        ar(122) = "Z9"
        ar(123) = "D3"
        ar(124) = "4T"
        ar(125) = "MG"
        ar(126) = "EY"
        ar(127) = "8Y"
        ar(128) = "VH"
        ar(129) = "XR"
        ar(130) = "IO"
        ar(131) = "M2"
        ar(132) = "E8"
        ar(133) = "4S"
        ar(134) = "XX"
        ar(135) = "3X"
        ar(136) = "AZ"
        ar(137) = "MT"
        ar(138) = "6P"
        ar(139) = "T0"
        ar(140) = "GN"
        ar(141) = "YJ"
        ar(142) = "K6"
        ar(143) = "R8"
        ar(144) = "PK"
        ar(145) = "WM"
        ar(146) = "A7"
        ar(147) = "20"
        ar(148) = "32"
        ar(149) = "9U"
        ar(150) = "AT"
        ar(151) = "ZB"
        ar(152) = "7B"
        ar(153) = "ZG"
        ar(154) = "A8"
        ar(155) = "YT"
        ar(156) = "FW"
        ar(157) = "8S"
        ar(158) = "I3"
        ar(159) = "UN"
        ar(160) = "7I"
        ar(161) = "Q5"
        ar(162) = "KP"
        ar(163) = "Y1"
        ar(164) = "BT"
        ar(165) = "OS"
        ar(166) = "BK"
        ar(167) = "4K"
        ar(168) = "SG"
        ar(169) = "SF"
        ar(170) = "RC"
        ar(171) = "R5"
        ar(172) = "NO"
        ar(173) = "PG"
        ar(174) = "P4"
        ar(175) = "CI"
        ar(176) = "3U"
        ar(177) = "BX"
        ar(178) = "VY"
        ar(179) = "YH"
        ar(180) = "59"
        ar(181) = "7E"
        ar(182) = "6Y"
        ar(183) = "FC"
        ar(184) = "LB"
        ar(185) = "2Z"
        ar(186) = "PQ"
        ar(187) = "4U"
        ar(188) = "2Q"
        ar(189) = "G6"
        ar(190) = "4A"
        ar(191) = "23"
        ar(192) = "HC"
        ar(193) = "UE"
        ar(194) = "24"
        ar(195) = "F0"
        ar(196) = "50"
        ar(197) = "37"
        ar(198) = "A3"
        ar(199) = "JT"
        ar(200) = "FA"
        ar(201) = "3I"
        ar(202) = "XV"
        ar(203) = "I1"
        ar(204) = "W0"
        ar(205) = "ME"
        ar(206) = "WX"
        ar(207) = "AO"
        ar(208) = "X5"
        ar(209) = "8E"
        ar(210) = "E4"
        ar(211) = "B8"
        ar(212) = "M6"
        ar(213) = "BG"
        ar(214) = "RF"
        ar(215) = "S7"
        ar(216) = "Q4"
        ar(217) = "GI"
        ar(218) = "I6"
        ar(219) = "U1"
        ar(220) = "8H"
        ar(221) = "AE"
        ar(222) = "VC"
        ar(223) = "EO"
        ar(224) = "PU"
        ar(225) = "DG"
        ar(226) = "RD"
        ar(227) = "5A"
        ar(228) = "L9"
        ar(229) = "3N"
        ar(230) = "SS"
        ar(231) = "I2"
        ar(232) = "RS"
        ar(233) = "SV"
        ar(234) = "CM"
        ar(235) = "FK"
        ar(236) = "KL"
        ar(237) = "ZR"
        ar(238) = "QE"
        ar(239) = "H1"
        ar(240) = "MH"
        ar(241) = "Z6"
        ar(242) = "ZD"
        ar(243) = "X9"
        ar(244) = "XZ"
        ar(245) = "6D"
        ar(246) = "NR"
        ar(247) = "9C"
        ar(248) = "A0"
        ar(249) = "JR"
        ar(250) = "5J"
        ar(251) = "5K"
        ar(252) = "L8"
        ar(253) = "3G"
        ar(254) = "8G"
        ar(255) = "AG"
        ar(256) = "WC"
        ar(257) = "HO"
        ar(258) = "N3"
        ar(259) = "84"
        ar(260) = "6B"
        ar(261) = "VL"
        ar(262) = "EK"
        ar(263) = "KT"
        ar(264) = "M1"
        ar(265) = "Z5"
        ar(266) = "GA"
        ar(267) = "AD"
        ar(268) = "O2"
        ar(269) = "C2"
        ar(270) = "XJ"
        ar(271) = "J4"
        ar(272) = "9L"
        ar(273) = "93"
        ar(274) = "UQ"
        ar(275) = "4Z"
        ar(276) = "K0"
        ar(277) = "46"
        ar(278) = "7O"
        ar(279) = "ZP"
        ar(280) = "CA"
        ar(281) = "IX"
        ar(282) = "OK"
        ar(283) = "58"
        ar(284) = "DA"
        ar(285) = "RX"
        ar(286) = "EX"
        ar(287) = "RN"
        ar(288) = "B1"
        ar(289) = "2H"
        ar(290) = "51"
        ar(291) = "QF"
        ar(292) = "S0"
        ar(293) = "F7"
        ar(294) = "GV"
        ar(295) = "QK"
        ar(296) = "UR"
        ar(297) = "LT"
        ar(298) = "4C"
        ar(299) = "WS"
        ar(300) = "9E"
        ar(301) = "TH"
        ar(302) = "ZL"
        ar(303) = "EZ"
        ar(304) = "U3"
        ar(305) = "QC"
        ar(306) = "IA"
        ar(307) = "5Z"
        ar(308) = "CO"
        ar(309) = "88"
        ar(310) = "T1"
        ar(311) = "MQ"
        ar(312) = "AM"
        ar(313) = "BL"
        ar(314) = "RK"
        ar(315) = "L4"
        ar(316) = "49"
        ar(317) = "6L"
        ar(318) = "GQ"
        ar(319) = "CB"
        ar(320) = "4F"
        ar(321) = "8O"
        ar(322) = "UK"
        ar(323) = "6J"
        ar(324) = "XB"
        ar(325) = "KB"
        ar(326) = "FD"
        ar(327) = "9F"
        ar(328) = "EE"
        ar(329) = "WN"
        ar(330) = "OQ"
        ar(331) = "AW"
        ar(332) = "TB"
        ar(333) = "W5"
        ar(334) = "AF"
        ar(335) = "J2"
        ar(336) = "UO"
        ar(337) = "MW"
        ar(338) = "5F"
        ar(339) = "LI"
        ar(340) = "AA"
        ar(341) = "JC"
        ar(342) = "EM"
        ar(343) = "TO"
        ar(344) = "SP"
        ar(345) = "J3"
        ar(346) = "BW"
        ar(347) = "FO"
        ar(348) = "CH"
        ar(349) = "DS"
        ar(350) = "NE"
        ar(351) = "U8"
        ar(352) = "CZ"
        ar(353) = "D6"
        ar(354) = "4I"
        ar(355) = "O3"
        ar(356) = "RY"
        ar(357) = "P2"
        ar(358) = "FN"
        ar(359) = "PE"
        ar(360) = "XI"
        ar(361) = "N4"
        ar(362) = "GF"
        ar(363) = "I8"
        ar(364) = "6Z"
        ar(365) = "6R"
        ar(366) = "CS"
        ar(367) = "CT"
        ar(368) = "JN"
        ar(369) = "Y7"
        ar(370) = "7F"
        ar(371) = "G0"
        ar(372) = "62"
        ar(373) = "M9"
        ar(374) = "ZQ"
        ar(375) = "JZ"
        ar(376) = "IU"
        ar(377) = "75"
        ar(378) = "E0"
        ar(379) = "NN"
        ar(380) = "GT"
        ar(381) = "UZ"
        ar(382) = "8M"
        ar(383) = "71"
        ar(384) = "3H"
        ar(385) = "AK"
        ar(386) = "QV"
        ar(387) = "H7"
        ar(388) = "76"
        ar(389) = "XU"
        ar(390) = "FR"
        ar(391) = "H3"
        ar(392) = "8F"
        ar(393) = "HI"
        ar(394) = "F8"
        ar(395) = "36"
        ar(396) = "YE"
        ar(397) = "MR"
        ar(398) = "V8"
        ar(399) = "JO"
        ar(400) = "XL"
        ar(401) = "GW"
        ar(402) = "3J"
        ar(403) = "CU"
        ar(404) = "2O"
        ar(405) = "R0"
        ar(406) = "9R"
        ar(407) = "DH"
        ar(408) = "TW"
        ar(409) = "JM"
        ar(410) = "E5"
        ar(411) = "LR"
        ar(412) = "FP"
        ar(413) = "D0"
        ar(414) = "Q8"
        ar(415) = "VU"
        ar(416) = "CC"
        ar(417) = "QU"
        ar(418) = "GL"
        ar(419) = "KA"
        ar(420) = "IV"
        ar(421) = "XY"
        ar(422) = "DN"
        ar(423) = "JG"
        ar(424) = "9G"
        ar(425) = "GG"
        ar(426) = "K2"
        ar(427) = "AP"
        ar(428) = "V1"
        ar(429) = "8J"
        ar(430) = "F4"
        ar(431) = "CQ"
        ar(432) = "K5"
        ar(433) = "EA"
        ar(434) = "NW"
        ar(435) = "RW"
        ar(436) = "OE"
        ar(437) = "MU"
        ar(438) = "DX"
        ar(439) = "TT"
        ar(440) = "2C"
        ar(441) = "7Y"
        ar(442) = "ZZ"
        ar(443) = "Y5"
        ar(444) = "SB"
        ar(445) = "R6"
        ar(446) = "4X"
        ar(447) = "N5"
        ar(448) = "VP"
        ar(449) = "O8"
        ar(450) = "T5"
        ar(451) = "Y9"
        ar(452) = "J0"
        ar(453) = "LU"
        ar(454) = "7Q"
        ar(455) = "V0"
        ar(456) = "KV"
        ar(457) = "KW"
        ar(458) = "GP"
        ar(459) = "X1"
        ar(460) = "Z0"
        ar(461) = "E2"
        ar(462) = "6W"
        ar(463) = "P0"
        ar(464) = "J6"
        ar(465) = "L2"
        ar(466) = "OU"
        ar(467) = "QA"
        ar(468) = "NI"
        ar(469) = "IF"
        ar(470) = "NS"
        ar(471) = "FT"
        ar(472) = "3V"
        ar(473) = "RJ"
        ar(474) = "ZF"
        ar(475) = "NL"
        ar(476) = "U2"
        ar(477) = "T7"
        ar(478) = "PN"
        ar(479) = "CD"
        ar(480) = "H2"
        ar(481) = "5L"
        ar(482) = "44"
        ar(483) = "O6"
        ar(484) = "X7"
        ar(485) = "NZ"
        ar(486) = "97"
        ar(487) = "ND"
        ar(488) = "PV"
        ar(489) = "95"
        ar(490) = "X0"
        ar(491) = "TU"
        ar(492) = "5C"
        ar(493) = "BU"
        ar(494) = "99"
        ar(495) = "QX"
        ar(496) = "NK"
        ar(497) = "A6"
        ar(498) = "SL"
        ar(499) = "41"



        Dim r As Integer

        Randomize()
        r = Int(Rnd() * 10)

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As Integer
        sR = ""
        If cText = "" Then
            msEncryptRandom3 = ""
            Exit Function
        End If

        nl = Len(cText)
        Dim p As String
        Dim k As Integer
        k = 0

        l = Asc(r)

        For i = 1 To nl
            k = k + 1
            If k > 13 Then k = 0
            p = Mid(cText, i, 1)
            aski = Asc(p) + k + r
            l = l + aski
            sR = sR & ar(aski)
        Next

        Dim m201 As Integer
        m201 = l Mod 201

        sR = ar(m201) & ar(r) & sR

        msEncryptRandom3 = sR


    End Function

    Public Function msDecryptRandom3(ByVal cText As String) As String

        Dim ar(500) As String


        ar(0) = "35"
        ar(1) = "VI"
        ar(2) = "GJ"
        ar(3) = "2L"
        ar(4) = "KM"
        ar(5) = "MZ"
        ar(6) = "PC"
        ar(7) = "GO"
        ar(8) = "GE"
        ar(9) = "53"
        ar(10) = "TF"
        ar(11) = "EV"
        ar(12) = "68"
        ar(13) = "4D"
        ar(14) = "CX"
        ar(15) = "81"
        ar(16) = "7L"
        ar(17) = "ZK"
        ar(18) = "SM"
        ar(19) = "RO"
        ar(20) = "S2"
        ar(21) = "VN"
        ar(22) = "6V"
        ar(23) = "SY"
        ar(24) = "LK"
        ar(25) = "Y4"
        ar(26) = "HV"
        ar(27) = "VK"
        ar(28) = "98"
        ar(29) = "AN"
        ar(30) = "LG"
        ar(31) = "XS"
        ar(32) = "UX"
        ar(33) = "TR"
        ar(34) = "G3"
        ar(35) = "VO"
        ar(36) = "OA"
        ar(37) = "2A"
        ar(38) = "YD"
        ar(39) = "78"
        ar(40) = "E3"
        ar(41) = "QL"
        ar(42) = "XM"
        ar(43) = "79"
        ar(44) = "PX"
        ar(45) = "RB"
        ar(46) = "DK"
        ar(47) = "U7"
        ar(48) = "DM"
        ar(49) = "OR"
        ar(50) = "HE"
        ar(51) = "Q3"
        ar(52) = "72"
        ar(53) = "NF"
        ar(54) = "3C"
        ar(55) = "P9"
        ar(56) = "PS"
        ar(57) = "8A"
        ar(58) = "TV"
        ar(59) = "7V"
        ar(60) = "XW"
        ar(61) = "4R"
        ar(62) = "NQ"
        ar(63) = "E6"
        ar(64) = "M0"
        ar(65) = "AR"
        ar(66) = "ZO"
        ar(67) = "6X"
        ar(68) = "YM"
        ar(69) = "6M"
        ar(70) = "XH"
        ar(71) = "L0"
        ar(72) = "5D"
        ar(73) = "D1"
        ar(74) = "KY"
        ar(75) = "OM"
        ar(76) = "VJ"
        ar(77) = "V2"
        ar(78) = "UD"
        ar(79) = "6F"
        ar(80) = "TP"
        ar(81) = "9Y"
        ar(82) = "FY"
        ar(83) = "X8"
        ar(84) = "45"
        ar(85) = "2F"
        ar(86) = "TJ"
        ar(87) = "ED"
        ar(88) = "T8"
        ar(89) = "VR"
        ar(90) = "OI"
        ar(91) = "P6"
        ar(92) = "V4"
        ar(93) = "YZ"
        ar(94) = "O1"
        ar(95) = "T9"
        ar(96) = "D7"
        ar(97) = "EJ"
        ar(98) = "WH"
        ar(99) = "BM"
        ar(100) = "9P"
        ar(101) = "EW"
        ar(102) = "80"
        ar(103) = "7D"
        ar(104) = "2V"
        ar(105) = "7H"
        ar(106) = "83"
        ar(107) = "2T"
        ar(108) = "TE"
        ar(109) = "9Z"
        ar(110) = "BD"
        ar(111) = "T3"
        ar(112) = "T4"
        ar(113) = "4Y"
        ar(114) = "VT"
        ar(115) = "WU"
        ar(116) = "4B"
        ar(117) = "IN"
        ar(118) = "AU"
        ar(119) = "7U"
        ar(120) = "B5"
        ar(121) = "JH"
        ar(122) = "Z9"
        ar(123) = "D3"
        ar(124) = "4T"
        ar(125) = "MG"
        ar(126) = "EY"
        ar(127) = "8Y"
        ar(128) = "VH"
        ar(129) = "XR"
        ar(130) = "IO"
        ar(131) = "M2"
        ar(132) = "E8"
        ar(133) = "4S"
        ar(134) = "XX"
        ar(135) = "3X"
        ar(136) = "AZ"
        ar(137) = "MT"
        ar(138) = "6P"
        ar(139) = "T0"
        ar(140) = "GN"
        ar(141) = "YJ"
        ar(142) = "K6"
        ar(143) = "R8"
        ar(144) = "PK"
        ar(145) = "WM"
        ar(146) = "A7"
        ar(147) = "20"
        ar(148) = "32"
        ar(149) = "9U"
        ar(150) = "AT"
        ar(151) = "ZB"
        ar(152) = "7B"
        ar(153) = "ZG"
        ar(154) = "A8"
        ar(155) = "YT"
        ar(156) = "FW"
        ar(157) = "8S"
        ar(158) = "I3"
        ar(159) = "UN"
        ar(160) = "7I"
        ar(161) = "Q5"
        ar(162) = "KP"
        ar(163) = "Y1"
        ar(164) = "BT"
        ar(165) = "OS"
        ar(166) = "BK"
        ar(167) = "4K"
        ar(168) = "SG"
        ar(169) = "SF"
        ar(170) = "RC"
        ar(171) = "R5"
        ar(172) = "NO"
        ar(173) = "PG"
        ar(174) = "P4"
        ar(175) = "CI"
        ar(176) = "3U"
        ar(177) = "BX"
        ar(178) = "VY"
        ar(179) = "YH"
        ar(180) = "59"
        ar(181) = "7E"
        ar(182) = "6Y"
        ar(183) = "FC"
        ar(184) = "LB"
        ar(185) = "2Z"
        ar(186) = "PQ"
        ar(187) = "4U"
        ar(188) = "2Q"
        ar(189) = "G6"
        ar(190) = "4A"
        ar(191) = "23"
        ar(192) = "HC"
        ar(193) = "UE"
        ar(194) = "24"
        ar(195) = "F0"
        ar(196) = "50"
        ar(197) = "37"
        ar(198) = "A3"
        ar(199) = "JT"
        ar(200) = "FA"
        ar(201) = "3I"
        ar(202) = "XV"
        ar(203) = "I1"
        ar(204) = "W0"
        ar(205) = "ME"
        ar(206) = "WX"
        ar(207) = "AO"
        ar(208) = "X5"
        ar(209) = "8E"
        ar(210) = "E4"
        ar(211) = "B8"
        ar(212) = "M6"
        ar(213) = "BG"
        ar(214) = "RF"
        ar(215) = "S7"
        ar(216) = "Q4"
        ar(217) = "GI"
        ar(218) = "I6"
        ar(219) = "U1"
        ar(220) = "8H"
        ar(221) = "AE"
        ar(222) = "VC"
        ar(223) = "EO"
        ar(224) = "PU"
        ar(225) = "DG"
        ar(226) = "RD"
        ar(227) = "5A"
        ar(228) = "L9"
        ar(229) = "3N"
        ar(230) = "SS"
        ar(231) = "I2"
        ar(232) = "RS"
        ar(233) = "SV"
        ar(234) = "CM"
        ar(235) = "FK"
        ar(236) = "KL"
        ar(237) = "ZR"
        ar(238) = "QE"
        ar(239) = "H1"
        ar(240) = "MH"
        ar(241) = "Z6"
        ar(242) = "ZD"
        ar(243) = "X9"
        ar(244) = "XZ"
        ar(245) = "6D"
        ar(246) = "NR"
        ar(247) = "9C"
        ar(248) = "A0"
        ar(249) = "JR"
        ar(250) = "5J"
        ar(251) = "5K"
        ar(252) = "L8"
        ar(253) = "3G"
        ar(254) = "8G"
        ar(255) = "AG"
        ar(256) = "WC"
        ar(257) = "HO"
        ar(258) = "N3"
        ar(259) = "84"
        ar(260) = "6B"
        ar(261) = "VL"
        ar(262) = "EK"
        ar(263) = "KT"
        ar(264) = "M1"
        ar(265) = "Z5"
        ar(266) = "GA"
        ar(267) = "AD"
        ar(268) = "O2"
        ar(269) = "C2"
        ar(270) = "XJ"
        ar(271) = "J4"
        ar(272) = "9L"
        ar(273) = "93"
        ar(274) = "UQ"
        ar(275) = "4Z"
        ar(276) = "K0"
        ar(277) = "46"
        ar(278) = "7O"
        ar(279) = "ZP"
        ar(280) = "CA"
        ar(281) = "IX"
        ar(282) = "OK"
        ar(283) = "58"
        ar(284) = "DA"
        ar(285) = "RX"
        ar(286) = "EX"
        ar(287) = "RN"
        ar(288) = "B1"
        ar(289) = "2H"
        ar(290) = "51"
        ar(291) = "QF"
        ar(292) = "S0"
        ar(293) = "F7"
        ar(294) = "GV"
        ar(295) = "QK"
        ar(296) = "UR"
        ar(297) = "LT"
        ar(298) = "4C"
        ar(299) = "WS"
        ar(300) = "9E"
        ar(301) = "TH"
        ar(302) = "ZL"
        ar(303) = "EZ"
        ar(304) = "U3"
        ar(305) = "QC"
        ar(306) = "IA"
        ar(307) = "5Z"
        ar(308) = "CO"
        ar(309) = "88"
        ar(310) = "T1"
        ar(311) = "MQ"
        ar(312) = "AM"
        ar(313) = "BL"
        ar(314) = "RK"
        ar(315) = "L4"
        ar(316) = "49"
        ar(317) = "6L"
        ar(318) = "GQ"
        ar(319) = "CB"
        ar(320) = "4F"
        ar(321) = "8O"
        ar(322) = "UK"
        ar(323) = "6J"
        ar(324) = "XB"
        ar(325) = "KB"
        ar(326) = "FD"
        ar(327) = "9F"
        ar(328) = "EE"
        ar(329) = "WN"
        ar(330) = "OQ"
        ar(331) = "AW"
        ar(332) = "TB"
        ar(333) = "W5"
        ar(334) = "AF"
        ar(335) = "J2"
        ar(336) = "UO"
        ar(337) = "MW"
        ar(338) = "5F"
        ar(339) = "LI"
        ar(340) = "AA"
        ar(341) = "JC"
        ar(342) = "EM"
        ar(343) = "TO"
        ar(344) = "SP"
        ar(345) = "J3"
        ar(346) = "BW"
        ar(347) = "FO"
        ar(348) = "CH"
        ar(349) = "DS"
        ar(350) = "NE"
        ar(351) = "U8"
        ar(352) = "CZ"
        ar(353) = "D6"
        ar(354) = "4I"
        ar(355) = "O3"
        ar(356) = "RY"
        ar(357) = "P2"
        ar(358) = "FN"
        ar(359) = "PE"
        ar(360) = "XI"
        ar(361) = "N4"
        ar(362) = "GF"
        ar(363) = "I8"
        ar(364) = "6Z"
        ar(365) = "6R"
        ar(366) = "CS"
        ar(367) = "CT"
        ar(368) = "JN"
        ar(369) = "Y7"
        ar(370) = "7F"
        ar(371) = "G0"
        ar(372) = "62"
        ar(373) = "M9"
        ar(374) = "ZQ"
        ar(375) = "JZ"
        ar(376) = "IU"
        ar(377) = "75"
        ar(378) = "E0"
        ar(379) = "NN"
        ar(380) = "GT"
        ar(381) = "UZ"
        ar(382) = "8M"
        ar(383) = "71"
        ar(384) = "3H"
        ar(385) = "AK"
        ar(386) = "QV"
        ar(387) = "H7"
        ar(388) = "76"
        ar(389) = "XU"
        ar(390) = "FR"
        ar(391) = "H3"
        ar(392) = "8F"
        ar(393) = "HI"
        ar(394) = "F8"
        ar(395) = "36"
        ar(396) = "YE"
        ar(397) = "MR"
        ar(398) = "V8"
        ar(399) = "JO"
        ar(400) = "XL"
        ar(401) = "GW"
        ar(402) = "3J"
        ar(403) = "CU"
        ar(404) = "2O"
        ar(405) = "R0"
        ar(406) = "9R"
        ar(407) = "DH"
        ar(408) = "TW"
        ar(409) = "JM"
        ar(410) = "E5"
        ar(411) = "LR"
        ar(412) = "FP"
        ar(413) = "D0"
        ar(414) = "Q8"
        ar(415) = "VU"
        ar(416) = "CC"
        ar(417) = "QU"
        ar(418) = "GL"
        ar(419) = "KA"
        ar(420) = "IV"
        ar(421) = "XY"
        ar(422) = "DN"
        ar(423) = "JG"
        ar(424) = "9G"
        ar(425) = "GG"
        ar(426) = "K2"
        ar(427) = "AP"
        ar(428) = "V1"
        ar(429) = "8J"
        ar(430) = "F4"
        ar(431) = "CQ"
        ar(432) = "K5"
        ar(433) = "EA"
        ar(434) = "NW"
        ar(435) = "RW"
        ar(436) = "OE"
        ar(437) = "MU"
        ar(438) = "DX"
        ar(439) = "TT"
        ar(440) = "2C"
        ar(441) = "7Y"
        ar(442) = "ZZ"
        ar(443) = "Y5"
        ar(444) = "SB"
        ar(445) = "R6"
        ar(446) = "4X"
        ar(447) = "N5"
        ar(448) = "VP"
        ar(449) = "O8"
        ar(450) = "T5"
        ar(451) = "Y9"
        ar(452) = "J0"
        ar(453) = "LU"
        ar(454) = "7Q"
        ar(455) = "V0"
        ar(456) = "KV"
        ar(457) = "KW"
        ar(458) = "GP"
        ar(459) = "X1"
        ar(460) = "Z0"
        ar(461) = "E2"
        ar(462) = "6W"
        ar(463) = "P0"
        ar(464) = "J6"
        ar(465) = "L2"
        ar(466) = "OU"
        ar(467) = "QA"
        ar(468) = "NI"
        ar(469) = "IF"
        ar(470) = "NS"
        ar(471) = "FT"
        ar(472) = "3V"
        ar(473) = "RJ"
        ar(474) = "ZF"
        ar(475) = "NL"
        ar(476) = "U2"
        ar(477) = "T7"
        ar(478) = "PN"
        ar(479) = "CD"
        ar(480) = "H2"
        ar(481) = "5L"
        ar(482) = "44"
        ar(483) = "O6"
        ar(484) = "X7"
        ar(485) = "NZ"
        ar(486) = "97"
        ar(487) = "ND"
        ar(488) = "PV"
        ar(489) = "95"
        ar(490) = "X0"
        ar(491) = "TU"
        ar(492) = "5C"
        ar(493) = "BU"
        ar(494) = "99"
        ar(495) = "QX"
        ar(496) = "NK"
        ar(497) = "A6"
        ar(498) = "SL"
        ar(499) = "41"


        Dim r As Integer
        Dim rChar As String

        Dim nl As Integer
        Dim i As Integer
        Dim l As Long
        Dim sR As String
        Dim aski As String
        Dim m201 As Integer
        Dim mChar As String

        If cText = "" Then
            msDecryptRandom3 = ""
            Exit Function
        End If


        mChar = Mid(cText, 1, 2)
        For i = 0 To 255
            If ar(i) = mChar Then
                m201 = i
                Exit For
            End If
        Next

        rChar = Mid(cText, 3, 2)
        For i = 0 To 255
            If ar(i) = rChar Then
                r = i
                Exit For
            End If
        Next

        l = Asc(r)
        nl = Len(cText)

        Dim j As Integer
        Dim k As Integer
        k = 0
        sR = ""
        For i = 5 To nl Step 2
            k = k + 1
            If k > 13 Then k = 0
            aski = Mid(cText, i, 2)
            For j = 0 To 255
                If ar(j) = aski Then
                    l = l + j
                    On Error Resume Next
                    sR = sR & Chr(j - k - r)

                    Exit For
                End If
            Next
        Next

        If m201 = l Mod 201 Then
            sR = "1" & sR
        Else
            sR = "0" & sR
        End If

        msDecryptRandom3 = sR


    End Function

    Public Function msEncryptNumDt(ByVal sNum As String) As String

        Dim ar(1010) As String

        ar(0) = "L2"
        ar(1) = "GX"
        ar(2) = "IG"
        ar(3) = "YK"
        ar(4) = "XH"
        ar(5) = "YX"
        ar(6) = "86"
        ar(7) = "C5"
        ar(8) = "SG"
        ar(9) = "YF"
        ar(10) = "PM"
        ar(11) = "CO"
        ar(12) = "ZH"
        ar(13) = "58"
        ar(14) = "BX"
        ar(15) = "OZ"
        ar(16) = "AH"
        ar(17) = "WF"
        ar(18) = "78"
        ar(19) = "8J"
        ar(20) = "H4"
        ar(21) = "PB"
        ar(22) = "TS"
        ar(23) = "5J"
        ar(24) = "Z8"
        ar(25) = "A9"
        ar(26) = "7D"
        ar(27) = "ZC"
        ar(28) = "D9"
        ar(29) = "RB"
        ar(30) = "NP"
        ar(31) = "XK"
        ar(32) = "FC"
        ar(33) = "K8"
        ar(34) = "EK"
        ar(35) = "96"
        ar(36) = "GT"
        ar(37) = "DL"
        ar(38) = "XC"
        ar(39) = "XI"
        ar(40) = "N4"
        ar(41) = "JC"
        ar(42) = "L3"
        ar(43) = "EX"
        ar(44) = "PE"
        ar(45) = "PF"
        ar(46) = "WW"
        ar(47) = "2W"
        ar(48) = "TZ"
        ar(49) = "V6"
        ar(50) = "IY"
        ar(51) = "HF"
        ar(52) = "MB"
        ar(53) = "OS"
        ar(54) = "E5"
        ar(55) = "S9"
        ar(56) = "ED"
        ar(57) = "39"
        ar(58) = "HT"
        ar(59) = "7W"
        ar(60) = "QH"
        ar(61) = "RL"
        ar(62) = "ZL"
        ar(63) = "ZT"
        ar(64) = "N8"
        ar(65) = "SN"
        ar(66) = "F3"
        ar(67) = "HH"
        ar(68) = "OI"
        ar(69) = "YZ"
        ar(70) = "26"
        ar(71) = "VJ"
        ar(72) = "OB"
        ar(73) = "Y7"
        ar(74) = "HE"
        ar(75) = "QV"
        ar(76) = "ZN"
        ar(77) = "67"
        ar(78) = "4U"
        ar(79) = "4R"
        ar(80) = "TU"
        ar(81) = "Y9"
        ar(82) = "QP"
        ar(83) = "EE"
        ar(84) = "SJ"
        ar(85) = "G9"
        ar(86) = "2S"
        ar(87) = "NF"
        ar(88) = "42"
        ar(89) = "XV"
        ar(90) = "8F"
        ar(91) = "KM"
        ar(92) = "9L"
        ar(93) = "AE"
        ar(94) = "ON"
        ar(95) = "5Y"
        ar(96) = "DY"
        ar(97) = "TN"
        ar(98) = "3Q"
        ar(99) = "7N"
        ar(100) = "IC"
        ar(101) = "AV"
        ar(102) = "SL"
        ar(103) = "5S"
        ar(104) = "4P"
        ar(105) = "VK"
        ar(106) = "8T"
        ar(107) = "BY"
        ar(108) = "8Y"
        ar(109) = "65"
        ar(110) = "QK"
        ar(111) = "8C"
        ar(112) = "3D"
        ar(113) = "3N"
        ar(114) = "DM"
        ar(115) = "IL"
        ar(116) = "OO"
        ar(117) = "HA"
        ar(118) = "R4"
        ar(119) = "WR"
        ar(120) = "X7"
        ar(121) = "O6"
        ar(122) = "ZB"
        ar(123) = "MM"
        ar(124) = "FA"
        ar(125) = "DU"
        ar(126) = "7Y"
        ar(127) = "WX"
        ar(128) = "ZR"
        ar(129) = "A5"
        ar(130) = "34"
        ar(131) = "3M"
        ar(132) = "2T"
        ar(133) = "MU"
        ar(134) = "DJ"
        ar(135) = "DP"
        ar(136) = "9V"
        ar(137) = "K3"
        ar(138) = "2C"
        ar(139) = "S6"
        ar(140) = "AP"
        ar(141) = "LK"
        ar(142) = "DK"
        ar(143) = "LD"
        ar(144) = "6S"
        ar(145) = "UN"
        ar(146) = "EM"
        ar(147) = "7G"
        ar(148) = "2X"
        ar(149) = "Y6"
        ar(150) = "IR"
        ar(151) = "XA"
        ar(152) = "F6"
        ar(153) = "T2"
        ar(154) = "6W"
        ar(155) = "CL"
        ar(156) = "98"
        ar(157) = "5U"
        ar(158) = "OH"
        ar(159) = "3S"
        ar(160) = "WS"
        ar(161) = "6L"
        ar(162) = "MY"
        ar(163) = "I6"
        ar(164) = "4S"
        ar(165) = "LZ"
        ar(166) = "ND"
        ar(167) = "A4"
        ar(168) = "VD"
        ar(169) = "HD"
        ar(170) = "QU"
        ar(171) = "OJ"
        ar(172) = "DT"
        ar(173) = "D5"
        ar(174) = "4L"
        ar(175) = "X2"
        ar(176) = "QX"
        ar(177) = "BV"
        ar(178) = "BM"
        ar(179) = "45"
        ar(180) = "WC"
        ar(181) = "KQ"
        ar(182) = "KC"
        ar(183) = "L4"
        ar(184) = "UZ"
        ar(185) = "SB"
        ar(186) = "VC"
        ar(187) = "6P"
        ar(188) = "73"
        ar(189) = "HU"
        ar(190) = "JK"
        ar(191) = "VI"
        ar(192) = "EJ"
        ar(193) = "SX"
        ar(194) = "K9"
        ar(195) = "3Z"
        ar(196) = "7J"
        ar(197) = "7S"
        ar(198) = "4Y"
        ar(199) = "QF"
        ar(200) = "YS"
        ar(201) = "8E"
        ar(202) = "37"
        ar(203) = "LB"
        ar(204) = "GJ"
        ar(205) = "Q2"
        ar(206) = "MX"
        ar(207) = "MG"
        ar(208) = "5A"
        ar(209) = "ET"
        ar(210) = "XY"
        ar(211) = "36"
        ar(212) = "4Q"
        ar(213) = "FB"
        ar(214) = "N6"
        ar(215) = "BW"
        ar(216) = "DO"
        ar(217) = "TE"
        ar(218) = "Z3"
        ar(219) = "33"
        ar(220) = "SA"
        ar(221) = "OV"
        ar(222) = "A2"
        ar(223) = "AZ"
        ar(224) = "9X"
        ar(225) = "LS"
        ar(226) = "69"
        ar(227) = "CD"
        ar(228) = "EB"
        ar(229) = "9W"
        ar(230) = "LC"
        ar(231) = "A7"
        ar(232) = "7T"
        ar(233) = "FH"
        ar(234) = "DA"
        ar(235) = "O7"
        ar(236) = "52"
        ar(237) = "F2"
        ar(238) = "23"
        ar(239) = "7V"
        ar(240) = "PT"
        ar(241) = "MZ"
        ar(242) = "W2"
        ar(243) = "R3"
        ar(244) = "TH"
        ar(245) = "5E"
        ar(246) = "8Q"
        ar(247) = "JA"
        ar(248) = "NE"
        ar(249) = "7U"
        ar(250) = "DX"
        ar(251) = "FP"
        ar(252) = "RI"
        ar(253) = "LW"
        ar(254) = "9H"
        ar(255) = "E8"
        ar(256) = "V2"
        ar(257) = "N9"
        ar(258) = "AR"
        ar(259) = "N2"
        ar(260) = "84"
        ar(261) = "MO"
        ar(262) = "EL"
        ar(263) = "YG"
        ar(264) = "ZW"
        ar(265) = "VA"
        ar(266) = "CT"
        ar(267) = "RG"
        ar(268) = "8N"
        ar(269) = "NQ"
        ar(270) = "OG"
        ar(271) = "OA"
        ar(272) = "9G"
        ar(273) = "JR"
        ar(274) = "72"
        ar(275) = "PQ"
        ar(276) = "2V"
        ar(277) = "6U"
        ar(278) = "GO"
        ar(279) = "9A"
        ar(280) = "KX"
        ar(281) = "RV"
        ar(282) = "LT"
        ar(283) = "QT"
        ar(284) = "7Z"
        ar(285) = "8G"
        ar(286) = "M8"
        ar(287) = "27"
        ar(288) = "XF"
        ar(289) = "XD"
        ar(290) = "H7"
        ar(291) = "FI"
        ar(292) = "FM"
        ar(293) = "E2"
        ar(294) = "P5"
        ar(295) = "3J"
        ar(296) = "BE"
        ar(297) = "6Q"
        ar(298) = "KK"
        ar(299) = "ER"
        ar(300) = "9S"
        ar(301) = "TQ"
        ar(302) = "2Q"
        ar(303) = "NB"
        ar(304) = "F9"
        ar(305) = "X4"
        ar(306) = "AL"
        ar(307) = "UG"
        ar(308) = "LU"
        ar(309) = "R7"
        ar(310) = "CN"
        ar(311) = "N7"
        ar(312) = "GB"
        ar(313) = "F5"
        ar(314) = "J7"
        ar(315) = "9U"
        ar(316) = "IO"
        ar(317) = "QW"
        ar(318) = "4V"
        ar(319) = "2R"
        ar(320) = "K6"
        ar(321) = "OP"
        ar(322) = "N5"
        ar(323) = "7C"
        ar(324) = "WZ"
        ar(325) = "3K"
        ar(326) = "J2"
        ar(327) = "KW"
        ar(328) = "Y8"
        ar(329) = "LY"
        ar(330) = "JZ"
        ar(331) = "7P"
        ar(332) = "T5"
        ar(333) = "8U"
        ar(334) = "XS"
        ar(335) = "Q3"
        ar(336) = "X8"
        ar(337) = "FN"
        ar(338) = "4I"
        ar(339) = "Q8"
        ar(340) = "R9"
        ar(341) = "TG"
        ar(342) = "R2"
        ar(343) = "W9"
        ar(344) = "ZZ"
        ar(345) = "2B"
        ar(346) = "2K"
        ar(347) = "DE"
        ar(348) = "LE"
        ar(349) = "WP"
        ar(350) = "9Y"
        ar(351) = "MQ"
        ar(352) = "YO"
        ar(353) = "WO"
        ar(354) = "QQ"
        ar(355) = "I4"
        ar(356) = "6H"
        ar(357) = "44"
        ar(358) = "SD"
        ar(359) = "NS"
        ar(360) = "AY"
        ar(361) = "CQ"
        ar(362) = "AK"
        ar(363) = "QS"
        ar(364) = "TF"
        ar(365) = "GK"
        ar(366) = "HJ"
        ar(367) = "KI"
        ar(368) = "3A"
        ar(369) = "ES"
        ar(370) = "DW"
        ar(371) = "UP"
        ar(372) = "J9"
        ar(373) = "FU"
        ar(374) = "9D"
        ar(375) = "3B"
        ar(376) = "LV"
        ar(377) = "IH"
        ar(378) = "R5"
        ar(379) = "NV"
        ar(380) = "JG"
        ar(381) = "3U"
        ar(382) = "DS"
        ar(383) = "35"
        ar(384) = "SZ"
        ar(385) = "9O"
        ar(386) = "QI"
        ar(387) = "HR"
        ar(388) = "AU"
        ar(389) = "4A"
        ar(390) = "P9"
        ar(391) = "RE"
        ar(392) = "UY"
        ar(393) = "S8"
        ar(394) = "4D"
        ar(395) = "TP"
        ar(396) = "6Z"
        ar(397) = "8V"
        ar(398) = "2M"
        ar(399) = "US"
        ar(400) = "4N"
        ar(401) = "5K"
        ar(402) = "GA"
        ar(403) = "FW"
        ar(404) = "J6"
        ar(405) = "HB"
        ar(406) = "DN"
        ar(407) = "HZ"
        ar(408) = "T4"
        ar(409) = "ZE"
        ar(410) = "OD"
        ar(411) = "Q7"
        ar(412) = "NL"
        ar(413) = "FE"
        ar(414) = "4F"
        ar(415) = "RS"
        ar(416) = "M2"
        ar(417) = "85"
        ar(418) = "XM"
        ar(419) = "OR"
        ar(420) = "JO"
        ar(421) = "EV"
        ar(422) = "WG"
        ar(423) = "CU"
        ar(424) = "L6"
        ar(425) = "PI"
        ar(426) = "M7"
        ar(427) = "NR"
        ar(428) = "NA"
        ar(429) = "CF"
        ar(430) = "3L"
        ar(431) = "2F"
        ar(432) = "JD"
        ar(433) = "RR"
        ar(434) = "VS"
        ar(435) = "7K"
        ar(436) = "IK"
        ar(437) = "4B"
        ar(438) = "MW"
        ar(439) = "9P"
        ar(440) = "4E"
        ar(441) = "V7"
        ar(442) = "4T"
        ar(443) = "ZG"
        ar(444) = "EH"
        ar(445) = "6R"
        ar(446) = "UT"
        ar(447) = "VY"
        ar(448) = "54"
        ar(449) = "MS"
        ar(450) = "KG"
        ar(451) = "U8"
        ar(452) = "PN"
        ar(453) = "LO"
        ar(454) = "UM"
        ar(455) = "L9"
        ar(456) = "UH"
        ar(457) = "7B"
        ar(458) = "SM"
        ar(459) = "8O"
        ar(460) = "HY"
        ar(461) = "62"
        ar(462) = "SY"
        ar(463) = "97"
        ar(464) = "NN"
        ar(465) = "VF"
        ar(466) = "2O"
        ar(467) = "28"
        ar(468) = "D8"
        ar(469) = "TO"
        ar(470) = "U2"
        ar(471) = "SR"
        ar(472) = "G3"
        ar(473) = "P2"
        ar(474) = "TB"
        ar(475) = "7R"
        ar(476) = "WJ"
        ar(477) = "93"
        ar(478) = "5P"
        ar(479) = "Y5"
        ar(480) = "IB"
        ar(481) = "9E"
        ar(482) = "L7"
        ar(483) = "H6"
        ar(484) = "4Z"
        ar(485) = "KD"
        ar(486) = "2Y"
        ar(487) = "5H"
        ar(488) = "HX"
        ar(489) = "PD"
        ar(490) = "JW"
        ar(491) = "AN"
        ar(492) = "6T"
        ar(493) = "V9"
        ar(494) = "2E"
        ar(495) = "S2"
        ar(496) = "QN"
        ar(497) = "BL"
        ar(498) = "8K"
        ar(499) = "6K"
        ar(500) = "ZS"
        ar(501) = "YM"
        ar(502) = "Y2"
        ar(503) = "3C"
        ar(504) = "ZO"
        ar(505) = "9Z"
        ar(506) = "RM"
        ar(507) = "E3"
        ar(508) = "IF"
        ar(509) = "WA"
        ar(510) = "HG"
        ar(511) = "6B"
        ar(512) = "H8"
        ar(513) = "IW"
        ar(514) = "RW"
        ar(515) = "U9"
        ar(516) = "EU"
        ar(517) = "7F"
        ar(518) = "RN"
        ar(519) = "T6"
        ar(520) = "T7"
        ar(521) = "NI"
        ar(522) = "6I"
        ar(523) = "MC"
        ar(524) = "V8"
        ar(525) = "2H"
        ar(526) = "FL"
        ar(527) = "TM"
        ar(528) = "HN"
        ar(529) = "Y4"
        ar(530) = "W6"
        ar(531) = "SC"
        ar(532) = "UO"
        ar(533) = "QJ"
        ar(534) = "E9"
        ar(535) = "PO"
        ar(536) = "WI"
        ar(537) = "RQ"
        ar(538) = "GV"
        ar(539) = "EN"
        ar(540) = "FJ"
        ar(541) = "JB"
        ar(542) = "EG"
        ar(543) = "YH"
        ar(544) = "4C"
        ar(545) = "GI"
        ar(546) = "CC"
        ar(547) = "SH"
        ar(548) = "VQ"
        ar(549) = "29"
        ar(550) = "D3"
        ar(551) = "MV"
        ar(552) = "46"
        ar(553) = "JJ"
        ar(554) = "AQ"
        ar(555) = "CK"
        ar(556) = "8W"
        ar(557) = "RY"
        ar(558) = "KN"
        ar(559) = "BN"
        ar(560) = "53"
        ar(561) = "HP"
        ar(562) = "BD"
        ar(563) = "XL"
        ar(564) = "XJ"
        ar(565) = "EO"
        ar(566) = "FR"
        ar(567) = "Z2"
        ar(568) = "EQ"
        ar(569) = "CM"
        ar(570) = "MJ"
        ar(571) = "AT"
        ar(572) = "6X"
        ar(573) = "QR"
        ar(574) = "9T"
        ar(575) = "C7"
        ar(576) = "VU"
        ar(577) = "XU"
        ar(578) = "UE"
        ar(579) = "CA"
        ar(580) = "YB"
        ar(581) = "G7"
        ar(582) = "J4"
        ar(583) = "HV"
        ar(584) = "D2"
        ar(585) = "RA"
        ar(586) = "HO"
        ar(587) = "38"
        ar(588) = "8L"
        ar(589) = "GF"
        ar(590) = "NC"
        ar(591) = "YU"
        ar(592) = "CI"
        ar(593) = "JM"
        ar(594) = "KS"
        ar(595) = "XB"
        ar(596) = "J5"
        ar(597) = "T9"
        ar(598) = "ID"
        ar(599) = "O2"
        ar(600) = "ZD"
        ar(601) = "3I"
        ar(602) = "5V"
        ar(603) = "SK"
        ar(604) = "MA"
        ar(605) = "2N"
        ar(606) = "7H"
        ar(607) = "QG"
        ar(608) = "BC"
        ar(609) = "O5"
        ar(610) = "7X"
        ar(611) = "55"
        ar(612) = "V5"
        ar(613) = "KJ"
        ar(614) = "NT"
        ar(615) = "CE"
        ar(616) = "VN"
        ar(617) = "KE"
        ar(618) = "LA"
        ar(619) = "8A"
        ar(620) = "GP"
        ar(621) = "9I"
        ar(622) = "PY"
        ar(623) = "JY"
        ar(624) = "R8"
        ar(625) = "GY"
        ar(626) = "KT"
        ar(627) = "56"
        ar(628) = "I3"
        ar(629) = "3F"
        ar(630) = "EW"
        ar(631) = "8D"
        ar(632) = "QM"
        ar(633) = "JV"
        ar(634) = "9K"
        ar(635) = "CX"
        ar(636) = "UQ"
        ar(637) = "ZX"
        ar(638) = "6J"
        ar(639) = "TY"
        ar(640) = "4H"
        ar(641) = "3Y"
        ar(642) = "3R"
        ar(643) = "QD"
        ar(644) = "YT"
        ar(645) = "64"
        ar(646) = "ZY"
        ar(647) = "83"
        ar(648) = "EC"
        ar(649) = "JL"
        ar(650) = "9F"
        ar(651) = "XG"
        ar(652) = "G8"
        ar(653) = "8X"
        ar(654) = "XP"
        ar(655) = "DV"
        ar(656) = "JF"
        ar(657) = "LH"
        ar(658) = "MN"
        ar(659) = "ZU"
        ar(660) = "JP"
        ar(661) = "RJ"
        ar(662) = "59"
        ar(663) = "JH"
        ar(664) = "CY"
        ar(665) = "AD"
        ar(666) = "HK"
        ar(667) = "W3"
        ar(668) = "O9"
        ar(669) = "MT"
        ar(670) = "ZP"
        ar(671) = "FF"
        ar(672) = "NK"
        ar(673) = "BU"
        ar(674) = "QO"
        ar(675) = "YW"
        ar(676) = "BG"
        ar(677) = "9N"
        ar(678) = "FZ"
        ar(679) = "22"
        ar(680) = "PH"
        ar(681) = "IX"
        ar(682) = "XO"
        ar(683) = "8R"
        ar(684) = "JX"
        ar(685) = "TX"
        ar(686) = "5W"
        ar(687) = "JI"
        ar(688) = "XR"
        ar(689) = "M9"
        ar(690) = "SW"
        ar(691) = "Q9"
        ar(692) = "76"
        ar(693) = "5C"
        ar(694) = "S7"
        ar(695) = "BI"
        ar(696) = "F7"
        ar(697) = "FX"
        ar(698) = "RZ"
        ar(699) = "CB"
        ar(700) = "5D"
        ar(701) = "ZI"
        ar(702) = "DZ"
        ar(703) = "GG"
        ar(704) = "GU"
        ar(705) = "DC"
        ar(706) = "RP"
        ar(707) = "SF"
        ar(708) = "I9"
        ar(709) = "6G"
        ar(710) = "MI"
        ar(711) = "B2"
        ar(712) = "NZ"
        ar(713) = "EI"
        ar(714) = "GD"
        ar(715) = "XT"
        ar(716) = "Z4"
        ar(717) = "SO"
        ar(718) = "VO"
        ar(719) = "VV"
        ar(720) = "PG"
        ar(721) = "3W"
        ar(722) = "SU"
        ar(723) = "P4"
        ar(724) = "PA"
        ar(725) = "DG"
        ar(726) = "OK"
        ar(727) = "OW"
        ar(728) = "KB"
        ar(729) = "WD"
        ar(730) = "C2"
        ar(731) = "4M"
        ar(732) = "YC"
        ar(733) = "WM"
        ar(734) = "GZ"
        ar(735) = "IV"
        ar(736) = "QZ"
        ar(737) = "WE"
        ar(738) = "VZ"
        ar(739) = "GN"
        ar(740) = "K5"
        ar(741) = "VL"
        ar(742) = "V3"
        ar(743) = "H9"
        ar(744) = "II"
        ar(745) = "9Q"
        ar(746) = "BP"
        ar(747) = "RO"
        ar(748) = "K4"
        ar(749) = "AF"
        ar(750) = "ZA"
        ar(751) = "Q5"
        ar(752) = "WB"
        ar(753) = "UD"
        ar(754) = "XN"
        ar(755) = "I7"
        ar(756) = "OY"
        ar(757) = "OL"
        ar(758) = "RD"
        ar(759) = "8B"
        ar(760) = "FQ"
        ar(761) = "UV"
        ar(762) = "O8"
        ar(763) = "PZ"
        ar(764) = "IT"
        ar(765) = "U4"
        ar(766) = "GE"
        ar(767) = "5F"
        ar(768) = "PV"
        ar(769) = "YA"
        ar(770) = "CJ"
        ar(771) = "2J"
        ar(772) = "7L"
        ar(773) = "LP"
        ar(774) = "79"
        ar(775) = "CV"
        ar(776) = "LQ"
        ar(777) = "IP"
        ar(778) = "8S"
        ar(779) = "2I"
        ar(780) = "B6"
        ar(781) = "L8"
        ar(782) = "W7"
        ar(783) = "JQ"
        ar(784) = "UU"
        ar(785) = "PX"
        ar(786) = "32"
        ar(787) = "IU"
        ar(788) = "J8"
        ar(789) = "68"
        ar(790) = "AW"
        ar(791) = "49"
        ar(792) = "OE"
        ar(793) = "XQ"
        ar(794) = "OF"
        ar(795) = "XW"
        ar(796) = "CH"
        ar(797) = "A6"
        ar(798) = "IZ"
        ar(799) = "MD"
        ar(800) = "5G"
        ar(801) = "3X"
        ar(802) = "TD"
        ar(803) = "UF"
        ar(804) = "3V"
        ar(805) = "YI"
        ar(806) = "3G"
        ar(807) = "EZ"
        ar(808) = "G5"
        ar(809) = "LX"
        ar(810) = "94"
        ar(811) = "AO"
        ar(812) = "B5"
        ar(813) = "S5"
        ar(814) = "H2"
        ar(815) = "U5"
        ar(816) = "UW"
        ar(817) = "YQ"
        ar(818) = "N3"
        ar(819) = "3T"
        ar(820) = "UA"
        ar(821) = "J3"
        ar(822) = "P8"
        ar(823) = "YD"
        ar(824) = "LI"
        ar(825) = "ZQ"
        ar(826) = "LM"
        ar(827) = "OC"
        ar(828) = "PW"
        ar(829) = "2U"
        ar(830) = "B4"
        ar(831) = "M5"
        ar(832) = "AX"
        ar(833) = "C3"
        ar(834) = "WV"
        ar(835) = "AA"
        ar(836) = "NU"
        ar(837) = "CR"
        ar(838) = "U6"
        ar(839) = "8P"
        ar(840) = "FV"
        ar(841) = "BR"
        ar(842) = "5B"
        ar(843) = "PJ"
        ar(844) = "UB"
        ar(845) = "UC"
        ar(846) = "RT"
        ar(847) = "6E"
        ar(848) = "NO"
        ar(849) = "89"
        ar(850) = "7O"
        ar(851) = "PU"
        ar(852) = "LJ"
        ar(853) = "LL"
        ar(854) = "ZJ"
        ar(855) = "S3"
        ar(856) = "QC"
        ar(857) = "HM"
        ar(858) = "4G"
        ar(859) = "YL"
        ar(860) = "5L"
        ar(861) = "U7"
        ar(862) = "DD"
        ar(863) = "MP"
        ar(864) = "RC"
        ar(865) = "8Z"
        ar(866) = "VM"
        ar(867) = "SE"
        ar(868) = "P6"
        ar(869) = "ZK"
        ar(870) = "2L"
        ar(871) = "Z5"
        ar(872) = "FS"
        ar(873) = "74"
        ar(874) = "M6"
        ar(875) = "X3"
        ar(876) = "AS"
        ar(877) = "5M"
        ar(878) = "Q4"
        ar(879) = "NJ"
        ar(880) = "IA"
        ar(881) = "TC"
        ar(882) = "YE"
        ar(883) = "7M"
        ar(884) = "CG"
        ar(885) = "5N"
        ar(886) = "RF"
        ar(887) = "UK"
        ar(888) = "GQ"
        ar(889) = "G4"
        ar(890) = "TL"
        ar(891) = "2P"
        ar(892) = "5O"
        ar(893) = "VE"
        ar(894) = "MK"
        ar(895) = "KF"
        ar(896) = "ZM"
        ar(897) = "M4"
        ar(898) = "4W"
        ar(899) = "E7"
        ar(900) = "DF"
        ar(901) = "YN"
        ar(902) = "UX"
        ar(903) = "H5"
        ar(904) = "YJ"
        ar(905) = "CS"
        ar(906) = "KA"
        ar(907) = "VG"
        ar(908) = "FG"
        ar(909) = "SV"
        ar(910) = "C4"
        ar(911) = "TT"
        ar(912) = "XX"
        ar(913) = "MF"
        ar(914) = "SP"
        ar(915) = "4X"
        ar(916) = "SS"
        ar(917) = "EA"
        ar(918) = "E6"
        ar(919) = "9J"
        ar(920) = "EY"
        ar(921) = "TR"
        ar(922) = "LN"
        ar(923) = "3H"
        ar(924) = "T3"
        ar(925) = "M3"
        ar(926) = "WH"
        ar(927) = "CZ"
        ar(928) = "AG"
        ar(929) = "6O"
        ar(930) = "RX"
        ar(931) = "I2"
        ar(932) = "BT"
        ar(933) = "ML"
        ar(934) = "XE"
        ar(935) = "O3"
        ar(936) = "W5"
        ar(937) = "6V"
        ar(938) = "63"
        ar(939) = "LF"
        ar(940) = "BQ"
        ar(941) = "QA"
        ar(942) = "KY"
        ar(943) = "FY"
        ar(944) = "B3"
        ar(945) = "DI"
        ar(946) = "VR"
        ar(947) = "6M"
        ar(948) = "BA"
        ar(949) = "Z9"
        ar(950) = "EF"
        ar(951) = "FD"
        ar(952) = "BZ"
        ar(953) = "DR"
        ar(954) = "7E"
        ar(955) = "DB"
        ar(956) = "JN"
        ar(957) = "WL"
        ar(958) = "GM"
        ar(959) = "92"
        ar(960) = "QB"
        ar(961) = "G6"
        ar(962) = "FO"
        ar(963) = "47"
        ar(964) = "E4"
        ar(965) = "LG"
        ar(966) = "QY"
        ar(967) = "DQ"
        ar(968) = "5R"
        ar(969) = "R6"
        ar(970) = "NG"
        ar(971) = "OQ"
        ar(972) = "GH"
        ar(973) = "AI"
        ar(974) = "OT"
        ar(975) = "K2"
        ar(976) = "TV"
        ar(977) = "UR"
        ar(978) = "F4"
        ar(979) = "5T"
        ar(980) = "8M"
        ar(981) = "P3"
        ar(982) = "BO"
        ar(983) = "25"
        ar(984) = "B9"
        ar(985) = "6A"
        ar(986) = "NH"
        ar(987) = "95"
        ar(988) = "TA"
        ar(989) = "VT"
        ar(990) = "L5"
        ar(991) = "QE"
        ar(992) = "2D"
        ar(993) = "D6"
        ar(994) = "PR"
        ar(995) = "QL"
        ar(996) = "IQ"
        ar(997) = "24"
        ar(998) = "2Z"
        ar(999) = "EP"
        ar(1000) = "BF"


        On Error GoTo erh

        msEncryptNumDt = ""

        If Not IsNumeric(sNum) Then Exit Function

        Dim rSeed As Integer
        Randomize()

        'rSeed = Int(Rnd * 88) + 11
        rSeed = Int(Rnd * 500)

        Dim l As Long
        l = Len(sNum)
        If l > 9 Then Exit Function

        If l Mod 2 = 1 Then
            sNum = "0" & sNum
            l = l + 1
        End If

        Dim sNummod As Integer

        'Dim newSnum As Long
        '
        'For l = 1 To Len(sNum)
        '    newSnum = newSnum + Asc(Mid(sNum, 1, 1))
        'Next
        '
        'sNummod = (newSnum Mod 71) + 12   ' to do something here

        sNummod = (sNum Mod 71) + 12

        sNum = sNum & sNummod



        Dim i As Integer
        Dim sRet As String
        sRet = ""

        Dim iNum As Integer
        iNum = 0

        Dim pNum As Integer
        pNum = 0

        For i = 1 To Len(sNum) Step 2
            iNum = Mid(sNum, i, 2) + rSeed + i + pNum
            If iNum > 700 Then
                Stop
            End If
            sRet = sRet & ar(iNum)
            pNum = Asc(Mid(sRet, Len(sRet), 1)) - 41
        Next

        sRet = ar(rSeed) & sRet

        Dim secNum As Long

        For i = 1 To Len(sRet)
            secNum = secNum + Asc(Mid(sRet, 1, 1)) - 39
        Next

        secNum = secNum Mod 489

        sRet = ar(secNum) & sRet

        msEncryptNumDt = sRet

        Exit Function

erh:
        MsgBox(Err.Description, vbExclamation, "encrypt error")


    End Function




    Public Function msDecryptNumDt(ByVal sCode As String) As String

        Dim ar(1010) As String

        ar(0) = "L2"
        ar(1) = "GX"
        ar(2) = "IG"
        ar(3) = "YK"
        ar(4) = "XH"
        ar(5) = "YX"
        ar(6) = "86"
        ar(7) = "C5"
        ar(8) = "SG"
        ar(9) = "YF"
        ar(10) = "PM"
        ar(11) = "CO"
        ar(12) = "ZH"
        ar(13) = "58"
        ar(14) = "BX"
        ar(15) = "OZ"
        ar(16) = "AH"
        ar(17) = "WF"
        ar(18) = "78"
        ar(19) = "8J"
        ar(20) = "H4"
        ar(21) = "PB"
        ar(22) = "TS"
        ar(23) = "5J"
        ar(24) = "Z8"
        ar(25) = "A9"
        ar(26) = "7D"
        ar(27) = "ZC"
        ar(28) = "D9"
        ar(29) = "RB"
        ar(30) = "NP"
        ar(31) = "XK"
        ar(32) = "FC"
        ar(33) = "K8"
        ar(34) = "EK"
        ar(35) = "96"
        ar(36) = "GT"
        ar(37) = "DL"
        ar(38) = "XC"
        ar(39) = "XI"
        ar(40) = "N4"
        ar(41) = "JC"
        ar(42) = "L3"
        ar(43) = "EX"
        ar(44) = "PE"
        ar(45) = "PF"
        ar(46) = "WW"
        ar(47) = "2W"
        ar(48) = "TZ"
        ar(49) = "V6"
        ar(50) = "IY"
        ar(51) = "HF"
        ar(52) = "MB"
        ar(53) = "OS"
        ar(54) = "E5"
        ar(55) = "S9"
        ar(56) = "ED"
        ar(57) = "39"
        ar(58) = "HT"
        ar(59) = "7W"
        ar(60) = "QH"
        ar(61) = "RL"
        ar(62) = "ZL"
        ar(63) = "ZT"
        ar(64) = "N8"
        ar(65) = "SN"
        ar(66) = "F3"
        ar(67) = "HH"
        ar(68) = "OI"
        ar(69) = "YZ"
        ar(70) = "26"
        ar(71) = "VJ"
        ar(72) = "OB"
        ar(73) = "Y7"
        ar(74) = "HE"
        ar(75) = "QV"
        ar(76) = "ZN"
        ar(77) = "67"
        ar(78) = "4U"
        ar(79) = "4R"
        ar(80) = "TU"
        ar(81) = "Y9"
        ar(82) = "QP"
        ar(83) = "EE"
        ar(84) = "SJ"
        ar(85) = "G9"
        ar(86) = "2S"
        ar(87) = "NF"
        ar(88) = "42"
        ar(89) = "XV"
        ar(90) = "8F"
        ar(91) = "KM"
        ar(92) = "9L"
        ar(93) = "AE"
        ar(94) = "ON"
        ar(95) = "5Y"
        ar(96) = "DY"
        ar(97) = "TN"
        ar(98) = "3Q"
        ar(99) = "7N"
        ar(100) = "IC"
        ar(101) = "AV"
        ar(102) = "SL"
        ar(103) = "5S"
        ar(104) = "4P"
        ar(105) = "VK"
        ar(106) = "8T"
        ar(107) = "BY"
        ar(108) = "8Y"
        ar(109) = "65"
        ar(110) = "QK"
        ar(111) = "8C"
        ar(112) = "3D"
        ar(113) = "3N"
        ar(114) = "DM"
        ar(115) = "IL"
        ar(116) = "OO"
        ar(117) = "HA"
        ar(118) = "R4"
        ar(119) = "WR"
        ar(120) = "X7"
        ar(121) = "O6"
        ar(122) = "ZB"
        ar(123) = "MM"
        ar(124) = "FA"
        ar(125) = "DU"
        ar(126) = "7Y"
        ar(127) = "WX"
        ar(128) = "ZR"
        ar(129) = "A5"
        ar(130) = "34"
        ar(131) = "3M"
        ar(132) = "2T"
        ar(133) = "MU"
        ar(134) = "DJ"
        ar(135) = "DP"
        ar(136) = "9V"
        ar(137) = "K3"
        ar(138) = "2C"
        ar(139) = "S6"
        ar(140) = "AP"
        ar(141) = "LK"
        ar(142) = "DK"
        ar(143) = "LD"
        ar(144) = "6S"
        ar(145) = "UN"
        ar(146) = "EM"
        ar(147) = "7G"
        ar(148) = "2X"
        ar(149) = "Y6"
        ar(150) = "IR"
        ar(151) = "XA"
        ar(152) = "F6"
        ar(153) = "T2"
        ar(154) = "6W"
        ar(155) = "CL"
        ar(156) = "98"
        ar(157) = "5U"
        ar(158) = "OH"
        ar(159) = "3S"
        ar(160) = "WS"
        ar(161) = "6L"
        ar(162) = "MY"
        ar(163) = "I6"
        ar(164) = "4S"
        ar(165) = "LZ"
        ar(166) = "ND"
        ar(167) = "A4"
        ar(168) = "VD"
        ar(169) = "HD"
        ar(170) = "QU"
        ar(171) = "OJ"
        ar(172) = "DT"
        ar(173) = "D5"
        ar(174) = "4L"
        ar(175) = "X2"
        ar(176) = "QX"
        ar(177) = "BV"
        ar(178) = "BM"
        ar(179) = "45"
        ar(180) = "WC"
        ar(181) = "KQ"
        ar(182) = "KC"
        ar(183) = "L4"
        ar(184) = "UZ"
        ar(185) = "SB"
        ar(186) = "VC"
        ar(187) = "6P"
        ar(188) = "73"
        ar(189) = "HU"
        ar(190) = "JK"
        ar(191) = "VI"
        ar(192) = "EJ"
        ar(193) = "SX"
        ar(194) = "K9"
        ar(195) = "3Z"
        ar(196) = "7J"
        ar(197) = "7S"
        ar(198) = "4Y"
        ar(199) = "QF"
        ar(200) = "YS"
        ar(201) = "8E"
        ar(202) = "37"
        ar(203) = "LB"
        ar(204) = "GJ"
        ar(205) = "Q2"
        ar(206) = "MX"
        ar(207) = "MG"
        ar(208) = "5A"
        ar(209) = "ET"
        ar(210) = "XY"
        ar(211) = "36"
        ar(212) = "4Q"
        ar(213) = "FB"
        ar(214) = "N6"
        ar(215) = "BW"
        ar(216) = "DO"
        ar(217) = "TE"
        ar(218) = "Z3"
        ar(219) = "33"
        ar(220) = "SA"
        ar(221) = "OV"
        ar(222) = "A2"
        ar(223) = "AZ"
        ar(224) = "9X"
        ar(225) = "LS"
        ar(226) = "69"
        ar(227) = "CD"
        ar(228) = "EB"
        ar(229) = "9W"
        ar(230) = "LC"
        ar(231) = "A7"
        ar(232) = "7T"
        ar(233) = "FH"
        ar(234) = "DA"
        ar(235) = "O7"
        ar(236) = "52"
        ar(237) = "F2"
        ar(238) = "23"
        ar(239) = "7V"
        ar(240) = "PT"
        ar(241) = "MZ"
        ar(242) = "W2"
        ar(243) = "R3"
        ar(244) = "TH"
        ar(245) = "5E"
        ar(246) = "8Q"
        ar(247) = "JA"
        ar(248) = "NE"
        ar(249) = "7U"
        ar(250) = "DX"
        ar(251) = "FP"
        ar(252) = "RI"
        ar(253) = "LW"
        ar(254) = "9H"
        ar(255) = "E8"
        ar(256) = "V2"
        ar(257) = "N9"
        ar(258) = "AR"
        ar(259) = "N2"
        ar(260) = "84"
        ar(261) = "MO"
        ar(262) = "EL"
        ar(263) = "YG"
        ar(264) = "ZW"
        ar(265) = "VA"
        ar(266) = "CT"
        ar(267) = "RG"
        ar(268) = "8N"
        ar(269) = "NQ"
        ar(270) = "OG"
        ar(271) = "OA"
        ar(272) = "9G"
        ar(273) = "JR"
        ar(274) = "72"
        ar(275) = "PQ"
        ar(276) = "2V"
        ar(277) = "6U"
        ar(278) = "GO"
        ar(279) = "9A"
        ar(280) = "KX"
        ar(281) = "RV"
        ar(282) = "LT"
        ar(283) = "QT"
        ar(284) = "7Z"
        ar(285) = "8G"
        ar(286) = "M8"
        ar(287) = "27"
        ar(288) = "XF"
        ar(289) = "XD"
        ar(290) = "H7"
        ar(291) = "FI"
        ar(292) = "FM"
        ar(293) = "E2"
        ar(294) = "P5"
        ar(295) = "3J"
        ar(296) = "BE"
        ar(297) = "6Q"
        ar(298) = "KK"
        ar(299) = "ER"
        ar(300) = "9S"
        ar(301) = "TQ"
        ar(302) = "2Q"
        ar(303) = "NB"
        ar(304) = "F9"
        ar(305) = "X4"
        ar(306) = "AL"
        ar(307) = "UG"
        ar(308) = "LU"
        ar(309) = "R7"
        ar(310) = "CN"
        ar(311) = "N7"
        ar(312) = "GB"
        ar(313) = "F5"
        ar(314) = "J7"
        ar(315) = "9U"
        ar(316) = "IO"
        ar(317) = "QW"
        ar(318) = "4V"
        ar(319) = "2R"
        ar(320) = "K6"
        ar(321) = "OP"
        ar(322) = "N5"
        ar(323) = "7C"
        ar(324) = "WZ"
        ar(325) = "3K"
        ar(326) = "J2"
        ar(327) = "KW"
        ar(328) = "Y8"
        ar(329) = "LY"
        ar(330) = "JZ"
        ar(331) = "7P"
        ar(332) = "T5"
        ar(333) = "8U"
        ar(334) = "XS"
        ar(335) = "Q3"
        ar(336) = "X8"
        ar(337) = "FN"
        ar(338) = "4I"
        ar(339) = "Q8"
        ar(340) = "R9"
        ar(341) = "TG"
        ar(342) = "R2"
        ar(343) = "W9"
        ar(344) = "ZZ"
        ar(345) = "2B"
        ar(346) = "2K"
        ar(347) = "DE"
        ar(348) = "LE"
        ar(349) = "WP"
        ar(350) = "9Y"
        ar(351) = "MQ"
        ar(352) = "YO"
        ar(353) = "WO"
        ar(354) = "QQ"
        ar(355) = "I4"
        ar(356) = "6H"
        ar(357) = "44"
        ar(358) = "SD"
        ar(359) = "NS"
        ar(360) = "AY"
        ar(361) = "CQ"
        ar(362) = "AK"
        ar(363) = "QS"
        ar(364) = "TF"
        ar(365) = "GK"
        ar(366) = "HJ"
        ar(367) = "KI"
        ar(368) = "3A"
        ar(369) = "ES"
        ar(370) = "DW"
        ar(371) = "UP"
        ar(372) = "J9"
        ar(373) = "FU"
        ar(374) = "9D"
        ar(375) = "3B"
        ar(376) = "LV"
        ar(377) = "IH"
        ar(378) = "R5"
        ar(379) = "NV"
        ar(380) = "JG"
        ar(381) = "3U"
        ar(382) = "DS"
        ar(383) = "35"
        ar(384) = "SZ"
        ar(385) = "9O"
        ar(386) = "QI"
        ar(387) = "HR"
        ar(388) = "AU"
        ar(389) = "4A"
        ar(390) = "P9"
        ar(391) = "RE"
        ar(392) = "UY"
        ar(393) = "S8"
        ar(394) = "4D"
        ar(395) = "TP"
        ar(396) = "6Z"
        ar(397) = "8V"
        ar(398) = "2M"
        ar(399) = "US"
        ar(400) = "4N"
        ar(401) = "5K"
        ar(402) = "GA"
        ar(403) = "FW"
        ar(404) = "J6"
        ar(405) = "HB"
        ar(406) = "DN"
        ar(407) = "HZ"
        ar(408) = "T4"
        ar(409) = "ZE"
        ar(410) = "OD"
        ar(411) = "Q7"
        ar(412) = "NL"
        ar(413) = "FE"
        ar(414) = "4F"
        ar(415) = "RS"
        ar(416) = "M2"
        ar(417) = "85"
        ar(418) = "XM"
        ar(419) = "OR"
        ar(420) = "JO"
        ar(421) = "EV"
        ar(422) = "WG"
        ar(423) = "CU"
        ar(424) = "L6"
        ar(425) = "PI"
        ar(426) = "M7"
        ar(427) = "NR"
        ar(428) = "NA"
        ar(429) = "CF"
        ar(430) = "3L"
        ar(431) = "2F"
        ar(432) = "JD"
        ar(433) = "RR"
        ar(434) = "VS"
        ar(435) = "7K"
        ar(436) = "IK"
        ar(437) = "4B"
        ar(438) = "MW"
        ar(439) = "9P"
        ar(440) = "4E"
        ar(441) = "V7"
        ar(442) = "4T"
        ar(443) = "ZG"
        ar(444) = "EH"
        ar(445) = "6R"
        ar(446) = "UT"
        ar(447) = "VY"
        ar(448) = "54"
        ar(449) = "MS"
        ar(450) = "KG"
        ar(451) = "U8"
        ar(452) = "PN"
        ar(453) = "LO"
        ar(454) = "UM"
        ar(455) = "L9"
        ar(456) = "UH"
        ar(457) = "7B"
        ar(458) = "SM"
        ar(459) = "8O"
        ar(460) = "HY"
        ar(461) = "62"
        ar(462) = "SY"
        ar(463) = "97"
        ar(464) = "NN"
        ar(465) = "VF"
        ar(466) = "2O"
        ar(467) = "28"
        ar(468) = "D8"
        ar(469) = "TO"
        ar(470) = "U2"
        ar(471) = "SR"
        ar(472) = "G3"
        ar(473) = "P2"
        ar(474) = "TB"
        ar(475) = "7R"
        ar(476) = "WJ"
        ar(477) = "93"
        ar(478) = "5P"
        ar(479) = "Y5"
        ar(480) = "IB"
        ar(481) = "9E"
        ar(482) = "L7"
        ar(483) = "H6"
        ar(484) = "4Z"
        ar(485) = "KD"
        ar(486) = "2Y"
        ar(487) = "5H"
        ar(488) = "HX"
        ar(489) = "PD"
        ar(490) = "JW"
        ar(491) = "AN"
        ar(492) = "6T"
        ar(493) = "V9"
        ar(494) = "2E"
        ar(495) = "S2"
        ar(496) = "QN"
        ar(497) = "BL"
        ar(498) = "8K"
        ar(499) = "6K"
        ar(500) = "ZS"
        ar(501) = "YM"
        ar(502) = "Y2"
        ar(503) = "3C"
        ar(504) = "ZO"
        ar(505) = "9Z"
        ar(506) = "RM"
        ar(507) = "E3"
        ar(508) = "IF"
        ar(509) = "WA"
        ar(510) = "HG"
        ar(511) = "6B"
        ar(512) = "H8"
        ar(513) = "IW"
        ar(514) = "RW"
        ar(515) = "U9"
        ar(516) = "EU"
        ar(517) = "7F"
        ar(518) = "RN"
        ar(519) = "T6"
        ar(520) = "T7"
        ar(521) = "NI"
        ar(522) = "6I"
        ar(523) = "MC"
        ar(524) = "V8"
        ar(525) = "2H"
        ar(526) = "FL"
        ar(527) = "TM"
        ar(528) = "HN"
        ar(529) = "Y4"
        ar(530) = "W6"
        ar(531) = "SC"
        ar(532) = "UO"
        ar(533) = "QJ"
        ar(534) = "E9"
        ar(535) = "PO"
        ar(536) = "WI"
        ar(537) = "RQ"
        ar(538) = "GV"
        ar(539) = "EN"
        ar(540) = "FJ"
        ar(541) = "JB"
        ar(542) = "EG"
        ar(543) = "YH"
        ar(544) = "4C"
        ar(545) = "GI"
        ar(546) = "CC"
        ar(547) = "SH"
        ar(548) = "VQ"
        ar(549) = "29"
        ar(550) = "D3"
        ar(551) = "MV"
        ar(552) = "46"
        ar(553) = "JJ"
        ar(554) = "AQ"
        ar(555) = "CK"
        ar(556) = "8W"
        ar(557) = "RY"
        ar(558) = "KN"
        ar(559) = "BN"
        ar(560) = "53"
        ar(561) = "HP"
        ar(562) = "BD"
        ar(563) = "XL"
        ar(564) = "XJ"
        ar(565) = "EO"
        ar(566) = "FR"
        ar(567) = "Z2"
        ar(568) = "EQ"
        ar(569) = "CM"
        ar(570) = "MJ"
        ar(571) = "AT"
        ar(572) = "6X"
        ar(573) = "QR"
        ar(574) = "9T"
        ar(575) = "C7"
        ar(576) = "VU"
        ar(577) = "XU"
        ar(578) = "UE"
        ar(579) = "CA"
        ar(580) = "YB"
        ar(581) = "G7"
        ar(582) = "J4"
        ar(583) = "HV"
        ar(584) = "D2"
        ar(585) = "RA"
        ar(586) = "HO"
        ar(587) = "38"
        ar(588) = "8L"
        ar(589) = "GF"
        ar(590) = "NC"
        ar(591) = "YU"
        ar(592) = "CI"
        ar(593) = "JM"
        ar(594) = "KS"
        ar(595) = "XB"
        ar(596) = "J5"
        ar(597) = "T9"
        ar(598) = "ID"
        ar(599) = "O2"
        ar(600) = "ZD"
        ar(601) = "3I"
        ar(602) = "5V"
        ar(603) = "SK"
        ar(604) = "MA"
        ar(605) = "2N"
        ar(606) = "7H"
        ar(607) = "QG"
        ar(608) = "BC"
        ar(609) = "O5"
        ar(610) = "7X"
        ar(611) = "55"
        ar(612) = "V5"
        ar(613) = "KJ"
        ar(614) = "NT"
        ar(615) = "CE"
        ar(616) = "VN"
        ar(617) = "KE"
        ar(618) = "LA"
        ar(619) = "8A"
        ar(620) = "GP"
        ar(621) = "9I"
        ar(622) = "PY"
        ar(623) = "JY"
        ar(624) = "R8"
        ar(625) = "GY"
        ar(626) = "KT"
        ar(627) = "56"
        ar(628) = "I3"
        ar(629) = "3F"
        ar(630) = "EW"
        ar(631) = "8D"
        ar(632) = "QM"
        ar(633) = "JV"
        ar(634) = "9K"
        ar(635) = "CX"
        ar(636) = "UQ"
        ar(637) = "ZX"
        ar(638) = "6J"
        ar(639) = "TY"
        ar(640) = "4H"
        ar(641) = "3Y"
        ar(642) = "3R"
        ar(643) = "QD"
        ar(644) = "YT"
        ar(645) = "64"
        ar(646) = "ZY"
        ar(647) = "83"
        ar(648) = "EC"
        ar(649) = "JL"
        ar(650) = "9F"
        ar(651) = "XG"
        ar(652) = "G8"
        ar(653) = "8X"
        ar(654) = "XP"
        ar(655) = "DV"
        ar(656) = "JF"
        ar(657) = "LH"
        ar(658) = "MN"
        ar(659) = "ZU"
        ar(660) = "JP"
        ar(661) = "RJ"
        ar(662) = "59"
        ar(663) = "JH"
        ar(664) = "CY"
        ar(665) = "AD"
        ar(666) = "HK"
        ar(667) = "W3"
        ar(668) = "O9"
        ar(669) = "MT"
        ar(670) = "ZP"
        ar(671) = "FF"
        ar(672) = "NK"
        ar(673) = "BU"
        ar(674) = "QO"
        ar(675) = "YW"
        ar(676) = "BG"
        ar(677) = "9N"
        ar(678) = "FZ"
        ar(679) = "22"
        ar(680) = "PH"
        ar(681) = "IX"
        ar(682) = "XO"
        ar(683) = "8R"
        ar(684) = "JX"
        ar(685) = "TX"
        ar(686) = "5W"
        ar(687) = "JI"
        ar(688) = "XR"
        ar(689) = "M9"
        ar(690) = "SW"
        ar(691) = "Q9"
        ar(692) = "76"
        ar(693) = "5C"
        ar(694) = "S7"
        ar(695) = "BI"
        ar(696) = "F7"
        ar(697) = "FX"
        ar(698) = "RZ"
        ar(699) = "CB"
        ar(700) = "5D"
        ar(701) = "ZI"
        ar(702) = "DZ"
        ar(703) = "GG"
        ar(704) = "GU"
        ar(705) = "DC"
        ar(706) = "RP"
        ar(707) = "SF"
        ar(708) = "I9"
        ar(709) = "6G"
        ar(710) = "MI"
        ar(711) = "B2"
        ar(712) = "NZ"
        ar(713) = "EI"
        ar(714) = "GD"
        ar(715) = "XT"
        ar(716) = "Z4"
        ar(717) = "SO"
        ar(718) = "VO"
        ar(719) = "VV"
        ar(720) = "PG"
        ar(721) = "3W"
        ar(722) = "SU"
        ar(723) = "P4"
        ar(724) = "PA"
        ar(725) = "DG"
        ar(726) = "OK"
        ar(727) = "OW"
        ar(728) = "KB"
        ar(729) = "WD"
        ar(730) = "C2"
        ar(731) = "4M"
        ar(732) = "YC"
        ar(733) = "WM"
        ar(734) = "GZ"
        ar(735) = "IV"
        ar(736) = "QZ"
        ar(737) = "WE"
        ar(738) = "VZ"
        ar(739) = "GN"
        ar(740) = "K5"
        ar(741) = "VL"
        ar(742) = "V3"
        ar(743) = "H9"
        ar(744) = "II"
        ar(745) = "9Q"
        ar(746) = "BP"
        ar(747) = "RO"
        ar(748) = "K4"
        ar(749) = "AF"
        ar(750) = "ZA"
        ar(751) = "Q5"
        ar(752) = "WB"
        ar(753) = "UD"
        ar(754) = "XN"
        ar(755) = "I7"
        ar(756) = "OY"
        ar(757) = "OL"
        ar(758) = "RD"
        ar(759) = "8B"
        ar(760) = "FQ"
        ar(761) = "UV"
        ar(762) = "O8"
        ar(763) = "PZ"
        ar(764) = "IT"
        ar(765) = "U4"
        ar(766) = "GE"
        ar(767) = "5F"
        ar(768) = "PV"
        ar(769) = "YA"
        ar(770) = "CJ"
        ar(771) = "2J"
        ar(772) = "7L"
        ar(773) = "LP"
        ar(774) = "79"
        ar(775) = "CV"
        ar(776) = "LQ"
        ar(777) = "IP"
        ar(778) = "8S"
        ar(779) = "2I"
        ar(780) = "B6"
        ar(781) = "L8"
        ar(782) = "W7"
        ar(783) = "JQ"
        ar(784) = "UU"
        ar(785) = "PX"
        ar(786) = "32"
        ar(787) = "IU"
        ar(788) = "J8"
        ar(789) = "68"
        ar(790) = "AW"
        ar(791) = "49"
        ar(792) = "OE"
        ar(793) = "XQ"
        ar(794) = "OF"
        ar(795) = "XW"
        ar(796) = "CH"
        ar(797) = "A6"
        ar(798) = "IZ"
        ar(799) = "MD"
        ar(800) = "5G"
        ar(801) = "3X"
        ar(802) = "TD"
        ar(803) = "UF"
        ar(804) = "3V"
        ar(805) = "YI"
        ar(806) = "3G"
        ar(807) = "EZ"
        ar(808) = "G5"
        ar(809) = "LX"
        ar(810) = "94"
        ar(811) = "AO"
        ar(812) = "B5"
        ar(813) = "S5"
        ar(814) = "H2"
        ar(815) = "U5"
        ar(816) = "UW"
        ar(817) = "YQ"
        ar(818) = "N3"
        ar(819) = "3T"
        ar(820) = "UA"
        ar(821) = "J3"
        ar(822) = "P8"
        ar(823) = "YD"
        ar(824) = "LI"
        ar(825) = "ZQ"
        ar(826) = "LM"
        ar(827) = "OC"
        ar(828) = "PW"
        ar(829) = "2U"
        ar(830) = "B4"
        ar(831) = "M5"
        ar(832) = "AX"
        ar(833) = "C3"
        ar(834) = "WV"
        ar(835) = "AA"
        ar(836) = "NU"
        ar(837) = "CR"
        ar(838) = "U6"
        ar(839) = "8P"
        ar(840) = "FV"
        ar(841) = "BR"
        ar(842) = "5B"
        ar(843) = "PJ"
        ar(844) = "UB"
        ar(845) = "UC"
        ar(846) = "RT"
        ar(847) = "6E"
        ar(848) = "NO"
        ar(849) = "89"
        ar(850) = "7O"
        ar(851) = "PU"
        ar(852) = "LJ"
        ar(853) = "LL"
        ar(854) = "ZJ"
        ar(855) = "S3"
        ar(856) = "QC"
        ar(857) = "HM"
        ar(858) = "4G"
        ar(859) = "YL"
        ar(860) = "5L"
        ar(861) = "U7"
        ar(862) = "DD"
        ar(863) = "MP"
        ar(864) = "RC"
        ar(865) = "8Z"
        ar(866) = "VM"
        ar(867) = "SE"
        ar(868) = "P6"
        ar(869) = "ZK"
        ar(870) = "2L"
        ar(871) = "Z5"
        ar(872) = "FS"
        ar(873) = "74"
        ar(874) = "M6"
        ar(875) = "X3"
        ar(876) = "AS"
        ar(877) = "5M"
        ar(878) = "Q4"
        ar(879) = "NJ"
        ar(880) = "IA"
        ar(881) = "TC"
        ar(882) = "YE"
        ar(883) = "7M"
        ar(884) = "CG"
        ar(885) = "5N"
        ar(886) = "RF"
        ar(887) = "UK"
        ar(888) = "GQ"
        ar(889) = "G4"
        ar(890) = "TL"
        ar(891) = "2P"
        ar(892) = "5O"
        ar(893) = "VE"
        ar(894) = "MK"
        ar(895) = "KF"
        ar(896) = "ZM"
        ar(897) = "M4"
        ar(898) = "4W"
        ar(899) = "E7"
        ar(900) = "DF"
        ar(901) = "YN"
        ar(902) = "UX"
        ar(903) = "H5"
        ar(904) = "YJ"
        ar(905) = "CS"
        ar(906) = "KA"
        ar(907) = "VG"
        ar(908) = "FG"
        ar(909) = "SV"
        ar(910) = "C4"
        ar(911) = "TT"
        ar(912) = "XX"
        ar(913) = "MF"
        ar(914) = "SP"
        ar(915) = "4X"
        ar(916) = "SS"
        ar(917) = "EA"
        ar(918) = "E6"
        ar(919) = "9J"
        ar(920) = "EY"
        ar(921) = "TR"
        ar(922) = "LN"
        ar(923) = "3H"
        ar(924) = "T3"
        ar(925) = "M3"
        ar(926) = "WH"
        ar(927) = "CZ"
        ar(928) = "AG"
        ar(929) = "6O"
        ar(930) = "RX"
        ar(931) = "I2"
        ar(932) = "BT"
        ar(933) = "ML"
        ar(934) = "XE"
        ar(935) = "O3"
        ar(936) = "W5"
        ar(937) = "6V"
        ar(938) = "63"
        ar(939) = "LF"
        ar(940) = "BQ"
        ar(941) = "QA"
        ar(942) = "KY"
        ar(943) = "FY"
        ar(944) = "B3"
        ar(945) = "DI"
        ar(946) = "VR"
        ar(947) = "6M"
        ar(948) = "BA"
        ar(949) = "Z9"
        ar(950) = "EF"
        ar(951) = "FD"
        ar(952) = "BZ"
        ar(953) = "DR"
        ar(954) = "7E"
        ar(955) = "DB"
        ar(956) = "JN"
        ar(957) = "WL"
        ar(958) = "GM"
        ar(959) = "92"
        ar(960) = "QB"
        ar(961) = "G6"
        ar(962) = "FO"
        ar(963) = "47"
        ar(964) = "E4"
        ar(965) = "LG"
        ar(966) = "QY"
        ar(967) = "DQ"
        ar(968) = "5R"
        ar(969) = "R6"
        ar(970) = "NG"
        ar(971) = "OQ"
        ar(972) = "GH"
        ar(973) = "AI"
        ar(974) = "OT"
        ar(975) = "K2"
        ar(976) = "TV"
        ar(977) = "UR"
        ar(978) = "F4"
        ar(979) = "5T"
        ar(980) = "8M"
        ar(981) = "P3"
        ar(982) = "BO"
        ar(983) = "25"
        ar(984) = "B9"
        ar(985) = "6A"
        ar(986) = "NH"
        ar(987) = "95"
        ar(988) = "TA"
        ar(989) = "VT"
        ar(990) = "L5"
        ar(991) = "QE"
        ar(992) = "2D"
        ar(993) = "D6"
        ar(994) = "PR"
        ar(995) = "QL"
        ar(996) = "IQ"
        ar(997) = "24"
        ar(998) = "2Z"
        ar(999) = "EP"
        ar(1000) = "BF"


        On Error GoTo erh

        msDecryptNumDt = ""

        Dim firstChk As String
        firstChk = Mid(sCode, 1, 2)

        sCode = Mid(sCode, 3)

        Dim m As Integer

        Dim secNum As Long

        For m = 1 To Len(sCode)
            secNum = secNum + Asc(Mid(sCode, 1, 1)) - 39
        Next

        secNum = secNum Mod 489

        If ar(secNum) <> firstChk Then
            Exit Function
        End If


        Dim rSeed As Integer
        Dim i As Integer
        rSeed = 0

        Dim sTemp As String
        sTemp = Mid(sCode, 1, 2)

        For i = 1 To 1000
            If ar(i) = sTemp Then
                rSeed = i
                Exit For
            End If
        Next

        'If rSeed < 11 Then GoTo erh

        If rSeed >= 500 Then Exit Function

        Dim sNum As String
        sNum = ""

        Dim j As Integer
        sCode = Mid(sCode, 3)
        Dim pNum As Integer
        pNum = 0

        For i = 1 To Len(sCode) Step 2
            sTemp = Mid(sCode, i, 2)
            For j = 1 To 1000
                If ar(j) = sTemp Then
                    sNum = sNum & Right("00" & (j - rSeed - i - pNum), 2)
                    Exit For
                End If
            Next
            pNum = Asc(Mid(sTemp, 2, 1)) - 41
        Next

        Dim sNummod As String
        sNummod = Mid(sNum, Len(sNum) - 1)

        'Dim nNumMod As Integer
        'If Len(sNummod) > 2 Then
        '    nNumMod = Mid(sNummod, Len(sNummod) - 2)
        'End If

        Dim sRet As String
        sRet = Mid(sNum, 1, Len(sNum) - 2)

        Dim newSnum As Long
        Dim l As Long

        'For l = 1 To Len(sRet)
        '    newSnum = newSnum + Asc(Mid(sNum, 1, 1))
        'Next

        'sNummod = (newSnum Mod 71) + 12

        'If (newSnum Mod 71) + 12 = sNummod Then
        If (sRet Mod 71) + 12 = sNummod Then
            msDecryptNumDt = sRet
        End If


        Exit Function

erh:
        MsgBox(Err.Description, vbCritical, "Decrypt error")



    End Function


#End Region

#Region "Internet-Email"

    Public Function msIsInternetOk(ByRef url As String) As Boolean

        '2009-03-02
        ' no need to check
        If 1 = 0 Then
            msIsInternetOk = True
            Exit Function
        End If

        'ex = 0
        msIsInternetOk = False
        Try
            msIsInternetOk = My.Computer.Network.Ping(url, 4000)
        Catch ex As Exception

        End Try


    End Function

#End Region


#Region "new db related"

    Public Function msFillDS(ByVal prmStrSql As String, ByRef prmDS As DataSet, Optional ByVal prmtblName As String = "tblA") As String

        msFillDS = ""

        Dim dbCn As New OleDbConnection

        If Not msOpenDbConnection(dbCn) Then
            msFillDS = "DB error"
            Exit Function
        End If


        Dim apt As OleDbDataAdapter

        Try
            apt = New OleDbDataAdapter(prmStrSql, dbCn)

            apt.FillSchema(prmDS, SchemaType.Source, prmtblName)

            apt.Fill(prmDS, prmtblName)

        Catch ex As Exception

            msFillDS = "Error: ws150116: " & ex.Message

        End Try

        dbCn.Close()


    End Function

    Public Function msFillGrid(ByRef prmGrid As DataGridView, ByRef prmDs As DataSet) As String

        msFillGrid = ""

        Dim f As Font
        f = New Font("Verdana", 8, FontStyle.Regular, GraphicsUnit.Point)

        prmGrid.Font = f

        Try
            prmGrid.DataSource = prmDs
            prmGrid.DataMember = prmDs.Tables(0).TableName
            msDoEvents()
            prmGrid.AutoResizeColumns()

        Catch ex As Exception

            msFillGrid = "Error 160730 " & ex.Message

        End Try


    End Function

#End Region

End Module
