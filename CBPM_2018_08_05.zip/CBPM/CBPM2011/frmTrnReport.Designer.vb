<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTrnReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtpTo = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpFrm = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBatchNo = New System.Windows.Forms.TextBox()
        Me.lstMailBr = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lstBranch = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnDespatch = New System.Windows.Forms.Button()
        Me.btnProductionRep = New System.Windows.Forms.Button()
        Me.btnSummary = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txtAccNo = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lstBkType = New System.Windows.Forms.ListBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnBrSummary = New System.Windows.Forms.Button()
        Me.lblAccName = New System.Windows.Forms.Label()
        Me.rbPrinted = New System.Windows.Forms.RadioButton()
        Me.rbPendings = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnbrSerials = New System.Windows.Forms.Button()
        Me.btnDeliveryReport = New System.Windows.Forms.Button()
        Me.ntmBrLeavesSummary = New System.Windows.Forms.Button()
        Me.btnLeavesSummary = New System.Windows.Forms.Button()
        Me.btnCitiProd = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rbGold = New System.Windows.Forms.RadioButton()
        Me.rbCorporate = New System.Windows.Forms.RadioButton()
        Me.rbConsumer = New System.Windows.Forms.RadioButton()
        Me.lblWait = New System.Windows.Forms.Label()
        Me.btnCitiSummary = New System.Windows.Forms.Button()
        Me.btnBkBrSum = New System.Windows.Forms.Button()
        Me.btnBktSummary = New System.Windows.Forms.Button()
        Me.btnBkTypeReport = New System.Windows.Forms.Button()
        Me.txtDelvMode = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtBrCodeStart = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtFileNo = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnBoxReport = New System.Windows.Forms.Button()
        Me.txtBoxNo = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.rbBothPs = New System.Windows.Forms.RadioButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpTo)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.dtpFrm)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(469, 56)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dates"
        '
        'dtpTo
        '
        Me.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpTo.Location = New System.Drawing.Point(288, 21)
        Me.dtpTo.Name = "dtpTo"
        Me.dtpTo.Size = New System.Drawing.Size(127, 22)
        Me.dtpTo.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(240, 25)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 18)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "To"
        '
        'dtpFrm
        '
        Me.dtpFrm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFrm.Location = New System.Drawing.Point(62, 21)
        Me.dtpFrm.Name = "dtpFrm"
        Me.dtpFrm.Size = New System.Drawing.Size(127, 22)
        Me.dtpFrm.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(14, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "From"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(501, 102)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 14)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Batch No"
        '
        'txtBatchNo
        '
        Me.txtBatchNo.Location = New System.Drawing.Point(634, 94)
        Me.txtBatchNo.Name = "txtBatchNo"
        Me.txtBatchNo.Size = New System.Drawing.Size(82, 22)
        Me.txtBatchNo.TabIndex = 5
        Me.txtBatchNo.Text = "0"
        Me.txtBatchNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lstMailBr
        '
        Me.lstMailBr.FormattingEnabled = True
        Me.lstMailBr.ItemHeight = 14
        Me.lstMailBr.Location = New System.Drawing.Point(527, 438)
        Me.lstMailBr.Name = "lstMailBr"
        Me.lstMailBr.Size = New System.Drawing.Size(224, 32)
        Me.lstMailBr.TabIndex = 9
        Me.lstMailBr.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(527, 421)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 14)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Mail Branch"
        Me.Label4.Visible = False
        '
        'lstBranch
        '
        Me.lstBranch.FormattingEnabled = True
        Me.lstBranch.ItemHeight = 14
        Me.lstBranch.Location = New System.Drawing.Point(12, 102)
        Me.lstBranch.Name = "lstBranch"
        Me.lstBranch.Size = New System.Drawing.Size(224, 88)
        Me.lstBranch.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(15, 84)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 14)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Branch"
        '
        'btnDespatch
        '
        Me.btnDespatch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDespatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDespatch.Location = New System.Drawing.Point(844, 264)
        Me.btnDespatch.Name = "btnDespatch"
        Me.btnDespatch.Size = New System.Drawing.Size(207, 33)
        Me.btnDespatch.TabIndex = 10
        Me.btnDespatch.Text = "Despatch Report"
        Me.btnDespatch.UseVisualStyleBackColor = True
        Me.btnDespatch.Visible = False
        '
        'btnProductionRep
        '
        Me.btnProductionRep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnProductionRep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProductionRep.Location = New System.Drawing.Point(844, 225)
        Me.btnProductionRep.Name = "btnProductionRep"
        Me.btnProductionRep.Size = New System.Drawing.Size(202, 33)
        Me.btnProductionRep.TabIndex = 11
        Me.btnProductionRep.Text = "Production Report"
        Me.btnProductionRep.UseVisualStyleBackColor = True
        Me.btnProductionRep.Visible = False
        '
        'btnSummary
        '
        Me.btnSummary.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSummary.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSummary.Location = New System.Drawing.Point(149, 302)
        Me.btnSummary.Name = "btnSummary"
        Me.btnSummary.Size = New System.Drawing.Size(207, 33)
        Me.btnSummary.TabIndex = 12
        Me.btnSummary.Text = "Summary Report"
        Me.btnSummary.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Location = New System.Drawing.Point(856, 341)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(70, 32)
        Me.btnClose.TabIndex = 13
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'txtAccNo
        '
        Me.txtAccNo.Location = New System.Drawing.Point(115, 200)
        Me.txtAccNo.MaxLength = 15
        Me.txtAccNo.Name = "txtAccNo"
        Me.txtAccNo.Size = New System.Drawing.Size(158, 22)
        Me.txtAccNo.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(20, 204)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 14)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Account No"
        '
        'lstBkType
        '
        Me.lstBkType.FormattingEnabled = True
        Me.lstBkType.ItemHeight = 14
        Me.lstBkType.Location = New System.Drawing.Point(259, 101)
        Me.lstBkType.Name = "lstBkType"
        Me.lstBkType.Size = New System.Drawing.Size(224, 88)
        Me.lstBkType.TabIndex = 17
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(256, 84)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(186, 14)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Segment (Transaction Code)"
        '
        'btnBrSummary
        '
        Me.btnBrSummary.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBrSummary.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBrSummary.Location = New System.Drawing.Point(364, 301)
        Me.btnBrSummary.Name = "btnBrSummary"
        Me.btnBrSummary.Size = New System.Drawing.Size(202, 33)
        Me.btnBrSummary.TabIndex = 19
        Me.btnBrSummary.Text = "Branch wise Summary"
        Me.btnBrSummary.UseVisualStyleBackColor = True
        '
        'lblAccName
        '
        Me.lblAccName.AutoSize = True
        Me.lblAccName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAccName.ForeColor = System.Drawing.Color.Purple
        Me.lblAccName.Location = New System.Drawing.Point(23, 229)
        Me.lblAccName.Name = "lblAccName"
        Me.lblAccName.Size = New System.Drawing.Size(29, 16)
        Me.lblAccName.TabIndex = 20
        Me.lblAccName.Text = "     "
        '
        'rbPrinted
        '
        Me.rbPrinted.AutoSize = True
        Me.rbPrinted.Location = New System.Drawing.Point(11, 50)
        Me.rbPrinted.Name = "rbPrinted"
        Me.rbPrinted.Size = New System.Drawing.Size(70, 18)
        Me.rbPrinted.TabIndex = 21
        Me.rbPrinted.Text = "Printed"
        Me.rbPrinted.UseVisualStyleBackColor = True
        '
        'rbPendings
        '
        Me.rbPendings.AutoSize = True
        Me.rbPendings.Location = New System.Drawing.Point(11, 73)
        Me.rbPendings.Name = "rbPendings"
        Me.rbPendings.Size = New System.Drawing.Size(83, 18)
        Me.rbPendings.TabIndex = 22
        Me.rbPendings.Text = "Pendings"
        Me.rbPendings.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbBothPs)
        Me.GroupBox2.Controls.Add(Me.rbPendings)
        Me.GroupBox2.Controls.Add(Me.rbPrinted)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 259)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(106, 114)
        Me.GroupBox2.TabIndex = 23
        Me.GroupBox2.TabStop = False
        '
        'btnbrSerials
        '
        Me.btnbrSerials.Location = New System.Drawing.Point(1, 451)
        Me.btnbrSerials.Name = "btnbrSerials"
        Me.btnbrSerials.Size = New System.Drawing.Size(142, 32)
        Me.btnbrSerials.TabIndex = 24
        Me.btnbrSerials.Text = "Branch Serials"
        Me.btnbrSerials.UseVisualStyleBackColor = True
        Me.btnbrSerials.Visible = False
        '
        'btnDeliveryReport
        '
        Me.btnDeliveryReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDeliveryReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDeliveryReport.Location = New System.Drawing.Point(149, 261)
        Me.btnDeliveryReport.Name = "btnDeliveryReport"
        Me.btnDeliveryReport.Size = New System.Drawing.Size(289, 35)
        Me.btnDeliveryReport.TabIndex = 25
        Me.btnDeliveryReport.Text = "Report by Branch / Segment"
        Me.btnDeliveryReport.UseVisualStyleBackColor = True
        '
        'ntmBrLeavesSummary
        '
        Me.ntmBrLeavesSummary.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ntmBrLeavesSummary.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ntmBrLeavesSummary.Location = New System.Drawing.Point(364, 340)
        Me.ntmBrLeavesSummary.Name = "ntmBrLeavesSummary"
        Me.ntmBrLeavesSummary.Size = New System.Drawing.Size(200, 33)
        Me.ntmBrLeavesSummary.TabIndex = 33
        Me.ntmBrLeavesSummary.Text = "Br wise Leaves Summary"
        Me.ntmBrLeavesSummary.UseVisualStyleBackColor = True
        '
        'btnLeavesSummary
        '
        Me.btnLeavesSummary.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLeavesSummary.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLeavesSummary.Location = New System.Drawing.Point(149, 341)
        Me.btnLeavesSummary.Name = "btnLeavesSummary"
        Me.btnLeavesSummary.Size = New System.Drawing.Size(207, 33)
        Me.btnLeavesSummary.TabIndex = 32
        Me.btnLeavesSummary.Text = "Leaves Summary"
        Me.btnLeavesSummary.UseVisualStyleBackColor = True
        '
        'btnCitiProd
        '
        Me.btnCitiProd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCitiProd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCitiProd.Location = New System.Drawing.Point(187, 536)
        Me.btnCitiProd.Name = "btnCitiProd"
        Me.btnCitiProd.Size = New System.Drawing.Size(146, 32)
        Me.btnCitiProd.TabIndex = 34
        Me.btnCitiProd.Text = "Citi Production Report"
        Me.btnCitiProd.UseVisualStyleBackColor = True
        Me.btnCitiProd.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbGold)
        Me.GroupBox3.Controls.Add(Me.rbCorporate)
        Me.GroupBox3.Controls.Add(Me.rbConsumer)
        Me.GroupBox3.Location = New System.Drawing.Point(29, 485)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(277, 45)
        Me.GroupBox3.TabIndex = 35
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Visible = False
        '
        'rbGold
        '
        Me.rbGold.AutoSize = True
        Me.rbGold.Location = New System.Drawing.Point(206, 17)
        Me.rbGold.Name = "rbGold"
        Me.rbGold.Size = New System.Drawing.Size(53, 18)
        Me.rbGold.TabIndex = 2
        Me.rbGold.TabStop = True
        Me.rbGold.Text = "Gold"
        Me.rbGold.UseVisualStyleBackColor = True
        '
        'rbCorporate
        '
        Me.rbCorporate.AutoSize = True
        Me.rbCorporate.Location = New System.Drawing.Point(115, 17)
        Me.rbCorporate.Name = "rbCorporate"
        Me.rbCorporate.Size = New System.Drawing.Size(89, 18)
        Me.rbCorporate.TabIndex = 1
        Me.rbCorporate.TabStop = True
        Me.rbCorporate.Text = "Corporate"
        Me.rbCorporate.UseVisualStyleBackColor = True
        '
        'rbConsumer
        '
        Me.rbConsumer.AutoSize = True
        Me.rbConsumer.Checked = True
        Me.rbConsumer.Location = New System.Drawing.Point(17, 17)
        Me.rbConsumer.Name = "rbConsumer"
        Me.rbConsumer.Size = New System.Drawing.Size(89, 18)
        Me.rbConsumer.TabIndex = 0
        Me.rbConsumer.TabStop = True
        Me.rbConsumer.Text = "Consumer"
        Me.rbConsumer.UseVisualStyleBackColor = True
        '
        'lblWait
        '
        Me.lblWait.AutoSize = True
        Me.lblWait.ForeColor = System.Drawing.Color.Red
        Me.lblWait.Location = New System.Drawing.Point(797, 23)
        Me.lblWait.Name = "lblWait"
        Me.lblWait.Size = New System.Drawing.Size(109, 14)
        Me.lblWait.TabIndex = 36
        Me.lblWait.Text = "Please Wait ......"
        Me.lblWait.Visible = False
        '
        'btnCitiSummary
        '
        Me.btnCitiSummary.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCitiSummary.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCitiSummary.Location = New System.Drawing.Point(29, 536)
        Me.btnCitiSummary.Name = "btnCitiSummary"
        Me.btnCitiSummary.Size = New System.Drawing.Size(146, 32)
        Me.btnCitiSummary.TabIndex = 37
        Me.btnCitiSummary.Text = "Citi Summary"
        Me.btnCitiSummary.UseVisualStyleBackColor = True
        Me.btnCitiSummary.Visible = False
        '
        'btnBkBrSum
        '
        Me.btnBkBrSum.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBkBrSum.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBkBrSum.Location = New System.Drawing.Point(575, 341)
        Me.btnBkBrSum.Name = "btnBkBrSum"
        Me.btnBkBrSum.Size = New System.Drawing.Size(204, 33)
        Me.btnBkBrSum.TabIndex = 47
        Me.btnBkBrSum.Text = "BkType Br Summary"
        Me.btnBkBrSum.UseVisualStyleBackColor = True
        '
        'btnBktSummary
        '
        Me.btnBktSummary.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBktSummary.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBktSummary.Location = New System.Drawing.Point(575, 302)
        Me.btnBktSummary.Name = "btnBktSummary"
        Me.btnBktSummary.Size = New System.Drawing.Size(204, 33)
        Me.btnBktSummary.TabIndex = 46
        Me.btnBktSummary.Text = "Book Type Summary"
        Me.btnBktSummary.UseVisualStyleBackColor = True
        '
        'btnBkTypeReport
        '
        Me.btnBkTypeReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBkTypeReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBkTypeReport.Location = New System.Drawing.Point(844, 301)
        Me.btnBkTypeReport.Name = "btnBkTypeReport"
        Me.btnBkTypeReport.Size = New System.Drawing.Size(204, 33)
        Me.btnBkTypeReport.TabIndex = 45
        Me.btnBkTypeReport.Text = "Report by BookType"
        Me.btnBkTypeReport.UseVisualStyleBackColor = True
        Me.btnBkTypeReport.Visible = False
        '
        'txtDelvMode
        '
        Me.txtDelvMode.Location = New System.Drawing.Point(891, 461)
        Me.txtDelvMode.MaxLength = 1
        Me.txtDelvMode.Name = "txtDelvMode"
        Me.txtDelvMode.Size = New System.Drawing.Size(50, 22)
        Me.txtDelvMode.TabIndex = 50
        Me.txtDelvMode.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(797, 465)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 14)
        Me.Label8.TabIndex = 49
        Me.Label8.Text = "Delivery Mode"
        Me.Label8.Visible = False
        '
        'txtBrCodeStart
        '
        Me.txtBrCodeStart.Location = New System.Drawing.Point(893, 491)
        Me.txtBrCodeStart.MaxLength = 4
        Me.txtBrCodeStart.Name = "txtBrCodeStart"
        Me.txtBrCodeStart.Size = New System.Drawing.Size(50, 22)
        Me.txtBrCodeStart.TabIndex = 52
        Me.txtBrCodeStart.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(741, 496)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(132, 14)
        Me.Label9.TabIndex = 51
        Me.Label9.Text = "Br Code Starts With"
        Me.Label9.Visible = False
        '
        'txtFileNo
        '
        Me.txtFileNo.Location = New System.Drawing.Point(634, 128)
        Me.txtFileNo.Name = "txtFileNo"
        Me.txtFileNo.Size = New System.Drawing.Size(85, 22)
        Me.txtFileNo.TabIndex = 54
        Me.txtFileNo.Text = "0"
        Me.txtFileNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(501, 131)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(110, 14)
        Me.Label10.TabIndex = 53
        Me.Label10.Text = "File No (0 for All)"
        '
        'btnBoxReport
        '
        Me.btnBoxReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBoxReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBoxReport.Location = New System.Drawing.Point(576, 261)
        Me.btnBoxReport.Name = "btnBoxReport"
        Me.btnBoxReport.Size = New System.Drawing.Size(204, 33)
        Me.btnBoxReport.TabIndex = 55
        Me.btnBoxReport.Text = "Box Report"
        Me.btnBoxReport.UseVisualStyleBackColor = True
        '
        'txtBoxNo
        '
        Me.txtBoxNo.Location = New System.Drawing.Point(634, 161)
        Me.txtBoxNo.Name = "txtBoxNo"
        Me.txtBoxNo.Size = New System.Drawing.Size(85, 22)
        Me.txtBoxNo.TabIndex = 57
        Me.txtBoxNo.Text = "0"
        Me.txtBoxNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(501, 164)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(112, 14)
        Me.Label11.TabIndex = 56
        Me.Label11.Text = "Box No (0 for All)"
        '
        'rbBothPs
        '
        Me.rbBothPs.AutoSize = True
        Me.rbBothPs.Checked = True
        Me.rbBothPs.Location = New System.Drawing.Point(11, 26)
        Me.rbBothPs.Name = "rbBothPs"
        Me.rbBothPs.Size = New System.Drawing.Size(79, 18)
        Me.rbBothPs.TabIndex = 23
        Me.rbBothPs.TabStop = True
        Me.rbBothPs.Text = "** All **"
        Me.rbBothPs.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.CBPM2011.My.Resources.Resources.ms6
        Me.PictureBox1.Location = New System.Drawing.Point(735, 44)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(191, 162)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 48
        Me.PictureBox1.TabStop = False
        '
        'frmTrnReport
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(938, 393)
        Me.ControlBox = False
        Me.Controls.Add(Me.txtBoxNo)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnBoxReport)
        Me.Controls.Add(Me.txtFileNo)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtBrCodeStart)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtDelvMode)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnBkBrSum)
        Me.Controls.Add(Me.btnBktSummary)
        Me.Controls.Add(Me.btnBkTypeReport)
        Me.Controls.Add(Me.btnCitiSummary)
        Me.Controls.Add(Me.lblWait)
        Me.Controls.Add(Me.btnLeavesSummary)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnCitiProd)
        Me.Controls.Add(Me.ntmBrLeavesSummary)
        Me.Controls.Add(Me.btnDeliveryReport)
        Me.Controls.Add(Me.btnbrSerials)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.lblAccName)
        Me.Controls.Add(Me.btnBrSummary)
        Me.Controls.Add(Me.lstBkType)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtAccNo)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnSummary)
        Me.Controls.Add(Me.btnProductionRep)
        Me.Controls.Add(Me.btnDespatch)
        Me.Controls.Add(Me.lstMailBr)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lstBranch)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtBatchNo)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmTrnReport"
        Me.Text = "Reports"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtpFrm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtBatchNo As System.Windows.Forms.TextBox
    Friend WithEvents lstMailBr As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lstBranch As System.Windows.Forms.ListBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnDespatch As System.Windows.Forms.Button
    Friend WithEvents btnProductionRep As System.Windows.Forms.Button
    Friend WithEvents btnSummary As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents txtAccNo As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lstBkType As System.Windows.Forms.ListBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnBrSummary As System.Windows.Forms.Button
    Friend WithEvents lblAccName As System.Windows.Forms.Label
    Friend WithEvents rbPrinted As System.Windows.Forms.RadioButton
    Friend WithEvents rbPendings As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnbrSerials As System.Windows.Forms.Button
    Friend WithEvents btnDeliveryReport As System.Windows.Forms.Button
    Friend WithEvents ntmBrLeavesSummary As System.Windows.Forms.Button
    Friend WithEvents btnLeavesSummary As System.Windows.Forms.Button
    Friend WithEvents btnCitiProd As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbGold As System.Windows.Forms.RadioButton
    Friend WithEvents rbCorporate As System.Windows.Forms.RadioButton
    Friend WithEvents rbConsumer As System.Windows.Forms.RadioButton
    Friend WithEvents lblWait As System.Windows.Forms.Label
    Friend WithEvents btnCitiSummary As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnBkBrSum As System.Windows.Forms.Button
    Friend WithEvents btnBktSummary As System.Windows.Forms.Button
    Friend WithEvents btnBkTypeReport As System.Windows.Forms.Button
    Friend WithEvents txtDelvMode As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtBrCodeStart As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtFileNo As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnBoxReport As Button
    Friend WithEvents txtBoxNo As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents rbBothPs As RadioButton
End Class
