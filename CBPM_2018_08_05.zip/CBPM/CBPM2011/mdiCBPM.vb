Imports System.Data
Imports System.Data.OleDb
Imports msLib.script


Public Class mdiCBPM

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click

        Me.Close()

    End Sub

    Private Sub mnuBanks_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuBanks.Click



    End Sub

    Private Sub mnuBranches_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuBranches.Click

        'Dim frmBr As New frmBanks
        'Dim s As String

        's = frmBr.ShowDialog(True, False)
        'If s <> msCancel Then
        '    sysvars.SelectedBankCode = s
        'End If



    End Sub

    Private Sub mdiCBPM_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Dim s As String

        s = msAlignText("Developed by : Muahammad Siddique", 40, textAlign.Center) & vbCrLf
        s = s & msAlignText("ms.analyst@outlook.com", 40, textAlign.Center) & vbCrLf
        s = s & msAlignText("Tel: +971 55 7135353", 40, textAlign.Center)
        If Format(Date.Today, "yyyyMMdd") < "200902" Then
            s = " "
        End If

        s = " "

        Me.lblMsname.Text = s
        Me.lblMsname.Text = Vers


        Try
            Kill(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\CBPM*.html")
            msDoEvents()
        Catch ex As Exception

        End Try

        ReadSysvars()
        DispBankName()

        'Dim frmL As New frmLogin
        'frmL.ShowDialog()
        'If CBDUser.UserID = "" Then
        '    End
        'End If

        CBDUser.UserName = "cbpmadmin"

        CBDUser.UserID = "CBPMADMIN"

        getUser()

        msGetHDserialNew("C:\")

        CheckPresence()

        

    End Sub


    Private Sub getUser()

        If UCase(CBDUser.UserID) = "CBPMADMIN" Then
            With CBDUser
                .AccAdd = 1 ' False
                .AccEdit = 1 ' False
                .BankAdd = 1 'False
                .BankEdit = 1 'False
                .BankSelect = 1 ' False
                .BranchAdd = 1 'False
                .BranchEdit = 1 'False
                .CancelCB = 1 'False
                .CBRdownload = 1 ' False
                .ManualEntry = 1 'False
                .PrintFile = 1 'False
                .Reports = 1 'False
                .Reprint = 1
                .Settings = 1
                .UserProfile = 1

            End With
            
            Exit Sub
        End If

        Dim sStr As String
        sStr = "Select * from tblUsers where UserID = '" & CBDUser.UserID & "'"
        Dim dbCn As New OleDbConnection
        If Not msOpenDbConnection(dbCn) Then GoTo gout
        Dim cm As OleDbCommand
        Dim dr As OleDbDataReader
        Try
            cm = New OleDbCommand(sStr, dbCn)
            dr = cm.ExecuteReader
            If dr.Read Then
                With CBDUser
                    .AccAdd = dr.Item("AccAdd")
                    .AccEdit = dr.Item("AccEdit")
                    .BankAdd = dr.Item("BankAdd")
                    .BankEdit = dr.Item("BankEdit")
                    .BankSelect = dr.Item("BankSelect")
                    .BranchAdd = dr.Item("BranchAdd")
                    .BranchEdit = dr.Item("BranchEdit")
                    .CancelCB = dr.Item("CancelCB")
                    .CBRdownload = dr.Item("CBRdownload")
                    .ManualEntry = dr.Item("ManualEntry")
                    .PrintFile = dr.Item("PrintFile")
                    .Reports = dr.Item("Reports")
                    .Reprint = dr.Item("Reprint")
                    .Settings = dr.Item("Settings")
                    .UserProfile = dr.Item("UserProfile")

                End With
                
            End If

            dr.Close()
            cm.Dispose()
        Catch ex As Exception
            msMessagebox(ex.Message, Emoticons.ErrorIcon)

        End Try

        dbCn.Close()

        If CBDUser.UserProfile = 0 Then
            Me.mnuNewUserToolStripMenuItem.Enabled = False
            Me.mnuModifyAccessRightsToolStripMenuItem.Enabled = False
            Me.mnuDeleteUserToolStripMenuItem.Enabled = False

        End If

        If CBDUser.CBRdownload = 0 Then
            Me.mnuDownloadRequestFile.Enabled = False
            Me.tsbDownload.Enabled = False
            Me.mnudownlaodSpecial.Enabled = False
        End If

        If CBDUser.ManualEntry = 0 Then
            Me.mnuManualEntry.Enabled = False
            Me.tsbManualEntry.Enabled = False
        End If

        If CBDUser.PrintFile = 0 Then
            Me.mnuMakePrintBatch.Enabled = False
            Me.tsbPrintBatch.Enabled = False
        End If
        If CBDUser.Reports = 0 Then
            Me.mnuReportsToolStripMenuItem.Enabled = False
            Me.tsbReports.Enabled = False
        End If
        If CBDUser.Reprint = 0 Then
            Me.mnuReprint.Enabled = False
        End If
        If CBDUser.CancelCB = 0 Then
            Me.mnuCancelCB.Enabled = False
        End If
        If CBDUser.Settings = 0 Then
            Me.mnuSettingsToolStripMenuItem.Enabled = False
        End If

gout:

    End Sub

    Public Sub DispBankName()

        Dim f As String
        If sysvars.SelectedBankCode = "" Then
            sysvars.SelectedBankCode = GetSetting("CBPM" & RegSet, "Settings", "SelectedBank", "001")
            Me.lblSelectedBank.Text = ""
        End If

        sysvars.SelectedBankCode = "002"

        Dim dbCnO As New OleDbConnection
            If Not msOpenDbConnection(dbCnO) Then Exit Sub
            Me.lblSelectedBank.Text = msGetFieldValue(dbCnO, "Select BankName from tblBanks where BankCode = '" & sysvars.SelectedBankCode & "'")
            sysvars.SelectedBankName = Me.lblSelectedBank.Text
            f = msGetFieldValue(dbCnO, "Select SerialType from tblBanks where BankCode = '" & sysvars.SelectedBankCode & "'")
            If IsNumeric(f) Then
                sysvars.SerialType = f
            End If

        
    End Sub


    Private Sub MakePrintBatchToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMakePrintBatch.Click



    End Sub

    Private Sub mnuDownloadRequestFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDownloadRequestFile.Click


    End Sub

    Private Sub mnuManualEntry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuManualEntry.Click



    End Sub

    
    Private Sub mnuBookType_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuBookType.Click



    End Sub

    Private Sub ReportsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuReportsToolStripMenuItem.Click

    End Sub

    Private Sub DeliveryReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDeiveryReport.Click

        Dim frmP As New frmTrnReport
        frmP.MdiParent = Me
        frmP.Show()

    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbSelectBank.Click


    End Sub

    Private Sub tsbDownload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbDownload.Click



    End Sub

    Private Sub tsbManualEntry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbManualEntry.Click


    End Sub

    Private Sub tsbPrintBatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbPrintBatch.Click


    End Sub

    Private Sub tsbReports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbReports.Click

        Dim frmP As New frmTrnReport
        frmP.MdiParent = Me
        frmP.Show()

    End Sub

    
    Private Sub mnuReprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuReprint.Click

    End Sub

    
    Private Sub mnuReprintRep_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuReprintRep.Click


    End Sub

    Private Sub mnuChangePasswordToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuChangePasswordToolStripMenuItem.Click



    End Sub

    Private Sub mnuNewUserToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuNewUserToolStripMenuItem.Click



    End Sub

    Private Sub mnuDeleteUserToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDeleteUserToolStripMenuItem.Click

    End Sub

    Private Sub mnuModifyAccessRightsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuModifyAccessRightsToolStripMenuItem.Click



    End Sub

    Private Sub mnuCancelCB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCancelCB.Click


    End Sub

    Private Sub CancelReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelReportToolStripMenuItem.Click


    End Sub

    Private Sub mnuSettingsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSettingsToolStripMenuItem.Click

        'Dim frmset As New frmsetOffice
        'frmset.ShowDialog()
        Dim frmdg As New frmDataGridSample
        frmdg.ShowDialog()

    End Sub

    Private Sub mnudownlaodSpecial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnudownlaodSpecial.Click



    End Sub

    Private Sub EndOfTheDayToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EndOfTheDayToolStripMenuItem.Click



    End Sub

    Private Sub tsbAddressDownload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbAddressDownload.Click


    End Sub

    Private Sub AccountQueryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccountQueryToolStripMenuItem.Click

    End Sub

    Private Sub lblSelectedBank_Click(sender As Object, e As EventArgs) Handles lblSelectedBank.Click

        'frmDataGridSample.Show()
        'Form1.ShowDialog()

        '        Dim m As New mstrain

        '        Dim s As String


        '        s = m.msMsgBox("this is some text to display here" & vbCrLf & "By default, in Normal mode, the Image is positioned in the upper-left corner of the PictureBox, and any part of the image that is too big for the PictureBox is clipped. Using the StretchImage value causes the image to stretch or shrink to fit the PictureBox. Using the Zoom value causes the image to be stretched or shrunk to fit the PictureBox; however, the aspect ratio in the original is maintained.
        '        Using the AutoSize value causes the control to resize to always fit the image. Using the CenterImage value causes the image to be centered in the client area." & vbCrLf & "Step 4
        '        Ok, " & vbCrLf & "thats pretty much it for the DLL so now we can go ahead and save the project, and then build it just like for an application. Now goto the projects Bin/Debug directory and you will find a DLL that you have just created.


        '        Step 7
        'Now lets do some coding. First you need to import it as you would with others. So, above Public Class Form1 type Imports and a list should show up, and select your DLL. Remember I named mine PDUNZDLL - Imports PDUNZDLL.

        'Step 8
        'Now in the Button_Click event, I added this line Dim Add As New PDUNZDLL.MyFunctions. As you can see I declared a name Add for MyFunctions in my DLL (look back at the DLL code. This is so I dont have to type PDUNZDLL.MyFunctions.AddMyValues, instead I can just use Add.AddMyValues.", mstrain.msgboxIcons.emailError, "", "Left", "Middle", "Right", "r", 5)

        '        Dim i As Int16

        '        For i = 0 To 17
        '            m.msMsgBox(s, i)
        '        Next

    End Sub

    Private Sub tsbPackList_Click(sender As Object, e As EventArgs) Handles tsbPackList.Click

        Dim frmp As New frmPacklist
        frmp.MdiParent = Me
        frmp.Show()

    End Sub

    Private Sub tsbPackListA4_Click(sender As Object, e As EventArgs) Handles tsbPackListA4.Click
        Dim frmp As New frmPackListA4
        frmp.MdiParent = Me
        frmp.Show()
    End Sub
End Class
