Public Class frmRepProgress

    Private Sub frmRepProgress_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.prBar.Maximum = All_Tot_recs

    End Sub

    Private Sub btnCan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCan.Click

        Finish_Reporting = True
        Me.Label1.Visible = True
        msDoEvents()

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        If All_Tot_recs <> Me.prBar.Maximum And All_Tot_recs <> 0 Then
            Me.prBar.Maximum = All_Tot_recs
        End If

        If Curr_rec < Me.prBar.Maximum Then
            If Curr_rec < Me.prBar.Value Then Stop
            Me.prBar.Value = Curr_rec
        End If

        msDoEvents()


    End Sub
End Class