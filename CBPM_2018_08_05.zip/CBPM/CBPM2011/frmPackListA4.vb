﻿Imports System.Drawing.Printing

Public Class frmPackListA4

    Dim pgCount As Integer
    Dim arData As List(Of String)
    Dim arPos As Integer

    Private Sub retrieveData()

        Dim s As String
        s = "Select AccountName1, AccountNo, BookType, NoOfLeaves, FrmChq, ToChq, "
        s = s & " RoutingCode, BrEngName "
        s = s & " , FileNo, BoxNo, CBSrNo From tblCBRS where fileNo = " & Val(txtFileNum.Text)

        If Val(txtBoxnum.Text) > 0 Then
            s = s & " and BoxNo = " & Val(txtBoxnum.Text)
        End If

        s = s & " order by RequestNo"

        Dim ds As New DataSet
        Dim w As String
        w = msFillDS(s, ds)

        If ds.Tables.Count < 1 Then Exit Sub

        If ds.Tables(0).Rows.Count < 1 Then Exit Sub

        Dim frmst As New frmStatus
        frmst.Show("Reading data ....")

        Dim i As Integer
        Dim dr As DataRow

        For i = 0 To ds.Tables(0).Rows.Count - 1

            dr = ds.Tables(0).Rows(i)

            s = "A ," & dr("AccountName1") & "," & dr("AccountNo")
            s = s & "," & dr("BookType") & "," & dr("NoOfLeaves")
            s = s & "," & dr("FrmChq") & "," & dr("ToChq")
            s = s & ",1," & dr("RoutingCode") & "," & dr("BrEngName")

            arData.Add(s)

            msDoEvents()

        Next

        frmst.Close()

    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click

        'Dim s As String
        'If My.Computer.FileSystem.FileExists(Me.txtFileNum.Text) Then

        '    's = msGetFileNameOrPath(File_name, "F") & vbCrLf & msStr("-", 40, "-") & vbCrLf
        '    s = My.Computer.FileSystem.ReadAllText(Me.txtFileNum.Text) ', System.Text.Encoding.ASCII)

        '    arData = Split(s, vbCrLf)
        '    arPos = 0

        'Else
        '    MsgBox("File does not exist", MsgBoxStyle.Exclamation)
        '    Exit Sub
        'End If

        If Not IsNumeric(txtFileNum.Text) Then
            MsgBox("Invalid file number", MsgBoxStyle.Critical)
            Exit Sub
        End If

        If Not IsNumeric(txtBoxnum.Text) Then
            txtBoxnum.Text = 0
        End If

        arData = New List(Of String)

        retrieveData()

        If arData.Count <= 0 Then
            MsgBox("Records not found to print", MsgBoxStyle.Exclamation)
            Exit Sub
        End If


        pgCount = 0
        arPos = 0

        Me.btnPrint.Enabled = False

        Me.PrintDialog1.ShowDialog()

        Me.PrintDocument1.PrinterSettings = Me.PrintDialog1.PrinterSettings

        ' not needed
        'PrintDocument1.PrintController = New PrintControllerWithStatusDialog(PrintDocument1.PrintController)


        If Me.chkPreview.Checked Then
            Me.PrintPreviewDialog1.Document = Me.PrintDocument1
            Me.PrintPreviewDialog1.ShowDialog()

        Else
            Me.PrintDocument1.Print()
        End If


        Me.btnPrint.Enabled = True

        txtBoxnum.Text = ""
        txtFileNum.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.FontDialog1.Font = Me.lblPrintFont.Font
        If FontDialog1.ShowDialog() <> DialogResult.Cancel Then
            Me.lblPrintFont.Font = FontDialog1.Font
            Me.lblPrintFont.Text = FontDialog1.Font.Name
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim tM As Single
        Dim lM As Single
        Dim arf() As String
        'arf = Split(arData(arPos), ",")    ' "|")

        'Me.lblPrintFont.Text = arf(7)

        tM = 100
        lM = 20

        Dim LPP As Integer
        Dim cnt As Integer
        '  Dim totpg As Integer

        'LPP = (e.MarginBounds.Height - 100) / Me.lblPrintFont.Font.GetHeight(e.Graphics)
        LPP = 60

        cnt = 0
        ' totpg = Int(arData.Length / LPP) + 1
        ' totpg = Int(arData.Count / LPP) + 1


        'MsgBox(e.MarginBounds.Width & vbCrLf & e.MarginBounds.Height)
        'Exit Sub

        'e.Graphics.DrawLine(Pens.Black, 740, 100, 740, 1050)

        ' header
        e.Graphics.DrawString("Box No.#", Me.lblPrintFont.Font, Brushes.Black, lM, tM - 50)
        e.Graphics.DrawString(txtBoxnum.Text, Me.lblPrintFont.Font, Brushes.Black, lM + 50, tM - 50)
        e.Graphics.DrawString("Sr#", Me.lblPrintFont.Font, Brushes.Black, lM, tM)
        e.Graphics.DrawString("Branch", Me.lblPrintFont.Font, Brushes.Black, lM + 50, tM)
        e.Graphics.DrawString("Name", Me.lblPrintFont.Font, Brushes.Black, lM + 220, tM)
        e.Graphics.DrawString("Acc #", Me.lblPrintFont.Font, Brushes.Black, lM + 460, tM)
        e.Graphics.DrawString("From", Me.lblPrintFont.Font, Brushes.Black, lM + 570, tM)
        e.Graphics.DrawString("To", Me.lblPrintFont.Font, Brushes.Black, lM + 650, tM)
        tM = tM + 22

        Dim sno As Integer

        sno = 0

        Dim fno As Long
        Dim tno As Long
        Dim nol As Integer

        Dim sTemp As String


        Do While True
            'If arPos < arData.Length Then
            If arPos < arData.Count Then
                arf = Split(arData(arPos), ",")   '  "|")
                If arf.Length < 9 Then Exit Do
                sno = sno + 1
                'e.Graphics.DrawString(arf(0), Me.lblPrintFont.Font, Brushes.Black, lM, tM)

                e.Graphics.DrawString(sno, Me.lblPrintFont.Font, Brushes.Black, lM, tM)     'srno
                If arData.Count > 9 Then           ' why?
                    e.Graphics.DrawString(Mid(Trim(arf(9)), 1, 30), Me.lblPrintFont.Font, Brushes.Black, lM + 50, tM)     'br
                End If
                e.Graphics.DrawString(Mid(Trim(arf(1)), 1, 40), Me.lblPrintFont.Font, Brushes.Black, lM + 220, tM)    ' name
                e.Graphics.DrawString(arf(2), Me.lblPrintFont.Font, Brushes.Black, lM + 460, tM)            ' accno
                sTemp = Trim(arf(4))
                If IsNumeric(sTemp) Then
                    nol = Val(sTemp)
                Else
                    nol = 0
                End If

                sTemp = Trim(arf(5))
                If IsNumeric(sTemp) Then
                    fno = Val(sTemp)
                    tno = fno + nol - 1
                Else
                    tno = 0
                End If

                e.Graphics.DrawString(fno, Me.lblPrintFont.Font, Brushes.Black, lM + 570, tM)           ' from 
                e.Graphics.DrawString(tno, Me.lblPrintFont.Font, Brushes.Black, lM + 650, tM)           ' to

                cnt = cnt + 1
                arPos = arPos + 1

                'tM = 100 + cnt * Me.lblPrintFont.Font.GetHeight(e.Graphics)
                tM = tM + 16
            Else
                Exit Do
            End If
        Loop

        'GoTo gt

        tM = 100
        lM = 800

        ' header
        'e.Graphics.DrawString("Sr#", Me.lblPrintFont.Font, Brushes.Black, lM, tM)
        'e.Graphics.DrawString("Branch", Me.lblPrintFont.Font, Brushes.Black, lM + 50, tM)
        'e.Graphics.DrawString("Name", Me.lblPrintFont.Font, Brushes.Black, lM + 220, tM)
        'e.Graphics.DrawString("Acc #", Me.lblPrintFont.Font, Brushes.Black, lM + 460, tM)
        'e.Graphics.DrawString("From", Me.lblPrintFont.Font, Brushes.Black, lM + 570, tM)
        'e.Graphics.DrawString("To", Me.lblPrintFont.Font, Brushes.Black, lM + 650, tM)
        'tM = tM + 22

        'If cnt >= 60 Then
        '    Do While cnt < 120
        '        If arPos < arData.Count Then
        '            arf = Split(arData(arPos), ",")
        '            If arf.Length < 9 Then Exit Do
        '            sno = sno + 1
        '            '-------------------
        '            e.Graphics.DrawString(sno, Me.lblPrintFont.Font, Brushes.Black, lM, tM)     'srno
        '            If arData.Count > 9 Then        ' why ?
        '                e.Graphics.DrawString(Mid(Trim(arf(9)), 1, 30), Me.lblPrintFont.Font, Brushes.Black, lM + 50, tM)     'br
        '            End If
        '            e.Graphics.DrawString(Mid(Trim(arf(1)), 1, 40), Me.lblPrintFont.Font, Brushes.Black, lM + 220, tM)    ' name
        '            e.Graphics.DrawString(arf(2), Me.lblPrintFont.Font, Brushes.Black, lM + 460, tM)            ' accno
        '            sTemp = Trim(arf(4))
        '            If IsNumeric(sTemp) Then
        '                nol = Val(sTemp)
        '            Else
        '                nol = 0
        '            End If

        '            sTemp = Trim(arf(5))
        '            If IsNumeric(sTemp) Then
        '                fno = Val(sTemp)
        '                tno = fno + nol - 1
        '            Else
        '                tno = 0
        '            End If

        '            e.Graphics.DrawString(fno, Me.lblPrintFont.Font, Brushes.Black, lM + 570, tM)           ' from 
        '            e.Graphics.DrawString(tno, Me.lblPrintFont.Font, Brushes.Black, lM + 650, tM)           ' to

        '            '________________________


        '            cnt = cnt + 1
        '            arPos = arPos + 1

        '            tM = tM + 16
        '        Else
        '            Exit Do
        '        End If
        '    Loop
        'End If

        '' hor line
        'e.Graphics.DrawLine(Pens.Black, 20, 118, 1500, 118)

        ''verticle line
        'e.Graphics.DrawLine(Pens.Black, 770, 100, 770, 1050)

gt:

        'e.HasMorePages
        If cnt < LPP Then
            e.HasMorePages = False
            Me.Button1.Enabled = True
        Else
            pgCount = pgCount + 1
            'e.Graphics.DrawString("Page : " & pgCount & " of " & totpg, Me.lblPrintFont.Font, Brushes.Black, lM, tM)
            e.HasMorePages = True
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
End Class