﻿Public Class Form1

    Dim urlTextBox As TextBox

    Dim WithEvents btnUrl As New Button
    Dim WithEvents btnClose As New Button

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Text = "URL Opener"

        Me.Panel1.AutoSize = True
        Me.Panel1.MinimumSize = Me.PictureBox1.Size
        Me.Panel1.AutoSizeMode = Windows.Forms.AutoSizeMode.GrowAndShrink

        Dim flowPanel As New FlowLayoutPanel()
        flowPanel.AutoSize = True
        flowPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel1.Controls.Add(flowPanel)

        Me.lblBlanktop.Text = " "
        flowPanel.Controls.Add(Me.lblBlanktop)
        flowPanel.SetFlowBreak(lblBlanktop, True)
    

        Dim urlLabel As New Label()
        urlLabel.Name = "urlLabel"
        urlLabel.Text = "URL:"
        urlLabel.Text = urlLabel.Text & vbCrLf & "connectivity with rms simplified server for online rpeorting and auto reports"
        urlLabel.Text = urlLabel.Text & vbCrLf & urlLabel.Text
        ' urlLabel.Width = 50
        urlLabel.AutoSize = True

        urlLabel.TextAlign = ContentAlignment.MiddleCenter
        flowPanel.Controls.Add(urlLabel)
        flowPanel.SetFlowBreak(urlLabel, True)

        urlTextBox = New TextBox()
        urlTextBox.Name = "urlTextBox"
        urlTextBox.Width = 250
        flowPanel.Controls.Add(urlTextBox)

        'Dim urlButton As New Button()
        btnUrl.Name = "btnUrl"
        btnUrl.Text = "Open URL in Browser"
        flowPanel.Controls.Add(btnUrl)

        btnClose.Name = "btnClose"
        btnClose.Text = "Close"
        flowPanel.Controls.Add(btnClose)

        flowPanel.SetFlowBreak(urlTextBox, True)

        Me.lblBlankBotton.Text = " "
        flowPanel.Controls.Add(Me.lblBlankBotton)
        flowPanel.SetFlowBreak(lblBlankBotton, True)

    End Sub


    Private Sub btnUrl_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUrl.Click

        Try
            Dim newUri As New Uri(urlTextBox.Text)
        Catch uriEx As UriFormatException
            MessageBox.Show(("Sorry, your URL is malformed. Try again. Error: " + uriEx.Message))
            urlTextBox.ForeColor = Color.Red
            Return
        End Try

        ' Valid URI. Reset any previous error color, and launch the URL in the 
        ' default browser.
        ' NOTE: Depending on the user's settings, this method of starting the
        ' browser may use an existing window in an existing Web browser process.
        ' To get around this, start up a specific browser instance instead using one of
        ' the overloads for Process.Start. You can examine the registry to find the
        ' current default browser and launch that, or hard-code a specific browser.
        urlTextBox.ForeColor = Color.Black
        Process.Start(urlTextBox.Text)
    End Sub


    Private Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

End Class