Public Class frmsetOffice

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Me.Close()

    End Sub

    Private Sub frmsetOffice_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.txtExcelPath.Text = Winreg.ExcelPath
        Me.txtWordPath.Text = Winreg.WordPath
        If Winreg.VerifyAccount <> "0" Then
            Me.chkAccVerify.Checked = True
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Winreg.ExcelPath = Me.txtExcelPath.Text
        SaveSetting("CBPM" & RegSet, "Settings", "ExcelPath", Winreg.ExcelPath)

        Winreg.WordPath = Me.txtWordPath.Text
        SaveSetting("CBPM" & RegSet, "Settings", "WordPath", Winreg.WordPath)

        Winreg.VerifyAccount = IIf(Me.chkAccVerify.Checked, "1", "0")
        SaveSetting("CBPM" & RegSet, "Settings", "VerifyAccount", Winreg.VerifyAccount)

        Me.Close()

    End Sub

End Class