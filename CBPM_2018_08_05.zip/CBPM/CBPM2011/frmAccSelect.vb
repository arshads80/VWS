Imports System.Data
Imports System.Data.OleDb

Public Class frmAccSelect

    Dim PrimeCode As String
    Dim dbCnP As OleDbConnection

    Dim DoClear As Boolean

    Public Overloads Function ShowDialog(ByVal prmPrimeCode As String, Optional ByVal ShowSelect As Boolean = True, Optional ByVal ShowEdits As Boolean = True) As String

        PrimeCode = prmPrimeCode
        If ShowSelect Then
            Me.btnSelect.Visible = True
        Else
            Me.btnSelect.Visible = False
        End If

        If ShowEdits Then
            Me.btnAdd.Visible = True
            Me.btnModify.Visible = True
            Me.btnDel.Visible = True

        Else
            Me.btnAdd.Visible = False
            Me.btnModify.Visible = False
            Me.btnDel.Visible = False

        End If

        ShowDialog()
        ShowDialog = Me.txtAccNo.Text
        dbCnP.Close()


        'Me.Close()

    End Function


    Private Sub frmAccSelect_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.AcceptButton = btnSelect
        Me.CancelButton = btnClose
        msOpenDbConnection(dbCnP)
        PopulateList()

        If PrimeCode <> "" Then
            findById(PrimeCode)
        End If

    End Sub

    Private Sub PopulateList()

        Dim sStr As String
        Dim lstItem As msListItem
        Dim x As Integer
        Dim i As Integer
        i = 1
        sStr = "Select * from tblAccount where AccountNo > '0'"
        If Len(Me.txtAccName.Text) > 0 Then
            sStr = sStr & " and AccountName Like '" & Me.txtAccName.Text & "%'"
        End If
        If Len(Me.txtAccNo.Text) > 0 Then
            sStr = sStr & " and AccountNo Like '" & Me.txtAccNo.Text & "%'"
        End If
        If Me.RadioButton1.Checked Then
            sStr = sStr & " order by AccountName "
        Else
            sStr = sStr & " order by AccountNo "
        End If

        Me.ListBox1.Items.Clear()

        If Len(Me.txtAccNo.Text) > 0 Or Len(Me.txtAccName.Text) > 0 Then

        Else
            Exit Sub
        End If

        Dim f As New frmStatus
        f.Show("Populating Records ... ")

        Try

            x = 0
            Dim cm As OleDbCommand
            Dim dr As OleDbDataReader
            cm = New OleDbCommand(sStr, dbCnP)
            dr = cm.ExecuteReader

            Do While dr.Read
                sStr = msAlignText(dr.Item("AccountNo").ToString, 16) & "-" & dr.Item("AccountName").ToString
                
                lstItem = New msListItem(sStr, dr.Item("AccountNo").ToString)
                x = Me.ListBox1.Items.Add(lstItem)
                i = i + 1
                If i > 300 Then Exit Do
            Loop

            dr.Close()
            cm.Dispose()

        Catch ex As Exception
            msMessagebox(ex.ToString, Emoticons.ErrorIcon)

        End Try
        f.Close()


    End Sub

    Private Sub btnRef_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRef.Click

        ClearScreen()
        PopulateList()
        Me.txtAccName.Focus()

    End Sub

    Private Sub ClearScreen()

        Me.txtAccNo.Text = ""
        Me.txtAccName.Text = ""
        DoClear = False

    End Sub

    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick

        Me.Close()

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

        PopulateForm()

    End Sub

    Private Sub PopulateForm()

        If Me.ListBox1.Items.Count < 1 Then Exit Sub
        If Me.ListBox1.SelectedIndex < 0 Then Me.ListBox1.SelectedIndex = 0
        Dim lstItem As msListItem
        lstItem = CType(Me.ListBox1.SelectedItem, msListItem)
        Me.txtAccNo.Text = lstItem.ID
        Me.txtAccName.Text = getAccDetail(Me.txtAccNo.Text)



gOut:
        'Me.txtDeptID.Text = ""
        'Me.Close()


    End Sub


    Private Sub ListBox1_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ListBox1.Validating

        DoClear = True

    End Sub


    Private Sub btnSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelect.Click

        PopulateForm()
        Me.Close()

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click



        'If IDs <> msCancel Then
        'PopulateList()
        'findbyid(IDs)
        'End If

    End Sub


    Private Sub findById(ByVal prmPID As String)

        If Me.ListBox1.Items.Count > 1 Then
            Dim i As Integer
            Dim lstItem As msListItem
            For i = 0 To Me.ListBox1.Items.Count - 1
                Me.ListBox1.SelectedIndex = i
                lstItem = CType(Me.ListBox1.SelectedItem, msListItem)
                If lstItem.ID = prmPID Then
                    Exit For
                End If
            Next
        End If

    End Sub

    Private Sub btnModify_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModify.Click



    End Sub

    
    Private Sub btnDel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDel.Click

        If Me.ListBox1.SelectedIndex >= 0 Then
            If msMessagebox("Are you sure you want to delete following record?" & vbCrLf & Me.txtAccNo.Text & vbCrLf & Me.txtAccName.Text, Emoticons.QuestionIcon, "Attention", "", "No", "Yes") = "Yes" Then
                If msMessagebox("If you click OK you can not undo the operation", Emoticons.ExclamationIcon2, "Warning", "", "Cancel", "Ok") = "Ok" Then
                    Try
                        'Dim dbCn As New OleDbConnection
                        'If Not OpenDbConnection(dbCn) Then Exit Sub
                        Dim cm As OleDbCommand
                        cm = New OleDbCommand("Delete * from tblAccount where AccountNo = '" & Me.txtAccNo.Text & "'", dbCnP)
                        Dim a As Integer
                        a = cm.ExecuteNonQuery
                        If a > 0 Then
                            msMessagebox("Record deleted")
                            PopulateForm()
                        End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)

                    End Try
                End If
            End If

        End If

    End Sub

    Private Function getAccDetail(ByVal dCode As String) As String

        getAccDetail = ""
        'Dim dbCn As New OleDbConnection
        'If Not OpenDbConnection(dbCn) Then GoTo gOut

        Dim s As String
        s = "Select * from tblAccount where AccountNo = '" & dCode & "'"

        Try
            Dim cm As OleDbCommand
            cm = New OleDbCommand(s, dbCnP)
            Dim dr As OleDbDataReader
            dr = cm.ExecuteReader
            If dr.Read Then
                getAccDetail = Trim(dr.Item("AccountName").ToString)
            End If
            dr.Close()
            cm.Dispose()
        Catch ex As Exception
            msMessagebox(ex.Message, Emoticons.ErrorIcon)

        End Try

gOut:
        '        frmS.Close()

    End Function

    
    Private Sub txtAccName_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAccName.GotFocus
        If DoClear Then
            ClearScreen()
            PopulateList()
        End If
    End Sub

    


    Private Sub txtAccNo_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAccNo.GotFocus
        If DoClear Then
            ClearScreen()
            PopulateList()
        End If

    End Sub

    Private Sub txtAccNo_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtAccNo.KeyUp

        If e.KeyCode = Keys.Down Then
            If Me.ListBox1.Items.Count > 0 Then
                Me.ListBox1.Focus()
                Me.ListBox1.SelectedIndex = 0
            End If
        Else
            PopulateList()
        End If

    End Sub

    Private Sub txtAccNo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAccNo.TextChanged
        'PopulateList()
    End Sub

    Private Sub txtAccName_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtAccName.KeyUp
        If e.KeyCode = Keys.Down Then
            If Me.ListBox1.Items.Count > 0 Then
                Me.ListBox1.Focus()
                Me.ListBox1.SelectedIndex = 0
            End If
        Else
            PopulateList()
        End If

    End Sub

    Private Sub txtAccName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAccName.TextChanged
        'PopulateList()

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.txtAccNo.Text = msCancel
        Me.Hide()

    End Sub
End Class