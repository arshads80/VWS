Imports System.Resources
Imports System.Runtime.InteropServices

Public Class frmReports
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbPrint As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbClose As System.Windows.Forms.ToolStripButton
    Friend WithEvents tscbOpenWith As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents MSWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MSExcelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents tsbSearch As System.Windows.Forms.ToolStripButton

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReports))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.tscbOpenWith = New System.Windows.Forms.ToolStripDropDownButton
        Me.MSWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MSExcelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument
        Me.Button1 = New System.Windows.Forms.Button
        Me.tsbPrint = New System.Windows.Forms.ToolStripButton
        Me.tsbSearch = New System.Windows.Forms.ToolStripButton
        Me.tsbClose = New System.Windows.Forms.ToolStripButton
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbPrint, Me.ToolStripSeparator1, Me.tscbOpenWith, Me.ToolStripSeparator2, Me.tsbSearch, Me.tsbClose})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(788, 39)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "Reporting Toolbar"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 39)
        '
        'tscbOpenWith
        '
        Me.tscbOpenWith.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MSWordToolStripMenuItem, Me.MSExcelToolStripMenuItem})
        Me.tscbOpenWith.Name = "tscbOpenWith"
        Me.tscbOpenWith.Size = New System.Drawing.Size(71, 36)
        Me.tscbOpenWith.Text = "Open With"
        '
        'MSWordToolStripMenuItem
        '
        Me.MSWordToolStripMenuItem.Name = "MSWordToolStripMenuItem"
        Me.MSWordToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.MSWordToolStripMenuItem.Text = "MS Word"
        '
        'MSExcelToolStripMenuItem
        '
        Me.MSExcelToolStripMenuItem.Name = "MSExcelToolStripMenuItem"
        Me.MSExcelToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.MSExcelToolStripMenuItem.Text = "MS Excel"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 39)
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 39)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(788, 511)
        Me.WebBrowser1.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(374, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(90, 39)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "print style 2"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'tsbPrint
        '
        Me.tsbPrint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbPrint.Image = CType(resources.GetObject("tsbPrint.Image"), System.Drawing.Image)
        Me.tsbPrint.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPrint.Name = "tsbPrint"
        Me.tsbPrint.Size = New System.Drawing.Size(36, 36)
        Me.tsbPrint.Text = "Print"
        '
        'tsbSearch
        '
        Me.tsbSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbSearch.Image = Global.CBPM2011.My.Resources.Resources.seach
        Me.tsbSearch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSearch.Name = "tsbSearch"
        Me.tsbSearch.Size = New System.Drawing.Size(36, 36)
        Me.tsbSearch.Text = "Search"
        '
        'tsbClose
        '
        Me.tsbClose.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbClose.Image = CType(resources.GetObject("tsbClose.Image"), System.Drawing.Image)
        Me.tsbClose.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbClose.Name = "tsbClose"
        Me.tsbClose.Size = New System.Drawing.Size(36, 36)
        Me.tsbClose.Text = "Close"
        '
        'frmReports
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(788, 550)
        Me.ControlBox = False
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmReports"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cheque book requisition Report"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Dim RFileName As String
    

    Public Overloads Sub ShowDialog(ByVal repFileName As String)

        RFileName = repFileName
        ShowDialog()

    End Sub

    Public Overloads Sub Show(ByVal repFileName As String)

        RFileName = repFileName
        ShowDialog()

    End Sub

    Private Sub tsbPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbPrint.Click

        Me.WebBrowser1.Focus()

        System.Windows.Forms.SendKeys.SendWait("^a")

        'SendKeys("^a", True)
        Application.DoEvents()
        SendKeys.SendWait("^p")
        Application.DoEvents()


    End Sub

    Private Sub MSWordToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSWordToolStripMenuItem.Click

        'msMessagebox("Option not yet implemented")

        Dim f As String
        f = ""
        Dim fs As New frmStatus
        fs.Show("Opening Microsoft Word, Please wait ...")
        Try
            f = Dir(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.doc")

            If f <> "" Then
                Kill(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.doc")

            End If
            FileCopy(RFileName, My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.doc")
            ' to check here
            'Shell(Winreg.WordPath & " " & Chr(34) & My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.doc" & Chr(34))
            Process.Start(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.doc")

        Catch ex As Exception
            msMessagebox("Err: " & ex.Message, Emoticons.ErrorIcon)

        End Try

        Dim i As Int32
        For i = 1 To 100000
            System.Windows.Forms.Application.DoEvents()
        Next
        fs.Close()

    End Sub

    Private Sub tsbClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbClose.Click
        Me.Close()

    End Sub

    Private Sub frmReports_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'ExcelPath = GetSetting("msReports", "Path", "ExcelPath", "")
        'If ExcelPath = "" Then
        '    SaveSetting("msReports", "Path", "ExcelPath", "C:\Program Files\Microsoft Office\OFFICE11\EXCEL.EXE")
        'End If

        'WordPath = GetSetting("msReports", "Path", "WordPath", "")
        'If WordPath = "" Then
        '    SaveSetting("msReports", "Path", "WordPath", "c:\Program Files\Microsoft Office\OFFICE11\WINWORD.EXE")
        'End If
        'WordPath = "d:\Program Files\Microsoft Office\OFFICE11\WINWORD.EXE"

        Me.WebBrowser1.Navigate(RFileName)

    End Sub

    Private Sub MSExcelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSExcelToolStripMenuItem.Click

        Dim f As String
        f = ""
        Dim fs As New frmStatus
        fs.Show("Opening Microsoft Excel, Please wait ...")

        Try
            f = Dir(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.xls")
            If f <> "" Then
                Kill(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.xls")
            End If

            FileCopy(RFileName, My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.xls")
            ' to check here
            'Shell(Winreg.ExcelPath & " " & Chr(34) & My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.xls" & Chr(34))
            Process.Start(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\MyReport.xls")
        Catch ex As Exception
            msMessagebox("Err: " & ex.Message, Emoticons.ErrorIcon)

        End Try

        Dim i As Int32
        For i = 1 To 100000
            System.Windows.Forms.Application.DoEvents()
        Next
        fs.Close()


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Me.PrintDocument1.DocumentName = RFileName
        Me.PrintDocument1.PrinterSettings.Copies = 1
        'me.PrintDocument1.PrinterSettings.LandscapeAngle =90
        Me.PrintDocument1.Print()

    End Sub

    Private Sub tsbSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbSearch.Click

        Me.WebBrowser1.Focus()

        Application.DoEvents()
        SendKeys.SendWait("^f")
        Application.DoEvents()

    End Sub
End Class
