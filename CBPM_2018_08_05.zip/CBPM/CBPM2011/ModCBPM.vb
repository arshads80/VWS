Imports System.Data
Imports System.Data.OleDb
'Imports CheckDV
Imports System.Net.Mail
Imports System.Net.Mime
Imports System.Net




Module ModCBPM

    Structure sv

        Dim SelectedBankCode As String
        Dim SelectedBankName As String
        Dim SerialType As Integer

        ' import file
        Dim RecordSrNo As Integer
        Dim BankCode As String
        Dim BranchCode As String
        Dim AccountNo As String
        Dim MICRAccount As String
        Dim Name1 As String
        Dim Name2 As String
        Dim LangId As String
        Dim NoOfLeaves As Integer
        Dim BookType As String
        Dim BkDescription As String

        Dim FrmChq As Long
        Dim ToChq As Long
        Dim MailBr As String
        Dim MailBrName As String
        Dim BankRefNo As String
        Dim CurrencyCode As String
        Dim SwiftCode As String
        Dim Currency As String
        Dim ReqBr As String
        Dim MisMessage As String
        Dim Remarks As String

        ' not in file
        Dim RoutingCode As String
        Dim BrEngName As String
        Dim BrArbName As String
        Dim BrEngAddress As String
        Dim BrArbAddress As String

        Dim AccId As Long

        ' added for adcb
        Dim curPath As String
        Dim UseThisPathOnly As String

        ' added for arab bank
        Dim NoOfBooks As Integer

        ' added for Invest bank
        Dim BatchKey As String   ' used for record ref code from bank

        ' addded for citi bank
        Dim Filler1 As String
        Dim MarkerID As String
        Dim TransDate As String
        Dim TransTime As String
        Dim Source As String
        Dim Origin As String
        Dim CheckType As String
        Dim Control1 As String
        Dim Control2 As String
        Dim ApplicationID As String
        Dim CustType As String
        Dim DeliveryMode As String       'DispatchMode As String
        Dim ClearingCode As String
        Dim OrdPos As Integer

        Dim Iban As String

        ' for future use
        Dim BookSize As String
        Dim CB1 As String
        Dim CB2 As String
        Dim CB3 As String
        Dim AC1 As String
        Dim AC2 As String
        Dim AC3 As String
        Dim BN1 As String
        Dim BN2 As String
        Dim BN3 As String

        ' for ENBD
        Dim GCCmes As String
        Dim NrFlag As Integer

        ' for DIB
        Dim VipFlag As String


    End Structure

    ' No need now
    'Structure WR
    '    Dim ExcelPath As String
    '    Dim WordPath As String
    '    Dim VerifyAccount As String
    'End Structure

    'Public Winreg As WR
    '----------------------


    Public sysvars As sv

    Structure Usr

        Dim UserName As String
        Dim UserPass As String
        Dim UserID As String
        Dim BankSelect As Integer
        Dim BankAdd As Integer
        Dim BankEdit As Integer
        Dim BranchAdd As Integer
        Dim BranchEdit As Integer
        Dim AccAdd As Integer
        Dim AccEdit As Integer
        Dim CBRdownload As Integer
        Dim ManualEntry As Integer
        Dim PrintFile As Integer
        Dim Reports As Integer
        Dim Reprint As Integer
        Dim CancelCB As Integer
        Dim Settings As Integer
        Dim UserProfile As Integer


    End Structure

    Public CBDUser As Usr

    Public RegSet As String

    Public Const Vers As String = "Cheque Book Print Management (CBPM)" & vbCrLf & "Version 5.6.0 Release in July 2018"         '  & vbCrLf & "www.aijunction.com"

    Public Const Custcode As String = "EPFLibya"

    Public Const DbTyp As String = "2007"   ' 2007 accss 2003 or 2010 database


    Public Sub main()

        ' not in use

        RegSet = ""

        ReadSysvars()

        ' login


    End Sub


    Public Sub ReadSysvars()

        sysvars.SelectedBankCode = "003"   'Dubai Islamic Bank  GetSetting("CBPM", "Settings", "SelectedBank", "") to do for npp
        'sysvars.SelectedBankCode = GetSetting("CBPM", "Settings", "SelectedBank", "")   ' to do for npp
        RegSet = "EPFLibya"    ' for omieara    sysvars.SelectedBankCode  ' to do for npp to keep setting of each bank separately
        'Winreg.ExcelPath = GetSetting("CBPM" & RegSet, "Settings", "ExcelPath", "C:\Program Files\Microsoft Office\OFFICE12\EXCEL.EXE")
        'Winreg.WordPath = GetSetting("CBPM" & RegSet, "Settings", "WordPath", "c:\Program Files\Microsoft Office\OFFICE12\WINWORD.EXE")
        'Winreg.VerifyAccount = GetSetting("CBPM" & RegSet, "Settings", "VerifyAccount", "0")
        sysvars.curPath = My.Computer.FileSystem.CurrentDirectory
        sysvars.UseThisPathOnly = "0"

    End Sub

    Public Function IsMyAccountCheckOK(ByVal Accno As String) As Boolean

        'Dim cdv As New CheckDV.CheckDV
        'IsMyAccountCheckOK = cdv.IsAccountOK(Accno)

    End Function

    Public Function IsMyRoutingCheckOK(ByVal rCode As String) As Boolean

        'Dim cdv As New CheckDV.CheckDV
        'IsMyRoutingCheckOK = cdv.IsRoutingOK(rCode)

    End Function

    Public Function GetRCode(ByVal rCode As String) As String

        GetRCode = rCode
        Exit Function

        'GetRCode = ""

        'Dim cData As String
        'cData = Mid(rCode, 1, 7)

        'If Not IsNumeric(rCode) Then Exit Function

        'Dim i As Integer
        'Dim iSum As Integer
        'iSum = 0

        'Dim cCode As String
        'cCode = "731"

        'Dim j As Integer
        'j = 1

        'For i = Len(cData) To 1 Step -1
        '    iSum = iSum + (Mid(cData, i, 1) * Mid(cCode, j, 1))
        '    j = j + 1
        '    If j > 3 Then j = 1
        'Next

        'Dim CDV As Integer

        'CDV = iSum Mod 10

        'GetRCode = cData & CDV

    End Function

    Public Function GetAccNum(ByVal AccNum As String) As String

        GetAccNum = ""

        If Not IsNumeric(AccNum) Then Exit Function

        Dim cData As String
        cData = Mid(AccNum, 1, 14)

        Dim i As Integer
        Dim iSum As Integer
        iSum = 0

        Dim cCode As String
        cCode = "731"

        Dim j As Integer
        j = 1

        For i = Len(cData) To 1 Step -1
            iSum = iSum + (Mid(cData, i, 1) * Mid(cCode, j, 1))
            j = j + 1
            If j > 3 Then j = 1
        Next

        Dim CDV As Integer

        CDV = iSum Mod 10

        GetAccNum = cData & CDV

    End Function

    Public PrCode As String
    Public ukCheksum As String

    Private Declare Function GetVolumeInformation Lib "kernel32" Alias "GetVolumeInformationA" (ByVal lpRootPathName As String, ByVal lpVolumeNameBuffer As String, ByVal nVolumeNameSize As Integer, ByRef lpVolumeSerialNumber As Integer, ByRef lpMaximumComponentLength As Integer, ByRef lpFileSystemFlags As Integer, ByVal lpFileSystemNameBuffer As String, ByVal nFileSystemNameSize As Integer) As Integer

    Public Function msGetHDserialNew(ByVal rDr As String) As String

        Dim root As String
        Dim volume_name As String
        Dim serial_number As Integer
        Dim max_component_length As Integer
        Dim file_system_flags As Integer
        Dim file_system_name As String
        Dim pos As Integer

        root = rDr
        volume_name = Space(1024)
        file_system_name = Space(1024)

        If GetVolumeInformation(root, volume_name, Len(volume_name), serial_number, max_component_length, file_system_flags, file_system_name, Len(file_system_name)) = 0 Then
            MessageBox.Show("Error getting volume information.", "Error Getting Information", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            msGetHDserialNew = ""
            Exit Function
        End If

        pos = volume_name.IndexOf(Chr(0))
        volume_name = volume_name.Substring(0, pos)

        PrCode = serial_number.ToString

        If Len(PrCode) > 6 Then
            PrCode = Mid(PrCode, 2, 6)

        Else
            PrCode = "0"  ' "74021"

        End If

        msGetHDserialNew = PrCode

    End Function


    Dim toMonOk As Integer
    Dim mdt As Integer


    Public Sub CheckPresence()

        toMonOk = GetSetting("cbpm", "Settings", "tom", "0")
        mdt = GetSetting("cbpm", "Settings", "mdt", "0")

        Dim sendOk As Integer

        If Val(toMonOk) = 0 Then
            If Date.Today.Day > 25 And Date.Today.Day < 30 Then
                sendOk = 0
                Try
                    sendOk = SendPresence()
                Catch ex As Exception

                End Try

                If sendOk = 0 Then
                    toMonOk = 1
                    SaveSetting("cbpm", "Settings", "tom", "1")
                End If
            End If

        Else   ' to monok = 1
            If Date.Today.Day < 25 Then
                toMonOk = 0
                SaveSetting("cbpm", "Settings", "tom", "0")
            End If
        End If


    End Sub

    Public Function msProperCtext(ByVal mText As String) As String

        Dim s As String
        's = msDecryptData(mText)
        s = msUniformText(mText, "ErinLee")
        If Mid(s, 1, 1) = "1" Then
            msProperCtext = s
        Else
            msProperCtext = "0"
        End If

    End Function

    Private Function SendPresence(Optional ByVal presenceType As String = "N") As Integer

        SendPresence = 0
        If msIsInternetOk("www.yahoo.com") Then
            ' ok 
        Else
            SendPresence = 1    ' can not reach intenet
            Exit Function
        End If

        Dim NetMail As New Net.Mail.MailMessage
        Dim MailClient As New Net.Mail.SmtpClient
        Dim TheseCredentials As New Net.NetworkCredential
        TheseCredentials = New Net.NetworkCredential(Mid(msProperCtext("999IZ60QP1H8A20EU243T4F2U30ER6Z5Z63L3LA65KM47CF25KH87CM40Q9IN39IF2P1A6I5Z55KA6"), 2), Mid(msProperCtext("X2R7M70QG2S8D4T4A6435T"), 2))

        Dim comname As String

        Try
            comname = My.Computer.Name
        Catch ex As Exception
            comname = "CBPM_Blom"
        End Try

        Dim sB As String

        'sB =   Sysvars.SMTPhost & "<BR>" & Sysvars.FromEmail & " <BR> " & Sysvars.EmailPW & " <BR> " & Me.txtemailsCount.Text

        sB = Format(Date.Today, "yyyy-MM-dd") & "|"
        sB = sB & comname & "|"
        sB = sB & PrCode & "|"
        sB = sB & "CBPM_ENBD" & "|"
        sB = sB & " |"
        sB = sB & " |"              'dCalls & "|"  
        sB = sB & " |"              'sVers & "|"
        sB = sB & " |"              'Sysvars.ToEmail1 & "|"
        sB = sB & " |"              'Sysvars.ToEmail2 & "|"
        sB = sB & " |"              'Sysvars.ToEmail3 & "|"
        sB = sB & ukCheksum & "|"
        sB = sB & presenceType          ' n normal, p presence on demand, l log, r report

        Try
            'NetMail.From = New Net.Mail.MailAddress("mailsfrom<cms@legendspeeddubai.com>")
            NetMail.From = New Net.Mail.MailAddress(Mid(msProperCtext("M999D6W8H29IZ60QP1H8A20EU243T4F2U30ER6Z5Z63L3LA65KM47CF25KH87CM40Q9IN39IF2P1A6I5Z55KA65S"), 2))   ' "CMS<sager5629kt46@callmonitoringsystem.com>")
            NetMail.To.Add(New Net.Mail.MailAddress(Mid(msProperCtext("U799D6W8H2E5H8P19IP1M4Z5P1R6Z5Z63L3LA65KM47CF25KH87CM40Q9IN39IF2P1A6I5Z55KA65S"), 2))) '"CMS<presence@callmonitoringsystem.com>"))

            NetMail.IsBodyHtml = True
            NetMail.Subject = "CBPM Present - " & Mid(comname, 1, 15)

            NetMail.Body = sB

            'Dim att As Net.Mail.Attachment
            If presenceType = "L" Then
                'Dim fLog As String
                'fLog = "Activity_" & Format(Date.Today, "yyyyMM") & ".log"
                'If Dir(fLog) > "" Then
                '    att = New Net.Mail.Attachment(fLog)
                '    NetMail.Attachments.Add(att)
                'End If

            ElseIf presenceType = "R" Then

                'If Dir(Sendfile) > "" Then
                '    att = New Net.Mail.Attachment(Sendfile)
                '    NetMail.Attachments.Add(att)
                'End If

            ElseIf presenceType = "D" Then
                'If Dir(dbpath) > "" Then
                '    att = New Net.Mail.Attachment(dbpath)
                '    NetMail.Attachments.Add(att)
                'End If

            End If


            NetMail.Priority = MailPriority.Normal

            MailClient.Host = Mid(msProperCtext("O0A6Z67C3LI5Z5Z63L3LA65KM47CF25KH87CM40Q9IN39IF2P1A6I5Z55KA6"), 2)   '  "mail.callmonitoringsystem.com"
            MailClient.Port = 25
            MailClient.UseDefaultCredentials = False
            MailClient.Credentials = TheseCredentials
            MailClient.Send(NetMail)

            'dCalls = 0

        Catch EXC As Exception

            MsgBox(EXC.ToString)
            'Trace.Warn(EXC.Message)
            'Me.lblMsg.Text = EXC.Message & "Init mails"
            SendPresence = 3

        Finally

        End Try

        NetMail.Dispose()
        NetMail = Nothing
        MailClient = Nothing

    End Function

    Public Function msUniformText(ByVal mText As String, ByVal pw As String) As String

        msUniformText = ""

        If pw = "ErinLee" Then
            Dim s As String
            s = msDecryptData(mText)
            msUniformText = s

        End If

    End Function

End Module
