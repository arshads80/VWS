﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPacklist
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPacklist))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtFileNum = New System.Windows.Forms.TextBox()
        Me.txtBoxnum = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.chkPreview = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblPrintFont = New System.Windows.Forms.Label()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(43, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "File No."
        '
        'txtFileNum
        '
        Me.txtFileNum.Location = New System.Drawing.Point(193, 40)
        Me.txtFileNum.MaxLength = 6
        Me.txtFileNum.Name = "txtFileNum"
        Me.txtFileNum.Size = New System.Drawing.Size(115, 23)
        Me.txtFileNum.TabIndex = 1
        Me.txtFileNum.Text = "0"
        Me.txtFileNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBoxnum
        '
        Me.txtBoxnum.Location = New System.Drawing.Point(217, 79)
        Me.txtBoxnum.MaxLength = 4
        Me.txtBoxnum.Name = "txtBoxnum"
        Me.txtBoxnum.Size = New System.Drawing.Size(91, 23)
        Me.txtBoxnum.TabIndex = 3
        Me.txtBoxnum.Text = "0"
        Me.txtBoxnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(42, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Box No. (0 for all)"
        '
        'chkPreview
        '
        Me.chkPreview.AutoSize = True
        Me.chkPreview.Location = New System.Drawing.Point(46, 154)
        Me.chkPreview.Name = "chkPreview"
        Me.chkPreview.Size = New System.Drawing.Size(152, 20)
        Me.chkPreview.TabIndex = 13
        Me.chkPreview.Text = "Open Print Preview"
        Me.chkPreview.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(122, 189)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(81, 31)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Font"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblPrintFont
        '
        Me.lblPrintFont.AutoSize = True
        Me.lblPrintFont.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.lblPrintFont.ForeColor = System.Drawing.Color.DarkRed
        Me.lblPrintFont.Location = New System.Drawing.Point(43, 122)
        Me.lblPrintFont.Name = "lblPrintFont"
        Me.lblPrintFont.Size = New System.Drawing.Size(68, 13)
        Me.lblPrintFont.TabIndex = 11
        Me.lblPrintFont.Text = "Printing Font"
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(237, 189)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(120, 31)
        Me.btnPrint.TabIndex = 10
        Me.btnPrint.Text = "Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(385, 189)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(82, 31)
        Me.btnClose.TabIndex = 14
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'frmPacklist
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(479, 237)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.chkPreview)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblPrintFont)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.txtBoxnum)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtFileNum)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmPacklist"
        Me.Text = "Cheque Books Packing List"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtFileNum As TextBox
    Friend WithEvents txtBoxnum As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents chkPreview As CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents lblPrintFont As Label
    Friend WithEvents btnPrint As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents PrintDialog1 As PrintDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents FontDialog1 As FontDialog
End Class
