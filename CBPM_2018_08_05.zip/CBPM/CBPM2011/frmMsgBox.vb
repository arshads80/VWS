
Public Class frmMsgBox
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents pbSad As System.Windows.Forms.PictureBox
    Friend WithEvents pbOk As System.Windows.Forms.PictureBox
    Friend WithEvents pbHappy As System.Windows.Forms.PictureBox
    Friend WithEvents pbError As System.Windows.Forms.PictureBox
    Friend WithEvents pbExclamation As System.Windows.Forms.PictureBox
    Friend WithEvents pbQuesMark As System.Windows.Forms.PictureBox
    Friend WithEvents pbHappy2 As System.Windows.Forms.PictureBox
    Friend WithEvents pbWrongEntry As System.Windows.Forms.PictureBox
    Friend WithEvents pbError2 As System.Windows.Forms.PictureBox
    Friend WithEvents pbTeleMessage As System.Windows.Forms.PictureBox
    Friend WithEvents pbStop As System.Windows.Forms.PictureBox
    Friend WithEvents pbTeasing As System.Windows.Forms.PictureBox
    Friend WithEvents pbTesing2 As System.Windows.Forms.PictureBox
    Friend WithEvents pbExclamation2 As System.Windows.Forms.PictureBox
    Friend WithEvents pbOk2 As System.Windows.Forms.PictureBox
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMsgBox))
        Me.pbHappy = New System.Windows.Forms.PictureBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.btn3 = New System.Windows.Forms.Button
        Me.btn2 = New System.Windows.Forms.Button
        Me.btn1 = New System.Windows.Forms.Button
        Me.pbSad = New System.Windows.Forms.PictureBox
        Me.pbOk = New System.Windows.Forms.PictureBox
        Me.pbError = New System.Windows.Forms.PictureBox
        Me.pbExclamation = New System.Windows.Forms.PictureBox
        Me.pbQuesMark = New System.Windows.Forms.PictureBox
        Me.pbHappy2 = New System.Windows.Forms.PictureBox
        Me.pbWrongEntry = New System.Windows.Forms.PictureBox
        Me.pbError2 = New System.Windows.Forms.PictureBox
        Me.pbTeleMessage = New System.Windows.Forms.PictureBox
        Me.pbStop = New System.Windows.Forms.PictureBox
        Me.pbTeasing = New System.Windows.Forms.PictureBox
        Me.pbTesing2 = New System.Windows.Forms.PictureBox
        Me.pbExclamation2 = New System.Windows.Forms.PictureBox
        Me.pbOk2 = New System.Windows.Forms.PictureBox
        Me.lblMessage = New System.Windows.Forms.Label
        CType(Me.pbHappy, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.pbSad, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbOk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbExclamation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbQuesMark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbHappy2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbWrongEntry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbError2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbTeleMessage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbStop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbTeasing, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbTesing2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbExclamation2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbOk2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pbHappy
        '
        Me.pbHappy.Image = CType(resources.GetObject("pbHappy.Image"), System.Drawing.Image)
        Me.pbHappy.Location = New System.Drawing.Point(16, 32)
        Me.pbHappy.Name = "pbHappy"
        Me.pbHappy.Size = New System.Drawing.Size(48, 48)
        Me.pbHappy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbHappy.TabIndex = 0
        Me.pbHappy.TabStop = False
        Me.pbHappy.Tag = "21"
        Me.pbHappy.Visible = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btn3)
        Me.Panel1.Controls.Add(Me.btn2)
        Me.Panel1.Controls.Add(Me.btn1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 96)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(424, 48)
        Me.Panel1.TabIndex = 1
        '
        'btn3
        '
        Me.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn3.ForeColor = System.Drawing.Color.Navy
        Me.btn3.Image = CType(resources.GetObject("btn3.Image"), System.Drawing.Image)
        Me.btn3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn3.Location = New System.Drawing.Point(304, 8)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(104, 32)
        Me.btn3.TabIndex = 2
        Me.btn3.Text = "Na Guma"
        Me.btn3.Visible = False
        '
        'btn2
        '
        Me.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn2.ForeColor = System.Drawing.Color.Navy
        Me.btn2.Image = CType(resources.GetObject("btn2.Image"), System.Drawing.Image)
        Me.btn2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn2.Location = New System.Drawing.Point(192, 8)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(104, 32)
        Me.btn2.TabIndex = 1
        Me.btn2.Text = "Cancel"
        Me.btn2.Visible = False
        '
        'btn1
        '
        Me.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn1.ForeColor = System.Drawing.Color.Navy
        Me.btn1.Image = CType(resources.GetObject("btn1.Image"), System.Drawing.Image)
        Me.btn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn1.Location = New System.Drawing.Point(80, 8)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(104, 32)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "Ok"
        Me.btn1.Visible = False
        '
        'pbSad
        '
        Me.pbSad.Image = CType(resources.GetObject("pbSad.Image"), System.Drawing.Image)
        Me.pbSad.Location = New System.Drawing.Point(16, 32)
        Me.pbSad.Name = "pbSad"
        Me.pbSad.Size = New System.Drawing.Size(48, 48)
        Me.pbSad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbSad.TabIndex = 4
        Me.pbSad.TabStop = False
        Me.pbSad.Tag = "71"
        Me.pbSad.Visible = False
        '
        'pbOk
        '
        Me.pbOk.Image = CType(resources.GetObject("pbOk.Image"), System.Drawing.Image)
        Me.pbOk.Location = New System.Drawing.Point(16, 32)
        Me.pbOk.Name = "pbOk"
        Me.pbOk.Size = New System.Drawing.Size(48, 48)
        Me.pbOk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbOk.TabIndex = 5
        Me.pbOk.TabStop = False
        Me.pbOk.Tag = "51"
        Me.pbOk.Visible = False
        '
        'pbError
        '
        Me.pbError.Image = CType(resources.GetObject("pbError.Image"), System.Drawing.Image)
        Me.pbError.Location = New System.Drawing.Point(16, 32)
        Me.pbError.Name = "pbError"
        Me.pbError.Size = New System.Drawing.Size(48, 48)
        Me.pbError.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbError.TabIndex = 6
        Me.pbError.TabStop = False
        Me.pbError.Tag = "31"
        Me.pbError.Visible = False
        '
        'pbExclamation
        '
        Me.pbExclamation.Image = CType(resources.GetObject("pbExclamation.Image"), System.Drawing.Image)
        Me.pbExclamation.Location = New System.Drawing.Point(16, 32)
        Me.pbExclamation.Name = "pbExclamation"
        Me.pbExclamation.Size = New System.Drawing.Size(48, 48)
        Me.pbExclamation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbExclamation.TabIndex = 7
        Me.pbExclamation.TabStop = False
        Me.pbExclamation.Tag = "41"
        Me.pbExclamation.Visible = False
        '
        'pbQuesMark
        '
        Me.pbQuesMark.Image = CType(resources.GetObject("pbQuesMark.Image"), System.Drawing.Image)
        Me.pbQuesMark.Location = New System.Drawing.Point(16, 32)
        Me.pbQuesMark.Name = "pbQuesMark"
        Me.pbQuesMark.Size = New System.Drawing.Size(48, 48)
        Me.pbQuesMark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbQuesMark.TabIndex = 8
        Me.pbQuesMark.TabStop = False
        Me.pbQuesMark.Tag = "61"
        Me.pbQuesMark.Visible = False
        '
        'pbHappy2
        '
        Me.pbHappy2.Image = CType(resources.GetObject("pbHappy2.Image"), System.Drawing.Image)
        Me.pbHappy2.Location = New System.Drawing.Point(16, 32)
        Me.pbHappy2.Name = "pbHappy2"
        Me.pbHappy2.Size = New System.Drawing.Size(48, 48)
        Me.pbHappy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbHappy2.TabIndex = 9
        Me.pbHappy2.TabStop = False
        Me.pbHappy2.Tag = "22"
        Me.pbHappy2.Visible = False
        '
        'pbWrongEntry
        '
        Me.pbWrongEntry.Image = CType(resources.GetObject("pbWrongEntry.Image"), System.Drawing.Image)
        Me.pbWrongEntry.Location = New System.Drawing.Point(16, 32)
        Me.pbWrongEntry.Name = "pbWrongEntry"
        Me.pbWrongEntry.Size = New System.Drawing.Size(48, 48)
        Me.pbWrongEntry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbWrongEntry.TabIndex = 10
        Me.pbWrongEntry.TabStop = False
        Me.pbWrongEntry.Tag = "101"
        Me.pbWrongEntry.Visible = False
        '
        'pbError2
        '
        Me.pbError2.Image = CType(resources.GetObject("pbError2.Image"), System.Drawing.Image)
        Me.pbError2.Location = New System.Drawing.Point(16, 32)
        Me.pbError2.Name = "pbError2"
        Me.pbError2.Size = New System.Drawing.Size(48, 48)
        Me.pbError2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbError2.TabIndex = 11
        Me.pbError2.TabStop = False
        Me.pbError2.Tag = "32"
        Me.pbError2.Visible = False
        '
        'pbTeleMessage
        '
        Me.pbTeleMessage.Image = CType(resources.GetObject("pbTeleMessage.Image"), System.Drawing.Image)
        Me.pbTeleMessage.Location = New System.Drawing.Point(16, 32)
        Me.pbTeleMessage.Name = "pbTeleMessage"
        Me.pbTeleMessage.Size = New System.Drawing.Size(48, 48)
        Me.pbTeleMessage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbTeleMessage.TabIndex = 12
        Me.pbTeleMessage.TabStop = False
        Me.pbTeleMessage.Tag = "91"
        Me.pbTeleMessage.Visible = False
        '
        'pbStop
        '
        Me.pbStop.Image = CType(resources.GetObject("pbStop.Image"), System.Drawing.Image)
        Me.pbStop.Location = New System.Drawing.Point(16, 32)
        Me.pbStop.Name = "pbStop"
        Me.pbStop.Size = New System.Drawing.Size(48, 48)
        Me.pbStop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbStop.TabIndex = 13
        Me.pbStop.TabStop = False
        Me.pbStop.Tag = "81"
        Me.pbStop.Visible = False
        '
        'pbTeasing
        '
        Me.pbTeasing.Image = CType(resources.GetObject("pbTeasing.Image"), System.Drawing.Image)
        Me.pbTeasing.Location = New System.Drawing.Point(16, 32)
        Me.pbTeasing.Name = "pbTeasing"
        Me.pbTeasing.Size = New System.Drawing.Size(48, 48)
        Me.pbTeasing.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbTeasing.TabIndex = 14
        Me.pbTeasing.TabStop = False
        Me.pbTeasing.Tag = "111"
        Me.pbTeasing.Visible = False
        '
        'pbTesing2
        '
        Me.pbTesing2.Image = CType(resources.GetObject("pbTesing2.Image"), System.Drawing.Image)
        Me.pbTesing2.Location = New System.Drawing.Point(16, 32)
        Me.pbTesing2.Name = "pbTesing2"
        Me.pbTesing2.Size = New System.Drawing.Size(48, 48)
        Me.pbTesing2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbTesing2.TabIndex = 15
        Me.pbTesing2.TabStop = False
        Me.pbTesing2.Tag = "112"
        Me.pbTesing2.Visible = False
        '
        'pbExclamation2
        '
        Me.pbExclamation2.Image = CType(resources.GetObject("pbExclamation2.Image"), System.Drawing.Image)
        Me.pbExclamation2.Location = New System.Drawing.Point(16, 32)
        Me.pbExclamation2.Name = "pbExclamation2"
        Me.pbExclamation2.Size = New System.Drawing.Size(48, 48)
        Me.pbExclamation2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbExclamation2.TabIndex = 16
        Me.pbExclamation2.TabStop = False
        Me.pbExclamation2.Tag = "42"
        Me.pbExclamation2.Visible = False
        '
        'pbOk2
        '
        Me.pbOk2.Image = CType(resources.GetObject("pbOk2.Image"), System.Drawing.Image)
        Me.pbOk2.Location = New System.Drawing.Point(16, 32)
        Me.pbOk2.Name = "pbOk2"
        Me.pbOk2.Size = New System.Drawing.Size(56, 56)
        Me.pbOk2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbOk2.TabIndex = 17
        Me.pbOk2.TabStop = False
        Me.pbOk2.Tag = "52"
        Me.pbOk2.Visible = False
        '
        'lblMessage
        '
        Me.lblMessage.Dock = System.Windows.Forms.DockStyle.Right
        Me.lblMessage.ForeColor = System.Drawing.Color.Navy
        Me.lblMessage.Location = New System.Drawing.Point(80, 0)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(344, 96)
        Me.lblMessage.TabIndex = 18
        Me.lblMessage.Text = "This is test string. Check alignment"
        Me.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmMsgBox
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(7, 16)
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(424, 144)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.pbOk2)
        Me.Controls.Add(Me.pbHappy)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pbError2)
        Me.Controls.Add(Me.pbWrongEntry)
        Me.Controls.Add(Me.pbHappy2)
        Me.Controls.Add(Me.pbExclamation)
        Me.Controls.Add(Me.pbError)
        Me.Controls.Add(Me.pbOk)
        Me.Controls.Add(Me.pbSad)
        Me.Controls.Add(Me.pbQuesMark)
        Me.Controls.Add(Me.pbStop)
        Me.Controls.Add(Me.pbTeleMessage)
        Me.Controls.Add(Me.pbExclamation2)
        Me.Controls.Add(Me.pbTesing2)
        Me.Controls.Add(Me.pbTeasing)
        Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.DarkBlue
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmMsgBox"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Attention"
        CType(Me.pbHappy, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        CType(Me.pbSad, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbOk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbExclamation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbQuesMark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbHappy2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbWrongEntry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbError2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbTeleMessage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbStop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbTeasing, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbTesing2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbExclamation2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbOk2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Public Overloads Function ShowDialog(ByVal cMsg As String, ByVal bt1 As String, ByVal bt2 As String, ByVal bt3 As String, ByVal iconCode As Integer, ByVal cTitle As String) As String

        Me.lblMessage.Text = cMsg
        If iconCode > 30 And iconCode < 40 Then
            Me.lblMessage.ForeColor = System.Drawing.Color.Red

        End If



        If Len(cMsg) > 160 Then
            Me.Height = 216

        End If
        If Len(cMsg) > 300 Then
            Me.Width = 550
            Me.lblMessage.Width = 470
        End If

        If bt1 <> "" Then
            btn1.Visible = True
            btn1.Text = bt1

        End If

        If bt2 <> "" Then
            btn2.Visible = True
            btn2.Text = bt2

        End If

        If bt3 <> "" Then
            btn3.Visible = True
            btn3.Text = bt3

        End If

        '''''''''''''''''''''''''
        Dim p As System.Windows.Forms.Control
        For Each p In Me.Controls
            If TypeOf p Is PictureBox Then
                If iconCode.ToString = p.Tag Then
                    p.Visible = True
                    Exit For
                End If
            End If

        Next
        ''''''''''''''''''''''
        If cTitle <> "" Then
            Me.Text = cTitle
        End If

        Me.ShowDialog()

        ShowDialog = Me.Tag
        Me.Close()

    End Function


    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click

        Me.Tag = btn1.Text
        Me.Hide()

    End Sub


    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        Me.Tag = btn2.Text
        Me.Hide()

    End Sub

    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        Me.Tag = btn3.Text
        Me.Hide()

    End Sub



    Private Sub frmMsgBox_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
