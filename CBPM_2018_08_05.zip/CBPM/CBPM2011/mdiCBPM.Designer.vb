<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mdiCBPM
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mdiCBPM))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAccountsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBranches = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBanks = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNewUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifyAccessRightsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDeleteUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuProcess = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDownloadRequestFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnudownlaodSpecial = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManualEntry = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuMakePrintBatch = New System.Windows.Forms.ToolStripMenuItem()
        Me.EndOfTheDayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDeiveryReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.LabelReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.AccountQueryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChequeNosQueryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuReprintRep = New System.Windows.Forms.ToolStripMenuItem()
        Me.CancelReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilitiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReprint = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCancelCB = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBookType = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblSelectedBank = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblMsname = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.tsbSelectBank = New System.Windows.Forms.ToolStripButton()
        Me.tsbDownload = New System.Windows.Forms.ToolStripButton()
        Me.tsbAddressDownload = New System.Windows.Forms.ToolStripButton()
        Me.tsbManualEntry = New System.Windows.Forms.ToolStripButton()
        Me.tsbPrintBatch = New System.Windows.Forms.ToolStripButton()
        Me.tsbReports = New System.Windows.Forms.ToolStripButton()
        Me.tsbPackList = New System.Windows.Forms.ToolStripButton()
        Me.tsbPackListA4 = New System.Windows.Forms.ToolStripButton()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Comic Sans MS", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuProcess, Me.mnuReportsToolStripMenuItem, Me.UtilitiesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(723, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMaster, Me.ToolStripSeparator1, Me.ToolStripMenuItem1, Me.ToolStripSeparator2, Me.ExitToolStripMenuItem})
        Me.mnuFile.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(52, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuMaster
        '
        Me.mnuMaster.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAccountsToolStripMenuItem, Me.mnuBranches, Me.mnuBanks})
        Me.mnuMaster.Name = "mnuMaster"
        Me.mnuMaster.Size = New System.Drawing.Size(140, 22)
        Me.mnuMaster.Text = "Masters"
        '
        'mnuAccountsToolStripMenuItem
        '
        Me.mnuAccountsToolStripMenuItem.Name = "mnuAccountsToolStripMenuItem"
        Me.mnuAccountsToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.mnuAccountsToolStripMenuItem.Text = "Accounts"
        Me.mnuAccountsToolStripMenuItem.Visible = False
        '
        'mnuBranches
        '
        Me.mnuBranches.Name = "mnuBranches"
        Me.mnuBranches.Size = New System.Drawing.Size(140, 22)
        Me.mnuBranches.Text = "Branches"
        '
        'mnuBanks
        '
        Me.mnuBanks.Name = "mnuBanks"
        Me.mnuBanks.Size = New System.Drawing.Size(140, 22)
        Me.mnuBanks.Text = "Banks"
        Me.mnuBanks.Visible = False
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(137, 6)
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuChangePasswordToolStripMenuItem, Me.mnuNewUserToolStripMenuItem, Me.mnuModifyAccessRightsToolStripMenuItem, Me.mnuDeleteUserToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(140, 22)
        Me.ToolStripMenuItem1.Text = "Security"
        Me.ToolStripMenuItem1.Visible = False
        '
        'mnuChangePasswordToolStripMenuItem
        '
        Me.mnuChangePasswordToolStripMenuItem.Name = "mnuChangePasswordToolStripMenuItem"
        Me.mnuChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.mnuChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'mnuNewUserToolStripMenuItem
        '
        Me.mnuNewUserToolStripMenuItem.Name = "mnuNewUserToolStripMenuItem"
        Me.mnuNewUserToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.mnuNewUserToolStripMenuItem.Text = "New User"
        '
        'mnuModifyAccessRightsToolStripMenuItem
        '
        Me.mnuModifyAccessRightsToolStripMenuItem.Name = "mnuModifyAccessRightsToolStripMenuItem"
        Me.mnuModifyAccessRightsToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.mnuModifyAccessRightsToolStripMenuItem.Text = "Modify Access Rights"
        '
        'mnuDeleteUserToolStripMenuItem
        '
        Me.mnuDeleteUserToolStripMenuItem.Name = "mnuDeleteUserToolStripMenuItem"
        Me.mnuDeleteUserToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.mnuDeleteUserToolStripMenuItem.Text = "Delete User"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(137, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'mnuProcess
        '
        Me.mnuProcess.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDownloadRequestFile, Me.mnudownlaodSpecial, Me.mnuManualEntry, Me.ToolStripMenuItem4, Me.mnuMakePrintBatch, Me.EndOfTheDayToolStripMenuItem})
        Me.mnuProcess.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuProcess.Name = "mnuProcess"
        Me.mnuProcess.Size = New System.Drawing.Size(76, 20)
        Me.mnuProcess.Text = "Process"
        '
        'mnuDownloadRequestFile
        '
        Me.mnuDownloadRequestFile.Name = "mnuDownloadRequestFile"
        Me.mnuDownloadRequestFile.Size = New System.Drawing.Size(244, 22)
        Me.mnuDownloadRequestFile.Text = "Download Request File"
        '
        'mnudownlaodSpecial
        '
        Me.mnudownlaodSpecial.Name = "mnudownlaodSpecial"
        Me.mnudownlaodSpecial.Size = New System.Drawing.Size(244, 22)
        Me.mnudownlaodSpecial.Text = "Download Address File"
        Me.mnudownlaodSpecial.Visible = False
        '
        'mnuManualEntry
        '
        Me.mnuManualEntry.Name = "mnuManualEntry"
        Me.mnuManualEntry.Size = New System.Drawing.Size(244, 22)
        Me.mnuManualEntry.Text = "Manual Entry"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(241, 6)
        '
        'mnuMakePrintBatch
        '
        Me.mnuMakePrintBatch.Name = "mnuMakePrintBatch"
        Me.mnuMakePrintBatch.Size = New System.Drawing.Size(244, 22)
        Me.mnuMakePrintBatch.Text = "Generate Print Batch"
        '
        'EndOfTheDayToolStripMenuItem
        '
        Me.EndOfTheDayToolStripMenuItem.Name = "EndOfTheDayToolStripMenuItem"
        Me.EndOfTheDayToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.EndOfTheDayToolStripMenuItem.Text = "End of the Day"
        '
        'mnuReportsToolStripMenuItem
        '
        Me.mnuReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDeiveryReport, Me.ToolStripMenuItem2, Me.AccountQueryToolStripMenuItem, Me.ChequeNosQueryToolStripMenuItem, Me.ToolStripMenuItem3, Me.mnuReprintRep, Me.CancelReportToolStripMenuItem})
        Me.mnuReportsToolStripMenuItem.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuReportsToolStripMenuItem.Name = "mnuReportsToolStripMenuItem"
        Me.mnuReportsToolStripMenuItem.Size = New System.Drawing.Size(76, 20)
        Me.mnuReportsToolStripMenuItem.Text = "Reports"
        '
        'mnuDeiveryReport
        '
        Me.mnuDeiveryReport.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LabelReportToolStripMenuItem})
        Me.mnuDeiveryReport.Name = "mnuDeiveryReport"
        Me.mnuDeiveryReport.Size = New System.Drawing.Size(212, 22)
        Me.mnuDeiveryReport.Text = "Reports"
        '
        'LabelReportToolStripMenuItem
        '
        Me.LabelReportToolStripMenuItem.Name = "LabelReportToolStripMenuItem"
        Me.LabelReportToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.LabelReportToolStripMenuItem.Text = "Label Report"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(209, 6)
        '
        'AccountQueryToolStripMenuItem
        '
        Me.AccountQueryToolStripMenuItem.Name = "AccountQueryToolStripMenuItem"
        Me.AccountQueryToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AccountQueryToolStripMenuItem.Text = "Account Query"
        Me.AccountQueryToolStripMenuItem.Visible = False
        '
        'ChequeNosQueryToolStripMenuItem
        '
        Me.ChequeNosQueryToolStripMenuItem.Name = "ChequeNosQueryToolStripMenuItem"
        Me.ChequeNosQueryToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.ChequeNosQueryToolStripMenuItem.Text = "Cheque nos. Query"
        Me.ChequeNosQueryToolStripMenuItem.Visible = False
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(209, 6)
        '
        'mnuReprintRep
        '
        Me.mnuReprintRep.Name = "mnuReprintRep"
        Me.mnuReprintRep.Size = New System.Drawing.Size(212, 22)
        Me.mnuReprintRep.Text = "Reprint Report"
        '
        'CancelReportToolStripMenuItem
        '
        Me.CancelReportToolStripMenuItem.Name = "CancelReportToolStripMenuItem"
        Me.CancelReportToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.CancelReportToolStripMenuItem.Text = "Cancel Report"
        '
        'UtilitiesToolStripMenuItem
        '
        Me.UtilitiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuReprint, Me.mnuCancelCB, Me.mnuBookType, Me.mnuSettingsToolStripMenuItem})
        Me.UtilitiesToolStripMenuItem.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UtilitiesToolStripMenuItem.Name = "UtilitiesToolStripMenuItem"
        Me.UtilitiesToolStripMenuItem.Size = New System.Drawing.Size(92, 20)
        Me.UtilitiesToolStripMenuItem.Text = "Utilities"
        '
        'mnuReprint
        '
        Me.mnuReprint.Name = "mnuReprint"
        Me.mnuReprint.Size = New System.Drawing.Size(316, 22)
        Me.mnuReprint.Text = "Reprint"
        '
        'mnuCancelCB
        '
        Me.mnuCancelCB.Name = "mnuCancelCB"
        Me.mnuCancelCB.Size = New System.Drawing.Size(316, 22)
        Me.mnuCancelCB.Text = "Cancel Cheque Book"
        '
        'mnuBookType
        '
        Me.mnuBookType.Name = "mnuBookType"
        Me.mnuBookType.Size = New System.Drawing.Size(316, 22)
        Me.mnuBookType.Text = "Book types / Transaction Codes"
        '
        'mnuSettingsToolStripMenuItem
        '
        Me.mnuSettingsToolStripMenuItem.Name = "mnuSettingsToolStripMenuItem"
        Me.mnuSettingsToolStripMenuItem.Size = New System.Drawing.Size(316, 22)
        Me.mnuSettingsToolStripMenuItem.Text = "Settings"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Transparent
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblSelectedBank, Me.lblMsname})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 409)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 15, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(723, 48)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblSelectedBank
        '
        Me.lblSelectedBank.Font = New System.Drawing.Font("Algerian", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectedBank.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblSelectedBank.Image = Global.CBPM2011.My.Resources.Resources.bank
        Me.lblSelectedBank.Name = "lblSelectedBank"
        Me.lblSelectedBank.Size = New System.Drawing.Size(292, 43)
        Me.lblSelectedBank.Text = "No Bank Selected"
        '
        'lblMsname
        '
        Me.lblMsname.AutoSize = False
        Me.lblMsname.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMsname.ForeColor = System.Drawing.Color.DimGray
        Me.lblMsname.Name = "lblMsname"
        Me.lblMsname.Size = New System.Drawing.Size(415, 43)
        Me.lblMsname.Spring = True
        Me.lblMsname.Text = "Developed by : Muhammad Siddique"
        Me.lblMsname.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblMsname.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
        '
        'ToolStrip1
        '
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbSelectBank, Me.tsbDownload, Me.tsbAddressDownload, Me.tsbManualEntry, Me.tsbPrintBatch, Me.tsbReports, Me.tsbPackList, Me.tsbPackListA4})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(723, 54)
        Me.ToolStrip1.TabIndex = 4
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'tsbSelectBank
        '
        Me.tsbSelectBank.Image = Global.CBPM2011.My.Resources.Resources.bank
        Me.tsbSelectBank.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSelectBank.Name = "tsbSelectBank"
        Me.tsbSelectBank.Size = New System.Drawing.Size(97, 51)
        Me.tsbSelectBank.Text = "Processing Bank"
        Me.tsbSelectBank.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsbSelectBank.Visible = False
        '
        'tsbDownload
        '
        Me.tsbDownload.Image = Global.CBPM2011.My.Resources.Resources.download
        Me.tsbDownload.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbDownload.Name = "tsbDownload"
        Me.tsbDownload.Size = New System.Drawing.Size(65, 51)
        Me.tsbDownload.Text = "Download"
        Me.tsbDownload.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbAddressDownload
        '
        Me.tsbAddressDownload.Image = Global.CBPM2011.My.Resources.Resources.msenv_dll_6807_3
        Me.tsbAddressDownload.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbAddressDownload.Name = "tsbAddressDownload"
        Me.tsbAddressDownload.Size = New System.Drawing.Size(110, 51)
        Me.tsbAddressDownload.Text = "Address Download"
        Me.tsbAddressDownload.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsbAddressDownload.Visible = False
        '
        'tsbManualEntry
        '
        Me.tsbManualEntry.Image = Global.CBPM2011.My.Resources.Resources.ManualEntry
        Me.tsbManualEntry.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbManualEntry.Name = "tsbManualEntry"
        Me.tsbManualEntry.Size = New System.Drawing.Size(81, 51)
        Me.tsbManualEntry.Text = "Manual Entry"
        Me.tsbManualEntry.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsbManualEntry.Visible = False
        '
        'tsbPrintBatch
        '
        Me.tsbPrintBatch.Image = Global.CBPM2011.My.Resources.Resources.makebatch
        Me.tsbPrintBatch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPrintBatch.Name = "tsbPrintBatch"
        Me.tsbPrintBatch.Size = New System.Drawing.Size(69, 51)
        Me.tsbPrintBatch.Text = "Print Batch"
        Me.tsbPrintBatch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbReports
        '
        Me.tsbReports.Image = Global.CBPM2011.My.Resources.Resources.reports4
        Me.tsbReports.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbReports.Name = "tsbReports"
        Me.tsbReports.Size = New System.Drawing.Size(51, 51)
        Me.tsbReports.Text = "Reports"
        Me.tsbReports.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbPackList
        '
        Me.tsbPackList.Image = Global.CBPM2011.My.Resources.Resources.packlist
        Me.tsbPackList.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPackList.Name = "tsbPackList"
        Me.tsbPackList.Size = New System.Drawing.Size(74, 51)
        Me.tsbPackList.Text = "Pack List A3"
        Me.tsbPackList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbPackListA4
        '
        Me.tsbPackListA4.Image = Global.CBPM2011.My.Resources.Resources.packlist
        Me.tsbPackListA4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPackListA4.Name = "tsbPackListA4"
        Me.tsbPackListA4.Size = New System.Drawing.Size(74, 51)
        Me.tsbPackListA4.Text = "Pack List A4"
        Me.tsbPackListA4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'mdiCBPM
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSlateGray
        Me.BackgroundImage = Global.CBPM2011.My.Resources.Resources.msForMDI_CBPM
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(723, 457)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "mdiCBPM"
        Me.Text = "Cheque Books Print Managment"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuProcess As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDownloadRequestFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManualEntry As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDeiveryReport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AccountQueryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChequeNosQueryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuReprintRep As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CancelReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UtilitiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMakePrintBatch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuReprint As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAccountsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBranches As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBanks As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBookType As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents lblSelectedBank As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbSelectBank As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbDownload As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbManualEntry As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbPrintBatch As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbReports As System.Windows.Forms.ToolStripButton
    Friend WithEvents lblMsname As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNewUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifyAccessRightsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDeleteUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuCancelCB As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnudownlaodSpecial As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EndOfTheDayToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsbAddressDownload As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbPackList As ToolStripButton
    Friend WithEvents LabelReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents tsbPackListA4 As ToolStripButton
End Class
